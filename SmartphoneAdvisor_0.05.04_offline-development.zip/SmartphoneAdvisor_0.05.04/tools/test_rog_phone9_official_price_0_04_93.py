#!/usr/bin/env python3
"""Regression guard for ASUS Japan official ROG Phone 9 price provenance."""
import json
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
data = json.loads((ROOT / "app/src/main/assets/phones.json").read_text(encoding="utf-8"))
phone = next(p for p in data["phones"] if p["model"] == "ROG Phone 9")
variant = next(v for v in phone["variants"] if v["storageGb"] == 256 and v.get("ramGb") == 12)
sale = next(s for s in variant["sales"] if s["retailer"] == "ASUS Store Japan")
assert sale["availability"] == "AVAILABLE"
assert sale["url"] == "https://rog.asus.com/jp/phones/rog-phone-9/"
assert len(sale["priceOptions"]) == 1
price = sale["priceOptions"][0]
assert (price["priceYen"], price["priceType"]) == (159800, "NORMAL")
assert price["sourceUrl"] == sale["url"]
assert price["checkedAt"] == "2026-10-21"
assert "税込" in price["conditions"] and "キャンペーン" in price["conditions"]
assert "https://rog.asus.com/jp/phones/rog-phone-9/" in data["authoritativeSalesSources"]
actual = {"phoneModels": len(data["phones"]), "variants": sum(len(p.get("variants", [])) for p in data["phones"]), "salesListings": sum(len(v.get("sales", [])) for p in data["phones"] for v in p.get("variants", [])), "priceOptions": sum(len(s.get("priceOptions", [])) for p in data["phones"] for v in p.get("variants", []) for s in v.get("sales", [])), "auditFindings": len(data.get("auditFindings", []))}
assert data["counts"] == actual
assert actual["priceOptions"] == 100
print("PASS: ROG Phone 9 ASUS official price provenance and catalog counts")
