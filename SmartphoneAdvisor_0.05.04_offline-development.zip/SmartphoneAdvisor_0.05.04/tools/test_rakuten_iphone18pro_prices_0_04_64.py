#!/usr/bin/env python3
"""Regression test for Rakuten official iPhone 18 Pro / Pro Max capacity prices."""
import json
from pathlib import Path
from current_version import current_version_is_valid
ROOT=Path(__file__).resolve().parents[1]
def main():
    errors=[]
    build=(ROOT/'app/build.gradle.kts').read_text(encoding='utf-8')
    data=json.loads((ROOT/'app/src/main/assets/phones.json').read_text(encoding='utf-8'))
    if not current_version_is_valid(build): errors.append('version mismatch')
    expected={('iPhone 18 Pro',256):255900,('iPhone 18 Pro',512):307600,('iPhone 18 Pro',1024):391200,('iPhone 18 Pro',2048):505600,('iPhone 18 Pro Max',256):288900,('iPhone 18 Pro Max',512):330700,('iPhone 18 Pro Max',1024):415400,('iPhone 18 Pro Max',2048):529800}
    source='https://network.mobile.rakuten.co.jp/product/iphone/fee/'
    actual={}
    for p in data.get('phones',[]):
        if p.get('model') not in ('iPhone 18 Pro','iPhone 18 Pro Max'): continue
        for v in p.get('variants',[]):
            for s in v.get('sales',[]):
                if s.get('channel')!='RAKUTEN': continue
                for o in s.get('priceOptions',[]):
                    if o.get('sourceUrl')==source: actual[(p['model'],v.get('storageGb'))]=o
    if set(actual)!=set(expected): errors.append(f'Rakuten capacity mismatch: expected {sorted(expected)}, got {sorted(actual)}')
    for key,price in expected.items():
        o=actual.get(key,{})
        if o.get('priceYen')!=price: errors.append(f'{key}: expected {price}, got {o.get("priceYen")}')
        if o.get('priceType')!='NORMAL' or o.get('checkedAt')!='2026-10-16': errors.append(f'{key}: price type/date mismatch')
        if '返却前提' not in (o.get('conditions') or '') or '割引' not in (o.get('conditions') or ''): errors.append(f'{key}: conditions caveat missing')
    all_options=[o for p in data['phones'] for v in p.get('variants',[]) for s in v.get('sales',[]) for o in s.get('priceOptions',[])]
    if len(all_options)!=100: errors.append(f'expected 100 total price options, got {len(all_options)}')
    print(f'0.04.64 Rakuten iPhone price regression: expected={len(expected)} options={len(all_options)} errors={len(errors)}')
    for e in errors: print('FAIL:',e)
    if errors:return 1
    print('PASS: all 8 Rakuten capacity prices and provenance/caveats match.')
    return 0
if __name__=='__main__': raise SystemExit(main())
