#!/usr/bin/env python3
"""Regression guard for Zenfone 12 Ultra 16GB/512GB official-store price."""
import json
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
data = json.loads((ROOT / "app/src/main/assets/phones.json").read_text(encoding="utf-8"))
phone = next(p for p in data["phones"] if p["model"] == "Zenfone 12 Ultra")
variant = next(v for v in phone["variants"] if v["storageGb"] == 512 and v.get("ramGb") == 16)
sale = next(s for s in variant["sales"] if s["channel"] == "SIM_FREE" and s["retailer"] == "ASUS Store Japan")
assert sale["availability"] == "AVAILABLE"
assert sale["url"] == "https://www.asus.com/jp/mobile-handhelds/phones/zenfone/zenfone-12-ultra/"
assert len(sale["priceOptions"]) == 1
price = sale["priceOptions"][0]
assert (price["priceYen"], price["priceType"], price["color"]) == (169800, "NORMAL", "全色共通")
assert price["sourceUrl"] == "https://www.rakuten.ne.jp/gold/asus-store/sale/2510CP2/"
assert price["checkedAt"] == "2026-10-21"
assert "152,820円" in price["conditions"] and "通常価格" in price["conditions"]
actual = {"phoneModels": len(data["phones"]), "variants": sum(len(p.get("variants", [])) for p in data["phones"]), "salesListings": sum(len(v.get("sales", [])) for p in data["phones"] for v in p.get("variants", [])), "priceOptions": sum(len(s.get("priceOptions", [])) for p in data["phones"] for v in p.get("variants", []) for s in v.get("sales", [])), "auditFindings": len(data.get("auditFindings", []))}
assert data["counts"] == actual
assert actual == {"phoneModels": 195, "variants": 315, "salesListings": 511, "priceOptions": 100, "auditFindings": actual["auditFindings"]}
print("PASS: Zenfone 12 Ultra 16GB/512GB official-store normal price provenance and catalog counts")
