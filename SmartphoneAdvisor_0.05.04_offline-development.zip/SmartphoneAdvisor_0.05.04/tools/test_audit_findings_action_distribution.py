"""Guard the mixed legacy/current auditFindings contract and its snapshot counts."""
import collections
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CATALOG = ROOT / "app/src/main/assets/phones.json"
data = json.loads(CATALOG.read_text(encoding="utf-8"))
findings = data.get("auditFindings", [])
assert data["counts"]["auditFindings"] == len(findings), "count must describe all audit records"
assert len(findings) == 45, f"unexpected audit record total: {len(findings)}"
actions = collections.Counter(item.get("action") for item in findings)
expected = {
    None: 27,
    "ADDED": 1,
    "NOT_ADDED": 1,
    "RESOLVED_SEED_LINKAGE": 8,
    "UNRESOLVED_SEED_LINKAGE": 8,
}
assert dict(actions) == expected, f"audit action distribution changed: {dict(actions)}"
# Legacy entries without action are valid records; do not drop them or interpret
# the entire auditFindings array as unresolved-only.
assert sum("action" not in item for item in findings) == 27
assert sum(item.get("action") == "RESOLVED_SEED_LINKAGE" for item in findings) == 8
assert sum(item.get("action") == "UNRESOLVED_SEED_LINKAGE" for item in findings) == 8
print("PASS: auditFindings keeps all 45 mixed-format records; action distribution is explicit")
