#!/usr/bin/env python3
"""Generate a traceable row-level inventory of all catalog sales URLs for 0.04.52."""
import csv, json
from collections import defaultdict
from pathlib import Path
from urllib.parse import urlparse
ROOT = Path(__file__).resolve().parents[1]
CATALOG = ROOT / "app/src/main/assets/phones.json"
BUILD = ROOT / "app/build.gradle.kts"
OUT = ROOT / "SALES_URL_INVENTORY_0.04.57.csv"

def main():
    data = json.loads(CATALOG.read_text(encoding="utf-8"))
    build = BUILD.read_text(encoding="utf-8")
    if not (( 'versionName = \"0.04.52\"' in build and 'versionCode = 101' in build) or ('versionName = \"0.04.53\"' in build and 'versionCode = 102' in build) or ('versionName = \"0.04.54\"' in build and 'versionCode = 103' in build) or ('versionName = \"0.04.55\"' in build and 'versionCode = 104' in build) or ('versionName = \"0.04.57\"' in build and 'versionCode = 106' in build)):
        raise SystemExit("FAIL: app version is neither historical 0.04.52/0.04.53/0.04.54/0.04.55 nor current 0.04.57")
    rows=[]
    identities_by_url=defaultdict(set)
    sales=[]
    for phone in data.get("phones", []):
        identity=(phone.get("manufacturer"), phone.get("model"), phone.get("platform"), phone.get("releaseYear"))
        for variant in phone.get("variants", []):
            for sale in variant.get("sales", []):
                url=(sale.get("url") or "").strip()
                sales.append((phone,variant,sale,identity,url))
                if url: identities_by_url[url].add(identity)
    for phone,variant,sale,identity,url in sales:
        parsed=urlparse(url) if url else None
        scope="NO_URL" if not url else ("SHARED_MODEL_URL" if len(identities_by_url[url]) > 1 else "UNIQUE_MODEL_URL")
        rows.append({
            "model_id": phone.get("id", ""), "manufacturer": phone.get("manufacturer", ""),
            "model": phone.get("model", ""), "platform": phone.get("platform", ""),
            "release_year": phone.get("releaseYear", ""), "storage_gb": variant.get("storageGb", ""),
            "ram_gb": variant.get("ramGb", ""), "channel": sale.get("channel", ""),
            "retailer": sale.get("retailer", ""), "availability": sale.get("availability", ""),
            "url_scope": scope, "url": url, "url_host": (parsed.hostname or "") if parsed else "",
            "url_path": (parsed.path or "") if parsed else ""
        })
    fields=list(rows[0]) if rows else []
    with OUT.open("w", encoding="utf-8-sig", newline="") as f:
        writer=csv.DictWriter(f,fieldnames=fields); writer.writeheader(); writer.writerows(rows)
    unique_urls=len(identities_by_url)
    shared_urls=sum(1 for ids in identities_by_url.values() if len(ids)>1)
    print("SmartphoneAdvisor 0.04.57 sales URL inventory")
    print(f"Models: {len(data.get('phones', []))}")
    print(f"Sales rows: {len(sales)}")
    print(f"Rows with URL: {sum(bool(r[4]) for r in sales)}")
    print(f"Unique URLs: {unique_urls}")
    print(f"URLs shared across model identities: {shared_urls}")
    print(f"Rows without URL: {sum(not bool(r[4]) for r in sales)}")
    print(f"Output: {OUT.name}")
    return 0
if __name__ == "__main__": raise SystemExit(main())
