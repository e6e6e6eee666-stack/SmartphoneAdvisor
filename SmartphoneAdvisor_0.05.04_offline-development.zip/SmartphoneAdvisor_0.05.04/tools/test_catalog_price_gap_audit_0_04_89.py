#!/usr/bin/env python3
"""Regression guard for the reproducible price-gap audit and its data provenance."""
import csv
import hashlib
import json
import subprocess
import sys
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CATALOG = ROOT / "app/src/main/assets/phones.json"
REPORT = ROOT / "CATALOG_PRICE_GAP_AUDIT_2026-10-20.csv"
SUMMARY = ROOT / "CATALOG_PRICE_GAP_AUDIT_2026-10-20.md"
raw = CATALOG.read_bytes()
data = json.loads(raw.decode("utf-8"))
subprocess.run([sys.executable, str(ROOT / "tools/audit_catalog_price_gaps_0_04_91.py")], cwd=ROOT, check=True, capture_output=True, text=True)
with REPORT.open(encoding="utf-8-sig", newline="") as f:
    rows = list(csv.DictReader(f))
actual_missing = []
for phone in data["phones"]:
    for variant in phone["variants"]:
        for sale in variant.get("sales", []):
            if not sale.get("priceOptions"):
                actual_missing.append((phone["id"], variant["storageGb"], sale["channel"], sale["retailer"], sale["availability"]))
reported = [(r["phoneId"], int(r["storageGb"]), r["channel"], r["retailer"], r["availability"]) for r in rows]
assert Counter(actual_missing) == Counter(reported), "CSV must enumerate every and only sales rows without price options"
assert len(rows) == 429, f"Expected current baseline of 429 price gaps, got {len(rows)}"
assert sum(r["availability"] == "AVAILABLE" for r in rows) == 385, "Available-but-unpriced count changed; review report expectations"
assert hashlib.sha256(raw).hexdigest() in SUMMARY.read_text(encoding="utf-8"), "Summary must pin the audited JSON SHA-256"
assert all(r["priceOptionCount"] == "0" for r in rows), "Gap report must not claim inferred prices"
print(f"PASS: price-gap audit report reconciliation ({len(rows)} rows; 385 AVAILABLE without price; source SHA-256 pinned)")
