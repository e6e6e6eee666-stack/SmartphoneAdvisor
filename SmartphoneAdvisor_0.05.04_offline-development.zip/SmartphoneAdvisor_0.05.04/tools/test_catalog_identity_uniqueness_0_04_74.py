#!/usr/bin/env python3
"""Detect likely duplicate model identities without erasing meaningful punctuation."""
import json, re, unicodedata
from collections import defaultdict
from pathlib import Path
from current_version import current_version_is_valid
ROOT = Path(__file__).resolve().parents[1]
DATA = json.loads((ROOT / 'app/src/main/assets/phones.json').read_text())
BUILD = (ROOT / 'app/build.gradle.kts').read_text()
errors = []
if not current_version_is_valid(BUILD):
    errors.append('current app version metadata is invalid')
def norm(value):
    return re.sub(r'\s+', ' ', unicodedata.normalize('NFKC', str(value or '')).casefold().strip())
groups = defaultdict(list)
for phone in DATA.get('phones', []):
    manufacturer = norm(phone.get('manufacturer'))
    model = norm(phone.get('model'))
    if manufacturer and model.startswith(manufacturer + ' '): model = model[len(manufacturer):].strip()
    key = (manufacturer, model, phone.get('releaseYear'), norm(phone.get('platform')))
    groups[key].append(phone.get('id'))
for key, ids in groups.items():
    if len(ids) > 1: errors.append(f'duplicate canonical model identity {key}: {ids}')
if errors:
    print('FAIL'); print('\n'.join(errors)); raise SystemExit(1)
print(f"PASS: {len(DATA.get('phones', []))} model records have unique canonical identities; punctuation preserved")
