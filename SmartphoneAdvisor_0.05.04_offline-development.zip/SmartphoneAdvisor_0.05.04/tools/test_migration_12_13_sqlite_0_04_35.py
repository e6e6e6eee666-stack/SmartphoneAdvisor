#!/usr/bin/env python3
"""Execute the actual SQL statements in AppDatabase MIGRATION_12_13 against a SQLite fixture.

This is a focused migration smoke test, not a substitute for Android Room MigrationTestHelper.
"""
from pathlib import Path
import re
import sqlite3

ROOT = Path(__file__).resolve().parents[1]
source = (ROOT / "app/src/main/java/jp/smartphoneadvisor/app/data/AppDatabase.kt").read_text(encoding="utf-8")
match = re.search(r"private val MIGRATION_12_13\s*=\s*object\s*:\s*Migration\(12,\s*13\)\s*\{(?P<body>.*?)\n\s*}\n", source, re.S)
if not match:
    raise SystemExit("FAIL | Could not locate MIGRATION_12_13 source block")
body = match.group("body")
statements = re.findall(r'db\.execSQL\("((?:\\.|[^"\\])*)"\)', body)
if len(statements) != 7:
    raise SystemExit(f"FAIL | Expected 7 SQL statements from migration, found {len(statements)}")

# The minimum pre-v12 columns actually read by this migration.
db = sqlite3.connect(":memory:")
db.execute("CREATE TABLE smartphone_model (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, manufacturerId INTEGER NOT NULL, seriesName TEXT)")
seed = [
    (101, 1, "Galaxy S"),
    (102, 1, "Galaxy S"),
    (103, 2, "Galaxy S"),
    (104, 1, None),
    (105, 1, "   "),
]
db.executemany("INSERT INTO smartphone_model(id, manufacturerId, seriesName) VALUES (?, ?, ?)", seed)
original = db.execute("SELECT id, manufacturerId, seriesName FROM smartphone_model ORDER BY id").fetchall()
for raw in statements:
    sql = bytes(raw, "utf-8").decode("unicode_escape")
    db.execute(sql)

checks = []
def check(label, condition):
    checks.append((label, bool(condition)))
    print(f"{'PASS' if condition else 'FAIL'} | {label}")

current = db.execute("SELECT id, manufacturerId, seriesName FROM smartphone_model ORDER BY id").fetchall()
check("all pre-existing smartphone_model rows and values preserved", current == original)
check("seriesId column added", "seriesId" in [r[1] for r in db.execute("PRAGMA table_info(smartphone_model)")])
series_rows = db.execute("SELECT manufacturerId, name FROM phone_series ORDER BY manufacturerId, name").fetchall()
check("series are unique by manufacturer and name", series_rows == [(1, "Galaxy S"), (2, "Galaxy S")])
assigned = dict(db.execute("SELECT id, seriesId FROM smartphone_model").fetchall())
check("matching manufacturer-specific series IDs assigned", assigned[101] == assigned[102] and assigned[101] != assigned[103])
check("null and blank series names remain unassigned", assigned[104] is None and assigned[105] is None)
check("data_change_log table created", db.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='data_change_log'").fetchone() is not None)
check("data_change_log index created", db.execute("SELECT name FROM sqlite_master WHERE type='index' AND name='index_data_change_log_deviceVariantId_changedAt'").fetchone() is not None)
check("foreign_key_check returns no violations", db.execute("PRAGMA foreign_key_check").fetchall() == [])
print(f"RESULT: {sum(ok for _, ok in checks)}/{len(checks)} passed")
if not all(ok for _, ok in checks):
    raise SystemExit(1)
