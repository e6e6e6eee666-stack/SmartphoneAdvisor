from pathlib import Path
root = Path(__file__).resolve().parents[1]
main = (root / 'app/src/main/java/jp/smartphoneadvisor/app/MainActivity.kt').read_text()
auditor = (root / 'app/src/main/java/jp/smartphoneadvisor/app/data/catalog/RetailerMasterAudit.kt').read_text()
tests = (root / 'app/src/test/java/jp/smartphoneadvisor/app/data/catalog/RetailerMasterAuditTest.kt').read_text()
gradle = (root / 'app/build.gradle.kts').read_text()
checks = {
    'normalized names use trim and Locale.ROOT lowercase': '.trim().lowercase(java.util.Locale.ROOT)' in auditor,
    'normalized name spelling variants are reported': 'normalizedNameVariants' in auditor and 'filterValues { it.size > 1 }' in auditor,
    'multiple website URLs are reported': 'mixedWebsiteUrls' in auditor and 'mapNotNull' in auditor,
    'website URL comparison ignores blank values': 'it.websiteUrl?.trim()?.takeIf { it.isNotEmpty() }' in auditor,
    'audit remains read-only': not any(token in auditor for token in ('insertRetailer', 'updateRetailer', 'deleteRetailer')),
    'startup logs normalized name conflicts': 'report.normalizedNameVariants.entries' in main,
    'startup logs website URL conflicts': 'report.mixedWebsiteUrls.entries' in main,
    'test covers case and whitespace variants': 'normalizedNameAndWebsiteConflictsAreReportedWithoutChangingRows' in tests,
    'test covers multiple URLs for normalized name': 'https://two.example' in tests,
    'version metadata updated': 'versionCode = 77' in gradle and 'versionName = "0.04.28"' in gradle,
}
for name, ok in checks.items():
    print(f'{"PASS" if ok else "FAIL"}: {name}')
if not all(checks.values()):
    raise SystemExit(1)
print(f'PASS: {sum(checks.values())}/{len(checks)} checks')
