#!/usr/bin/env python3
"""Regression guard for the price-gap follow-up prioritization report."""
import csv
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CATALOG = ROOT / "app/src/main/assets/phones.json"
REPORT = ROOT / "CATALOG_PRICE_GAP_FOLLOWUP_2026-10-21.csv"
SUMMARY = ROOT / "CATALOG_PRICE_GAP_FOLLOWUP_2026-10-21.md"
data = json.loads(CATALOG.read_text(encoding="utf-8"))
subprocess.run([sys.executable, str(ROOT / "tools/audit_price_gap_followup_0_04_96.py")], cwd=ROOT, check=True, capture_output=True, text=True)
with REPORT.open(encoding="utf-8-sig", newline="") as f:
    rows = list(csv.DictReader(f))
expected = [(p["id"], str(v["storageGb"]), s.get("channel", ""), s.get("retailer", ""), s.get("availability", "UNKNOWN")) for p in data["phones"] for v in p["variants"] for s in v.get("sales", []) if not s.get("priceOptions")]
actual = [(r["phoneId"], r["storageGb"], r["channel"], r["retailer"], r["availability"]) for r in rows]
assert sorted(expected) == sorted(actual), "follow-up report must enumerate every and only unpriced sales row"
assert len(rows) == 429, "0.05.03 price options added five entries; current gap count must be 429"
assert sum(not r["modelNumber"] for r in rows) == 354
assert sum(r["availability"] == "AVAILABLE" and not r["modelNumber"] for r in rows) == 315
assert sum(r["urlSpecificity"] == "CATEGORY_OR_TOP_PAGE" for r in rows) == 7
assert sum(r["availability"] == "AVAILABLE" and r["urlSpecificity"] == "CATEGORY_OR_TOP_PAGE" for r in rows) == 7
verified_detail_url = False
for phone in data["phones"]:
    if phone["id"] != "FCNT:arrows Alpha2:2026":
        continue
    for variant in phone.get("variants", []):
        if variant.get("storageGb") != 256 or variant.get("ramGb") != 8:
            continue
        for sale in variant.get("sales", []):
            if sale.get("channel") == "IIJ_MIO" and sale.get("url") == "https://www.iijmio.jp/device/detail.html?deviceSpecified=1&key=arrows_Alpha2_256GB" and not sale.get("priceOptions"):
                verified_detail_url = True
assert verified_detail_url, "arrows Alpha2 IIJmio 256GB registration must retain verified product-specific URL"
assert all(r["priceOptionCount"] == "0" for r in rows), "report must not invent prices"
assert "354" in SUMMARY.read_text(encoding="utf-8") and "315" in SUMMARY.read_text(encoding="utf-8")
print("PASS: follow-up audit reconciliation for 0.05.03 (429 gaps; 354 missing model numbers; 7 generic URLs; no inferred prices)")
