#!/usr/bin/env python3
"""Audit nested phones.json sales.priceOptions rather than only listing-level keys."""
import collections, json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
CATALOG=ROOT/'app/src/main/assets/phones.json'; BUILD=ROOT/'app/build.gradle.kts'
OUT=ROOT/'SALES_FACT_COMPLETENESS_AUDIT_0.04.58.md'
def main():
    data=json.loads(CATALOG.read_text(encoding='utf-8')); build=BUILD.read_text(encoding='utf-8')
    if 'versionName = "0.04.58"' not in build or 'versionCode = 107' not in build: raise SystemExit('FAIL: version mismatch; expected 0.04.58 / versionCode 107')
    phones=data.get('phones',[]); variants=[(p,v) for p in phones for v in p.get('variants',[])]; rows=[(p,v,s) for p,v in variants for s in v.get('sales',[])]; opts=[(p,v,s,o) for p,v,s in rows for o in s.get('priceOptions',[])]
    status=collections.Counter(s.get('availability','<MISSING>') for _,_,s in rows)
    valid=[x for x in opts if isinstance(x[3].get('priceYen'),int) and x[3]['priceYen']>0]
    source=[x for x in opts if x[3].get('sourceUrl')]; checked=[x for x in opts if x[3].get('checkedAt')]; both=[x for x in opts if x[3].get('sourceUrl') and x[3].get('checkedAt')]
    no_opts=[f"{p.get('model')} / {v.get('storageGb')}GB / RAM {v.get('ramGb')}GB / {s.get('channel')}" for p,v,s in rows if not s.get('priceOptions')]
    bad=[f"{p.get('model')} / {v.get('storageGb')}GB / {s.get('channel')} / option {i}" for p,v,s,o in opts for i in [0] if not isinstance(o.get('priceYen'),int) or o['priceYen']<=0]
    lines=['# 販売情報の根拠・鮮度監査（0.04.58・訂正版）','', '## 0.04.54監査の訂正','', '前版は販売登録直下のフィールドだけを確認し、ネストされた `sales[].priceOptions[]` を数えていませんでした。そのため「価格情報0件」という前版の記述は不正確です。この版では実際のJSON構造をたどって再集計しました。','', '## 集計','',f'- 機種：{len(phones)}件',f'- バリエーション：{len(variants)}件',f'- 販売登録：{len(rows)}件',f'- priceOptions登録が1件以上ある販売登録：{sum(bool(s.get("priceOptions")) for _,_,s in rows)}件 / {len(rows)}件',f'- 価格オプション総数：{len(opts)}件',f'- 正の整数価格を持つオプション：{len(valid)}件 / {len(opts)}件',f'- sourceUrl登録あり：{len(source)}件 / {len(opts)}件',f'- checkedAt登録あり：{len(checked)}件 / {len(opts)}件',f'- sourceUrlとcheckedAtの両方あり：{len(both)}件 / {len(opts)}件',f'- priceOptions未登録の販売登録：{len(no_opts)}件',f'- URL未登録の販売登録：{sum(not s.get("url") for _,_,s in rows)}件','', '### 販売状態の登録値（現在の在庫をライブ確認した件数ではない）','']
    lines += [f'- {k}: {v}件' for k,v in sorted(status.items())]
    lines += ['', '## 判定','', '- 現在の `phones.json` には価格オプションが存在しますが、今回のスナップショットでは22件の価格オプションが12販売登録に含まれており、ほか475販売登録には価格オプションがありません。', '- 価格オプション22件にはいずれも `sourceUrl` と `checkedAt` が記録されています。ただし、フィールドがあることは、リンク先が現在も有効、価格が現在も同じ、対象容量・色・販売チャネルが完全一致することを保証しません。', '- `AVAILABLE` 等の登録値は現在の在庫をライブ確認した件数ではありません。', '- 0.04.54の誤った集計記述を本書で訂正します。Pixel 11ファミリーの公式SIMフリー通常価格および楽天モバイルのPixel 11 256GB通常価格を追加し、iPhone 18 Pro / Pro Maxの公式2TB容量を復元し、Apple Store公式価格を登録しました。','', '## priceOptions未登録の販売登録（全件一覧）','']
    lines += [f'- {x}' for x in no_opts] if no_opts else ['- なし']
    lines += ['', '## 検証範囲','', 'JSON構造と入れ子フィールドの集計のみ。全販売ページのライブ照合、Gradle/KSPビルド、Room実行、Android JUnit、エミュレータ・実機試験は含みません。','']
    OUT.write_text('\n'.join(lines),encoding='utf-8')
    print(f'PASS: models={len(phones)} variants={len(variants)} listings={len(rows)} priceOptions={len(opts)} validPrices={len(valid)} sourceUrl={len(source)} checkedAt={len(checked)} listingsWithoutPriceOptions={len(no_opts)}')
    return 0
if __name__=='__main__': raise SystemExit(main())
