#!/usr/bin/env python3
"""Execute DAO identity SQL against small SQLite fixtures (not a Room test)."""
import re
import sqlite3
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DAO_PATH = ROOT / "app/src/main/java/jp/smartphoneadvisor/app/data/PhoneDao.kt"
source = DAO_PATH.read_text(encoding="utf-8")

def query_for(function_name: str) -> str:
    function_match = re.search(r"suspend fun " + re.escape(function_name) + r"\(", source)
    if not function_match:
        raise AssertionError(f"function not found for {function_name}")
    query_start = source.rfind('@Query("""', 0, function_match.start())
    if query_start < 0:
        raise AssertionError(f"query annotation not found for {function_name}")
    body_start = source.find('"""', query_start + len('@Query("""'))
    if body_start < 0:
        raise AssertionError(f"query body terminator not found for {function_name}")
    return source[query_start + len('@Query("""'):body_start].strip()

full_sql = query_for("getDeviceVariantIdByFullIdentity")
fallback_sql = query_for("getDeviceVariantIdByModelAndStorage")
model_sql = query_for("getModelIdByIdentity")

def db_fixture():
    db = sqlite3.connect(":memory:")
    db.executescript("""
      CREATE TABLE manufacturer(id INTEGER PRIMARY KEY, name TEXT NOT NULL);
      CREATE TABLE smartphone_model(id INTEGER PRIMARY KEY, manufacturerId INTEGER, modelName TEXT, platform TEXT, releaseYear INTEGER, isActive INTEGER);
      CREATE TABLE device_variant(id INTEGER PRIMARY KEY, modelId INTEGER, storageGb INTEGER, ramGb INTEGER, condition TEXT, isActive INTEGER);
      INSERT INTO manufacturer VALUES (1, 'Example'), (2, 'Other');
      INSERT INTO smartphone_model VALUES (10, 1, 'Model X', 'ANDROID', 2026, 1);
      INSERT INTO device_variant VALUES (100, 10, 128, 8, 'NEW', 1);
    """)
    return db

full_params = {"modelName":"Model X", "manufacturerName":"Example", "platform":"ANDROID", "releaseYear":2026, "storageGb":128, "ramGb":8, "condition":"NEW"}
fallback_params = {"modelName":"Model X", "storageGb":128, "ramGb":8, "condition":"NEW"}
model_params = {"manufacturerId":1, "modelName":"Model X", "platform":"ANDROID", "releaseYear":2026}

# A duplicate model identity without a matching 128GB variant must still block the lookup.
db = db_fixture()
db.execute("INSERT INTO smartphone_model VALUES (11, 1, 'Model X', 'ANDROID', 2026, 1)")
assert db.execute(full_sql, full_params).fetchone()[0] is None, "full identity lookup selected a model despite duplicate master identity"
assert db.execute(fallback_sql, fallback_params).fetchone()[0] is None, "fallback lookup selected a model despite duplicate name"
assert db.execute(model_sql, model_params).fetchone()[0] is None, "model identity lookup selected arbitrary duplicate"

# A single exact model and variant resolves normally.
db = db_fixture()
assert db.execute(full_sql, full_params).fetchone()[0] == 100
assert db.execute(fallback_sql, fallback_params).fetchone()[0] == 100
assert db.execute(model_sql, model_params).fetchone()[0] == 10

# Same display name under another manufacturer/platform/year must block name-only fallback.
db = db_fixture()
db.execute("INSERT INTO smartphone_model VALUES (12, 2, 'Model X', 'ANDROID', 2026, 1)")
assert db.execute(fallback_sql, fallback_params).fetchone()[0] is None

print("SQLite identity query tests: PASS (7 assertions)")
print("Scope: executes extracted SQL against synthetic SQLite fixtures; does not replace Room/KSP compilation or app runtime testing.")
