#!/usr/bin/env python3
"""Static regression checks for model/variant identity resolution in seed code.

This is source inspection only; it does not compile Kotlin or exercise Room.
"""
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
DAO = (ROOT / 'app/src/main/java/jp/smartphoneadvisor/app/data/PhoneDao.kt').read_text(encoding='utf-8')
SEED = (ROOT / 'app/src/main/java/jp/smartphoneadvisor/app/data/SeedData.kt').read_text(encoding='utf-8')
EXPANSION = (ROOT / 'app/src/main/java/jp/smartphoneadvisor/app/data/CatalogExpansion.kt').read_text(encoding='utf-8')

checks = {
    'DAO identity lookup uses manufacturer, model, platform, release year': all(s in DAO for s in (
        'm.manufacturerId = :manufacturerId', 'm.modelName = :modelName',
        'm.platform = :platform', 'm.releaseYear = :releaseYear')),
    'CatalogExpansion no longer resolves models by model name alone': 'getModelIdByName(record.model)' not in EXPANSION,
    'CatalogExpansion uses full model identity': 'getModelIdByIdentity(' in EXPANSION,
    'SeedData addition uses full model identity': 'getModelIdByIdentity(' in SEED,
    'SeedData addition checks exact storage and RAM before insert': 'getDeviceVariantIdByModelIdStorageAndRam(' in SEED,
    'ignored insert IDs are resolved through lookup or explicit error': 'insertedId >= 0L' in SEED and 'could not be resolved' in SEED and 'could not be resolved' in EXPANSION,
}
for label, ok in checks.items():
    print(f"{'PASS' if ok else 'FAIL'}: {label}")
if not all(checks.values()):
    sys.exit(1)
print('STATIC IDENTITY SAFETY CHECK: PASS')
print('LIMITATION: no Kotlin compilation, Room database, Gradle build, or runtime test.')
