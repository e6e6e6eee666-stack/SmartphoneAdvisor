#!/usr/bin/env python3
"""Execute the exact price-selection SQL expression used by PhoneDao in SQLite."""
import re
import sqlite3
from pathlib import Path

root = Path(__file__).resolve().parents[1]
source = (root / 'app/src/main/java/jp/smartphoneadvisor/app/data/PhoneDao.kt').read_text()
marker = 'COALESCE(\n                   (SELECT pr.priceYen'
start = source.find(marker)
assert start >= 0, 'V2-first recommendation price expression missing'
# Capture the full COALESCE(...) expression by balancing parentheses.
i = start
level = 0
quote = None
while i < len(source):
    ch = source[i]
    if quote:
        if ch == quote and (i == 0 or source[i - 1] != '\\'):
            quote = None
    elif ch in "'\"":
        quote = ch
    elif ch == '(':
        level += 1
    elif ch == ')':
        level -= 1
        if level == 0:
            i += 1
            break
    i += 1
expr = source[start:i]
assert 'price_record_v2' in expr and 'p.priceYen' in expr
assert "pr.priceType IN ('NORMAL','SALE')" in expr
assert "plv.availability IN ('AVAILABLE','LIMITED')" in expr
assert 'ORDER BY pr2.checkedAt DESC, pr2.id DESC' in expr, 'same-timestamp price history must select a deterministic latest row'
assert 'SELECT MAX(pr2.checkedAt)' not in expr, 'timestamp-only matching can return duplicate history rows'

con = sqlite3.connect(':memory:')
con.executescript('''
CREATE TABLE sales_variant(id INTEGER PRIMARY KEY, deviceVariantId INTEGER, salesChannel TEXT, isActive INTEGER);
CREATE TABLE product_listing(id INTEGER PRIMARY KEY, salesVariantId INTEGER, availability TEXT);
CREATE TABLE price_record_v2(id INTEGER PRIMARY KEY, productListingId INTEGER, priceType TEXT, priceYen INTEGER, checkedAt INTEGER, color TEXT, sourceId INTEGER);
CREATE TABLE price_record(priceYen INTEGER, checkedAt INTEGER);
INSERT INTO sales_variant VALUES (1, 10, 'SIM_FREE', 1), (2, 10, 'DOCOMO', 1), (3, 20, 'SIM_FREE', 1);
INSERT INTO product_listing VALUES (101, 1, 'AVAILABLE'), (102, 2, 'LIMITED'), (201, 3, 'DISCONTINUED');
INSERT INTO price_record_v2 VALUES
 (1,101,'NORMAL',100000,1000,'black',NULL),
 (2,101,'NORMAL',99000,2000,'black',NULL),
 (3,101,'SALE',95000,3000,'black',NULL),
 (4,102,'NORMAL',97000,2500,'white',NULL),
 (6,101,'SALE',96000,3000,'black',NULL),
 (5,201,'NORMAL',50000,4000,'black',NULL);
''')
# Latest eligible V2 record takes precedence over the legacy row; old legacy price remains fallback only.
con.execute('INSERT INTO price_record VALUES (?,?)', (77700, 5000))
row = con.execute(f'SELECT {expr} FROM (SELECT 10 AS id) d LEFT JOIN price_record p ON 1=1', {'purchaseChannel': ''}).fetchone()
assert row[0] == 96000, row
# If no eligible V2 listing exists, the legacy price remains available for the existing freshness filter.
row = con.execute(f'SELECT {expr} FROM (SELECT 20 AS id) d LEFT JOIN price_record p ON 1=1', {'purchaseChannel': ''}).fetchone()
assert row[0] == 77700, row
# A device without either source has no price; unknown is not invented.
row = con.execute(f'SELECT {expr} FROM (SELECT 30 AS id) d LEFT JOIN (SELECT NULL AS priceYen) p ON 1=1', {'purchaseChannel': ''}).fetchone()
assert row[0] is None, row
print('PASS: exact PhoneDao price-selection expression executes in SQLite')
print('PASS: latest eligible V2 normal/sale price takes precedence over legacy price')
print('PASS: duplicate same-time/same-type/same-color records select highest id deterministically')
print('PASS: discontinued listings do not supply recommendation prices')
print('PASS: legacy fallback remains available when no eligible V2 price exists')
print('PASS: missing prices remain NULL')
