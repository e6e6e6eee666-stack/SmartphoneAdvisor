#!/usr/bin/env python3
"""Deterministic static audit for SmartphoneAdvisor's diagnostic JSON catalog.

Usage: python tools/audit_diagnostic_catalog.py [path/to/phones.json]
No network access; does not infer missing data or mutate the catalog.
"""
from __future__ import annotations
import collections
import json
import pathlib
import sys

ROOT = pathlib.Path(__file__).resolve().parents[1]
CATALOG = pathlib.Path(sys.argv[1]) if len(sys.argv) > 1 else ROOT / "app/src/main/assets/phones.json"
ALLOWED_CHANNELS = {
    "DOCOMO", "AU", "SOFTBANK", "RAKUTEN", "UQ_MOBILE", "Y_MOBILE",
    "IIJ_MIO", "MINEO", "SIM_FREE", "MVNO", "OTHER"
}
ALLOWED_AVAILABILITY = {"AVAILABLE", "LIMITED", "UNKNOWN", "PREORDER", "DISCONTINUED", "OUT_OF_STOCK"}

def main() -> int:
    try:
        data = json.loads(CATALOG.read_text(encoding="utf-8"))
    except Exception as exc:
        print(f"FAIL: cannot parse UTF-8 JSON: {exc}")
        return 2

    errors: list[str] = []
    warnings: list[str] = []
    phones = data.get("phones")
    if not isinstance(phones, list):
        print("FAIL: 'phones' must be an array")
        return 2

    model_ids = [p.get("id") for p in phones]
    if any(not x for x in model_ids): errors.append("one or more models have no id")
    if len(model_ids) != len(set(model_ids)): errors.append("duplicate model ids")

    variants = []
    sales = []
    variant_keys = collections.Counter()
    sales_keys = collections.Counter()
    channel_counts = collections.Counter()
    availability_counts = collections.Counter()
    official_count = 0
    missing_sales_variants = 0
    for phone in phones:
        if phone.get("isJapanOfficial") is True: official_count += 1
        if phone.get("platform") not in {"ANDROID", "IPHONE"}:
            errors.append(f"{phone.get('id')}: invalid platform {phone.get('platform')!r}")
        for v in phone.get("variants", []):
            variants.append(v)
            variant_keys[(phone.get("id"), v.get("storageGb"), v.get("ramGb"))] += 1
            listing = v.get("sales", [])
            if not listing: missing_sales_variants += 1
            for s in listing:
                sales.append(s)
                channel = s.get("channel")
                status = s.get("availability")
                channel_counts[channel] += 1
                availability_counts[status] += 1
                sales_keys[(phone.get("id"), v.get("storageGb"), v.get("ramGb"), channel, s.get("retailer"), s.get("modelNumber"))] += 1
                if channel not in ALLOWED_CHANNELS: errors.append(f"{phone.get('id')}: unknown channel {channel!r}")
                if status not in ALLOWED_AVAILABILITY: errors.append(f"{phone.get('id')}: unknown availability {status!r}")
                url = s.get("url")
                if url and not (url.startswith("https://") or url.startswith("http://")):
                    errors.append(f"{phone.get('id')}: malformed URL {url!r}")
                if not url: warnings.append(f"{phone.get('id')}: sales listing has no URL")

    duplicate_variants = sum(n - 1 for n in variant_keys.values() if n > 1)
    duplicate_sales = sum(n - 1 for n in sales_keys.values() if n > 1)
    if duplicate_variants: errors.append(f"duplicate model/storage/RAM keys: {duplicate_variants}")
    if duplicate_sales: errors.append(f"duplicate sales listing keys: {duplicate_sales}")

    print(f"Catalog: {CATALOG}")
    print(f"Schema version: {data.get('schemaVersion')}")
    print(f"Models: {len(phones)} (Japan-official: {official_count})")
    print(f"Variants: {len(variants)}")
    print(f"Sales listings: {len(sales)}")
    print(f"Variants without sales listings: {missing_sales_variants}")
    print("Sales by channel:")
    for k, v in sorted(channel_counts.items(), key=lambda item: str(item[0])): print(f"  {k}: {v}")
    print("Sales by availability:")
    for k, v in sorted(availability_counts.items(), key=lambda item: str(item[0])): print(f"  {k}: {v}")
    print(f"Audit findings: {len(data.get('auditFindings', []))}")
    print(f"Warnings: {len(warnings)}")
    for item in warnings[:30]: print(f"  WARN: {item}")
    print(f"Errors: {len(errors)}")
    for item in errors: print(f"  ERROR: {item}")
    print("NOTE: This checks catalog structure only. It does not verify prices, specifications, URLs, stock, Room linkage, Gradle build, or runtime behavior.")
    return 1 if errors else 0

if __name__ == "__main__":
    raise SystemExit(main())
