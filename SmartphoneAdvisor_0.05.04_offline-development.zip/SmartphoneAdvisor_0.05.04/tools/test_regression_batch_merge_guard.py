"""Prevent stale batch reports from producing misleading aggregate test counts."""
from pathlib import Path
source = (Path(__file__).resolve().parent / "run_current_regression_suite.py").read_text(encoding="utf-8")
assert "actual_names != expected_names" in source
assert "refusing to merge stale/mismatched batch reports" in source
assert "total_pass += 1" in source and "total_fail += 1" in source
# Aggregate counts must be computed from validated per-test result lines, not old summary counters.
assert 'line.startswith("Passed: ")' not in source
assert 'line.startswith("Failed: ")' not in source
print("PASS: stale or reordered batch reports are rejected; aggregate counts derive from validated per-test results")
