#!/usr/bin/env python3
"""Static regression guard for phones.json -> Room -> single-phone diagnostic wiring."""
import json
from pathlib import Path

from current_version import current_version_is_valid
ROOT = Path(__file__).resolve().parents[1]
BUILD = (ROOT / 'app/build.gradle.kts').read_text(encoding='utf-8')
MAIN = (ROOT / 'app/src/main/java/jp/smartphoneadvisor/app/MainActivity.kt').read_text(encoding='utf-8')
LOADER = (ROOT / 'app/src/main/java/jp/smartphoneadvisor/app/data/catalog/PhoneCatalogJson.kt').read_text(encoding='utf-8')
IMPORTER = (ROOT / 'app/src/main/java/jp/smartphoneadvisor/app/data/catalog/PhoneCatalogRoomImporter.kt').read_text(encoding='utf-8')
DAO = (ROOT / 'app/src/main/java/jp/smartphoneadvisor/app/data/PhoneDao.kt').read_text(encoding='utf-8')
SCREEN = (ROOT / 'app/src/main/java/jp/smartphoneadvisor/app/ui/SinglePhoneDiagnosticScreen.kt').read_text(encoding='utf-8')
ENGINE = (ROOT / 'app/src/main/java/jp/smartphoneadvisor/app/domain/SinglePhoneDiagnosticEngine.kt').read_text(encoding='utf-8')
CATALOG = json.loads((ROOT / 'app/src/main/assets/phones.json').read_text(encoding='utf-8'))
errors = []

if not current_version_is_valid(BUILD):
    errors.append('current app version metadata is invalid')
if 'ASSET_NAME = "phones.json"' not in LOADER or 'PhoneCatalogJsonLoader.load(context)' not in MAIN:
    errors.append('MainActivity must load the bundled phones.json asset')
if 'PhoneCatalogRoomImporter.importCatalog(database, jsonCatalog)' not in MAIN:
    errors.append('MainActivity must import the JSON catalog into Room')
if MAIN.find('PhoneCatalogRoomImporter.importCatalog(database, jsonCatalog)') > MAIN.find('dbReady = true'):
    errors.append('database must not be marked ready before catalog import attempt completes')
if 'PhoneCatalogJsonLoader.load(context)' not in SCREEN or 'searchJapanOfficialDevices(os.name, "")' not in SCREEN:
    errors.append('diagnostic screen must load JSON and query official Room device rows')
if 'SinglePhoneDiagnosticEngine.catalogCandidates(catalog, rows)' not in SCREEN:
    errors.append('diagnostic screen must intersect JSON catalog with Room candidates')
if 'fun catalogCandidates(' not in ENGINE or 'sale.availability == "AVAILABLE" || sale.availability == "LIMITED"' not in ENGINE:
    errors.append('diagnostic candidate filtering must require a purchasable JSON sale listing')
if 'price_record_v2' not in DAO or "pr.priceType IN ('NORMAL','SALE')" not in DAO:
    errors.append('device search query must include current catalog price_record_v2 values')
if 'dao.insertPriceRecordsV2' not in IMPORTER or 'dao.hasPriceOption' not in IMPORTER:
    errors.append('Room importer must persist price options idempotently')
if 'if (c.osaifuKeitai == SupportStatus.SUPPORTED)' in ENGINE or 'c.osaifuKeitai == SupportStatus.SUPPORTED' not in ENGINE:
    errors.append('required Osaifu-Keitai support must not treat UNKNOWN as supported')
if 'c.microSd == SupportStatus.SUPPORTED' not in ENGINE:
    errors.append('required microSD support must not treat UNKNOWN as supported')

phones = CATALOG.get('phones', [])
variants = [v for p in phones for v in p.get('variants', [])]
sales = [s for v in variants for s in v.get('sales', [])]
prices = [o for s in sales for o in s.get('priceOptions', [])]
if not phones or not variants or not sales:
    errors.append('bundled catalog must include phones, variants and sales listings')
for i, option in enumerate(prices):
    if not isinstance(option.get('priceYen'), int) or option['priceYen'] <= 0:
        errors.append(f'price option {i} must have a positive integer price')
    if not option.get('sourceUrl') or not option.get('checkedAt'):
        errors.append(f'price option {i} must include source URL and checked date')

print(f'JSON→Room→diagnostic linkage static guard: phones={len(phones)} variants={len(variants)} sales={len(sales)} prices={len(prices)} errors={len(errors)}')
for error in errors:
    print('FAIL:', error)
raise SystemExit(bool(errors))
