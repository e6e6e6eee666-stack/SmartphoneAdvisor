#!/usr/bin/env python3
"""Regression assertions for official fact corrections retained through 0.04.22."""
import json
from pathlib import Path
root=Path(__file__).resolve().parents[1]
data=json.loads((root/'app/src/main/assets/phones.json').read_text(encoding='utf-8'))
phones=data['phones']
def model(name):
    matches=[p for p in phones if p.get('model')==name]
    assert len(matches)==1, f'{name}: expected one model, got {len(matches)}'
    return matches[0]
assert model('iPhone 17e')['releaseYear']==2026
assert model('motorola razr 60 ultra')['releaseYear']==2025
assert model('motorola razr 60 ultra')['id']=='Motorola:motorola razr 60 ultra:2025'
assert model('AQUOS R9 pro')['releaseYear']==2024
xperia=model('Xperia 10 VI')
assert any(v.get('storageGb')==128 and v.get('ramGb')==6 for v in xperia['variants'])
pro=model('iPhone 17 Pro Max')
v=[v for v in pro['variants'] if v.get('storageGb')==2048]
assert len(v)==1, 'iPhone 17 Pro Max 2TB variant must exist exactly once'
assert len(v[0]['sales'])==5
assert all(s.get('availability')=='UNKNOWN' for s in v[0]['sales']), 'channel availability must remain unverified'
assert data['counts']['phoneModels']==len(phones)
assert data['counts']['variants']==sum(len(p.get('variants',[])) for p in phones)
assert data['counts']['salesListings']==sum(len(v.get('sales',[])) for p in phones for v in p.get('variants',[]))
print('Official fact regression tests: PASS (10 assertions)')
