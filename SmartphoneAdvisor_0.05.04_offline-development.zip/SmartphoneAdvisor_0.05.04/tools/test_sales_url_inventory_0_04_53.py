#!/usr/bin/env python3
"""Regression for catalog URL reuse classification in 0.04.53."""
import csv, json, subprocess, sys
from pathlib import Path
from current_version import current_version_is_valid
ROOT=Path(__file__).resolve().parents[1]
CATALOG=ROOT/"app/src/main/assets/phones.json"
BUILD=ROOT/"app/build.gradle.kts"
OUT=ROOT/"SALES_URL_INVENTORY_0.04.76.csv"
def main():
    data=json.loads(CATALOG.read_text(encoding="utf-8")); build=BUILD.read_text(encoding="utf-8")
    errors=[]
    if not current_version_is_valid(build): errors.append("version mismatch")
    sales=[(p,v,s) for p in data.get("phones",[]) for v in p.get("variants",[]) for s in v.get("sales",[])]
    if any(not s.get("url") and s.get("availability")=="AVAILABLE" for _,_,s in sales): errors.append("URL-less listing marked AVAILABLE")
    proc=subprocess.run([sys.executable,str(ROOT/"tools/audit_sales_url_inventory_0_04_76.py")],cwd=ROOT,text=True,capture_output=True)
    if proc.returncode: errors.append("inventory generator failed: "+proc.stdout+proc.stderr)
    rows=[]
    if not OUT.exists(): errors.append("inventory CSV missing")
    else:
        with OUT.open(encoding="utf-8-sig",newline="") as f: rows=list(csv.DictReader(f))
        if len(rows)!=len(sales): errors.append(f"CSV rows {len(rows)} != catalog sales {len(sales)}")
        if sum(bool(r["url"]) for r in rows)!=sum(bool(s.get("url")) for _,_,s in sales): errors.append("CSV URL-row count mismatch")
        if any(r["url"] and (not r["url_host"] or not r["url_path"]) for r in rows): errors.append("URL row missing host/path")
        allowed={"NO_URL","SHARED_MODEL_URL","UNIQUE_MODEL_URL"}
        if any(r["url_scope"] not in allowed for r in rows): errors.append("unknown or misleading reuse label")
        if any(not r["url"] and r["url_scope"]!="NO_URL" for r in rows): errors.append("missing URL reuse state incorrectly assigned")
        if any(r["url_scope"]=="NOT_SHARED_IN_CATALOG" and not r["url"] for r in rows): errors.append("URL-less row classified as not-shared")
    print("SmartphoneAdvisor 0.04.61 sales URL inventory regression")
    print(f"Catalog sales rows: {len(sales)}; inventory rows: {len(rows)}")
    print(f"Errors: {len(errors)}")
    for e in errors: print("FAIL:",e)
    if errors: return 1
    print("PASS: complete inventory; labels describe catalog reuse only and do not claim model-specific pages.")
    return 0
if __name__=="__main__": raise SystemExit(main())
