#!/usr/bin/env python3
"""Regression checks for deterministic latest price history in PhoneDao SQL."""
import sqlite3
from pathlib import Path

root = Path(__file__).resolve().parents[1]
dao = (root / 'app/src/main/java/jp/smartphoneadvisor/app/data/PhoneDao.kt').read_text(encoding='utf-8')

def query_for(method):
    pos = dao.find(f'suspend fun {method}(')
    assert pos >= 0, f'{method} missing'
    start = dao.rfind('@Query("""', 0, pos)
    assert start >= 0, f'{method} @Query missing'
    body = dao.find('"""', start + len('@Query("""'))
    assert body >= 0
    return dao[start + len('@Query("""'):body].strip()

comparison = query_for('getComparisonPrices')
purchase = query_for('getPurchaseOptions')
assert 'ORDER BY pr2.checkedAt DESC, pr2.id DESC' in comparison
assert 'ORDER BY pr2.checkedAt DESC, pr2.id DESC' in purchase
assert 'SELECT MAX(pr2.checkedAt)' not in dao[dao.find('suspend fun getComparisonPrices('):dao.find('suspend fun getPurchaseOptions(')]

con = sqlite3.connect(':memory:')
con.executescript('''
CREATE TABLE sales_variant(id INTEGER PRIMARY KEY, deviceVariantId INTEGER, isActive INTEGER);
CREATE TABLE product_listing(id INTEGER PRIMARY KEY, salesVariantId INTEGER, retailerId INTEGER, productUrl TEXT, availability TEXT);
CREATE TABLE retailer(id INTEGER PRIMARY KEY, name TEXT, type TEXT, official INTEGER);
CREATE TABLE price_record_v2(id INTEGER PRIMARY KEY, productListingId INTEGER, priceType TEXT, priceYen INTEGER, pointsValueYen INTEGER, couponValueYen INTEGER, tradeInValueYen INTEGER, shippingFeeYen INTEGER, conditions TEXT, checkedAt INTEGER, color TEXT, sourceUrl TEXT);
INSERT INTO sales_variant VALUES (1,501,1);
INSERT INTO product_listing VALUES (11,1,1,'https://example.com','AVAILABLE');
INSERT INTO retailer VALUES (1,'Shop','OTHER',0);
INSERT INTO price_record_v2 VALUES
 (101,11,'NORMAL',140000,NULL,NULL,NULL,NULL,NULL,500,'Black','https://example.com/price'),
 (102,11,'NORMAL',139000,NULL,NULL,NULL,NULL,NULL,700,'Black','https://example.com/price'),
 (103,11,'NORMAL',138000,NULL,NULL,NULL,NULL,NULL,700,'Black','https://example.com/price'),
 (104,11,'NORMAL',137000,NULL,NULL,NULL,NULL,NULL,700,'White','https://example.com/price');
''')
rows = con.execute(purchase, {"deviceVariantId": 501}).fetchall()
black = [r for r in rows if r[14] == 'Black']
white = [r for r in rows if r[14] == 'White']
assert len(black) == 1, black
assert black[0][7] == 138000 and black[0][13] == 700, black
assert len(white) == 1 and white[0][7] == 137000, white
assert con.execute('PRAGMA integrity_check').fetchone()[0] == 'ok'
print('PASS: purchase-options DAO query executes against SQLite fixture')
print('PASS: same timestamp + same type + same color resolves to the highest price-record ID')
print('PASS: different colors retain separate latest prices')
print('PASS: SQLite integrity_check=ok')
