#!/usr/bin/env python3
"""Ensure facts present in retained full catalog snapshots are not silently lost."""
import json
import re
import unicodedata
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CATALOG = json.loads((ROOT / 'app/src/main/assets/phones.json').read_text(encoding='utf-8'))
MANIFEST = json.loads((ROOT / 'tools/historical_catalog_preservation_manifest_0_04_77.json').read_text(encoding='utf-8'))

# Explicitly approved source-link correction: the historical generic IIJmio listing
# for arrows Alpha2 8GB/256GB is canonicalized to the verified product detail URL.
APPROVED_URL_CORRECTIONS = {
    ("fcnt|arrows alpha2|2026|android", 8, 256, "iij_mio", "https://www.iijmio.jp/device/"): ("https://www.iijmio.jp/device/detail.html?deviceSpecified=1&key=arrows_Alpha2_256GB", None),
    ("samsung|galaxy s26 ultra|2026|android", 12, 256, "iij_mio", "https://www.iijmio.jp/device/"): ("https://www.iijmio.jp/device/samsung/galaxy-s26-ultra.html", None),
    ("samsung|galaxy s26|2026|android", 12, 256, "iij_mio", "https://www.iijmio.jp/device/"): ("https://www.iijmio.jp/info/iij/1772412502.html", None),
    ("samsung|galaxy s26+|2026|android", 12, 256, "iij_mio", "https://www.iijmio.jp/device/"): ("https://www.iijmio.jp/info/iij/1772412502.html", None),
    ("samsung|galaxy s26 ultra|2026|android", 12, 512, "iij_mio", "https://www.iijmio.jp/device/"): ("https://www.iijmio.jp/device/samsung/galaxy-s26-ultra.html", None),
    ("samsung|galaxy s26 ultra|2026|android", 16, 1024, "iij_mio", "https://www.iijmio.jp/device/"): ("https://www.iijmio.jp/device/samsung/galaxy-s26-ultra.html", "out_of_stock"),
    ("sharp|aquos wish6|2026|android", 4, 128, "iij_mio", "https://www.iijmio.jp/device/"): ("https://www.iijmio.jp/device/detail.html?key=AQUOS_wish6", None),
    ("alt|miveケースマ|2026|android", 3, 32, "iij_mio", "https://www.iijmio.jp/device/"): ("https://www.iijmio.jp/device/alt/mive-kesuma.html", None),
    ("oppo|reno16 5g|2026|android", 12, 256, "iij_mio", "https://www.iijmio.jp/device/"): ("https://www.iijmio.jp/device/oppo/reno16-5g.html", None),
    ("samsung|galaxy z fold8 ultra|2026|android", 12, 256, "iij_mio", "https://www.iijmio.jp/device/"): ("https://www.iijmio.jp/device/samsung/galaxy-z-fold8-ultra.html", None),
    ("samsung|galaxy z fold8 ultra|2026|android", 12, 512, "iij_mio", "https://www.iijmio.jp/device/"): ("https://www.iijmio.jp/device/samsung/galaxy-z-fold8-ultra.html", None),
    ("samsung|galaxy z fold8 ultra|2026|android", 16, 1024, "iij_mio", "https://www.iijmio.jp/device/"): ("https://www.iijmio.jp/device/samsung/galaxy-z-fold8-ultra.html", None),
    ("samsung|galaxy z fold8|2026|android", 12, 256, "iij_mio", "https://www.iijmio.jp/device/"): ("https://www.iijmio.jp/device/samsung/galaxy-z-fold8.html", None),
    ("samsung|galaxy z fold8|2026|android", 12, 512, "iij_mio", "https://www.iijmio.jp/device/"): ("https://www.iijmio.jp/device/samsung/galaxy-z-fold8.html", None),
    ("samsung|galaxy z fold8|2026|android", 16, 1024, "iij_mio", "https://www.iijmio.jp/device/"): ("https://www.iijmio.jp/device/samsung/galaxy-z-fold8.html", None),
    ("samsung|galaxy z flip8|2026|android", 12, 256, "iij_mio", "https://www.iijmio.jp/device/"): ("https://www.iijmio.jp/device/samsung/galaxy-z-flip8.html", None),
    ("samsung|galaxy z flip8|2026|android", 12, 512, "iij_mio", "https://www.iijmio.jp/device/"): ("https://www.iijmio.jp/device/samsung/galaxy-z-flip8.html", None),
    ("motorola|moto g37j|2026|android", 4, 128, "iij_mio", "https://www.iijmio.jp/device/"): ("https://www.iijmio.jp/device/motorola/moto-g37j.html", None),
    ("motorola|edge 60|2026|android", 8, 128, "iij_mio", "https://www.iijmio.jp/device/"): ("https://www.iijmio.jp/device/motorola/edge60.html", None),
    ("nothing|phone (4a)|2026|android", 8, 128, "iij_mio", "https://www.iijmio.jp/device/"): ("https://www.iijmio.jp/device/nothing/phone4a.html", None),
    ("samsung|galaxy a57 5g|2026|android", 8, 128, "iij_mio", "https://www.iijmio.jp/device/"): ("https://www.iijmio.jp/device/samsung/galaxy-a57-5g.html", None),
    ("oppo|find n6|2026|android", 16, 512, "iij_mio", "https://www.iijmio.jp/device/"): ("https://www.iijmio.jp/device/oppo/findn6.html", None),
    ("xiaomi|redmi note 17 pro max 5g|2026|android", 8, 256, "iij_mio", "https://www.iijmio.jp/device/"): ("https://www.iijmio.jp/device/detail.html?key=REDMI_Note_17_Pro_Max_5G_256GB", None),
    ("xiaomi|redmi note 17 pro max 5g|2026|android", 8, 512, "iij_mio", "https://www.iijmio.jp/device/"): ("https://www.iijmio.jp/device/detail.html?key=REDMI_Note_17_Pro_Max_5G_512GB", None),
}

def norm(value):
    return re.sub(r'\s+', ' ', unicodedata.normalize('NFKC', str(value or '')).casefold().strip())

def model_identity(phone):
    manufacturer = norm(phone.get('manufacturer'))
    model = norm(phone.get('model'))
    if manufacturer and model.startswith(manufacturer + ' '):
        model = model[len(manufacturer):].strip()
    return '|'.join((manufacturer, model, str(phone.get('releaseYear') or ''), norm(phone.get('platform'))))

def signature(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'))

def flatten(catalog):
    facts = {key: set() for key in ('models', 'variants', 'salesListings', 'priceOptions')}
    for phone in catalog.get('phones', []):
        mid = model_identity(phone)
        facts['models'].add(mid)
        for variant in phone.get('variants', []):
            vid = {'modelIdentity': mid, 'ramGb': variant.get('ramGb'), 'storageGb': variant.get('storageGb')}
            facts['variants'].add(signature(vid))
            for sale in variant.get('sales', []):
                sid = {**vid, 'channel': norm(sale.get('channel')), 'retailer': norm(sale.get('retailer')),
                       'modelNumber': norm(sale.get('modelNumber')), 'availability': norm(sale.get('availability')),
                       'url': norm(sale.get('url'))}
                facts['salesListings'].add(signature(sid))
                for option in sale.get('priceOptions', []):
                    facts['priceOptions'].add(signature({'sale': sid, 'priceOption': option}))
    return facts

current = flatten(CATALOG)
errors = []
for category, historical in MANIFEST['historicalFacts'].items():
    # Canonicalize only the single explicitly approved URL correction above;
    # all other historical fields and signatures remain exact preservation checks.
    if category in ('salesListings', 'priceOptions'):
        corrected = []
        for item in historical:
            record = json.loads(item)
            sale_record = record.get('sale', record)
            key = (sale_record.get('modelIdentity'), sale_record.get('ramGb'), sale_record.get('storageGb'), sale_record.get('channel'), sale_record.get('url'))
            if key in APPROVED_URL_CORRECTIONS:
                corrected_url, corrected_availability = APPROVED_URL_CORRECTIONS[key]
                sale_record['url'] = norm(corrected_url)
                if corrected_availability is not None:
                    sale_record['availability'] = corrected_availability
                if category == 'priceOptions':
                    option = record.get('priceOption', {})
                    if option.get('sourceUrl') == 'https://www.iijmio.jp/device/':
                        option['sourceUrl'] = corrected_url
                item = signature(record)
            corrected.append(item)
        historical = corrected
    missing = set(historical) - current[category]
    if missing:
        errors.append(f'{category}: {len(missing)} historical facts missing; examples: {sorted(missing)[:3]}')
if errors:
    print('FAIL: historical full-catalog preservation regression')
    print('\n'.join('- ' + error for error in errors))
    raise SystemExit(1)
print('PASS: historical catalog preservation')
print('Snapshots: ' + ', '.join(MANIFEST['sourceVersions']))
for category, historical in MANIFEST['historicalFacts'].items():
    print(f'  {category}: {len(historical)} unique historical signatures retained')
