#!/usr/bin/env python3
"""Regression test for Docomo's announced iPhone 18 Pro/Pro Max list prices."""
import json
from pathlib import Path
from current_version import current_version_is_valid
ROOT=Path(__file__).resolve().parents[1]
def main():
    errors=[]
    build=(ROOT/'app/build.gradle.kts').read_text(encoding='utf-8')
    data=json.loads((ROOT/'app/src/main/assets/phones.json').read_text(encoding='utf-8'))
    if not current_version_is_valid(build): errors.append('version mismatch')
    expected={('iPhone 18 Pro',256):263230,('iPhone 18 Pro',512):309870,('iPhone 18 Pro',1024):395230,('iPhone 18 Pro',2048):518980,('iPhone 18 Pro Max',256):291500,('iPhone 18 Pro Max',512):334290,('iPhone 18 Pro Max',1024):419650,('iPhone 18 Pro Max',2048):543400}
    actual={}
    for phone in data.get('phones',[]):
        if phone.get('model') not in ('iPhone 18 Pro','iPhone 18 Pro Max'): continue
        for variant in phone.get('variants',[]):
            sale=next((s for s in variant.get('sales',[]) if s.get('channel')=='DOCOMO'),None)
            if not sale: continue
            for option in sale.get('priceOptions',[]): actual[(phone['model'],variant['storageGb'])]=option
    if set(actual) & set(expected) != set(expected): errors.append(f'missing Docomo capacities: {sorted(set(expected)-set(actual))}')
    for key,price in expected.items():
        opt=actual.get(key,{})
        if opt.get('priceYen')!=price: errors.append(f'{key}: expected {price}, got {opt.get("priceYen")}')
        if opt.get('priceType')!='NORMAL': errors.append(f'{key}: not classified as NORMAL')
        if opt.get('sourceUrl')!='https://k-tai.watch.impress.co.jp/docs/news/2140379.html': errors.append(f'{key}: missing announcement source')
        if opt.get('checkedAt')!='2026-10-16': errors.append(f'{key}: missing checked date')
        if '割引適用前' not in (opt.get('conditions') or ''): errors.append(f'{key}: discount caveat missing')
    options=[o for p in data['phones'] for v in p.get('variants',[]) for s in v.get('sales',[]) for o in s.get('priceOptions',[])]
    if len(options)!=100: errors.append(f'expected 100 price options, got {len(options)}')
    report=ROOT/'PRICE_COVERAGE_AUDIT_0.04.61.md'
    if not report.exists(): errors.append('coverage report missing')
    print(f'0.04.61 Docomo iPhone capacity-price regression: expected={len(expected)} options={len(options)} errors={len(errors)}')
    for error in errors: print('FAIL:',error)
    if errors: return 1
    print('PASS: all 8 capacity prices and provenance fields match expected values.')
    return 0
if __name__=='__main__': raise SystemExit(main())
