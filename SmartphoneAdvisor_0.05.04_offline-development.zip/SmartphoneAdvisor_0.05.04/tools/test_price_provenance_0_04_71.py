#!/usr/bin/env python3
"""Regression guard: every catalog price must have a positive value and traceable source/date."""
import json
from pathlib import Path
from current_version import current_version_is_valid
ROOT = Path(__file__).resolve().parents[1]
build = (ROOT / 'app/build.gradle.kts').read_text(encoding='utf-8')
if not current_version_is_valid(build):
    raise SystemExit('FAIL: current app version metadata is invalid')
data = json.loads((ROOT / 'app/src/main/assets/phones.json').read_text(encoding='utf-8'))
errors=[]; options=[]; missing=[]
for phone in data.get('phones', []):
    for variant in phone.get('variants', []):
        for sale in variant.get('sales', []):
            price_options = sale.get('priceOptions', [])
            if not price_options:
                missing.append((phone.get('model'), variant.get('storageGb'), sale.get('channel'), sale.get('availability')))
            for option in price_options:
                options.append(option)
                price = option.get('priceYen')
                if not isinstance(price, int) or isinstance(price, bool) or price <= 0:
                    errors.append(f"{phone.get('model')} {variant.get('storageGb')}GB {sale.get('channel')}: invalid price {price!r}")
                if not str(option.get('sourceUrl') or '').startswith(('https://','http://')):
                    errors.append(f"{phone.get('model')} {variant.get('storageGb')}GB {sale.get('channel')}: missing/invalid sourceUrl")
                if not str(option.get('checkedAt') or '').strip():
                    errors.append(f"{phone.get('model')} {variant.get('storageGb')}GB {sale.get('channel')}: missing checkedAt")
if errors:
    print('FAIL\n'+'\n'.join(errors)); raise SystemExit(1)
print(f'PASS: {len(options)} price options have positive integer prices, source URLs and checkedAt dates; {len(missing)} sales listings remain without price options (not treated as zero yen).')
