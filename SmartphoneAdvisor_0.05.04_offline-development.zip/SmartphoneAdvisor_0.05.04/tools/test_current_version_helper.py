from pathlib import Path
from current_version import current_version_is_valid
ROOT = Path(__file__).resolve().parents[1]
BUILD = (ROOT / "app/build.gradle.kts").read_text(encoding="utf-8")
assert current_version_is_valid(BUILD), "current Gradle version metadata must be valid"
assert current_version_is_valid("versionCode = 1\nversionName = \"1.2.3\"")
assert not current_version_is_valid("versionCode = 0\nversionName = \"1.2.3\"")
assert not current_version_is_valid("versionCode = 4\nversionName = \"1.2\"")
print("PASS: current version helper validates format and positive code without pinning a release")
