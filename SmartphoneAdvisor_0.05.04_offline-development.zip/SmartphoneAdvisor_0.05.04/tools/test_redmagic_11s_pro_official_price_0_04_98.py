#!/usr/bin/env python3
"""Regression guard for REDMAGIC 11S Pro official Japanese sales and prices."""
import json
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
data = json.loads((ROOT / "app/src/main/assets/phones.json").read_text(encoding="utf-8"))
phone = next(p for p in data["phones"] if p["id"] == "REDMAGIC:REDMAGIC 11S Pro:2026")
expected = {256: (12, 149800), 512: (16, 172800)}
for storage, (ram, yen) in expected.items():
    variant = next(v for v in phone["variants"] if v["storageGb"] == storage)
    assert variant["ramGb"] == ram
    sale = next(s for s in variant["sales"] if s["retailer"] == "REDMAGIC Japan")
    assert sale["channel"] == "SIM_FREE" and sale["availability"] == "AVAILABLE"
    assert sale["url"] == "https://jp.redmagic.gg/products/redmagic-11s-pro"
    assert len(sale["priceOptions"]) == 1
    price = sale["priceOptions"][0]
    assert (price["priceYen"], price["priceType"]) == (yen, "NORMAL")
    assert price["sourceUrl"] == sale["url"] and price["checkedAt"] == "2026-10-21"
    assert "税込" in price["conditions"] and "先行予約割引" in price["conditions"]
actual = {
    "phoneModels": len(data["phones"]),
    "variants": sum(len(p.get("variants", [])) for p in data["phones"]),
    "salesListings": sum(len(v.get("sales", [])) for p in data["phones"] for v in p.get("variants", [])),
    "priceOptions": sum(len(s.get("priceOptions", [])) for p in data["phones"] for v in p.get("variants", []) for s in v.get("sales", [])),
    "auditFindings": len(data.get("auditFindings", [])),
}
assert data["counts"] == actual
assert actual == {"phoneModels": 195, "variants": 315, "salesListings": 511, "priceOptions": 100, "auditFindings": 45}
print("PASS: REDMAGIC 11S Pro official sales, capacity prices, provenance, and catalog counts")
