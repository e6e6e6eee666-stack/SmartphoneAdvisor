#!/usr/bin/env python3
"""Compare sales seed identities and storage variants with phones.json.

Static source audit only. It does not assert official facts, import Room rows,
or auto-correct conflicts. Every non-unique/missing match is review work.
"""
from pathlib import Path
import collections, json, re
ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "app/src/main/java/jp/smartphoneadvisor/app/data"
CATALOG = ROOT / "app/src/main/assets/phones.json"
FILES = ["CarrierCatalogSeed.kt", "SimFreeCatalogSeed.kt", "VerifiedSalesSeed.kt", "SubBrandMvnoCatalogSeed.kt"]
phones = json.loads(CATALOG.read_text(encoding="utf-8"))["phones"]
records=[]
for filename in FILES:
    for line_no,line in enumerate((DATA/filename).read_text(encoding="utf-8").splitlines(),1):
        m=re.search(r'\b(?:Entry|PriceEntry)\("([^"]+)"',line)
        if not m: continue
        model=m.group(1)
        sm=re.search(r'storageGb\s*=\s*(\d+)',line)
        if not sm: sm=re.search(r'\b(?:Entry|PriceEntry)\("[^"]+"\s*,\s*(\d+)\s*,',line)
        storage=int(sm.group(1)) if sm else None
        rm=re.search(r'ramGb\s*=\s*(\d+)',line); ram=int(rm.group(1)) if rm else None
        mm=re.search(r'\bEntry\("[^"]+"\s*,\s*"([^"]+)"\s*,',line) if filename=="CarrierCatalogSeed.kt" else None
        manufacturer=mm.group(1) if mm else None
        pm=re.search(r'platform\s*=\s*"([^"]+)"',line); platform=pm.group(1) if pm else None
        ym=re.search(r',\s*(19\d{2}|20\d{2})\s*,',line) if filename=="CarrierCatalogSeed.kt" else None
        year=int(ym.group(1)) if ym else None
        candidates=[]
        for phone in phones:
            if phone.get("model") != model: continue
            variants=[v for v in phone.get("variants",[]) if storage is None or v.get("storageGb")==storage]
            if variants: candidates.append((phone,variants))
        valid=[]; conflict_reasons=[]
        for phone,variants in candidates:
            identity_reasons=[]
            if manufacturer and phone.get("manufacturer") != manufacturer: identity_reasons.append(f"manufacturer seed={manufacturer} catalog={phone.get('manufacturer')}")
            if platform and phone.get("platform") != platform: identity_reasons.append(f"platform seed={platform} catalog={phone.get('platform')}")
            if year and phone.get("releaseYear") != year: identity_reasons.append(f"releaseYear seed={year} catalog={phone.get('releaseYear')}")
            if identity_reasons:
                conflict_reasons.extend(identity_reasons)
                continue
            matching_variants=[v for v in variants if ram is None or v.get("ramGb") in (None,ram)]
            if matching_variants:
                valid.append((phone,matching_variants))
            elif ram is not None:
                available_rams=sorted({v.get("ramGb") for v in variants},key=lambda x: (-1 if x is None else x))
                conflict_reasons.append(f"RAM seed={ram} catalog options={available_rams}")
        if len(valid)==1: status="UNIQUE_MATCH"
        elif len(valid)>1: status="AMBIGUOUS_MATCH"
        elif not candidates:
            same_model=[p for p in phones if p.get("model")==model]
            status="VARIANT_NOT_IN_CATALOG" if same_model else "MODEL_NOT_IN_CATALOG"
        else: status="IDENTITY_OR_RAM_CONFLICT"
        records.append({"file":filename,"line":line_no,"model":model,"storageGb":storage,"ramGb":ram,"manufacturer":manufacturer,"platform":platform,"releaseYear":year,"status":status,"reasons":sorted(set(conflict_reasons)),"candidateIds":[p.get("id") for p,_ in candidates]})
counts=collections.Counter(r['status'] for r in records)
needs=[r for r in records if r['status']!="UNIQUE_MATCH"]
lines=["# Seed-to-catalog coverage audit 0.04.22","","Static source comparison of sales seed constructors against `phones.json` model names, storage, and declared identity fields.","This report does not verify official facts, live prices/URLs, Room runtime import, Gradle build, or device behavior.","",f"Seed records parsed: {len(records)}","","## Counts",""]
for status in sorted(counts): lines.append(f"- {status}: {counts[status]}")
lines += ["", "## Records requiring review", ""]
if not needs: lines.append("None")
for r in needs:
    reasons="; ".join(r['reasons']) if r['reasons'] else "no exact model/storage candidate"
    lines.append(f"- `{r['status']}` — `{r['file']}:{r['line']}` — {r['model']} / {r['storageGb']}GB / RAM {r['ramGb'] if r['ramGb'] is not None else 'unspecified'}; candidate IDs: {', '.join(r['candidateIds']) or 'none'}; {reasons}")
lines += ["", "## Safe interpretation", "", "- `UNIQUE_MATCH`: one catalog model remains after all identity fields present in that seed row and its storage/RAM are checked.", "- `IDENTITY_OR_RAM_CONFLICT`: model/storage candidate exists but the seed's declared year/platform/manufacturer or RAM conflicts with the catalog. Do not force-link it.", "- `VARIANT_NOT_IN_CATALOG`: model exists but the requested storage is not in its catalog variants. This may be a catalog gap or seed error; verify source before changing either.", "- `MODEL_NOT_IN_CATALOG`: exact model name is not in the catalog. Check naming aliases or catalog completeness; do not guess.", "- `AMBIGUOUS_MATCH`: multiple candidates remain; do not auto-link.", ""]
report=ROOT/"SEED_CATALOG_COVERAGE_AUDIT_0.04.22.md"
report.write_text("\n".join(lines),encoding="utf-8")
print("SEED TO CATALOG COVERAGE AUDIT")
print("Seed records parsed:",len(records))
for status in sorted(counts): print(f"{status}: {counts[status]}")
print("Records requiring review:",len(needs))
for r in needs:
    print(f"{r['status']} {r['file']}:{r['line']} {r['model']} {r['storageGb']}GB; {'; '.join(r['reasons']) if r['reasons'] else 'no exact model/storage candidate'}")
print("Report:",report.name)
