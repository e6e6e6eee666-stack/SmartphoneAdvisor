#!/usr/bin/env python3
"""Guard exact IIJmio product links, configurations, prices, and preorder status."""
import json
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
DATA = json.loads((ROOT / 'app/src/main/assets/phones.json').read_text(encoding='utf-8'))
SOURCE = 'https://www.iijmio.jp/info/iij/1791342895.html'
EXPECTED = {
    ('POCO F9 Ultra', 512, 16): ('AVAILABLE', 'https://www.iijmio.jp/device/xiaomi/pocof9ultra.html', {169800: 'NORMAL', 149800: 'SALE', 144800: 'MNP'}),
    ('POCO F9 Ultra', 256, 12): ('AVAILABLE', 'https://www.iijmio.jp/device/xiaomi/pocof9ultra.html', {149800: 'NORMAL', 129800: 'SALE', 124800: 'MNP'}),
    ('Xperia 10 VIII', 128, 8): ('AVAILABLE', 'https://www.iijmio.jp/device/sony/xperia-10-VIII.html', {99000: 'NORMAL', 84800: 'MNP'}),
    ('motorola edge 70 fusion', 256, 12): ('PREORDER', 'https://www.iijmio.jp/device/motorola/edge70fusion.html', {79800: 'NORMAL', 69800: 'MNP'}),
}
found = {}
for phone in DATA['phones']:
    for variant in phone.get('variants', []):
        key = (phone.get('model'), variant.get('storageGb'), variant.get('ramGb'))
        for sale in variant.get('sales', []):
            if sale.get('channel') == 'IIJ_MIO' and sale.get('url') in {v[1] for v in EXPECTED.values()}:
                found[key] = sale
errors = []
for key, (status, url, expected_prices) in EXPECTED.items():
    sale = found.get(key)
    if not sale:
        errors.append(f'missing IIJmio record for {key}')
        continue
    if sale.get('availability') != status: errors.append(f'{key}: status expected {status}, got {sale.get("availability")}')
    if sale.get('url') != url: errors.append(f'{key}: wrong product URL {sale.get("url")}')
    options = sale.get('priceOptions', [])
    actual = {o.get('priceYen'): o.get('priceType') for o in options}
    if actual != expected_prices: errors.append(f'{key}: expected price/type map {expected_prices}, got {actual}')
    for option in options:
        if option.get('sourceUrl') != SOURCE: errors.append(f'{key}: price lacks official announcement source')
        if option.get('checkedAt') != '2026-10-20': errors.append(f'{key}: price check date mismatch')
        if not option.get('conditions'): errors.append(f'{key}: missing price conditions')
if len(found) != len(EXPECTED): errors.append(f'expected {len(EXPECTED)} exact IIJmio registrations, found {len(found)}')
actual_variants = sum(len(p.get('variants', [])) for p in DATA['phones'])
actual_sales = sum(len(v.get('sales', [])) for p in DATA['phones'] for v in p.get('variants', []))
actual_prices = sum(len(s.get('priceOptions', [])) for p in DATA['phones'] for v in p.get('variants', []) for s in v.get('sales', []))
if (DATA['counts'].get('variants'), DATA['counts'].get('salesListings'), DATA['counts'].get('priceOptions')) != (actual_variants, actual_sales, actual_prices):
    errors.append('catalog count metadata does not match actual tree')
if (actual_variants, actual_sales, actual_prices) != (315, 511, 100): errors.append(f'unexpected updated totals {(actual_variants, actual_sales, actual_prices)}')
if errors:
    print('FAIL: IIJmio verified product registrations')
    print('\n'.join('- ' + e for e in errors))
    raise SystemExit(1)
print('PASS: 4 exact IIJmio registrations; 4 product URLs; 10 source-backed price options; edge 70 fusion remains PREORDER; catalog totals 315 variants / 511 sales / 100 prices.')
