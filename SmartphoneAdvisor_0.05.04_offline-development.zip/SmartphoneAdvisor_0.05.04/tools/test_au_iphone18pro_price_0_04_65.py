#!/usr/bin/env python3
"""Regression test for the official AU iPhone 18 Pro 256GB base price."""
import json
from pathlib import Path

from current_version import current_version_is_valid
ROOT = Path(__file__).resolve().parents[1]
BUILD = (ROOT / 'app/build.gradle.kts').read_text(encoding='utf-8')
CATALOG = json.loads((ROOT / 'app/src/main/assets/phones.json').read_text(encoding='utf-8'))
errors = []
if not current_version_is_valid(BUILD):
    errors.append('current app version metadata is invalid')

matches = []
for phone in CATALOG['phones']:
    if phone.get('model') != 'iPhone 18 Pro':
        continue
    for variant in phone.get('variants', []):
        if variant.get('storageGb') != 256:
            continue
        for sale in variant.get('sales', []):
            if sale.get('channel') == 'AU' and sale.get('retailer') == 'au':
                matches.extend(sale.get('priceOptions', []))
if len(matches) != 1:
    errors.append(f'expected exactly one AU price option for iPhone 18 Pro 256GB, got {len(matches)}')
else:
    option = matches[0]
    expected = {
        'color': '全色共通',
        'priceYen': 268800,
        'priceType': 'NORMAL',
        'sourceUrl': 'https://onlineshop.au.com/info/CSfViewInfo.jsp?no=257&sort=6',
        'checkedAt': '2026-10-16',
    }
    for key, value in expected.items():
        if option.get(key) != value:
            errors.append(f'{key}: expected {value!r}, got {option.get(key)!r}')
    if not option.get('conditions') or '実質負担額' not in option['conditions']:
        errors.append('conditions must distinguish base price from installment-program effective burden')

print(f'AU iPhone 18 Pro price regression (current catalog): options={len(matches)} errors={len(errors)}')
for error in errors:
    print('FAIL:', error)
raise SystemExit(bool(errors))
