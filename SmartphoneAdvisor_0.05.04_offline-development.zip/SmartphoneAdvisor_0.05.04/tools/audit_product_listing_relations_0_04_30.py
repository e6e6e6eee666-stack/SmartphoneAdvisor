#!/usr/bin/env python3
"""Static guardrails for the read-only product-listing relationship audit."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
checks = {
    "audit reports sales variant -> missing device variant": "salesVariantsMissingDeviceVariant" in (ROOT / "app/src/main/java/jp/smartphoneadvisor/app/data/catalog/ProductListingRelationAudit.kt").read_text(),
    "audit reports listing -> missing sales variant": "listingsMissingSalesVariant" in (ROOT / "app/src/main/java/jp/smartphoneadvisor/app/data/catalog/ProductListingRelationAudit.kt").read_text(),
    "audit reports listing -> missing retailer": "listingsMissingRetailer" in (ROOT / "app/src/main/java/jp/smartphoneadvisor/app/data/catalog/ProductListingRelationAudit.kt").read_text(),
    "audit reports blank product URLs": "blankProductUrls" in (ROOT / "app/src/main/java/jp/smartphoneadvisor/app/data/catalog/ProductListingRelationAudit.kt").read_text(),
    "audit reports duplicate listing identities": "duplicateListingIdentities" in (ROOT / "app/src/main/java/jp/smartphoneadvisor/app/data/catalog/ProductListingRelationAudit.kt").read_text(),
    "audit reports price -> missing listing": "priceRecordsMissingListing" in (ROOT / "app/src/main/java/jp/smartphoneadvisor/app/data/catalog/ProductListingRelationAudit.kt").read_text(),
    "DAO exposes all required read-only table queries": all(x in (ROOT / "app/src/main/java/jp/smartphoneadvisor/app/data/PhoneDao.kt").read_text() for x in ["getAllDeviceVariantsForAudit", "getAllSalesVariantsForAudit", "getAllProductListingsForAudit", "getAllPriceRecordsV2ForAudit"]),
    "audit is invoked after catalog import path": "ProductListingRelationAudit.analyze(" in (ROOT / "app/src/main/java/jp/smartphoneadvisor/app/MainActivity.kt").read_text(),
    "audit has unit tests": (ROOT / "app/src/test/java/jp/smartphoneadvisor/app/data/catalog/ProductListingRelationAuditTest.kt").exists(),
    "audit does not perform mutations": not any(x in (ROOT / "app/src/main/java/jp/smartphoneadvisor/app/data/catalog/ProductListingRelationAudit.kt").read_text() for x in ["@Insert", "@Update", "@Delete", "suspend fun insert", "suspend fun update", "suspend fun delete"]),
    "version name updated": 'versionName = "0.04.30"' in (ROOT / "app/build.gradle.kts").read_text(),
    "version code updated": "versionCode = 79" in (ROOT / "app/build.gradle.kts").read_text(),
}
for name, ok in checks.items():
    print(f"{'PASS' if ok else 'FAIL'} | {name}")
print(f"RESULT: {sum(checks.values())}/{len(checks)} passed")
raise SystemExit(0 if all(checks.values()) else 1)
