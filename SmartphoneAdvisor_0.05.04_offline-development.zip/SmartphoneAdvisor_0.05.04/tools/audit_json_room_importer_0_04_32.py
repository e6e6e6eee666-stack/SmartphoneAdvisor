#!/usr/bin/env python3
"""Static preflight for the non-destructive phones.json -> Room importer."""
import json
from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parents[1]
JSON = ROOT / "app/src/main/assets/phones.json"
IMPORTER = ROOT / "app/src/main/java/jp/smartphoneadvisor/app/data/catalog/PhoneCatalogRoomImporter.kt"
DAO = ROOT / "app/src/main/java/jp/smartphoneadvisor/app/data/PhoneDao.kt"
MAIN = ROOT / "app/src/main/java/jp/smartphoneadvisor/app/MainActivity.kt"
BUILD = ROOT / "app/build.gradle.kts"

def main():
    data = json.loads(JSON.read_text(encoding="utf-8"))
    src = IMPORTER.read_text(encoding="utf-8")
    dao = DAO.read_text(encoding="utf-8")
    main = MAIN.read_text(encoding="utf-8")
    build = BUILD.read_text(encoding="utf-8")
    phones = data.get("phones", [])
    variants = [(p.get("id"), v.get("storageGb"), v.get("ramGb")) for p in phones for v in p.get("variants", [])]
    sales = [s for p in phones for v in p.get("variants", []) for s in v.get("sales", [])]
    checks = {
        "catalog IDs unique": len({p.get("id") for p in phones}) == len(phones),
        "catalog model identities unique": len({(p.get("manufacturer"),p.get("model"),p.get("platform"),p.get("releaseYear")) for p in phones}) == len(phones),
        "variant keys unique per model": len(set(variants)) == len(variants),
        "Room transaction used": "db.withTransaction" in src,
        "duplicate manufacturer blocked": "manufacturers.size > 1" in src,
        "same-name model/year conflict blocked": "releaseYear mismatch" in src,
        "duplicate null-RAM variant detected": "getVariantsByModelStorageAndRam" in src and "matches.size > 1" in src,
        "existing attributes not overwritten": "hasRecommendationAttributes" in src and "RecommendationAttributesEntity(deviceVariantId = variantId)" in src,
        "model/variant import wired at startup": "PhoneCatalogRoomImporter.importCatalog(database, jsonCatalog)" in main,
        "failure logged rather than silently accepted": "Catalog import failed; existing seed retained" in main,
        "DAO has identity lookup list": "getModelsByNameAndPlatform" in dao and "getManufacturersByName" in dao,
        "version is 0.04.32 / code 81": 'versionName = "0.04.32"' in build and "versionCode = 81" in build,
        "sales URL/availability import implemented": "insertProductListings" in src and "AvailabilityStatus.valueOf" in src,
    }
    lines=["SmartphoneAdvisor 0.04.32 JSON-to-Room importer static audit", "Scope: source/preflight inspection only; not Android Room runtime or Gradle build.", f"JSON models: {len(phones)}", f"JSON variants: {len(variants)}", f"JSON sales listings: {len(sales)}", "", "Checks:"]
    lines += [f"{'PASS' if ok else 'FAIL'}: {name}" for name,ok in checks.items()]
    lines += ["", "Import safety rules:", "- validates catalog before starting database transaction", "- never deletes or replaces existing rows", "- reuses only unambiguous manufacturer/model/variant identities", "- leaves existing feature/specification rows untouched", "- initializes missing recommendation attributes to UNKNOWN", "- preserves existing listing values on conflict", "- imports sales variants, retailers, and listings conservatively; skips URL-less listings", "- logs conflicts and retains existing seed if import throws"]
    out=ROOT/"JSON_ROOM_IMPORT_AUDIT_0.04.32.md"
    out.write_text("\n".join(lines)+"\n",encoding="utf-8")
    print("\n".join(lines))
    return 0 if all(checks.values()) else 1
if __name__ == "__main__": raise SystemExit(main())
