from pathlib import Path
import json
from urllib.parse import urlsplit

root = Path(__file__).resolve().parents[1]
source = (root / 'app/src/main/java/jp/smartphoneadvisor/app/data/catalog/PhoneCatalogRoomImporter.kt').read_text()
tests = (root / 'app/src/test/java/jp/smartphoneadvisor/app/data/catalog/PhoneCatalogRoomImporterTest.kt').read_text()
checks = {
    'URI parser used for source URLs': 'URI(url)' in source,
    'HTTP and HTTPS scheme allowlist retained': 'parsed.scheme.equals("https"' in source and 'parsed.scheme.equals("http"' in source,
    'missing host rejected': 'parsed.host.isNullOrBlank()' in source,
    'URL whitespace rejected': 'url != rawUrl' in source,
    'padded retailer name rejected': 'sales retailer has leading/trailing whitespace' in source,
    'blank model number rejected': 'blank modelNumber must be null' in source,
    'tests cover no-host URL': 'no valid host' in tests,
    'tests cover whitespace URL': 'leading/trailing whitespace' in tests,
    'tests cover blank model number': 'blank modelNumber' in tests,
}
asset = root / 'app/src/main/assets/phones.json'
data = json.loads(asset.read_text(encoding='utf-8'))
url_count = 0
bad_urls = []
for phone in data.get('phones', []):
    for variant in phone.get('variants', []):
        for sale in variant.get('sales', []):
            raw = sale.get('url')
            if raw:
                url_count += 1
                parsed = urlsplit(raw.strip())
                if raw != raw.strip() or parsed.scheme.lower() not in ('http', 'https') or not parsed.hostname:
                    bad_urls.append((phone.get('model'), sale.get('retailer'), raw))
checks['current catalog URLs satisfy stricter rules'] = not bad_urls
for name, ok in checks.items():
    print(f'{"PASS" if ok else "FAIL"}: {name}')
print(f'Catalog URL count checked: {url_count}; invalid: {len(bad_urls)}')
if bad_urls:
    for item in bad_urls[:20]: print('INVALID:', item)
if not all(checks.values()):
    raise SystemExit(1)
print(f'PASS: {sum(checks.values())}/{len(checks)} checks')
