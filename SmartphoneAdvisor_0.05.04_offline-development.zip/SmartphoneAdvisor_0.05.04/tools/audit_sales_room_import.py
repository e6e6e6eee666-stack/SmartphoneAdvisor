from pathlib import Path

root = Path(__file__).resolve().parents[1]
importer = (root / 'app/src/main/java/jp/smartphoneadvisor/app/data/catalog/PhoneCatalogRoomImporter.kt').read_text()
price_import = importer.split('// Import every verified price option', 1)[1].split('return Result(', 1)[0]
dao = (root / 'app/src/main/java/jp/smartphoneadvisor/app/data/PhoneDao.kt').read_text()
main = (root / 'app/src/main/java/jp/smartphoneadvisor/app/MainActivity.kt').read_text()
tests = (root / 'app/src/test/java/jp/smartphoneadvisor/app/data/catalog/PhoneCatalogRoomImporterTest.kt').read_text()
checks = {
    'transactional import retained': 'db.withTransaction {' in importer,
    'sales variant import': 'insertSalesVariants' in importer and 'getSalesVariantsByIdentity' in importer,
    'retailer ambiguity detection': 'getRetailersByName' in importer and 'retailers.size > 1' in importer,
    'listing ambiguity detection': 'getProductListingsByIdentity' in importer and 'existingListings.size > 1' in importer,
    'existing listing is not overwritten': 'preserved without overwrite' in importer,
    'missing URL does not create listing': 'if (url == null)' in importer and 'listingsSkippedNoUrl++' in importer,
    'retailer official status not inferred from URL': 'official = false' in importer,
    'prices require explicit verification date': 'price.checkedAt?.let' in price_import and 'price skipped' in price_import and '?: System.currentTimeMillis()' not in price_import,
    'DAO returns full identity candidate lists': all(x in dao for x in ['getSalesVariantsByIdentity', 'getRetailersByName', 'getProductListingsByIdentity']),
    'startup logs sales import counts': all(x in main for x in ['salesVariantsInserted=', 'retailersInserted=', 'listingsInserted=', 'listingsSkippedNoUrl=']),
    'tests cover unknown availability': 'unsupportedAvailabilityIsRejectedBeforeImport' in tests,
    'tests cover missing URL': 'missingSalesUrlIsAllowedWithoutInventingUrl' in tests,
}
for name, ok in checks.items():
    print(f'{"PASS" if ok else "FAIL"}: {name}')
if not all(checks.values()):
    raise SystemExit(1)
print(f'PASS: {sum(checks.values())}/{len(checks)} static checks')
