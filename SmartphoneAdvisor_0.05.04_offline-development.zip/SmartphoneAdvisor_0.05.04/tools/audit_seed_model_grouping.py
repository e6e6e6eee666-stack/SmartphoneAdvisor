#!/usr/bin/env python3
"""Static guard for the initial Room seed model/variant grouping.

This does not replace a Room instrumentation test or Gradle build.
"""
import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SEED = ROOT / "app/src/main/java/jp/smartphoneadvisor/app/data/SeedData.kt"
JSON = ROOT / "app/src/main/assets/phones.json"
source = SEED.read_text(encoding="utf-8")
asset = json.loads(JSON.read_text(encoding="utf-8"))
errors = []

if "val modelIds = mutableMapOf<ModelKey, Long>()" not in source:
    errors.append("SeedData does not cache model IDs by model identity")
if "val modelId = modelIds[modelKey] ?: db.phoneDao().insertModels(" not in source:
    errors.append("SeedData model creation is not guarded by the model-ID cache")
if "data class ModelKey(" not in source:
    errors.append("ModelKey definition missing")

# Check that model key fields intentionally exclude storage/RAM and include platform/year.
key_match = re.search(r"data class ModelKey\((.*?)\n    \)", source, re.S)
if not key_match:
    errors.append("Could not parse ModelKey fields")
else:
    fields = key_match.group(1)
    for required in ("manufacturer: String", "model: String", "platform: String", "releaseYear: Int"):
        if required not in fields:
            errors.append(f"ModelKey missing required field: {required}")
    if "storageGb" in fields or "ramGb" in fields:
        errors.append("ModelKey incorrectly includes variant-only storage/RAM")

phones = asset.get("phones", [])
variants = sum(len(p.get("variants", [])) for p in phones)
print(f"JSON models: {len(phones)}")
print(f"JSON variants: {variants}")
print("Seed model grouping source check: " + ("PASS" if not errors else "FAIL"))
if errors:
    print("Errors:")
    for error in errors:
        print("- " + error)
    sys.exit(1)
print("Scope: static source check only; Room runtime and Gradle compilation are not tested.")
