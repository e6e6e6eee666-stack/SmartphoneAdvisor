#!/usr/bin/env python3
"""Regression test for verified Pixel 11 family prices 0.04.57."""
import json, subprocess, sys
from pathlib import Path
from current_version import current_version_is_valid
ROOT=Path(__file__).resolve().parents[1]
def main():
    errors=[]
    build=(ROOT/'app/build.gradle.kts').read_text(encoding='utf-8')
    data=json.loads((ROOT/'app/src/main/assets/phones.json').read_text(encoding='utf-8'))
    if not current_version_is_valid(build): errors.append('version mismatch')
    rows=[(p,v,s) for p in data.get('phones',[]) for v in p.get('variants',[]) for s in v.get('sales',[])]
    options=[o for _,_,s in rows for o in s.get('priceOptions',[])]
    if len(data.get('phones',[])) != 195: errors.append(f'expected 195 models, got {len(data.get("phones",[]))}')
    if len(rows) != 511: errors.append(f'expected 511 sales listings, got {len(rows)}')
    if len(options) != 100: errors.append(f'expected 100 price options after verified additions, got {len(options)}')
    expected = {('Pixel 11',256):136800,('Pixel 11',512):156800,('Pixel 11 Pro',256):174800,('Pixel 11 Pro',512):194800,('Pixel 11 Pro',1024):234800,('Pixel 11 Pro XL',256):207800,('Pixel 11 Pro XL',512):227800,('Pixel 11 Pro XL',1024):267800,('Pixel 11 Pro Fold',256):279900,('Pixel 11 Pro Fold',512):299900}
    actual = {(p.get('model'),v.get('storageGb')):o.get('priceYen') for p,v,s in rows if s.get('channel')=='SIM_FREE' and s.get('retailer')=='Google Store Japan' for o in s.get('priceOptions',[])}
    if any(actual.get(k)!=v for k,v in expected.items()): errors.append('official Google Store Pixel 11 family price mismatch')
    if not any(p.get('model')=='iPhone 18 Pro' and v.get('storageGb')==2048 for p in data.get('phones',[]) for v in p.get('variants',[])): errors.append('official iPhone 18 Pro 2TB variant missing')
    # The audit must not mutate source facts; unknown prices must remain missing, not zero-valued.
    if any(not isinstance(o.get('priceYen'),int) or o['priceYen']<=0 for o in options): errors.append('invalid existing price option')
    proc=subprocess.run([sys.executable,str(ROOT/'tools/audit_price_coverage_0_04_76.py')],cwd=ROOT,text=True,capture_output=True)
    if proc.returncode: errors.append('audit failed: '+proc.stdout+proc.stderr)
    report=ROOT/'PRICE_COVERAGE_AUDIT_0.04.76.md'
    if not report.exists(): errors.append('coverage report missing')
    else:
        t=report.read_text(encoding='utf-8')
        for phrase in ('販売チャネル別','価格未登録の優先確認対象','確認済みの公式価格（2026-10-16確認）','Pixel 11 Pro Fold','公式ページ全件照合'):
            if phrase not in t: errors.append('report missing: '+phrase)
    print(f'0.04.61 price coverage regression: listings={len(rows)} options={len(options)} errors={len(errors)}')
    for e in errors: print('FAIL:',e)
    if errors:return 1
    print('PASS: coverage report generated; catalog price data preserved.')
    return 0
if __name__=='__main__': raise SystemExit(main())
