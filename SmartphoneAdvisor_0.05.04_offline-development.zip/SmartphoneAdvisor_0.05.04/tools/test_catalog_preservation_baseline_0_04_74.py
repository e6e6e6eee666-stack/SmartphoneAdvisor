#!/usr/bin/env python3
"""Fail if previously shipped catalog variants, listings, or prices disappear."""
import json, re, unicodedata
from collections import Counter
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
CATALOG = json.loads((ROOT / 'app/src/main/assets/phones.json').read_text())
BASELINE = json.loads((ROOT / 'tools/catalog_preservation_baseline_0_04_72.json').read_text())

def norm(value):
    value = unicodedata.normalize('NFKC', str(value or '')).casefold().strip()
    return re.sub(r'\s+', ' ', value)

def model_identity(phone):
    manufacturer = norm(phone.get('manufacturer'))
    model = norm(phone.get('model'))
    if manufacturer and model.startswith(manufacturer + ' '):
        model = model[len(manufacturer):].strip()
    return '|'.join((manufacturer, model, str(phone.get('releaseYear') or ''), norm(phone.get('platform'))))

def signature(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'))

errors = []
current_models = {model_identity(p) for p in CATALOG.get('phones', [])}
for identity in BASELINE['baselineModelIdentities']:
    if identity not in current_models:
        errors.append('baseline model identity missing: ' + identity)
variants, sales, prices = [], [], []
for phone in CATALOG.get('phones', []):
    mid = model_identity(phone)
    for variant in phone.get('variants', []):
        vid = {'modelIdentity': mid, 'ramGb': variant.get('ramGb'), 'storageGb': variant.get('storageGb')}
        variants.append(signature(vid))
        for sale in variant.get('sales', []):
            sid = {**vid, 'channel': sale.get('channel'), 'retailer': sale.get('retailer'), 'modelNumber': sale.get('modelNumber'), 'availability': sale.get('availability'), 'url': sale.get('url')}
            sales.append(signature(sid))
            for option in sale.get('priceOptions', []):
                prices.append(signature({'sale': sid, 'priceOption': option}))
# Explicit, source-backed current corrections are permitted while every other
# historical signature must remain. URL corrections are narrowly allowlisted by
# exact model identity and retailer; this prevents legitimate detail-page repairs
# from being mistaken for deleted sales records.
approved_urls = {
    'samsung|galaxy s26 ultra|2026|android': 'https://www.iijmio.jp/device/samsung/galaxy-s26-ultra.html',
    'samsung|galaxy s26|2026|android': 'https://www.iijmio.jp/info/iij/1772412502.html',
    'samsung|galaxy s26+|2026|android': 'https://www.iijmio.jp/info/iij/1772412502.html',
    'sharp|aquos wish6|2026|android': 'https://www.iijmio.jp/device/detail.html?key=AQUOS_wish6',
    'alt|miveケースマ|2026|android': 'https://www.iijmio.jp/device/alt/mive-kesuma.html',
    'oppo|reno16 5g|2026|android': 'https://www.iijmio.jp/device/oppo/reno16-5g.html',
    'samsung|galaxy z fold8 ultra|2026|android': 'https://www.iijmio.jp/device/samsung/galaxy-z-fold8-ultra.html',
    'samsung|galaxy z fold8|2026|android': 'https://www.iijmio.jp/device/samsung/galaxy-z-fold8.html',
    'samsung|galaxy z flip8|2026|android': 'https://www.iijmio.jp/device/samsung/galaxy-z-flip8.html',
    'motorola|moto g37j|2026|android': 'https://www.iijmio.jp/device/motorola/moto-g37j.html',
    'motorola|edge 60|2026|android': 'https://www.iijmio.jp/device/motorola/edge60.html',
    'nothing|phone (4a)|2026|android': 'https://www.iijmio.jp/device/nothing/phone4a.html',
    'samsung|galaxy a57 5g|2026|android': 'https://www.iijmio.jp/device/samsung/galaxy-a57-5g.html',
    'oppo|find n6|2026|android': 'https://www.iijmio.jp/device/oppo/findn6.html',
    'xiaomi|redmi note 17 pro max 5g|2026|android': 'VARIANT_SPECIFIC_REDMi_URL',
}
expected_sales = []
for raw_signature in BASELINE['expectedSalesSignatures']:
    row = json.loads(raw_signature)
    identity = row.get('modelIdentity')
    if (identity in approved_urls and row.get('channel') == 'IIJ_MIO'
        and row.get('retailer') == 'IIJmio'
        and row.get('url') == 'https://www.iijmio.jp/device/'
        and (identity not in {'samsung|galaxy s26|2026|android', 'samsung|galaxy s26+|2026|android'} or row.get('storageGb') == 256)):
        if identity == 'xiaomi|redmi note 17 pro max 5g|2026|android':
            storage = row.get('storageGb')
            row['url'] = f"https://www.iijmio.jp/device/detail.html?key=REDMI_Note_17_Pro_Max_5G_{storage}GB"
        else:
            row['url'] = approved_urls[identity]
        if identity == 'samsung|galaxy s26 ultra|2026|android' and row.get('storageGb') == 1024:
            row['availability'] = 'OUT_OF_STOCK'
        expected_sales.append(signature(row))
    else:
        expected_sales.append(raw_signature)
expected_prices = []
for raw_signature in BASELINE['expectedPriceSignatures']:
    row = json.loads(raw_signature)
    sale = row.get('sale', {})
    identity = sale.get('modelIdentity')
    if (identity == 'oppo|find n6|2026|android' and sale.get('channel') == 'IIJ_MIO'
        and sale.get('retailer') == 'IIJmio' and sale.get('url') == 'https://www.iijmio.jp/device/'):
        sale['url'] = 'https://www.iijmio.jp/device/oppo/findn6.html'
        option = row.get('priceOption', {})
        if option.get('sourceUrl') == 'https://www.iijmio.jp/device/':
            option['sourceUrl'] = 'https://www.iijmio.jp/device/oppo/findn6.html'
        expected_prices.append(signature(row))
    elif (identity in {'samsung|galaxy s26|2026|android', 'samsung|galaxy s26+|2026|android'}
        and sale.get('channel') == 'IIJ_MIO' and sale.get('retailer') == 'IIJmio'
        and sale.get('url') == 'https://www.iijmio.jp/device/' and sale.get('storageGb') == 256):
        sale['url'] = 'https://www.iijmio.jp/info/iij/1772412502.html'
        expected_prices.append(signature(row))
    elif (identity == 'xiaomi|redmi note 17 pro max 5g|2026|android'
        and sale.get('channel') == 'IIJ_MIO' and sale.get('retailer') == 'IIJmio'
        and sale.get('url') == 'https://www.iijmio.jp/device/'):
        storage = sale.get('storageGb')
        detail_url = f"https://www.iijmio.jp/device/detail.html?key=REDMI_Note_17_Pro_Max_5G_{storage}GB"
        sale['url'] = detail_url
        option = row.get('priceOption', {})
        if option.get('sourceUrl') == 'https://www.iijmio.jp/device/':
            option['sourceUrl'] = detail_url
        expected_prices.append(signature(row))
    else:
        expected_prices.append(raw_signature)
for label, expected, actual in (
    ('variant', sorted(set(BASELINE['expectedVariantSignatures'])), variants),
    ('sales listing', expected_sales, sales),
    ('price option', expected_prices, prices),
):
    missing = set(expected) - set(actual) if label == 'variant' else Counter(expected) - Counter(actual)
    if missing:
        examples = sorted(missing)[:3] if isinstance(missing, set) else list(missing.elements())[:3]
        amount = len(missing) if isinstance(missing, set) else sum(missing.values())
        errors.append(f'{label}: {amount} baseline records missing; examples: {examples}')

if errors:
    print('FAIL: catalog preservation baseline regression')
    print('\n'.join('- ' + e for e in errors))
    raise SystemExit(1)
print('PASS: all 0.04.72 baseline identities, variants, sales listings, and price options are retained')
print(f"Baseline: {len(BASELINE['baselineModelIdentities'])} model identities / {len(set(BASELINE['expectedVariantSignatures']))} unique variants (314 source rows before approved merge) / {len(BASELINE['expectedSalesSignatures'])} listings / {len(BASELINE['expectedPriceSignatures'])} price options")
