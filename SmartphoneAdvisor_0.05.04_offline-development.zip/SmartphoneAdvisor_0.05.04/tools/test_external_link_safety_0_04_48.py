#!/usr/bin/env python3
"""Static regression checks for safe and transparent external links in 0.04.48."""
import json
from pathlib import Path
from urllib.parse import urlparse

from current_version import current_version_is_valid
ROOT = Path(__file__).resolve().parents[1]
CATALOG = ROOT / "app/src/main/assets/phones.json"
SOURCE = ROOT / "app/src/main/java/jp/smartphoneadvisor/app/MainActivity.kt"
BUILD = ROOT / "app/build.gradle.kts"
GENERAL_PATHS = {
    ("mineo.jp", "/device/smartphone"),
    ("www.iijmio.jp", "/device"),
    ("shop.uqmobile.jp", "/shop/lineup"),
    ("network.mobile.rakuten.co.jp", "/product/smartphone"),
    ("buy.mi.com", "/jp/products/all"),
    ("www.ymobile.jp", "/lineup/simfree"),
    ("jp.nothing.tech", "/collections/phones"),
    ("jp.nubia.com", "/collections/nubia-z-series"),
    ("www.softbank.jp", "/iphone/iphone-16"),
    ("www.softbank.jp", "/mobile/products/google-pixel/google-pixel-9-pro"),
    ("rog.asus.com", "/jp/phones/rog-phone-9-pro"),
    ("store.google.com", "/jp/config/pixel_11_pro"),
}


def is_safe_web_url(raw: str) -> bool:
    u = urlparse(raw.strip())
    return u.scheme.lower() in {"https", "http"} and bool(u.hostname)


def is_general(raw: str) -> bool:
    if not is_safe_web_url(raw):
        return False
    u = urlparse(raw.strip())
    return (u.hostname or "", u.path.rstrip("/")) in GENERAL_PATHS


def main() -> int:
    data = json.loads(CATALOG.read_text(encoding="utf-8"))
    source = SOURCE.read_text(encoding="utf-8")
    build = BUILD.read_text(encoding="utf-8")
    errors = []
    all_urls = {
        s.get("url")
        for p in data.get("phones", [])
        for v in p.get("variants", [])
        for s in v.get("sales", [])
        if s.get("url")
    }
    for url in all_urls:
        if not is_safe_web_url(url):
            errors.append(f"catalog contains unsafe/non-web URL: {url!r}")
    general = sorted(url for url in all_urls if is_general(url))
    for host, path in sorted(GENERAL_PATHS):
        if not is_general(f"https://{host}{path}/"):
            errors.append(f"general URL not recognized: {host}{path}")
    if is_general("https://www.ymobile.jp/lineup/smartphone/pixel10a/"):
        errors.append("model-specific Y!mobile URL incorrectly classified as general")
    if is_safe_web_url("javascript:alert(1)"):
        errors.append("javascript scheme accepted")
    if is_safe_web_url("file:///etc/passwd"):
        errors.append("file scheme accepted")
    if is_safe_web_url("https:///missing-host"):
        errors.append("hostless https URL accepted")
    if "private fun safeExternalWebUri(rawUrl: String): Uri?" not in source:
        errors.append("safe external URL validator missing")
    if "safeExternalWebUri(url)?.let { safeUri ->" not in source:
        errors.append("external intent does not use validated URI")
    if 'Text("価格の出典を開く")' not in source:
        errors.append("neutral price-source label missing")
    if 'Text("価格の根拠・公式情報を開く")' in source:
        errors.append("price source still labelled as official regardless of source")
    if not current_version_is_valid(build):
        errors.append("app version mismatch")
    print("SmartphoneAdvisor 0.04.49 external link safety regression")
    print(f"Unique catalogue URLs: {len(all_urls)}")
    print(f"Recognized general listing URLs: {len(general)}")
    print("Unsafe test URLs rejected: javascript, file, hostless https")
    print(f"Errors: {len(errors)}")
    for err in errors:
        print(f"FAIL: {err}")
    if errors:
        return 1
    print("PASS: URLs are constrained to HTTP(S) with hosts; price-source wording is neutral; listing-page labels remain distinct")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
