#!/usr/bin/env python3
"""Guard comparison UI against separate row-value formatters drifting apart."""
from pathlib import Path

root = Path(__file__).resolve().parents[1]
source = (root / 'app/src/main/java/jp/smartphoneadvisor/app/MainActivity.kt').read_text(encoding='utf-8')
comparison_start = source.index('private fun ComparisonScreen(')
comparison_end = source.index('\nprivate fun priceTypeLabelJa(', comparison_start)
comparison = source[comparison_start:comparison_end]

assert 'val rows: List<Pair<String, (ComparisonRow) -> String>> = listOf(' in comparison, \
    'comparison rows should store a single formatter per row'
assert 'val visibleRows = if (differentOnly) rows.filter { row -> items.map(row.second).distinct().size > 1 } else rows' in comparison, \
    'different-only filtering must use the shared row formatter'
assert 'val values = orderedItems.map(row.second)' in comparison, \
    'display values must use the same formatter in either sort mode'
assert 'comparisonValueForRow(' not in source, \
    'obsolete second formatter must be removed to prevent value drift'
assert comparison.count('"通常価格（販売先・色別）" to { item ->') == 1
assert comparison.count('"条件付き価格（通常価格と別）" to { item ->') == 1
for label in ('"重量"', '"本体サイズ"', '"RAM"', '"ストレージ"', '"おサイフケータイ"', '"microSD"'):
    assert label in comparison, f'comparison row disappeared: {label}'

print('PASS: comparison values have one formatter per row')
print('PASS: different-only filtering and condition-priority ordering share the same formatter')
print('PASS: key comparison rows remain present')
