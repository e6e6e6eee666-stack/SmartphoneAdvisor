#!/usr/bin/env python3
"""Regression guard for IIJmio's MIVE Kesuma official normal price."""
import json
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
data = json.loads((ROOT / "app/src/main/assets/phones.json").read_text(encoding="utf-8"))
phone = next(p for p in data["phones"] if p["id"] == "ALT:MIVEケースマ:2026")
variant = next(v for v in phone["variants"] if v.get("storageGb") == 32 and v.get("ramGb") == 3)
sale = next(s for s in variant["sales"] if s.get("channel") == "IIJ_MIO" and s.get("retailer") == "IIJmio")
assert sale["modelNumber"] is None
assert sale["availability"] == "AVAILABLE"
assert sale["url"] == "https://www.iijmio.jp/device/alt/mive-kesuma.html"
assert len(sale["priceOptions"]) == 1
price = sale["priceOptions"][0]
assert (price["priceYen"], price["priceType"]) == (34800, "NORMAL")
assert price["sourceUrl"] == "https://www.iijmio.jp/info/iij/1787302297.html"
assert price["checkedAt"] == "2026-10-21"
assert "32,800円" in price["conditions"] and "通常価格" in price["conditions"]
actual = {
 "phoneModels": len(data["phones"]),
 "variants": sum(len(p.get("variants", [])) for p in data["phones"]),
 "salesListings": sum(len(v.get("sales", [])) for p in data["phones"] for v in p.get("variants", [])),
 "priceOptions": sum(len(s.get("priceOptions", [])) for p in data["phones"] for v in p.get("variants", []) for s in v.get("sales", [])),
 "auditFindings": len(data.get("auditFindings", [])),
}
assert data["counts"] == actual
assert actual == {"phoneModels": 195, "variants": 315, "salesListings": 511, "priceOptions": 100, "auditFindings": 45}
print("PASS: MIVE Kesuma IIJmio normal price and source integrity")
