"""Regression: five existing sales rows receive source-qualified normal prices."""
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
data=json.loads((ROOT/'app/src/main/assets/phones.json').read_text(encoding='utf-8'))
expected=[
 ('Samsung:Galaxy S26:2026',256,'IIJ_MIO',136400,'https://www.iijmio.jp/info/iij/1772412502.html','公式端末ラインアップ'),
 ('Samsung:Galaxy S26+:2026',256,'IIJ_MIO',169920,'https://www.iijmio.jp/info/iij/1772412502.html','公式端末ラインアップ'),
 ('Samsung:Galaxy S26 Ultra:2026',256,'IIJ_MIO',218900,'https://www.iijmio.jp/device/samsung/galaxy-s26-ultra.html','公式端末ラインアップ'),
 ('Sony:Xperia 1 VIII:2026',256,'AU',269800,'https://www.au.com/mobile/product/smartphone/xperia1m8/','独立再取得は未完了'),
 ('Sony:Xperia 10 VIII:2026',128,'AU',98800,'https://www.au.com/mobile/product/smartphone/xperia_10_viii/','独立再取得は未完了'),
]
for model,storage,channel,price,url,phrase in expected:
 p=next(p for p in data['phones'] if p['id']==model)
 v=next(v for v in p['variants'] if v['storageGb']==storage)
 sales=[s for s in v['sales'] if s['channel']==channel]
 assert len(sales)==1,(model,storage,channel,'sales entry duplicated or missing')
 if model in {'Samsung:Galaxy S26:2026','Samsung:Galaxy S26+:2026'}: assert sales[0].get('url')==url,(model,'sale URL must match the official price evidence URL')
 opts=sales[0].get('priceOptions',[])
 normals=[o for o in opts if o.get('priceType')=='NORMAL']
 assert len(normals)==1,(model,'expected one NORMAL option',normals)
 o=normals[0]
 assert o['priceYen']==price and o['sourceUrl']==url and o['checkedAt']=='2026-10-21',(model,o)
 assert phrase in o['conditions'],(model,o['conditions'])
actual={'phoneModels':len(data['phones']),'variants':sum(len(p.get('variants',[])) for p in data['phones']),'salesListings':sum(len(v.get('sales',[])) for p in data['phones'] for v in p.get('variants',[])),'priceOptions':sum(len(s.get('priceOptions',[])) for p in data['phones'] for v in p.get('variants',[]) for s in v.get('sales',[])),'auditFindings':len(data.get('auditFindings',[]))}
assert actual=={'phoneModels':195,'variants':315,'salesListings':511,'priceOptions':100,'auditFindings':45},actual
assert data['counts']==actual,(data['counts'],actual)
print('PASS: five targeted NORMAL price options, source provenance, uniqueness and declared counts')
