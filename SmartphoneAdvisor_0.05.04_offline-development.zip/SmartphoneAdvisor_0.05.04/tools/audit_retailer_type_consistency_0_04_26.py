from pathlib import Path
import json
from collections import Counter

root = Path(__file__).resolve().parents[1]
source = (root / 'app/src/main/java/jp/smartphoneadvisor/app/data/catalog/PhoneCatalogRoomImporter.kt').read_text()
checks = {
    'expected retailer type is derived before resolving retailer': 'val expectedRetailerType = when (channel)' in source,
    'existing retailer type mismatch is explicitly detected': 'retailers.single().type != expectedRetailerType' in source,
    'type mismatch records a conflict': 'type mismatch (Room=' in source,
    'type mismatch does not reuse mismatched retailer': 'retailers.single().type != expectedRetailerType' in source and source.find('return@saleLoop', source.find('retailers.single().type != expectedRetailerType')) < source.find('retailers.size == 1 ->', source.find('retailers.single().type != expectedRetailerType')),
    'new retailer uses the expected type': 'type = expectedRetailerType' in source,
    'official status remains conservative': 'official = false' in source,
    'product URL is not reused as retailer homepage': 'websiteUrl = null' in source,
}
asset = json.loads((root / 'app/src/main/assets/phones.json').read_text(encoding='utf-8'))
channels = Counter(s['channel'] for p in asset.get('phones', []) for v in p.get('variants', []) for s in v.get('sales', []))
checks['catalog contains recognized channel classes'] = all(k in channels for k in ('SIM_FREE', 'DOCOMO', 'AU', 'SOFTBANK', 'RAKUTEN', 'MINEO', 'IIJ_MIO'))
for name, ok in checks.items():
    print(f'{"PASS" if ok else "FAIL"}: {name}')
print('Sales entries by channel:', dict(sorted(channels.items())))
if not all(checks.values()):
    raise SystemExit(1)
print(f'PASS: {sum(checks.values())}/{len(checks)} checks')
