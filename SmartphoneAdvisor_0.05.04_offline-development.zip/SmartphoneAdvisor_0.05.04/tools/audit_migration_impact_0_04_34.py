#!/usr/bin/env python3
"""Read-only static preflight for planning Room relationship constraints in 0.04.34."""
from pathlib import Path
import json
import re

ROOT = Path(__file__).resolve().parents[1]
models = (ROOT / "app/src/main/java/jp/smartphoneadvisor/app/data/PhoneModels.kt").read_text(encoding="utf-8")
db = (ROOT / "app/src/main/java/jp/smartphoneadvisor/app/data/AppDatabase.kt").read_text(encoding="utf-8")
importer = (ROOT / "app/src/main/java/jp/smartphoneadvisor/app/data/catalog/PhoneCatalogRoomImporter.kt").read_text(encoding="utf-8")
gradle = (ROOT / "app/build.gradle.kts").read_text(encoding="utf-8")
json_path = ROOT / "app/src/main/assets/phones.json"
catalog = json.loads(json_path.read_text(encoding="utf-8"))

sales = listings = blank_urls = 0
identity_counts = {}
for phone in catalog.get("phones", []):
    for variant in phone.get("variants", []):
        variant_key = (phone.get("id"), variant.get("storageGb"), variant.get("ramGb"))
        for item in variant.get("sales", []):
            sales += 1
            if not str(item.get("url") or "").strip():
                blank_urls += 1
            key = (variant_key, item.get("channel"), item.get("retailer"))
            identity_counts[key] = identity_counts.get(key, 0) + 1
            listings += 1
source_duplicate_identities = {k: v for k, v in identity_counts.items() if v > 1}

checks = {
    "Room schema currently version 13": bool(re.search(r"version\s*=\s*13", db)),
    "No migration 13->14 is registered yet (planning only)": "Migration(13, 14)" not in db,
    "sales_variant references deviceVariantId without FK annotation": "tableName = \"sales_variant\"" in models and "ForeignKey(entity = DeviceVariantEntity" not in models,
    "product_listing references salesVariantId and retailerId": all(x in models[models.find('data class ProductListingEntity'):models.find('data class CampaignEntity')] for x in ["salesVariantId", "retailerId"]),
    "price_record_v2 references productListingId": "val productListingId: Long" in models[models.find('data class PriceRecordV2Entity'):models.find('data class FavoriteDeviceEntity')],
    "product_listing already declares unique (salesVariantId, retailerId) index": 'Index(value = ["salesVariantId", "retailerId"], unique = true)' in models,
    "migration 6->7 already creates matching product_listing unique index": "index_product_listing_salesVariantId_retailerId" in db,
    "sales_variant already declares unique identity index": 'Index(value = ["deviceVariantId", "salesChannel", "modelNumber"], unique = true)' in models,
    "migration 6->7 already creates matching sales_variant unique index": "index_sales_variant_deviceVariantId_salesChannel_modelNumber" in db,
    "importer refuses blank URL instead of inserting listing": "if (url == null)" in importer and "listingsSkippedNoUrl++" in importer,
    "importer preserves conflicting existing listing instead of overwriting": "preserved without overwrite" in importer,
    "importer checks duplicate identities before reusing them": "existingListings.size > 1" in importer and "existingSales.size > 1" in importer,
    "catalog JSON is present and parseable": json_path.exists() and isinstance(catalog.get("phones"), list),
    "version metadata is 0.04.34 / 83": 'versionName = "0.04.34"' in gradle and "versionCode = 83" in gradle,
}
for name, ok in checks.items():
    print(f"{'PASS' if ok else 'FAIL'} | {name}")
print(f"SOURCE_JSON | models={catalog.get('counts', {}).get('phoneModels')} variants={catalog.get('counts', {}).get('variants')} sales={sales} blank_urls={blank_urls} duplicate_model_variant_channel_retailer_identities={len(source_duplicate_identities)}")
print(f"RESULT: {sum(checks.values())}/{len(checks)} passed")
raise SystemExit(0 if all(checks.values()) else 1)
