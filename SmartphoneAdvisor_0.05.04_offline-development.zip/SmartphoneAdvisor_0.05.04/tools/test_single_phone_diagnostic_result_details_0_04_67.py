#!/usr/bin/env python3
"""Static regression guard for the one-phone diagnostic result detail display."""
from pathlib import Path
from current_version import current_version_is_valid
ROOT = Path(__file__).resolve().parents[1]
BUILD = (ROOT / "app/build.gradle.kts").read_text()
UI = (ROOT / "app/src/main/java/jp/smartphoneadvisor/app/ui/SinglePhoneDiagnosticScreen.kt").read_text()
errors = []
if not current_version_is_valid(BUILD):
    errors.append("current app version metadata is invalid")
for label in (
    '"主な仕様"', 'c.bodyHeightMm', 'c.bodyWidthMm', 'c.bodyThicknessMm',
    'c.weightG', 'c.displayRefreshRateHz', 'c.batteryCapacityMah',
    'c.chargingPowerW', 'c.rearTelephotoMp', 'c.osaifuKeitai', 'c.microSd',
    'c.waterproof', 'c.updateSupportYears', 'c.availabilityStatus',
    'result.reasons.forEach', 'result.cautions.forEach',
):
    if label not in UI:
        errors.append(f"diagnostic result does not display required detail: {label}")
if '?: "未確認"' not in UI:
    errors.append("unknown or missing specifications must be displayed as unconfirmed")
if 'formatMillimeters(c.bodyHeightMm)' not in UI or 'formatMillimeters(c.bodyWidthMm)' not in UI or 'formatMillimeters(c.bodyThicknessMm)' not in UI:
    errors.append("body dimensions must be shown in mm, not inferred inches")
if errors:
    print("FAIL")
    print("\n".join(f"- {e}" for e in errors))
    raise SystemExit(1)
print("PASS: diagnostic result exposes specs, must-have support states, sale status, reasons, cautions, and explicit unknowns")
