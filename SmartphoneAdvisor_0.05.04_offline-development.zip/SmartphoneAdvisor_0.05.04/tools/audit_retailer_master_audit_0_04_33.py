from pathlib import Path
root = Path(__file__).resolve().parents[1]
main = (root / 'app/src/main/java/jp/smartphoneadvisor/app/MainActivity.kt').read_text()
auditor = (root / 'app/src/main/java/jp/smartphoneadvisor/app/data/catalog/RetailerMasterAudit.kt').read_text()
tests = (root / 'app/src/test/java/jp/smartphoneadvisor/app/data/catalog/RetailerMasterAuditTest.kt').read_text()
gradle = (root / 'app/build.gradle.kts').read_text()
checks = {
    'normalized names use trim and Locale.ROOT lowercase': '.trim().lowercase(java.util.Locale.ROOT)' in auditor,
    'normalized spelling variants are reported': 'normalizedNameVariants' in auditor,
    'multiple website URLs are reported': 'mixedWebsiteUrls' in auditor,
    'invalid URLs are checked with java.net.URI': 'java.net.URI(trimmed)' in auditor,
    'only absolute HTTP(S) URLs with a host are valid': 'uri.scheme.equals("https", ignoreCase = true)' in auditor and '!uri.host.isNullOrBlank()' in auditor,
    'raw whitespace around URLs is separately reported': 'whitespaceWebsiteUrls' in auditor and 'raw != raw.trim()' in auditor,
    'invalid URL details are logged': 'report.invalidWebsiteUrls.entries' in main,
    'whitespace URL details are logged': 'report.whitespaceWebsiteUrls.entries' in main,
    'tests cover invalid scheme and missing host': 'javascript:alert(1)' in tests and 'https:///path' in tests,
    'tests cover whitespace and valid URL': ' https://example.com ' in tests and 'https://example.com/path' in tests,
    'audit remains read-only': not any(token in auditor for token in ('insertRetailer', 'updateRetailer', 'deleteRetailer')),
    'version metadata updated': 'versionCode = 82' in gradle and 'versionName = "0.04.33"' in gradle,
}
for name, ok in checks.items():
    print(f'{"PASS" if ok else "FAIL"}: {name}')
if not all(checks.values()):
    raise SystemExit(1)
print(f'PASS: {sum(checks.values())}/{len(checks)} checks')
