#!/usr/bin/env python3
"""Prioritize price-gap remediation by source specificity and model-number availability.

No prices are inferred. This report identifies records where a reviewer may struggle
 to verify the exact model/variant and where the URL is a retailer category page.
"""
import csv
import hashlib
import json
from collections import Counter
from pathlib import Path
from urllib.parse import urlparse

ROOT = Path(__file__).resolve().parents[1]
CATALOG = ROOT / "app/src/main/assets/phones.json"
CSV_OUT = ROOT / "CATALOG_PRICE_GAP_FOLLOWUP_2026-10-21.csv"
MD_OUT = ROOT / "CATALOG_PRICE_GAP_FOLLOWUP_2026-10-21.md"
GENERIC_PATHS = {"/device", "/devices", "/phones", "/products", "/smartphone", "/mobile"}

def url_specificity(url):
    if not url:
        return "MISSING_URL"
    parsed = urlparse(url)
    path = parsed.path.rstrip("/") or "/"
    if path in GENERIC_PATHS or (parsed.netloc.lower() == "www.iijmio.jp" and path == "/device"):
        return "CATEGORY_OR_TOP_PAGE"
    return "ITEM_OR_BRAND_PAGE_REVIEW_REQUIRED"

def main():
    raw = CATALOG.read_bytes()
    data = json.loads(raw.decode("utf-8"))
    rows = []
    counts = Counter()
    for phone in data.get("phones", []):
        for variant in phone.get("variants", []):
            for sale in variant.get("sales", []):
                if sale.get("priceOptions"):
                    continue
                status = sale.get("availability", "UNKNOWN")
                model_number = sale.get("modelNumber") or ""
                specificity = url_specificity(sale.get("url") or "")
                if status == "AVAILABLE" and specificity == "CATEGORY_OR_TOP_PAGE":
                    priority = "P1: available, unpriced, generic sales page"
                elif status == "AVAILABLE" and not model_number:
                    priority = "P2: available, unpriced, model number missing"
                elif status == "AVAILABLE":
                    priority = "P3: available, unpriced, verify exact price"
                else:
                    priority = "P4: confirm availability before price research"
                counts[(status, specificity, not bool(model_number))] += 1
                rows.append({
                    "phoneId": phone.get("id", ""),
                    "manufacturer": phone.get("manufacturer", ""),
                    "model": phone.get("model", ""),
                    "storageGb": variant.get("storageGb", ""),
                    "ramGb": "" if variant.get("ramGb") is None else variant.get("ramGb"),
                    "channel": sale.get("channel", ""),
                    "retailer": sale.get("retailer", ""),
                    "modelNumber": model_number,
                    "availability": status,
                    "productUrl": sale.get("url") or "",
                    "urlSpecificity": specificity,
                    "priceOptionCount": 0,
                    "followupPriority": priority,
                })
    fields = ["phoneId", "manufacturer", "model", "storageGb", "ramGb", "channel", "retailer", "modelNumber", "availability", "productUrl", "urlSpecificity", "priceOptionCount", "followupPriority"]
    priority_order = {"P1": 1, "P2": 2, "P3": 3, "P4": 4}
    rows.sort(key=lambda r: (priority_order[r["followupPriority"][:2]], r["manufacturer"], r["model"], int(r["storageGb"] or 0), r["channel"]))
    with CSV_OUT.open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader(); writer.writerows(rows)
    available = [r for r in rows if r["availability"] == "AVAILABLE"]
    missing_model = [r for r in rows if not r["modelNumber"]]
    available_missing_model = [r for r in available if not r["modelNumber"]]
    generic = [r for r in rows if r["urlSpecificity"] == "CATEGORY_OR_TOP_PAGE"]
    available_generic = [r for r in available if r["urlSpecificity"] == "CATEGORY_OR_TOP_PAGE"]
    summary = [
        "# 価格欠損フォローアップ監査（2026-10-21）", "",
        f"- 対象JSON SHA-256: `{hashlib.sha256(raw).hexdigest()}`",
        f"- 価格未登録の販売登録: {len(rows)}件（価格は補完していない）",
        f"- 販売中・価格未登録: {len(available)}件",
        f"- 型番未登録: {len(missing_model)}件（販売中: {len(available_missing_model)}件）",
        f"- カテゴリ/トップページURL: {len(generic)}件（販売中: {len(available_generic)}件）",
        "", "## 優先順位", "",
        "1. P1: 販売中・価格未登録かつカテゴリ/トップページURL。機種固有の販売ページを特定する。",
        "2. P2: 販売中・価格未登録かつ型番未登録。容量・型番・販売条件の照合を先に行う。",
        "3. P3: 販売中・価格未登録で上記以外。税込一括価格と割引/返却条件を確認する。",
        "4. P4: 販売状態が販売中と確定していない。価格調査の前に販売状態を確認する。",
        "", "## 注意", "",
        "URLが個別商品ページに見える場合でも、現行価格・購入可能性・対象容量が確認済みとは限らない。各価格は公式根拠、税込条件、確認日を記録してから登録する。",
        "", "詳細は `CATALOG_PRICE_GAP_FOLLOWUP_2026-10-21.csv`。", ""
    ]
    MD_OUT.write_text("\n".join(summary), encoding="utf-8")
    print(f"PASS: follow-up audit rows={len(rows)} available={len(available)} missingModelNumber={len(missing_model)} availableMissingModelNumber={len(available_missing_model)} genericUrl={len(generic)} availableGenericUrl={len(available_generic)}")

if __name__ == "__main__":
    main()
