#!/usr/bin/env python3
"""Exercise the same preflight gates that can cause JSON-to-Room imports to skip data."""
import json
import re
from datetime import date
from pathlib import Path
from urllib.parse import urlparse

ROOT = Path(__file__).resolve().parents[1]
JSON_PATH = ROOT / 'app/src/main/assets/phones.json'
IMPORTER_PATH = ROOT / 'app/src/main/java/jp/smartphoneadvisor/app/data/catalog/PhoneCatalogRoomImporter.kt'
DATA = json.loads(JSON_PATH.read_text(encoding='utf-8'))
SOURCE = IMPORTER_PATH.read_text(encoding='utf-8')
ALLOWED_CHANNELS = {'SIM_FREE','DOCOMO','AU','SOFTBANK','RAKUTEN','UQ_MOBILE','Y_MOBILE','IIJ_MIO','MINEO','MVNO','OTHER'}
ALLOWED_AVAILABILITY = {'AVAILABLE','LIMITED','OUT_OF_STOCK','DISCONTINUED','PREORDER','UNKNOWN'}
ALLOWED_PRICE_TYPES = {'NORMAL','SALE','CAMPAIGN','MNP','NEW_CONTRACT','MODEL_CHANGE','CONTRACT_REQUIRED','OTHER'}
errors = []
phones = DATA.get('phones', [])
seen_ids, seen_models = set(), set()
sales_count = price_count = 0
missing_url_count = missing_checked_at_count = 0

def https_url(value):
    parsed = urlparse(value or '')
    return parsed.scheme.lower() == 'https' and bool(parsed.hostname)

def http_url(value):
    parsed = urlparse(value or '')
    return parsed.scheme.lower() in {'http', 'https'} and bool(parsed.hostname)

if not phones:
    errors.append('catalog has no phones')
for pi, phone in enumerate(phones):
    label = f"phones[{pi}] {phone.get('model', '<no model>')}"
    pid = phone.get('id')
    if not isinstance(pid, str) or not pid.strip(): errors.append(f'{label}: blank id')
    elif pid in seen_ids: errors.append(f'{label}: duplicate id {pid}')
    seen_ids.add(pid)
    if not phone.get('isJapanOfficial'): errors.append(f'{label}: importer will skip non-Japan-official model')
    if phone.get('platform') not in {'ANDROID','IPHONE'}: errors.append(f'{label}: unsupported platform')
    if not isinstance(phone.get('releaseYear'), int) or not 2000 <= phone['releaseYear'] <= 2100: errors.append(f'{label}: invalid releaseYear')
    identity = (phone.get('manufacturer'), phone.get('model'), phone.get('platform'), phone.get('releaseYear'))
    if identity in seen_models: errors.append(f'{label}: duplicate model identity {identity}')
    seen_models.add(identity)
    variants = phone.get('variants', [])
    if not variants: errors.append(f'{label}: no variants')
    seen_variants = set()
    for vi, variant in enumerate(variants):
        vlabel = f'{label} variant[{vi}]'
        storage, ram = variant.get('storageGb'), variant.get('ramGb')
        if not isinstance(storage, int) or storage <= 0: errors.append(f'{vlabel}: invalid storageGb')
        if ram is not None and (not isinstance(ram, int) or ram <= 0): errors.append(f'{vlabel}: invalid ramGb')
        vkey = (storage, ram)
        if vkey in seen_variants: errors.append(f'{vlabel}: duplicate storage/RAM identity {vkey}')
        seen_variants.add(vkey)
        seen_sales = set()
        for si, sale in enumerate(variant.get('sales', [])):
            sales_count += 1
            slabel = f'{vlabel} sale[{si}]'
            channel, retailer = sale.get('channel'), sale.get('retailer')
            if channel not in ALLOWED_CHANNELS: errors.append(f'{slabel}: unsupported channel {channel}')
            if not isinstance(retailer, str) or not retailer.strip() or retailer != retailer.strip(): errors.append(f'{slabel}: blank or untrimmed retailer')
            availability = sale.get('availability')
            if availability not in ALLOWED_AVAILABILITY: errors.append(f'{slabel}: unsupported availability {availability}')
            skey = (channel, retailer, sale.get('modelNumber'))
            if skey in seen_sales: errors.append(f'{slabel}: duplicate sales identity {skey}')
            seen_sales.add(skey)
            url = sale.get('url')
            if not url: missing_url_count += 1
            elif url != url.strip() or not http_url(url): errors.append(f'{slabel}: invalid or untrimmed listing URL')
            for oi, option in enumerate(sale.get('priceOptions', [])):
                price_count += 1
                plabel = f'{slabel} price[{oi}]'
                price = option.get('priceYen')
                if not isinstance(price, int) or price <= 0: errors.append(f'{plabel}: invalid priceYen')
                if option.get('priceType') not in ALLOWED_PRICE_TYPES: errors.append(f'{plabel}: unsupported priceType')
                checked = option.get('checkedAt')
                if not checked:
                    missing_checked_at_count += 1
                    errors.append(f'{plabel}: importer silently skips option without checkedAt')
                else:
                    try:
                        if date.fromisoformat(checked).isoformat() != checked: errors.append(f'{plabel}: checkedAt not canonical YYYY-MM-DD')
                    except (ValueError, TypeError): errors.append(f'{plabel}: invalid checkedAt')
                if not https_url(option.get('sourceUrl')): errors.append(f'{plabel}: sourceUrl must be valid HTTPS URL')
                color = option.get('color')
                if color is not None and (not isinstance(color, str) or not color.strip()): errors.append(f'{plabel}: blank color should be null')

# Guard the assumptions this test is meant to protect against changes in importer implementation.
for token in ('if (!phone.isJapanOfficial)', 'if (checkedAt == null)', 'LocalDate.parse(it)', 'PhoneCatalogRoomImporter'):
    if token not in SOURCE and token != 'PhoneCatalogRoomImporter': errors.append(f'importer implementation changed; expected gate not found: {token}')
if len(phones) != 195: errors.append(f'expected 195 phones, got {len(phones)}')
if sales_count != 511: errors.append(f'expected 511 sales rows, got {sales_count}')
if price_count != 100: errors.append(f'expected 100 price options, got {price_count}')
if missing_url_count: errors.append(f'{missing_url_count} sales rows have no URL and will not create ProductListing rows')
if missing_checked_at_count: errors.append(f'{missing_checked_at_count} price options have no checkedAt and will be skipped')

if errors:
    print(f'FAIL: JSON-to-Room import preflight ({len(errors)} issues)')
    print('\n'.join('- ' + e for e in errors[:100]))
    raise SystemExit(1)
print('PASS: JSON-to-Room import preflight')
print(f'  Japan-official models: {len(phones)}')
print(f'  Sales rows: {sales_count}; URL-less rows: {missing_url_count}')
print(f'  Price options: {price_count}; missing checkedAt: {missing_checked_at_count}')
print('  All price options meet importer date/source/type/value requirements.')
