#!/usr/bin/env python3
"""Static preflight for Room schema export and instrumentation test setup."""
from pathlib import Path
import re
ROOT = Path(__file__).resolve().parents[1]
DB = ROOT / "app/src/main/java/jp/smartphoneadvisor/app/data/AppDatabase.kt"
BUILD = ROOT / "app/build.gradle.kts"
README = ROOT / "app/schemas/README_0.04.35.md"
db = DB.read_text(encoding="utf-8")
build = BUILD.read_text(encoding="utf-8")
checks = {
    "Room schema export enabled": "exportSchema = true" in db,
    "KSP schema output path configured": 'arg("room.schemaLocation", "$projectDir/schemas")' in build,
    "instrumentation runner configured": 'testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"' in build,
    "Room testing dependency matches runtime version": 'androidTestImplementation("androidx.room:room-testing:2.8.5")' in build and 'implementation("androidx.room:room-runtime:2.8.5")' in build,
    "AndroidX instrumentation JUnit dependency present": 'androidTestImplementation("androidx.test.ext:junit:1.3.0")' in build,
    "AndroidX runner dependency present": 'androidTestImplementation("androidx.test:runner:1.7.0")' in build,
    "Room schema version remains 13 until tested migration exists": bool(re.search(r"version\s*=\s*13", db)) and "Migration(13, 14)" not in db,
    "No destructive migration fallback added": "fallbackToDestructiveMigration" not in db,
    "Schema directory documents generated snapshots only": README.exists() and "No schema JSON is fabricated" in README.read_text(encoding="utf-8"),
    "App version is 0.04.35 / code 84": 'versionName = "0.04.35"' in build and "versionCode = 84" in build,
}
for label, ok in checks.items():
    print(f"{'PASS' if ok else 'FAIL'} | {label}")
print(f"RESULT: {sum(checks.values())}/{len(checks)} passed")
raise SystemExit(0 if all(checks.values()) else 1)
