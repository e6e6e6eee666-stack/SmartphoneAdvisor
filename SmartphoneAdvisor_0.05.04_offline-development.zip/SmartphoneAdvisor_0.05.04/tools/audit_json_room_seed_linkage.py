#!/usr/bin/env python3
"""Compare the phones.json variant catalog with the hand-authored Room seed.

This is a static source audit, not a Room runtime test. It deliberately does not
claim that a JSON record missing from SeedData is an invalid record: it measures
how much of the JSON catalog is represented by the current smoke-test seed.
"""
from __future__ import annotations
import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
JSON_PATH = ROOT / "app/src/main/assets/phones.json"
SEED_PATH = ROOT / "app/src/main/java/jp/smartphoneadvisor/app/data/SeedData.kt"
OUT_PATH = ROOT / "JSON_ROOM_LINKAGE_AUDIT_0.04.22.txt"


def constructor_blocks(source: str, name: str) -> list[str]:
    needle = name + "("
    blocks: list[str] = []
    pos = 0
    while True:
        start = source.find(needle, pos)
        if start < 0:
            break
        i = start + len(name)
        depth = 0
        in_string = False
        escaped = False
        while i < len(source):
            char = source[i]
            if in_string:
                if escaped:
                    escaped = False
                elif char == "\\":
                    escaped = True
                elif char == '"':
                    in_string = False
            else:
                if char == '"':
                    in_string = True
                elif char == "(":
                    depth += 1
                elif char == ")":
                    depth -= 1
                    if depth == 0:
                        i += 1
                        break
            i += 1
        blocks.append(source[start:i])
        pos = i
    return blocks


def parse_seed_values(block: str) -> tuple | None:
    raw = dict(re.findall(
        r'\b(manufacturer|model|platform|year|storageGb|ramGb)\s*=\s*("(?:[^"\\]|\\.)*"|null|-?\d+)',
        block,
    ))
    fields = ("manufacturer", "model", "platform", "year", "storageGb", "ramGb")
    if not all(key in raw for key in fields):
        return None

    def convert(value: str):
        if value == "null":
            return None
        if value.startswith('"'):
            return json.loads(value)
        return int(value)

    values = tuple(convert(raw[key]) for key in fields)
    return values


def variant_key(manufacturer, model, platform, year, storage, ram):
    return (manufacturer, model, platform, year, storage, ram)


def main() -> int:
    catalog = json.loads(JSON_PATH.read_text(encoding="utf-8"))
    source = SEED_PATH.read_text(encoding="utf-8")
    json_keys = set()
    for phone in catalog.get("phones", []):
        for variant in phone.get("variants", []):
            json_keys.add(variant_key(
                phone.get("manufacturer"), phone.get("model"), phone.get("platform"),
                phone.get("releaseYear"), variant.get("storageGb"), variant.get("ramGb"),
            ))

    seed_keys = set()
    for block in constructor_blocks(source, "PhoneSeed"):
        key = parse_seed_values(block)
        if key is not None:
            seed_keys.add(key)

    matched = json_keys & seed_keys
    seed_only = seed_keys - json_keys
    catalog_only = json_keys - seed_keys
    model_count = len(catalog.get("phones", []))
    variant_count = sum(len(phone.get("variants", [])) for phone in catalog.get("phones", []))
    matched_percent = (100.0 * len(matched) / len(json_keys)) if json_keys else 0.0

    lines = [
        "SmartphoneAdvisor JSON / Room seed linkage audit 0.04.22",
        "Scope: static comparison of phones.json variants to PhoneSeed constructors in SeedData.kt.",
        "This is NOT a Room database count, Android build, or runtime test.",
        "",
        f"JSON models: {model_count}",
        f"JSON variants (raw count): {variant_count}",
        f"JSON unique variant keys: {len(json_keys)}",
        f"PhoneSeed constructors with parseable keys: {len(seed_keys)}",
        f"Exact JSON/seed variant key matches: {len(matched)}",
        f"Matched share of JSON unique variant keys: {matched_percent:.2f}%",
        f"Seed keys absent from JSON: {len(seed_only)}",
        f"JSON variant keys absent from PhoneSeed: {len(catalog_only)}",
        "",
        "Interpretation:",
        "- The PhoneSeed list is an initial smoke-test seed, not the full catalog.",
        "- JSON variants absent from PhoneSeed are not automatically invalid; this result quantifies the current gap.",
        "- Sales listings, price, feature attributes, and diagnostic eligibility are not validated by this key comparison.",
        "- The two additional verified models inserted by separate legacy logic are not counted as PhoneSeed constructors twice.",
        "",
        "JSON variants absent from PhoneSeed (first 30 sorted keys):",
    ]
    lines.extend("- " + " | ".join("null" if value is None else str(value) for value in key)
                 for key in sorted(catalog_only, key=lambda item: tuple("" if x is None else str(x) for x in item))[:30])
    lines += ["", "Seed keys absent from JSON:"]
    lines.extend("- " + " | ".join("null" if value is None else str(value) for value in key)
                 for key in sorted(seed_only, key=lambda item: tuple("" if x is None else str(x) for x in item)))
    OUT_PATH.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print("\n".join(lines[:17]))
    print(f"Report written: {OUT_PATH.relative_to(ROOT)}")
    if not json_keys:
        print("ERROR: no JSON variant keys found", file=sys.stderr)
        return 1
    if seed_only:
        print("ERROR: seed contains variants missing from JSON", file=sys.stderr)
        return 1
    print("STATIC AUDIT: PASS (no seed-only variant keys); catalog coverage gap is reported, not treated as an error.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
