#!/usr/bin/env python3
"""Regression test for nested price option completeness audit 0.04.55."""
import json, subprocess, sys
from pathlib import Path
from current_version import current_version_is_valid
ROOT=Path(__file__).resolve().parents[1]
def main():
    errors=[]; build=(ROOT/'app/build.gradle.kts').read_text(encoding='utf-8'); data=json.loads((ROOT/'app/src/main/assets/phones.json').read_text(encoding='utf-8'))
    if not current_version_is_valid(build): errors.append('version mismatch')
    listings=[(p,v,s) for p in data.get('phones',[]) for v in p.get('variants',[]) for s in v.get('sales',[])]
    options=[o for _,_,s in listings for o in s.get('priceOptions',[])]
    if len(listings)!=511: errors.append(f'expected 511 listings, got {len(listings)}')
    if len(options)!=100: errors.append(f'expected 100 nested price options, got {len(options)}')
    if not options or not all(isinstance(o.get('priceYen'),int) and o['priceYen']>0 and o.get('sourceUrl') and o.get('checkedAt') for o in options): errors.append('nested price options missing price/source/date')
    proc=subprocess.run([sys.executable,str(ROOT/'tools/audit_sales_fact_completeness_0_04_76.py')],cwd=ROOT,text=True,capture_output=True)
    if proc.returncode: errors.append('audit failed: '+proc.stdout+proc.stderr)
    report=ROOT/'SALES_FACT_COMPLETENESS_AUDIT_0.04.76.md'
    if not report.exists(): errors.append('report missing')
    else:
        t=report.read_text(encoding='utf-8')
        for phrase in ('0.04.72監査の訂正','価格オプション総数：100件','priceOptions未登録の販売登録：429件','sourceUrlとcheckedAtの両方あり：100件'):
            if phrase not in t: errors.append('report missing expected result: '+phrase)
    print(f'SmartphoneAdvisor 0.04.61 nested price audit regression: listings={len(listings)} options={len(options)} errors={len(errors)}')
    for e in errors: print('FAIL:',e)
    if errors:return 1
    print('PASS: nested priceOptions and provenance are counted accurately.')
    return 0
if __name__=='__main__': raise SystemExit(main())
