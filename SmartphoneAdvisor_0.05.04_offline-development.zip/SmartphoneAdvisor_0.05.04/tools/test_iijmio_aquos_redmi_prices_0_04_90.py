import json, unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
DATA=json.loads((ROOT/'app/src/main/assets/phones.json').read_text(encoding='utf-8'))
def sales_for(model, storage, channel='IIJ_MIO'):
 p=next(p for p in DATA['phones'] if p['model']==model)
 v=next(v for v in p['variants'] if v['storageGb']==storage)
 return next(s for s in v['sales'] if s['channel']==channel)
class IIJMioAquosRedmiPriceTest(unittest.TestCase):
 def test_aquos_wish6_detail_url_and_prices_are_source_backed(self):
  s=sales_for('AQUOS wish6',128)
  self.assertEqual(s['url'],'https://www.iijmio.jp/device/detail.html?key=AQUOS_wish6')
  self.assertEqual({(x['priceType'],x['priceYen']) for x in s['priceOptions']},{('NORMAL',49300),('MNP',39800)})
  self.assertTrue(all(x['sourceUrl'] and x['checkedAt']=='2026-10-20' for x in s['priceOptions']))
 def test_redmi_note_17_pro_max_official_listing_prices_for_both_capacities(self):
  expected={256:{('NORMAL',79800),('SALE',69800),('MNP',64980)},512:{('NORMAL',99980),('SALE',89980),('MNP',84800)}}
  for storage, prices in expected.items():
   s=sales_for('REDMI Note 17 Pro Max 5G',storage)
   expected_url=f"https://www.iijmio.jp/device/detail.html?key=REDMI_Note_17_Pro_Max_5G_{storage}GB"
   self.assertEqual(s['url'],expected_url)
   self.assertEqual({(x['priceType'],x['priceYen']) for x in s['priceOptions']},prices)
   self.assertTrue(all(x['sourceUrl']==expected_url and x['checkedAt']=='2026-10-20' for x in s['priceOptions']))

 def test_moto_g37j_official_detail_url_and_campaign_prices_are_source_backed(self):
  s=sales_for('moto g37j',128)
  self.assertEqual(s['url'],'https://www.iijmio.jp/device/motorola/moto-g37j.html')
  self.assertEqual({(x['priceType'],x['priceYen']) for x in s['priceOptions']},{('NORMAL',38800),('MNP',19800)})
  self.assertTrue(all(x['sourceUrl']=='https://www.iijmio.jp/info/iij/1784598862.html' and x['checkedAt']=='2026-10-20' for x in s['priceOptions']))


 def test_three_official_iijmio_pages_and_current_prices_are_source_backed(self):
  expected={
   'motorola edge 60':(128,'https://www.iijmio.jp/device/motorola/edge60.html',{('NORMAL',59800),('MNP',37800)}),
   'Nothing Phone (4a)':(128,'https://www.iijmio.jp/device/nothing/phone4a.html',{('NORMAL',59800),('MNP',44800)}),
   'Galaxy A57 5G':(128,'https://www.iijmio.jp/device/samsung/galaxy-a57-5g.html',{('NORMAL',79800),('MNP',59800)}),
  }
  for model,(storage,url,prices) in expected.items():
   sale=sales_for(model,storage)
   self.assertEqual(sale['url'],url)
   self.assertEqual({(x['priceType'],x['priceYen']) for x in sale['priceOptions']},prices)
   self.assertTrue(all(x['checkedAt']=='2026-10-20' for x in sale['priceOptions']))
   self.assertEqual(next(x['sourceUrl'] for x in sale['priceOptions'] if x['priceType']=='NORMAL'), {'motorola edge 60':'https://www.iijmio.jp/info/iij/1782785893.html','Nothing Phone (4a)':'https://www.iijmio.jp/info/iij/1779069706.html','Galaxy A57 5G':'https://www.iijmio.jp/info/iij/1779069706.html'}[model])
   self.assertEqual(next(x['sourceUrl'] for x in sale['priceOptions'] if x['priceType']=='MNP'),'https://www.iijmio.jp/info/iij/1780297417.html')

 def test_catalog_declared_counts_match(self):
  variants=sum(len(p['variants']) for p in DATA['phones'])
  sales=sum(len(v['sales']) for p in DATA['phones'] for v in p['variants'])
  prices=sum(len(s.get('priceOptions',[])) for p in DATA['phones'] for v in p['variants'] for s in v['sales'])
  self.assertEqual((DATA['counts']['phoneModels'],DATA['counts']['variants'],DATA['counts']['salesListings'],DATA['counts']['priceOptions']),(195,315,511,100))
  self.assertEqual((variants,sales,prices),(315,511,100))
if __name__=='__main__': unittest.main()
