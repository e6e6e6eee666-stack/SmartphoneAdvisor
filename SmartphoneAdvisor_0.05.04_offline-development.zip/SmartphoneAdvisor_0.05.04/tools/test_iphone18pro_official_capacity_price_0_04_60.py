#!/usr/bin/env python3
"""Regression: Apple Japan iPhone 18 Pro / Pro Max official capacities and SIM-free prices."""
import json
from pathlib import Path
from current_version import current_version_is_valid
ROOT=Path(__file__).resolve().parents[1]
def main():
 errors=[]
 build=(ROOT/'app/build.gradle.kts').read_text(encoding='utf-8')
 data=json.loads((ROOT/'app/src/main/assets/phones.json').read_text(encoding='utf-8'))
 if not current_version_is_valid(build): errors.append('version mismatch')
 expected={('iPhone 18 Pro',256):219800,('iPhone 18 Pro',512):254800,('iPhone 18 Pro',1024):324800,('iPhone 18 Pro',2048):429800,('iPhone 18 Pro Max',256):239800,('iPhone 18 Pro Max',512):274800,('iPhone 18 Pro Max',1024):344800,('iPhone 18 Pro Max',2048):449800}
 phones={p['model']:p for p in data['phones'] if p.get('model') in ('iPhone 18 Pro','iPhone 18 Pro Max')}
 for (model,cap),price in expected.items():
  phone=phones.get(model)
  variant=next((v for v in phone.get('variants',[]) if v.get('storageGb')==cap),None) if phone else None
  if not variant: errors.append(f'missing official capacity {model} {cap}GB'); continue
  matches=[s for s in variant.get('sales',[]) if s.get('channel')=='SIM_FREE' and s.get('retailer')=='Apple Store（SIMフリー）']
  if len(matches)!=1: errors.append(f'expected one Apple Store listing: {model} {cap}GB'); continue
  opts=matches[0].get('priceOptions',[])
  if len(opts)!=1 or opts[0].get('priceYen')!=price or opts[0].get('priceType')!='NORMAL' or opts[0].get('sourceUrl')!='https://www.apple.com/jp/shop/buy-iphone/iphone-18-pro' or opts[0].get('checkedAt')!='2026-10-16': errors.append(f'Apple official price mismatch: {model} {cap}GB')
  if cap==2048:
   for sale in variant.get('sales',[]):
    if sale.get('channel') in ('DOCOMO','AU','SOFTBANK','RAKUTEN') and sale.get('availability')!='UNKNOWN': errors.append(f'unverified carrier 2TB status not UNKNOWN: {model} {sale.get("channel")}')
 rows=[s for p in data['phones'] for v in p.get('variants',[]) for s in v.get('sales',[])]
 opts=[o for s in rows for o in s.get('priceOptions',[])]
 if len(data['phones'])!=195: errors.append('model count changed unexpectedly')
 if sum(len(p.get('variants',[])) for p in data['phones'])!=315: errors.append('expected 315 variants')
 if len(rows)!=511: errors.append(f'expected 511 sales listings, got {len(rows)}')
 if len(opts)!=100: errors.append(f'expected 100 price options, got {len(opts)}')
 if any(not isinstance(o.get('priceYen'),int) or o['priceYen']<=0 or not o.get('sourceUrl') or not o.get('checkedAt') for o in opts): errors.append('invalid price option')
 print(f'0.04.61 iPhone official capacity/price regression: variants={sum(len(p.get("variants",[])) for p in data["phones"])} listings={len(rows)} prices={len(opts)} errors={len(errors)}')
 for e in errors: print('FAIL:',e)
 if errors: return 1
 print('PASS: both models include 2TB; Apple Store prices are capacity-specific; unverified carrier 2TB statuses remain UNKNOWN.')
 return 0
if __name__=='__main__': raise SystemExit(main())
