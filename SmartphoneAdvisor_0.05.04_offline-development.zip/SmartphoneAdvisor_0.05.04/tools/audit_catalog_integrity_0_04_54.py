#!/usr/bin/env python3
"""Efficient static catalog integrity audit for SmartphoneAdvisor 0.04.54."""
import collections, json
from pathlib import Path
from urllib.parse import urlparse
ROOT=Path(__file__).resolve().parents[1]
CATALOG=ROOT/'app/src/main/assets/phones.json'; BUILD=ROOT/'app/build.gradle.kts'; OUT=ROOT/'CATALOG_INTEGRITY_AUDIT_0.04.54.txt'
CHANNELS={'SIM_FREE','DOCOMO','AU','SOFTBANK','RAKUTEN','UQ_MOBILE','Y_MOBILE','IIJ_MIO','MINEO','MVNO','OTHER'}
STATUSES={'AVAILABLE','LIMITED','OUT_OF_STOCK','DISCONTINUED','PREORDER','UNKNOWN'}
def main():
 data=json.loads(CATALOG.read_text(encoding='utf-8')); build=BUILD.read_text(encoding='utf-8'); phones=data.get('phones',[])
 variants=[(p,v) for p in phones for v in p.get('variants',[])]; sales=[(p,v,s) for p,v in variants for s in v.get('sales',[])]
 errors=[]; warnings=[]; ids=[p.get('id') for p in phones]; identities=[(p.get('manufacturer'),p.get('model'),p.get('platform'),p.get('releaseYear')) for p in phones]
 if len(ids)!=len(set(ids)): errors.append('duplicate model IDs')
 if len(identities)!=len(set(identities)): errors.append('duplicate model identities')
 for p,v in variants:
  if not isinstance(v.get('storageGb'),(int,float)) or v.get('storageGb',0)<=0: errors.append(f'{p.get("id")}: invalid storage')
  if v.get('ramGb') is not None and (not isinstance(v['ramGb'],(int,float)) or v['ramGb']<=0): errors.append(f'{p.get("id")}: invalid RAM')
 for p,v,s in sales:
  if s.get('channel') not in CHANNELS: errors.append(f'{p.get("id")}: unknown channel {s.get("channel")!r}')
  if s.get('availability') not in STATUSES: errors.append(f'{p.get("id")}: unknown availability {s.get("availability")!r}')
  url=s.get('url')
  if url:
   u=urlparse(url)
   if u.scheme not in {'http','https'} or not u.netloc: errors.append(f'{p.get("id")}: malformed URL {url!r}')
  else:
   warnings.append(f'{p.get("id")} / {v.get("storageGb")}GB / {s.get("channel")}: URL absent')
   if s.get('availability')=='AVAILABLE': errors.append(f'{p.get("id")}: URL-less listing incorrectly marked AVAILABLE')
 counts=data.get('counts',{}); observed={'phoneModels':len(phones),'variants':len(variants),'salesListings':len(sales),'auditFindings':len(data.get('auditFindings',[]))}
 for key,n in observed.items():
  if counts.get(key)!=n: errors.append(f'counts.{key}={counts.get(key)!r}, actual={n}')
 if 'versionName = "0.04.54"' not in build or 'versionCode = 103' not in build: errors.append('app version mismatch; expected versionName 0.04.54 / versionCode 103')
 avail=collections.Counter(s.get('availability') for _,_,s in sales)
 lines=['SmartphoneAdvisor 0.04.54 catalog integrity audit','Scope: static JSON/source integrity; not official-fact verification, Android build, Room runtime, or device test.',f'Models: {len(phones)}',f'Variants: {len(variants)}',f'Sales listings: {len(sales)}',f'Availability distribution: {dict(sorted(avail.items()))}',f'URL-less listings: {len(warnings)}',f'Errors: {len(errors)}',f'Warnings: {len(warnings)}','','Warnings:',*([f'- {w}' for w in warnings] or ['- none']),'','Errors:',*([f'- {e}' for e in errors] or ['- none']),'','Interpretation: URL-less listings are retained but not treated as confirmed available. This audit does not establish current live stock or price correctness.']
 OUT.write_text('\n'.join(lines)+'\n',encoding='utf-8'); print('\n'.join(lines)); return 1 if errors else 0
if __name__=='__main__': raise SystemExit(main())
