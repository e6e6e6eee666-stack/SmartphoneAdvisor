#!/usr/bin/env python3
"""Compatibility entry point for current nested sales-fact completeness audit."""
import subprocess, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
proc=subprocess.run([sys.executable,str(ROOT/'tools/test_sales_fact_completeness_0_04_55.py')],cwd=ROOT,text=True,capture_output=True)
print(proc.stdout,end=''); print(proc.stderr,end='',file=sys.stderr)
raise SystemExit(proc.returncode)
