#!/usr/bin/env python3
"""Create a reproducible, source-linked inventory of sales rows without prices.

This audit intentionally does not infer or fill prices. It separates purchasable
rows without price data from non-current/unknown availability so follow-up work
can prioritize official source verification.
"""
import csv
import hashlib
import json
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CATALOG_PATH = ROOT / "app/src/main/assets/phones.json"
CSV_PATH = ROOT / "CATALOG_PRICE_GAP_AUDIT_2026-10-20.csv"
MD_PATH = ROOT / "CATALOG_PRICE_GAP_AUDIT_2026-10-20.md"

def main():
    raw = CATALOG_PATH.read_bytes()
    catalog = json.loads(raw.decode("utf-8"))
    rows = []
    status_counts = Counter()
    channel_status_counts = Counter()
    manufacturer_status_counts = Counter()
    total_sales = total_prices = 0

    for phone in catalog.get("phones", []):
        for variant in phone.get("variants", []):
            for sale in variant.get("sales", []):
                total_sales += 1
                price_options = sale.get("priceOptions", [])
                total_prices += len(price_options)
                if price_options:
                    continue
                status = sale.get("availability", "UNKNOWN")
                status_counts[status] += 1
                channel_status_counts[(sale.get("channel", ""), status)] += 1
                manufacturer_status_counts[(phone.get("manufacturer", ""), status)] += 1
                rows.append({
                    "phoneId": phone.get("id", ""),
                    "manufacturer": phone.get("manufacturer", ""),
                    "model": phone.get("model", ""),
                    "releaseYear": phone.get("releaseYear", ""),
                    "platform": phone.get("platform", ""),
                    "storageGb": variant.get("storageGb", ""),
                    "ramGb": "" if variant.get("ramGb") is None else variant.get("ramGb"),
                    "channel": sale.get("channel", ""),
                    "retailer": sale.get("retailer", ""),
                    "modelNumber": sale.get("modelNumber") or "",
                    "availability": status,
                    "productUrl": sale.get("url") or "",
                    "priceOptionCount": 0,
                    "priority": "HIGH: available but price missing" if status == "AVAILABLE" else "REVIEW: status is not confirmed currently purchasable",
                })

    expected = catalog.get("counts", {})
    actual = {
        "phoneModels": len(catalog.get("phones", [])),
        "variants": sum(len(p.get("variants", [])) for p in catalog.get("phones", [])),
        "salesListings": total_sales,
        "priceOptions": total_prices,
        "auditFindings": len(catalog.get("auditFindings", [])),
    }
    if expected != actual:
        raise SystemExit(f"FAIL: declared counts {expected} do not match actual counts {actual}")
    if len(rows) != total_sales - sum(1 for p in catalog["phones"] for v in p["variants"] for s in v.get("sales", []) if s.get("priceOptions")):
        raise SystemExit("FAIL: price-gap row count reconciliation failed")

    fields = ["phoneId", "manufacturer", "model", "releaseYear", "platform", "storageGb", "ramGb", "channel", "retailer", "modelNumber", "availability", "productUrl", "priceOptionCount", "priority"]
    with CSV_PATH.open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        writer.writerows(sorted(rows, key=lambda r: (r["priority"], r["manufacturer"], r["model"], int(r["storageGb"] or 0), r["channel"])))

    high = status_counts.get("AVAILABLE", 0)
    lines = [
        "# カタログ価格欠損監査（2026-10-20）", "",
        "## 対象と制約", "",
        f"- 対象JSON: `app/src/main/assets/phones.json`", 
        f"- JSON SHA-256: `{hashlib.sha256(raw).hexdigest()}`",
        f"- 実件数: {actual['phoneModels']}機種 / {actual['variants']} variants / {total_sales}販売登録 / {total_prices}価格選択肢",
        f"- 価格選択肢が0件の販売登録: **{len(rows)}件**",
        f"- うち販売中（AVAILABLE）だが価格未登録: **{high}件**（販売中登録全体 {sum(1 for p in catalog['phones'] for v in p['variants'] for s in v.get('sales', []) if s.get('availability') == 'AVAILABLE')}件中）",
        "- この監査は価格を推測・補完しません。価格は容量・販売先・割引条件・確認日・出典を照合してから登録してください。",
        "- 詳細行は `CATALOG_PRICE_GAP_AUDIT_2026-10-20.csv`。",
        "", "## 価格未登録件数（販売状態別）", "", "| 販売状態 | 件数 |", "|---|---:|",
    ]
    for status, count in sorted(status_counts.items()):
        lines.append(f"| {status} | {count} |")
    lines += ["", "## 販売中・価格未登録（販売チャネル別）", "", "| チャネル | 件数 |", "|---|---:|"]
    channel_counts = Counter()
    for (channel, status), count in channel_status_counts.items():
        if status == "AVAILABLE": channel_counts[channel] += count
    for channel, count in sorted(channel_counts.items(), key=lambda x: (-x[1], x[0])):
        lines.append(f"| {channel} | {count} |")
    lines += ["", "## 解釈", "", 
        "最優先は `AVAILABLE` で価格が欠けている販売登録です。ただし、販売ページが存在することだけでは価格が現行・購入可能と証明されません。公式ページ、容量、税込一括価格、割引/返却条件、確認日を個別に検証し、確認できない場合は未登録のまま理由を記録してください。", ""]
    MD_PATH.write_text("\n".join(lines), encoding="utf-8")
    print(f"PASS: price-gap inventory; models={actual['phoneModels']}, variants={actual['variants']}, sales={total_sales}, priceOptions={total_prices}, noPrice={len(rows)}, availableNoPrice={high}")
    print(f"CSV: {CSV_PATH.name}")
    print(f"Markdown: {MD_PATH.name}")
    for status, count in sorted(status_counts.items()): print(f"  {status}: {count}")

if __name__ == "__main__": main()
