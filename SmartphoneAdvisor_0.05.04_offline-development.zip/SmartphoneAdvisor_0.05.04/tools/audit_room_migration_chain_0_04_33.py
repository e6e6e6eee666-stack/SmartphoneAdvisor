#!/usr/bin/env python3
"""Static audit of Room migration chain and destructive-fallback policy."""
from pathlib import Path
import re, sys
ROOT = Path(__file__).resolve().parents[1]
s = (ROOT / 'app/src/main/java/jp/smartphoneadvisor/app/data/AppDatabase.kt').read_text(encoding='utf-8')
g = (ROOT / 'app/build.gradle.kts').read_text(encoding='utf-8')
checks=[]
def check(name, ok, detail=''): checks.append((name, bool(ok), detail))
vm = re.search(r'@Database\([\s\S]*?version\s*=\s*(\d+)', s)
version = int(vm.group(1)) if vm else None
migrations = [(int(a),int(b)) for a,b in re.findall(r'Migration\((\d+)\s*,\s*(\d+)\)',s)]
am = re.search(r'\.addMigrations\(([^)]*)\)',s,re.S)
registered = [(int(a),int(b)) for a,b in re.findall(r'MIGRATION_(\d+)_(\d+)',am.group(1) if am else '')]
check('database version is readable',version is not None,f'version={version}')
check('declared migrations ascend',bool(migrations) and all(b>a for a,b in migrations),f'count={len(migrations)}')
check('migration declarations are unique',len(migrations)==len(set(migrations)))
check('registered migrations are unique',len(registered)==len(set(registered)))
check('all declarations are registered',set(migrations).issubset(set(registered)),f'missing registrations={sorted(set(migrations)-set(registered))}')
check('all registrations are declared',set(registered).issubset(set(migrations)),f'unknown registrations={sorted(set(registered)-set(migrations))}')
missing=[(i,i+1) for i in range(1,version or 1) if (i,i+1) not in set(migrations)]
check('sequential upgrade chain v1 to current has no gaps',not missing,f'gaps={missing}')
ex=re.search(r'exportSchema\s*=\s*(true|false)',s)
check('schema export setting is explicit',bool(ex),ex.group(0) if ex else '')
check('schema export limitation is surfaced',bool(ex and ex.group(1)=='false'),'exportSchema=false' if ex and ex.group(1)=='false' else 'exportSchema enabled or unknown')
check('no destructive migration fallback in database builder','fallbackToDestructiveMigration' not in s)
check('app version metadata matches 0.04.33 / 82','versionName = "0.04.33"' in g and bool(re.search(r'versionCode\s*=\s*82\b',g)))
print('ROOM MIGRATION CHAIN AUDIT 0.04.33')
for n,ok,d in checks: print(('PASS' if ok else 'FAIL')+' | '+n+((' | '+d) if d else ''))
print(f'SUMMARY: {sum(x[1] for x in checks)}/{len(checks)} PASS')
if not all(x[1] for x in checks): sys.exit(1)
