from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
plan = (ROOT / "PROJECT_MASTER_PLAN_CURRENT.md").read_text(encoding="utf-8")
register = (ROOT / "PROJECT_TASK_REGISTER_0.04.90.md").read_text(encoding="utf-8")
review = (ROOT / "PROJECT_DEPENDENCY_REVIEW_2026-10-18.md").read_text(encoding="utf-8")
assert "G0 基準資産・追跡性" in plan and "G8 公開後運用" in plan
assert "20項目固定・番号順の逐次実行を規則とはしない" in plan
assert "G1/G2の未通過を飛ばして統合完了にはできない" in plan
assert "大項目数を固定しない" in register
assert "G1 AndroidビルドとG2 Room実行検証が未通過" in register
assert "Android実ビルド、Kotlin/JUnit、Room実DB" in review
assert "大項目1へ戻した扱い" in review
print("PASS: canonical roadmap, flexible task decomposition, dependency gates, and blockers")
