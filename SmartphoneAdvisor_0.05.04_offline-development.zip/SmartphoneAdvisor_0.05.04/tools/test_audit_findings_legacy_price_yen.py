"""Regression test: legacy price_yen must not leak into generated auditFindings."""
import csv
import importlib.util
import json
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MODULE_PATH = ROOT / "tools/convert_carrier_seed_to_phones_json.py"
spec = importlib.util.spec_from_file_location("catalog_converter", MODULE_PATH)
converter = importlib.util.module_from_spec(spec)
spec.loader.exec_module(converter)

with tempfile.TemporaryDirectory() as tmp:
    tmp = Path(tmp)
    seed = tmp / "seed.kt"
    audit = tmp / "audit.csv"
    output = tmp / "phones.json"
    seed.write_text('Entry("Test Phone", "Maker", "Series", 2026, storageGb=128, ramGb=8, channel=SIM_FREE, retailer="Maker Store", url="https://example.com", availability=AVAILABLE)\n', encoding="utf-8")
    with audit.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=["model", "action", "price_yen", "evidence"])
        writer.writeheader()
        writer.writerow({"model": "Old Phone", "action": "UNRESOLVED_SEED_LINKAGE", "price_yen": "12345", "evidence": "legacy CSV row"})
        writer.writerow({"model": "Old Phone", "action": "UNRESOLVED_SEED_LINKAGE", "price_yen": "67890", "evidence": "legacy CSV row"})
    import sys
    old_argv = sys.argv
    try:
        sys.argv = [str(MODULE_PATH), "--seed", str(seed), "--csv", str(audit), "--output", str(output)]
        converter.main()
    finally:
        sys.argv = old_argv
    generated = json.loads(output.read_text(encoding="utf-8"))
    assert len(generated["auditFindings"]) == 2, generated["auditFindings"]
    for finding in generated["auditFindings"]:
        assert "price_yen" not in finding, finding
        assert finding["model"] == "Old Phone"
        assert finding["action"] == "UNRESOLVED_SEED_LINKAGE"
        assert finding["evidence"] == "legacy CSV row"
print("PASS: legacy price_yen is omitted while other audit finding fields are preserved")
