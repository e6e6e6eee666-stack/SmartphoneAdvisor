#!/usr/bin/env python3
"""Static audit for nubia Z80 Ultra color-specific official price options."""
import json
from pathlib import Path

root = Path(__file__).resolve().parents[1]
data = json.loads((root / "app/src/main/assets/phones.json").read_text(encoding="utf-8"))
phones = [p for p in data["phones"] if p.get("model") == "nubia Z80 Ultra"]
assert len(phones) == 1, f"expected one nubia Z80 Ultra model, got {len(phones)}"
variants = [v for v in phones[0]["variants"] if v.get("storageGb") == 512 and v.get("ramGb") == 16]
assert len(variants) == 1, f"expected one 512GB/16GB variant, got {len(variants)}"
sales = [s for s in variants[0]["sales"] if s.get("retailer") == "nubia Store Japan"]
assert len(sales) == 1, f"expected one official store listing, got {len(sales)}"
options = sales[0].get("priceOptions", [])
actual = [(x.get("color"), x.get("priceYen")) for x in options]
expected = [("ブラック", 139800), ("ホワイト", 139800), ("スターレイナイト", 144800)]
assert actual == expected, f"color-price mismatch: {actual!r}"
for option in options:
    assert option.get("priceType") == "NORMAL"
    assert option.get("sourceUrl", "").startswith("https://")
    assert option.get("checkedAt") == "2026-10-15"
print("PASS: nubia Z80 Ultra 16GB/512GB has 3 correctly mapped color-specific list-price options.")
