#!/usr/bin/env python3
"""Compare available historical sales inventories by logical listing identity."""
from __future__ import annotations
import csv
from collections import Counter
from pathlib import Path
from current_version import current_version_is_valid
ROOT = Path(__file__).resolve().parents[1]
VERSIONS = ['0.04.52','0.04.53','0.04.57','0.04.58','0.04.59','0.04.60','0.04.61','0.04.62','0.04.69','0.04.70','0.04.71','0.04.72','0.04.73','0.04.74','0.04.75','0.04.76']
FIELDS = ['manufacturer','model','storage_gb','ram_gb','channel','retailer']
STATE_FIELDS = ['availability','url']

def load(version):
    path = ROOT / f'SALES_URL_INVENTORY_{version}.csv'
    if not path.is_file(): raise SystemExit(f'MISSING historical inventory: {path.name}; generate current inventory first')
    with path.open(encoding='utf-8-sig', newline='') as f: return list(csv.DictReader(f))

def key(row): return tuple(row.get(k,'') for k in FIELDS)

def main():
    build=(ROOT/'app/build.gradle.kts').read_text(encoding='utf-8')
    if not current_version_is_valid(build):
        raise SystemExit('FAIL: current app version metadata is invalid')
    snapshots={v:load(v) for v in VERSIONS}
    out_rows=[]; sections=[]
    for before,after in zip(VERSIONS,VERSIONS[1:]):
        a,b=snapshots[before],snapshots[after]
        ca,cb=Counter(key(r) for r in a),Counter(key(r) for r in b)
        removed=(ca-cb); added=(cb-ca)
        # Compare listing attributes for keys present on both sides.
        changes=[]
        amap={key(r):r for r in a}; bmap={key(r):r for r in b}
        for k in sorted(set(amap)&set(bmap)):
            old,new=amap[k],bmap[k]
            diff={f:(old.get(f,'') or '')+' => '+(new.get(f,'') or '') for f in STATE_FIELDS if (old.get(f,'') or '') != (new.get(f,'') or '')}
            if diff: changes.append((k,diff))
        sections.append(f'### {before} → {after}\n\n- 行数：{len(a)} → {len(b)}\n- 論理販売登録の削除：{sum(removed.values())}\n- 論理販売登録の追加：{sum(added.values())}\n- 状態・URL等の変更：{len(changes)}')
        for k,n in removed.items():
            out_rows.append({'from_version':before,'to_version':after,'change':'REMOVED','manufacturer':k[0],'model':k[1],'storage_gb':k[2],'ram_gb':k[3],'channel':k[4],'retailer':k[5],'field':'','old_value':f'count={n}','new_value':''})
        for k,n in added.items():
            out_rows.append({'from_version':before,'to_version':after,'change':'ADDED','manufacturer':k[0],'model':k[1],'storage_gb':k[2],'ram_gb':k[3],'channel':k[4],'retailer':k[5],'field':'','old_value':'','new_value':f'count={n}'})
        for k,diff in changes:
            for f,val in diff.items():
                old,new=val.split(' => ',1)
                out_rows.append({'from_version':before,'to_version':after,'change':'FIELD_CHANGED','manufacturer':k[0],'model':k[1],'storage_gb':k[2],'ram_gb':k[3],'channel':k[4],'retailer':k[5],'field':f,'old_value':old,'new_value':new})
    csv_path=ROOT/'HISTORICAL_SALES_TRANSITIONS_0.04.76.csv'
    fields=['from_version','to_version','change',*FIELDS,'field','old_value','new_value']
    with csv_path.open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields); w.writeheader(); w.writerows(out_rows)
    report=['# 過去版販売登録の差分監査（0.04.76）','', '## 目的','', '保存されている販売URLインベントリを版順に比較し、販売登録の追加・削除と、販売状態・URLの変更を区別して可視化する。', '', '## 対象と限界','', '- 利用できたスナップショット：'+', '.join(VERSIONS), '- 0.04.54〜0.04.56、0.04.63〜0.04.68など、個別インベントリが保存されていない版は連続比較できない。', '- この監査は販売URL台帳に含まれる販売登録の比較であり、価格オプション、機種仕様、診断ロジック、Android実行時の動作を証明しない。', '- 表記揺れや機種統合は論理キーの変更として現れる場合があるため、削除・追加を自動で「不具合」と断定しない。', '', '## 版間差分', '', *sections, '', '## 既知の再発事例', '', '- iPhone 18 Pro 2TBの4キャリア販売登録は0.04.53→0.04.57で消失し、0.04.60で復元。', '- Xiaomi REDMI Note 17 Pro Max 5Gの256GB・512GBは0.04.61で公式SIMフリー登録に修正後、0.04.62でY!mobile・URLなしへ戻り、0.04.69で再修正。', '- Nothing Phone (4a)の機種名表記揺れは0.04.70〜0.04.72で重複し、0.04.73で統合。', '', '## 判定','', '差分はCSVへ1行ずつ記録した。変更理由が作業記録で確認できない削除・追加は、承認済みの仕様変更とみなさず、人手の確認対象とする。']
    (ROOT/'HISTORICAL_SALES_TRANSITIONS_0.04.76.md').write_text('\n'.join(report)+'\n',encoding='utf-8')
    print(f'PASS: historical transition matrix generated; snapshots={len(snapshots)} transitions={len(VERSIONS)-1} change_rows={len(out_rows)} csv={csv_path.name}')
if __name__=='__main__': main()
