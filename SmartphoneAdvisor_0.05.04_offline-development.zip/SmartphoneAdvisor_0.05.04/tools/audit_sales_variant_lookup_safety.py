#!/usr/bin/env python3
"""Static regression checks for safe sales-seed variant resolution.

This checks source structure only. It does not execute Room SQL or compile Kotlin.
"""
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
DAO = (ROOT / 'app/src/main/java/jp/smartphoneadvisor/app/data/PhoneDao.kt').read_text(encoding='utf-8')
SEED_FILES = [
    ROOT / 'app/src/main/java/jp/smartphoneadvisor/app/data/CarrierCatalogSeed.kt',
    ROOT / 'app/src/main/java/jp/smartphoneadvisor/app/data/SimFreeCatalogSeed.kt',
    ROOT / 'app/src/main/java/jp/smartphoneadvisor/app/data/VerifiedSalesSeed.kt',
    ROOT / 'app/src/main/java/jp/smartphoneadvisor/app/data/SubBrandMvnoCatalogSeed.kt',
]
checks = {
    'RAM-specified lookup only returns a unique matching row': 'SUM(CASE WHEN d.ramGb = :ramGb THEN 1 ELSE 0 END) = 1' in DAO,
    'ambiguous/no-match branch returns NULL': 'ELSE NULL' in DAO,
    'lookup remains restricted to exact model name, storage, condition': all(x in DAO for x in (
        'WHERE m.modelName = :modelName', 'd.storageGb = :storageGb', 'd.condition = :condition')),
}
for path in SEED_FILES:
    text = path.read_text(encoding='utf-8')
    required_lookup = 'getDeviceVariantIdByFullIdentity(' if path.name == 'CarrierCatalogSeed.kt' else 'getDeviceVariantIdByModelAndStorage('
    checks[f'{path.name} uses guarded variant lookup'] = required_lookup in text
for label, ok in checks.items():
    print(f"{'PASS' if ok else 'FAIL'}: {label}")
if not all(checks.values()):
    sys.exit(1)
print('STATIC SALES VARIANT LOOKUP SAFETY CHECK: PASS')
print('LIMITATION: no Kotlin compilation, Room SQL execution, Gradle build, or device test.')
