from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
script = (ROOT / "PREPARE_GRADLE_WRAPPER_WINDOWS.ps1").read_text(encoding="utf-8")
import re
build = (ROOT / "app/build.gradle.kts").read_text(encoding="utf-8")
version = re.search(r'versionName\s*=\s*"([0-9.]+)"', build).group(1)
guide_path = ROOT / f"ANDROID_STUDIO_BUILD_GUIDE_{version}.md"
if not guide_path.exists():
    # Build guide is a milestone artifact, not recreated for every catalog-only release.
    guide_path = ROOT / "ANDROID_STUDIO_BUILD_GUIDE_0.04.90.md"
guide = guide_path.read_text(encoding="utf-8")
assert "bbaeb2fef8710818cf0e261201dab964c572f92b942812df0c3620d62a529a01" in script
assert "497c8c2a7e5031f6aa847f88104aa80a93532ec32ee17bdb8d1d2f67a194a9c7" in script
assert "Get-FileHash $zipPath -Algorithm SHA256" in script
assert "Get-FileHash $jar -Algorithm SHA256" in script
assert "https://services.gradle.org/distributions/gradle-$GradleVersion-bin.zip" in script
assert "wrapper --gradle-version $GradleVersion" in script
assert "Java 17以上が必要です" in script
assert "if ($buildFile -match 'versionName\\s*=\\s*\"([0-9.]+)\"')" in script
assert "$AppVersion = $Matches[1]" in script
assert script.index("$ProjectRoot = (Resolve-Path $ProjectRoot).Path") < script.index("$buildFile = Get-Content (Join-Path $ProjectRoot 'app/build.gradle.kts') -Raw")
assert '"SmartphoneAdvisor $AppVersion Gradle Wrapper setup"' in script
assert '"GRADLE_WRAPPER_SETUP_$AppVersion.txt"' in script
assert "0.04.86" not in script, "wrapper bootstrap must not hardcode a stale app version"
assert "Android Gradle/KSPビルド" in guide and "未実施" in guide
assert "PREPARE_GRADLE_WRAPPER_WINDOWS.ps1" in guide
print("PASS: wrapper bootstrap is pinned to official Gradle 9.6.0, verifies distribution/JAR checksums, and documents unverified app build status")
