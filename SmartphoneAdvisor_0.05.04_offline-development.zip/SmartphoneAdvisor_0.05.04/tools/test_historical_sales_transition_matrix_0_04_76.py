#!/usr/bin/env python3
"""Regression guard for the full available historical sales-inventory transition matrix."""
import csv, json
from pathlib import Path
from current_version import current_version_is_valid
ROOT=Path(__file__).resolve().parents[1]
BUILD=(ROOT/'app/build.gradle.kts').read_text(encoding='utf-8')
assert current_version_is_valid(BUILD), 'invalid active version metadata'
report=(ROOT/'HISTORICAL_SALES_TRANSITIONS_0.04.76.md').read_text(encoding='utf-8')
assert '0.04.53 → 0.04.57' in report and '0.04.61 → 0.04.62' in report, 'key historical transitions missing'
with (ROOT/'HISTORICAL_SALES_TRANSITIONS_0.04.76.csv').open(encoding='utf-8-sig',newline='') as f: rows=list(csv.DictReader(f))
assert rows, 'transition matrix is empty'
assert any(r['from_version']=='0.04.53' and r['to_version']=='0.04.57' and r['change']=='REMOVED' and r['manufacturer']=='Apple' and r['model']=='iPhone 18 Pro' and r['storage_gb']=='2048' and r['channel']=='DOCOMO' for r in rows), 'iPhone 18 Pro 2TB historical disappearance not represented'
assert any(r['from_version']=='0.04.61' and r['to_version']=='0.04.62' and r['change']=='REMOVED' and r['manufacturer']=='Xiaomi' and r['storage_gb']=='256' and r['channel']=='SIM_FREE' for r in rows), 'Xiaomi corrected listing disappearance not represented'
data=json.loads((ROOT/'app/src/main/assets/phones.json').read_text(encoding='utf-8'))
assert len(data['phones'])==195 and sum(len(p.get('variants',[])) for p in data['phones'])==315
print(f'PASS: historical transition matrix has {len(rows)} change rows; known regression events represented; current catalog 195 models / 315 variants retained')
