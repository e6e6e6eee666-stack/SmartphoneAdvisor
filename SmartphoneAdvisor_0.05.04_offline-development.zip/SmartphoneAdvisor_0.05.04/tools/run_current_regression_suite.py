#!/usr/bin/env python3
"""Run the maintained SmartphoneAdvisor regression baseline in one command."""
import argparse, json, re, subprocess, sys, time
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--batch-index", type=int, default=None, help="zero-based batch index; omit to run all tests")
parser.add_argument("--batch-size", type=int, default=12, help="tests per batch when --batch-index is supplied")
args = parser.parse_args()
if args.batch_size < 1 or (args.batch_index is not None and args.batch_index < 0):
    parser.error("batch index must be >= 0 and batch size must be >= 1")
BUILD = (ROOT / "app/build.gradle.kts").read_text(encoding="utf-8")
version_match = re.search(r'versionName\s*=\s*"([0-9.]+)"', BUILD)
if not version_match:
    print("FAIL: cannot derive current app version from app/build.gradle.kts")
    raise SystemExit(2)
version = version_match.group(1)
version_suffix = version.replace(".", "_")
manifest = json.loads((ROOT / "tools/current_regression_manifest.json").read_text(encoding="utf-8"))
tests = list(manifest["tests"])
# Automatically include tests introduced for the current app version so they cannot be silently omitted.
for path in sorted((ROOT / "tools").glob(f"test_*_{version_suffix}.py")):
    name = path.name
    if name not in tests:
        tests.append(name)
missing = [name for name in tests if not (ROOT / "tools" / name).is_file()]
if missing:
    print("FAIL: manifest test missing: " + ", ".join(missing))
    raise SystemExit(2)
all_tests = tests
batch_count = (len(all_tests) + args.batch_size - 1) // args.batch_size
if args.batch_index is not None:
    if args.batch_index >= batch_count:
        parser.error(f"batch index must be between 0 and {batch_count-1}")
    start_index = args.batch_index * args.batch_size
    tests = all_tests[start_index:start_index + args.batch_size]
else:
    start_index = 0
results, failures = [], []
start = time.monotonic()
print(f"SmartphoneAdvisor current regression suite {version}: {len(tests)} tests in this run ({len(all_tests)} total; batch {args.batch_index+1 if args.batch_index is not None else 'all'}/{batch_count})")
for local_index, name in enumerate(tests, 1):
    index = start_index + local_index
    try:
        proc = subprocess.run([sys.executable, str(ROOT / "tools" / name)], cwd=ROOT, text=True, capture_output=True, timeout=45)
        ok = proc.returncode == 0
        detail = (proc.stdout + proc.stderr).strip()
        if not ok:
            failures.append((name, detail[-3000:]))
        results.append((name, ok, detail))
        print(f"[{index}/{len(all_tests)}] {'PASS' if ok else 'FAIL'} {name}", flush=True)
    except subprocess.TimeoutExpired as exc:
        detail = f"TIMEOUT after 45 seconds\n{(exc.stdout or b'').decode(errors='replace')}\n{(exc.stderr or b'').decode(errors='replace')}"
        failures.append((name, detail))
        results.append((name, False, detail))
        print(f"[{index}/{len(all_tests)}] FAIL {name} (timeout)", flush=True)
output = [f"SmartphoneAdvisor {version} current regression suite", f"Tests: {len(results)}", f"Passed: {sum(1 for _, ok, _ in results if ok)}", f"Failed: {sum(1 for _, ok, _ in results if not ok)}", f"Duration seconds: {time.monotonic()-start:.1f}", "", "Per-test results:"]
for name, ok, detail in results:
    output.append(f"[{ 'PASS' if ok else 'FAIL' }] {name}")
    if not ok and detail:
        output.append(detail)
if args.batch_index is None:
    report = ROOT / f"test_results_{version}.txt"
else:
    report = ROOT / f"test_results_{version}_batch_{args.batch_index+1}.txt"
report.write_text("\n".join(output) + "\n", encoding="utf-8")
print(f"\nReport: {report.name}")
if args.batch_index is not None:
    # Merge only when all batch reports exist; each batch is independently rerunnable.
    batch_reports = [ROOT / f"test_results_{version}_batch_{i+1}.txt" for i in range(batch_count)]
    if all(path.is_file() for path in batch_reports):
        merged_results = []
        total_pass = total_fail = 0
        stale_reports = []
        for batch_number, batch_path in enumerate(batch_reports):
            content = batch_path.read_text(encoding="utf-8").splitlines()
            actual_names = [line[7:] for line in content if line.startswith("[PASS] ") or line.startswith("[FAIL] ")]
            expected_start = batch_number * args.batch_size
            expected_names = all_tests[expected_start:expected_start + args.batch_size]
            if actual_names != expected_names:
                stale_reports.append(f"{batch_path.name}: expected {len(expected_names)} tests in current order, found {len(actual_names)} or different names/order")
                continue
            for line in content:
                if line.startswith("[PASS] "):
                    total_pass += 1
                    merged_results.append(line)
                elif line.startswith("[FAIL] "):
                    total_fail += 1
                    merged_results.append(line)
        if stale_reports:
            print("WARNING: refusing to merge stale/mismatched batch reports:")
            for warning in stale_reports:
                print("  " + warning)
            print("Rerun the affected batch(es); no combined report was written.")
        else:
            merged = [f"SmartphoneAdvisor {version} current regression suite", f"Batches: {batch_count}", f"Tests: {len(all_tests)}", f"Passed: {total_pass}", f"Failed: {total_fail}", "", "Per-test results:"] + merged_results
            (ROOT / f"test_results_{version}.txt").write_text("\n".join(merged)+"\n", encoding="utf-8")
            print(f"Merged report: test_results_{version}.txt ({total_pass} passed, {total_fail} failed)")
if failures:
    print(f"FAIL: {len(failures)} regression test(s) failed")
    raise SystemExit(1)
print(f"PASS: all {len(results)} regression tests passed")
