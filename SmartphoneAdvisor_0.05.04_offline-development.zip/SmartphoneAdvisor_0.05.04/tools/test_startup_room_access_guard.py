"""Regression test: Room flows must not instantiate the database before guarded startup succeeds."""
from pathlib import Path
from current_version import current_version_is_valid
ROOT = Path(__file__).resolve().parents[1]
ACTIVITY = (ROOT / "app/src/main/java/jp/smartphoneadvisor/app/MainActivity.kt").read_text(encoding="utf-8")
BUILD = (ROOT / "app/build.gradle.kts").read_text(encoding="utf-8")
errors = []
for token, message in [
    ('val favoriteDeviceIdsFlow = remember(dbReady, context)', "favorites flow is not recreated when readiness changes"),
    ('if (dbReady) AppDatabase.getInstance(context).phoneDao().observeFavoriteDeviceIds()', "favorites Room access is not gated by dbReady"),
    ('else flowOf(emptyList<Long>())', "favorites flow has no safe pre-startup fallback"),
    ('val diagnosticProfilesFlow = remember(dbReady, context)', "diagnostic profile flow is not recreated when readiness changes"),
    ('if (dbReady) AppDatabase.getInstance(context).diagnosticDao().observeProfiles()', "diagnostic profile Room access is not gated by dbReady"),
    ('else flowOf(emptyList<jp.smartphoneadvisor.app.data.DiagnosticProfileEntity>())', "diagnostic profile flow has no safe pre-startup fallback"),
    ('val draftOutcome = runCatching', "saved-draft load failures are not caught"),
    ('Saved diagnostic draft load failed', "saved-draft load failure is not logged"),
]:
    if token not in ACTIVITY:
        errors.append(message)
if not current_version_is_valid(BUILD):
    errors.append("expected current version metadata is missing")
# The startup behavior tests are intentionally version-agnostic; future version changes must not break them.
for name in ("test_catalog_load_and_import_failure_visibility.py", "test_startup_initialization_failure_visibility.py"):
    content = (ROOT / "tools" / name).read_text(encoding="utf-8")
    if "versionName = \"0.04." in content or "versionCode = 13" in content:
        errors.append(f"{name} pins a release version")
if errors:
    print("FAIL: " + "; ".join(errors))
    raise SystemExit(1)
print("PASS: Room flows are gated until successful initialization; draft-load errors are handled; startup tests are version-independent")
