#!/usr/bin/env python3
"""Static regression guard for concrete, non-misleading diagnostic budget reasons."""
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
BUILD = (ROOT / "app/build.gradle.kts").read_text(encoding="utf-8")
ENGINE = (ROOT / "app/src/main/java/jp/smartphoneadvisor/app/domain/SinglePhoneDiagnosticEngine.kt").read_text(encoding="utf-8")
JUNIT = (ROOT / "app/src/test/java/jp/smartphoneadvisor/app/domain/SinglePhoneDiagnosticEngineTest.kt").read_text(encoding="utf-8")
errors = []
if 'versionName = "0.05.04"' not in BUILD or not re.search(r"versionCode\s*=\s*152\b", BUILD):
    errors.append("app version metadata must be 0.05.04 / 152")
for required in (
    'NumberFormat.getNumberInstance(Locale.JAPAN)',
    '価格${priceText}は希望予算${targetText}以内です',
    '価格${priceText}は希望予算${targetText}を超えますが、絶対上限${maxText}以内です',
    '価格${priceText}は希望価格未設定ですが、絶対上限${maxText}以内です',
    '価格が未確認のため、${budgetContext}への適合を確認できません',
):
    # Keep Japanese strings exactly as implemented; typo guards below check concrete required phrases.
    if required not in ENGINE:
        errors.append(f"diagnostic engine missing expected budget detail: {required}")
for required in (
    '価格150,000円は希望予算100,000円を超えますが、絶対上限200,000円以内です',
    '価格が未確認のため、希望予算100,000円・絶対上限200,000円への適合を確認できません',
):
    if required not in JUNIT:
        errors.append(f"JUnit regression coverage missing: {required}")
if errors:
    print("FAIL")
    print("\n".join("- " + e for e in errors))
    sys.exit(1)
print("PASS: diagnostic budget reasons include concrete yen amounts and unknown-price caveats")
print("LIMITATION: static source check only; Kotlin/JUnit execution still requires Android/Gradle tooling.")
