#!/usr/bin/env python3
"""Ensure canonical identity validation is wired into the real JSON-to-Room import path."""
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
importer = (ROOT / 'app/src/main/java/jp/smartphoneadvisor/app/data/catalog/PhoneCatalogRoomImporter.kt').read_text()
identity = (ROOT / 'app/src/main/java/jp/smartphoneadvisor/app/data/catalog/CatalogModelIdentity.kt').read_text()
tests = (ROOT / 'app/src/test/java/jp/smartphoneadvisor/app/data/catalog/PhoneCatalogRoomImporterTest.kt').read_text()
errors = []
if 'CatalogModelIdentity.key(phone.manufacturer, phone.model, phone.platform, phone.releaseYear)' not in importer:
    errors.append('actual JSON-to-Room importer does not use shared canonical model identity')
if 'duplicate canonical model identity' not in importer:
    errors.append('importer does not reject duplicate canonical identities')
if 'manufacturer-prefix aliases' not in identity:
    errors.append('shared identity helper contract/comment missing')
if 'manufacturerPrefixAliasIsRejectedBeforeRoomImport' not in tests:
    errors.append('missing runtime-importer regression test for manufacturer-prefix alias')
if 'modelPunctuationIsPreservedDuringIdentityCheck' not in tests:
    errors.append('missing regression test that distinguishes Galaxy S26 and S26+')
if errors:
    print('FAIL'); print('\\n'.join(errors)); raise SystemExit(1)
print('PASS: canonical identity guard is wired into JSON-to-Room preflight; alias and punctuation regression tests present')
