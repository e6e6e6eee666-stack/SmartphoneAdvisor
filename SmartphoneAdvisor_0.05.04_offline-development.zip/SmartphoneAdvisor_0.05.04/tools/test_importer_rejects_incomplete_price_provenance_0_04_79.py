#!/usr/bin/env python3
"""Static contract regression test: malformed price facts must fail before Room writes."""
from pathlib import Path

from current_version import current_version_is_valid
ROOT = Path(__file__).resolve().parents[1]
SOURCE_PATH = ROOT / 'app/src/main/java/jp/smartphoneadvisor/app/data/catalog/PhoneCatalogRoomImporter.kt'
BUILD_PATH = ROOT / 'app/build.gradle.kts'
source = SOURCE_PATH.read_text(encoding='utf-8')
build = BUILD_PATH.read_text(encoding='utf-8')
errors = []

# This test checks implementation structure; it does not substitute for Android/Room runtime tests.
required_contracts = {
    'missing checkedAt rejected': 'checkedAt.isNullOrBlank()' in source and 'checkedAt is required' in source,
    'calendar date parsed before import': 'LocalDate.parse(checkedAt)' in source and 'parsedDate.toString() != checkedAt' in source,
    'missing source URL rejected': 'source == null || source.isBlank()' in source,
    'source URL must use HTTPS': '!parsedSource.scheme.equals("https", true)' in source,
    'validation occurs before transaction': source.index('val validationErrors = validate(catalog)') < source.index('db.withTransaction {'),
    'invalid catalog rejected before writes': 'Catalog import rejected before database changes:' in source,
    'current version metadata valid': current_version_is_valid(build),
}
for label, passed in required_contracts.items():
    if not passed:
        errors.append(label)

# Regression cases for the date contract used by the Kotlin validator.
from datetime import date
for value in ('2026-10-17',):
    try:
        if date.fromisoformat(value).isoformat() != value:
            errors.append(f'valid date unexpectedly rejected: {value}')
    except ValueError:
        errors.append(f'valid date unexpectedly rejected: {value}')
for value in ('', '2026-02-30', '2026-1-01', 'not-a-date'):
    try:
        parsed = date.fromisoformat(value)
        if parsed.isoformat() == value:
            errors.append(f'invalid date unexpectedly accepted: {value!r}')
    except ValueError:
        pass

if errors:
    print(f'FAIL: {len(errors)} importer provenance contract issue(s)')
    for error in errors:
        print('- ' + error)
    raise SystemExit(1)
print(f'PASS: importer rejects incomplete price provenance contract ({len(required_contracts)} source guards; date regressions)')
