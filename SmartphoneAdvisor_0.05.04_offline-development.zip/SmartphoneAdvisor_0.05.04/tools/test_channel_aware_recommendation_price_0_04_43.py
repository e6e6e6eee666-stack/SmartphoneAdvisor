#!/usr/bin/env python3
"""Static + SQLite regression test for purchase-channel-specific recommendation prices."""
import sqlite3
from pathlib import Path
root = Path(__file__).resolve().parents[1]
dao = (root / "app/src/main/java/jp/smartphoneadvisor/app/data/PhoneDao.kt").read_text(encoding="utf-8")
main = (root / "app/src/main/java/jp/smartphoneadvisor/app/MainActivity.kt").read_text(encoding="utf-8")
method = dao.index('suspend fun searchJapanOfficialDevices(')
start = dao.rfind('@Query("""', 0, method)
query = dao[start:method]
assert 'purchaseChannel: String = ""' in dao[method:method + 150]
assert query.count('svv.salesChannel = :purchaseChannel') >= 5, query.count('svv.salesChannel = :purchaseChannel')
assert "CASE WHEN :purchaseChannel = '' THEN p.priceYen ELSE NULL END" in query
assert "CASE WHEN :purchaseChannel = '' THEN p.checkedAt ELSE NULL END" in query
assert "CASE WHEN :purchaseChannel = '' THEN src.sourceType ELSE NULL END" in query
assert "CASE WHEN :purchaseChannel = '' THEN src.name ELSE NULL END" in query
assert 'purchaseChannel.toSalesChannelDbValue()' in main
assert 'battery, purchaseChannel, diagnosticRunToken' in main

# Behavioral fixture: one phone, different channels and prices.
con = sqlite3.connect(':memory:')
con.executescript("""
CREATE TABLE sales_variant(id INTEGER PRIMARY KEY, deviceVariantId INTEGER, salesChannel TEXT, isActive INTEGER);
CREATE TABLE product_listing(id INTEGER PRIMARY KEY, salesVariantId INTEGER, availability TEXT);
CREATE TABLE price_record_v2(id INTEGER PRIMARY KEY, productListingId INTEGER, priceType TEXT, priceYen INTEGER, checkedAt INTEGER, color TEXT);
INSERT INTO sales_variant VALUES (1, 500, 'SIM_FREE', 1), (2, 500, 'DOCOMO', 1);
INSERT INTO product_listing VALUES (11, 1, 'AVAILABLE'), (22, 2, 'AVAILABLE');
INSERT INTO price_record_v2 VALUES (101, 11, 'NORMAL', 150000, 100, NULL), (201, 22, 'NORMAL', 60000, 200, NULL);
""")
price_sql = """SELECT pr.priceYen FROM price_record_v2 pr
JOIN product_listing pl ON pl.id=pr.productListingId
JOIN sales_variant sv ON sv.id=pl.salesVariantId
WHERE sv.deviceVariantId=? AND sv.isActive=1
AND (?='' OR sv.salesChannel=?) AND pl.availability IN ('AVAILABLE','LIMITED')
AND pr.priceType IN ('NORMAL','SALE') AND pr.priceYen IS NOT NULL
ORDER BY pr.checkedAt DESC, pr.priceYen ASC, pr.id DESC LIMIT 1"""
assert con.execute(price_sql, (500, 'SIM_FREE', 'SIM_FREE')).fetchone() == (150000,)
assert con.execute(price_sql, (500, 'DOCOMO', 'DOCOMO')).fetchone() == (60000,)
assert con.execute(price_sql, (500, 'UQ_MOBILE', 'UQ_MOBILE')).fetchone() is None
assert con.execute(price_sql, (500, '', '')).fetchone() == (60000,)
print('PASS: DAO price and source subqueries are purchase-channel scoped')
print('PASS: explicit channel cannot fall back to the legacy unattributed price')
print('PASS: changing purchase channel is a recomposition/reload key')
print('PASS: SQLite fixture selects SIM_FREE=150000, DOCOMO=60000, unsupported channel=NULL')
