#!/usr/bin/env python3
"""Regression test: do not claim availability for sales entries without a URL."""
import json
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CATALOG = ROOT / "app/src/main/assets/phones.json"
IMPORTER = ROOT / "app/src/main/java/jp/smartphoneadvisor/app/data/catalog/PhoneCatalogRoomImporter.kt"


class CatalogUrlAvailabilityTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.data = json.loads(CATALOG.read_text(encoding="utf-8"))
        cls.importer = IMPORTER.read_text(encoding="utf-8")
        cls.sales = [
            (phone, variant, sale)
            for phone in cls.data["phones"]
            for variant in phone.get("variants", [])
            for sale in variant.get("sales", [])
        ]

    def test_catalog_count_metadata_matches_actual_records(self):
        counts = self.data["counts"]
        self.assertEqual(counts["phoneModels"], len(self.data["phones"]))
        self.assertEqual(counts["variants"], sum(len(p.get("variants", [])) for p in self.data["phones"]))
        self.assertEqual(counts["salesListings"], len(self.sales))
        self.assertEqual(counts["auditFindings"], len(self.data.get("auditFindings", [])))

    def test_no_url_listing_is_not_marked_available(self):
        false_available = [
            (phone["id"], sale.get("channel"), sale.get("retailer"))
            for phone, _variant, sale in self.sales
            if not sale.get("url") and sale.get("availability") == "AVAILABLE"
        ]
        self.assertEqual([], false_available, f"unverified availability: {false_available}")

    def test_former_url_less_placeholders_are_replaced_with_verified_xiaomi_store_entries(self):
        unresolved = [
            (phone, variant, sale)
            for phone, variant, sale in self.sales
            if not sale.get("url")
        ]
        self.assertEqual([], unresolved)
        redmi = next(phone for phone in self.data["phones"] if phone.get("model") == "REDMI Note 17 Pro Max 5G")
        self.assertEqual(2, len(redmi["variants"]))
        for variant in redmi["variants"]:
            store = [sale for sale in variant["sales"] if sale.get("channel") == "SIM_FREE" and sale.get("retailer") == "Xiaomi公式ストア（SIMフリー）"]
            self.assertEqual(1, len(store))
            self.assertTrue(store[0].get("url"))
            if variant.get("storageGb") == 256:
                self.assertEqual(79980, store[0]["priceOptions"][0]["priceYen"])
            else:
                self.assertEqual("UNKNOWN", store[0].get("availability"))

    def test_importer_does_not_fabricate_url_for_missing_source(self):
        self.assertIn("listingsSkippedNoUrl", self.importer)
        self.assertIn("sale.url?.trim()?.takeIf { it.isNotEmpty() }", self.importer)

    def test_catalog_ids_and_variant_keys_are_unique(self):
        ids = [p.get("id") for p in self.data["phones"]]
        self.assertEqual(len(ids), len(set(ids)))
        for phone in self.data["phones"]:
            keys = [(v.get("storageGb"), v.get("ramGb")) for v in phone.get("variants", [])]
            self.assertEqual(len(keys), len(set(keys)), phone.get("id"))


if __name__ == "__main__":
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(CatalogUrlAvailabilityTest)
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    raise SystemExit(0 if result.wasSuccessful() else 1)
