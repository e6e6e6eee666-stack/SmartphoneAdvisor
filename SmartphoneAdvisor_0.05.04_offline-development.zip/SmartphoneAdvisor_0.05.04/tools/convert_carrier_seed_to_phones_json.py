#!/usr/bin/env python3
"""Convert CarrierCatalogSeed.kt files and reverse-audit CSVs into phones.json.

Usage:
  python convert_carrier_seed_to_phones_json.py \
    --seed path/to/CarrierCatalogSeed.kt \
    --csv path/to/softbank_reverse_audit.csv \
    --output app/src/main/assets/phones.json

The latest cumulative CarrierCatalogSeed should be supplied as --seed. CSV findings
are retained under auditFindings and are never silently promoted to sales listings.
"""
import argparse, csv, json, re
from collections import OrderedDict

def split_args(text):
    parts=[]; cur=[]; depth=0; quote=False; esc=False
    for c in text:
        if quote:
            cur.append(c)
            if esc: esc=False
            elif c=='\\': esc=True
            elif c=='"': quote=False
        else:
            if c=='"': quote=True; cur.append(c)
            elif c=='(': depth+=1; cur.append(c)
            elif c==')': depth-=1; cur.append(c)
            elif c==',' and depth==0: parts.append(''.join(cur).strip()); cur=[]
            else: cur.append(c)
    if ''.join(cur).strip(): parts.append(''.join(cur).strip())
    return parts

def parse_entry(line):
    if 'Entry(' not in line or 'private data class Entry' in line: return None
    body=line.split('Entry(',1)[1].rstrip()
    if body.endswith('),'): body=body[:-2]
    elif body.endswith(')'): body=body[:-1]
    parts=split_args(body); positional=['model','manufacturer','series','year']; vals={}
    for i,p in enumerate(parts):
        if '=' in p: k,v=p.split('=',1); vals[k.strip()]=v.strip()
        elif i < len(positional): vals[positional[i]]=p.strip()
    def s(v):
        if v is None or v=='null': return None
        if v.startswith('"') and v.endswith('"'): return v[1:-1]
        return v
    def i(v): return None if s(v) is None else int(s(v))
    def e(v): return None if s(v) is None else s(v).split('.')[-1]
    return {
      'model':s(vals.get('model')), 'manufacturer':s(vals.get('manufacturer')), 'series':s(vals.get('series')),
      'year':i(vals.get('year')), 'platform':s(vals.get('platform')) or 'ANDROID', 'storageGb':i(vals.get('storageGb')),
      'ramGb':i(vals.get('ramGb')), 'modelNumber':s(vals.get('modelNumber')), 'channel':e(vals.get('channel')),
      'retailer':s(vals.get('retailer')), 'url':s(vals.get('url')), 'availability':e(vals.get('availability')) or 'AVAILABLE'
    }

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--seed',required=True); ap.add_argument('--csv',action='append',default=[]); ap.add_argument('--output',required=True); args=ap.parse_args()
    entries=[e for line in open(args.seed,encoding='utf-8') if (e:=parse_entry(line)) and e['model']]
    phones=OrderedDict()
    for e in entries:
        pk=(e['manufacturer'],e['model'],e['year'],e['platform'])
        p=phones.setdefault(pk,OrderedDict(id=f'{e["manufacturer"]}:{e["model"]}:{e["year"]}',manufacturer=e['manufacturer'],model=e['model'],series=e['series'],platform=e['platform'],releaseYear=e['year'],isJapanOfficial=True,variants=OrderedDict()))
        vk=(e['storageGb'],e['ramGb'])
        v=p['variants'].setdefault(vk,OrderedDict(storageGb=e['storageGb'],ramGb=e['ramGb'],sales=[]))
        v['sales'].append(OrderedDict(channel=e['channel'],retailer=e['retailer'],modelNumber=e['modelNumber'],availability=e['availability'],url=e['url']))
    out=[]
    for p in phones.values():
        p['variants']=list(p['variants'].values()); out.append(p)
    findings=[]; seen=set()
    for path in args.csv:
        with open(path,encoding='utf-8-sig',newline='') as f:
            for r in csv.DictReader(f):
                # Legacy reverse-audit CSVs may contain price_yen. It is not part
                # of JsonAuditFinding and must not be re-emitted into phones.json.
                # Keep the original-row deduplication semantics, even if two
                # rows differ only in the now-omitted legacy price field.
                k=tuple(sorted(r.items()))
                finding = {key: value for key, value in r.items() if key != 'price_yen'}
                if k not in seen: seen.add(k); findings.append(finding)
    doc=OrderedDict(schemaVersion='1.0.0',generatedFrom='CarrierCatalogSeed.kt + reverse-audit CSV',authoritativeCarrierSource=args.seed,sourceArtifacts=[args.seed]+args.csv,counts=OrderedDict(carrierEntryRecords=len(entries),phoneModels=len(out),variants=sum(len(p['variants']) for p in out),salesListings=sum(len(v['sales']) for p in out for v in p['variants']),uniqueAuditFindings=len(findings)),phones=out,auditFindings=findings)
    with open(args.output,'w',encoding='utf-8') as f: json.dump(doc,f,ensure_ascii=False,indent=2)
    print(json.dumps(doc['counts'],ensure_ascii=False))
if __name__=='__main__': main()
