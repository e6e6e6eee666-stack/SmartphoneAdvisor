"""Guard the parser against trusting stale counts embedded in phones.json."""
import json
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
source = (ROOT / "app/src/main/java/jp/smartphoneadvisor/app/data/catalog/PhoneCatalogJson.kt").read_text(encoding="utf-8")
assert 'root.optJSONObject("counts")' in source
for key in ("phoneModels", "variants", "salesListings", "priceOptions", "auditFindings"):
    assert f'"{key}" to' in source, f"parser does not calculate {key}"
assert '"phones.json: counts.$key is missing"' in source
assert '"phones.json: counts.$key=${counts.getInt(key)} does not match parsed value $actual"' in source
catalog = json.loads((ROOT / "app/src/main/assets/phones.json").read_text(encoding="utf-8"))
actual = {
    "phoneModels": len(catalog["phones"]),
    "variants": sum(len(p.get("variants", [])) for p in catalog["phones"]),
    "salesListings": sum(len(v.get("sales", [])) for p in catalog["phones"] for v in p.get("variants", [])),
    "priceOptions": sum(len(s.get("priceOptions", [])) for p in catalog["phones"] for v in p.get("variants", []) for s in v.get("sales", [])),
    "auditFindings": len(catalog.get("auditFindings", [])),
}
assert catalog["counts"] == actual, f"phones.json counts mismatch: declared={catalog['counts']} actual={actual}"
print("PASS: parser validates all five declared catalog counts; current phones.json counts match parsed content")
