import csv, json, unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
class IIJMioGenericUrlReviewTest(unittest.TestCase):
 def test_official_product_specific_urls_replace_generic_urls_for_verified_models(self):
  data=json.loads((ROOT/"app/src/main/assets/phones.json").read_text(encoding="utf-8"))
  expected={
   "MIVEケースマ":"https://www.iijmio.jp/device/alt/mive-kesuma.html",
   "OPPO Reno16 5G":"https://www.iijmio.jp/device/oppo/reno16-5g.html",
   "Galaxy Z Fold8 Ultra":"https://www.iijmio.jp/device/samsung/galaxy-z-fold8-ultra.html",
   "Galaxy Z Fold8":"https://www.iijmio.jp/device/samsung/galaxy-z-fold8.html",
   "Galaxy Z Flip8":"https://www.iijmio.jp/device/samsung/galaxy-z-flip8.html",
   "moto g37j":"https://www.iijmio.jp/device/motorola/moto-g37j.html",
   "motorola edge 60":"https://www.iijmio.jp/device/motorola/edge60.html",
   "Nothing Phone (4a)":"https://www.iijmio.jp/device/nothing/phone4a.html",
   "Galaxy A57 5G":"https://www.iijmio.jp/device/samsung/galaxy-a57-5g.html",
   "OPPO Find N6":"https://www.iijmio.jp/device/oppo/findn6.html",
  }
  found={}
  for phone in data["phones"]:
   if phone.get("model") not in expected: continue
   for variant in phone.get("variants",[]):
    for sale in variant.get("sales",[]):
     if sale.get("channel")=="IIJ_MIO": found.setdefault(phone["model"],set()).add(sale.get("url"))
  for model,url in expected.items(): self.assertEqual(found.get(model),{url},model)
  self.assertEqual(sum(1 for urls in found.values() for url in urls if url in expected.values()),10)
  redmi_urls={}
  for phone in data["phones"]:
   if phone.get("model") != "REDMI Note 17 Pro Max 5G": continue
   for variant in phone.get("variants",[]):
    for sale in variant.get("sales",[]):
     if sale.get("channel") == "IIJ_MIO":
      redmi_urls[variant.get("storageGb")] = sale.get("url")
      self.assertTrue(all(x.get("sourceUrl") == sale.get("url") for x in sale.get("priceOptions",[])))
  self.assertEqual(redmi_urls,{256:"https://www.iijmio.jp/device/detail.html?key=REDMI_Note_17_Pro_Max_5G_256GB",512:"https://www.iijmio.jp/device/detail.html?key=REDMI_Note_17_Pro_Max_5G_512GB"})
 def test_review_matches_source_records_without_mutating_catalog(self):
  data=json.loads((ROOT/"app/src/main/assets/phones.json").read_text(encoding="utf-8"))
  expected=[]
  for phone in data["phones"]:
   for variant in phone.get("variants",[]):
    for sale in variant.get("sales",[]):
     if sale.get("channel")=="IIJ_MIO" and sale.get("url")=="https://www.iijmio.jp/device/":
      expected.append((phone.get("id",""),phone.get("model",""),str(variant.get("storageGb","")),str(variant.get("ramGb",""))))
  with (ROOT/"IIJMIO_GENERIC_URL_REVIEW_2026-10-20.csv").open(encoding="utf-8-sig",newline="") as f: rows=list(csv.DictReader(f))
  actual=[(r["phoneId"],r["model"],r["storageGb"],r["ramGb"]) for r in rows]
  self.assertEqual(len(expected),7)
  self.assertEqual(sorted(expected),sorted(actual))
  self.assertTrue(all(r["repairDecision"]=="DO_NOT_GUESS_PRODUCT_URL" for r in rows))
  self.assertTrue(all(r["currentUrl"]=="https://www.iijmio.jp/device/" for r in rows))
  self.assertTrue(all(r["modelEvidence"] in {"MODEL_SEEN_EXACT_VARIANT_UNVERIFIED", "MODEL_NOT_CONFIRMED_IN_RETRIEVED_OFFICIAL_PAGE"} for r in rows))
  self.assertEqual(sum(r["modelEvidence"]=="MODEL_SEEN_EXACT_VARIANT_UNVERIFIED" for r in rows), 3)
  self.assertEqual(sum(r["modelEvidence"]=="MODEL_NOT_CONFIRMED_IN_RETRIEVED_OFFICIAL_PAGE" for r in rows), 4)
  self.assertTrue(all(r["availability"]=="AVAILABLE" for r in rows))
  self.assertTrue(all("exact SKU" in r["evidenceNote"] or "Model name" in r["evidenceNote"] or "Model family" in r["evidenceNote"] or "Current official lineup" in r["evidenceNote"] for r in rows))
  report=(ROOT/"IIJMIO_GENERIC_URL_REVIEW_2026-10-20.md").read_text(encoding="utf-8")
  self.assertIn("**10**", report)
  self.assertNotIn("{len(rows)}", report)
  self.assertIn("**5**", report)
  self.assertIn("not a determination that unconfirmed models are not sold", report)
if __name__=="__main__": unittest.main()
