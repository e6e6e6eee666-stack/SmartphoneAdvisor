#!/usr/bin/env python3
"""Static regression test for honest retailer-link labels in SmartphoneAdvisor 0.04.47."""
import json
from pathlib import Path
from urllib.parse import urlparse

from current_version import current_version_is_valid
ROOT = Path(__file__).resolve().parents[1]
CATALOG = ROOT / "app/src/main/assets/phones.json"
SOURCE = ROOT / "app/src/main/java/jp/smartphoneadvisor/app/MainActivity.kt"

# Mirror the intentionally narrow host/path allowlist in isGeneralSalesListingUrl.
GENERAL_PATHS = {
    ("mineo.jp", "/device/smartphone"),
    ("www.iijmio.jp", "/device"),
    ("shop.uqmobile.jp", "/shop/lineup"),
    ("network.mobile.rakuten.co.jp", "/product/smartphone"),
    ("buy.mi.com", "/jp/products/all"),
    ("www.ymobile.jp", "/lineup/simfree"),
    ("jp.nothing.tech", "/collections/phones"),
    ("jp.nubia.com", "/collections/nubia-z-series"),
    ("www.softbank.jp", "/iphone/iphone-16"),
    ("www.softbank.jp", "/iphone/iphone-18-pro"),
    ("www.au.com", "/iphone/product/iphone-18-pro"),
    ("www.softbank.jp", "/mobile/products/google-pixel/google-pixel-9-pro"),
    ("rog.asus.com", "/jp/phones/rog-phone-9-pro"),
}


def is_general(url: str) -> bool:
    u = urlparse(url)
    return (u.hostname or "", u.path.rstrip("/")) in GENERAL_PATHS


def main() -> int:
    data = json.loads(CATALOG.read_text(encoding="utf-8"))
    source = SOURCE.read_text(encoding="utf-8")
    errors = []
    all_urls = {
        s.get("url")
        for p in data.get("phones", [])
        for v in p.get("variants", [])
        for s in v.get("sales", [])
        if s.get("url")
    }
    catalog_general_urls = sorted(url for url in all_urls if is_general(url))
    for host, path in sorted(GENERAL_PATHS):
        url = f"https://{host}{path}/"
        if not is_general(url):
            errors.append(f"general URL not recognized: {url}")
    product_url = "https://www.ymobile.jp/lineup/smartphone/pixel10a/"
    if is_general(product_url):
        errors.append("model-specific Y!mobile URL was incorrectly classified as general")
    if "private fun isGeneralSalesListingUrl(rawUrl: String): Boolean" not in source:
        errors.append("Kotlin classifier function missing")
    for phrase in ("販売機種一覧を開く", "販売ページを開く", "移動先で機種・容量・在庫を確認してください。"):
        if phrase not in source:
            errors.append(f"UI wording missing: {phrase}")
    build = (ROOT / "app/build.gradle.kts").read_text(encoding="utf-8")
    # This historical regression test is also run against later versions that preserve its behavior.
    if not current_version_is_valid(build):
        errors.append("current app version does not retain the 0.04.47 sales-link behavior")
    print("SmartphoneAdvisor 0.04.47 retailer URL label test")
    print(f"Unique catalogue URLs: {len(all_urls)}")
    print(f"Known general listing URLs found in catalogue: {len(catalog_general_urls)}")
    for url in catalog_general_urls:
        print(f"GENERAL: {url}")
    print(f"Errors: {len(errors)}")
    for e in errors:
        print(f"FAIL: {e}")
    if errors:
        return 1
    print("PASS: generic listing pages have a distinct label; model-specific product URL remains classified as a product page")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
