#!/usr/bin/env python3
"""Guard that Android JUnit covers malformed price provenance in the Kotlin validator."""
from pathlib import Path
from current_version import current_version_is_valid
ROOT = Path(__file__).resolve().parents[1]
test = (ROOT / "app/src/test/java/jp/smartphoneadvisor/app/data/catalog/PhoneCatalogRoomImporterTest.kt").read_text(encoding="utf-8")
build = (ROOT / "app/build.gradle.kts").read_text(encoding="utf-8")
required = [
    "priceOptionWithImpossibleCalendarDateIsRejected",
    "priceOptionWithNonHttpsOrHostlessSourceIsRejected",
    "priceOptionWithMissingProvenanceIsRejected",
    "checkedAt must be a real calendar date",
    "price sourceUrl must be a valid HTTPS URL",
]
missing = [x for x in required if x not in test]
if not current_version_is_valid(build):
    missing.append("app version guard")
if missing:
    raise SystemExit("FAIL: missing JUnit provenance coverage: " + ", ".join(missing))
print("PASS: Kotlin JUnit suite now explicitly covers invalid dates, missing provenance, and invalid price-source URLs")
