#!/usr/bin/env python3
"""Regression test: combined official Pro/Pro Max pages must be treated as shared listings."""
import json
from pathlib import Path
from current_version import current_version_is_valid
ROOT = Path(__file__).resolve().parents[1]
DATA = json.loads((ROOT / "app/src/main/assets/phones.json").read_text(encoding="utf-8"))
BUILD = (ROOT / "app/build.gradle.kts").read_text(encoding="utf-8")

def main():
    errors=[]
    models={p.get("model"):p for p in DATA.get("phones",[])}
    target=models.get("iPhone 18 Pro Max")
    if target is None: errors.append("iPhone 18 Pro Max missing")
    else:
        checked=0
        for v in target.get("variants",[]):
            for s in v.get("sales",[]):
                if s.get("channel") in {"AU","SOFTBANK"}:
                    checked += 1
                    url=(s.get("url") or "").lower()
                    expected = {"AU": "https://www.au.com/iphone/product/iphone-18-pro/", "SOFTBANK": "https://www.softbank.jp/iphone/iphone-18-pro/"}.get(s.get("channel"))
                    if url and url != expected:
                        errors.append(f"unexpected official combined page: {v.get('storageGb')}GB {s.get('channel')} {url}")
                    if url and s.get("availability") == "AVAILABLE" and s.get("channel") == "AU" and v.get("storageGb") == 2048:
                        errors.append("AU 2TB listing marked AVAILABLE although official page does not list 2TB")
                    if s.get("availability") == "AVAILABLE" and not url:
                        errors.append(f"URL-less Pro Max listing marked AVAILABLE: {v.get('storageGb')}GB {s.get('channel')}")
                    if not url and s.get("availability") != "UNKNOWN":
                        errors.append(f"URL-less Pro Max listing must be UNKNOWN: {v.get('storageGb')}GB {s.get('channel')}")
        if checked != 8: errors.append(f"expected 8 AU/SoftBank storage/channel entries, got {checked}")
    if not current_version_is_valid(BUILD):
        errors.append("build version mismatch")
    print("SmartphoneAdvisor model-sales-link identity regression (introduced 0.04.49)")
    print("Pro Max AU/SoftBank entries checked: 8")
    print(f"Errors: {len(errors)}")
    for e in errors: print("FAIL:",e)
    if errors: return 1
    print("PASS: AU/SoftBank Pro Max entries use official combined Pro/Pro Max pages; unconfirmed capacities are not asserted available")
    return 0
if __name__ == "__main__": raise SystemExit(main())
