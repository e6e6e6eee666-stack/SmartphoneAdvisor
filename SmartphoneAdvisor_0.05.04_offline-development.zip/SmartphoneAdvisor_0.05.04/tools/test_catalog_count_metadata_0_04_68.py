#!/usr/bin/env python3
"""Ensure phones.json count metadata matches the actual catalog records."""
import json
from pathlib import Path
from current_version import current_version_is_valid
ROOT = Path(__file__).resolve().parents[1]
BUILD = (ROOT / "app/build.gradle.kts").read_text()
CATALOG = json.loads((ROOT / "app/src/main/assets/phones.json").read_text())
errors = []
if not current_version_is_valid(BUILD):
    errors.append("current app version metadata is invalid")
actual = {
    "phoneModels": len(CATALOG.get("phones", [])),
    "variants": sum(len(phone.get("variants", [])) for phone in CATALOG.get("phones", [])),
    "salesListings": sum(len(variant.get("sales", [])) for phone in CATALOG.get("phones", []) for variant in phone.get("variants", [])),
    "auditFindings": len(CATALOG.get("auditFindings", [])),
    "priceOptions": sum(len(sale.get("priceOptions", [])) for phone in CATALOG.get("phones", []) for variant in phone.get("variants", []) for sale in variant.get("sales", [])),
}
for key, value in actual.items():
    recorded = CATALOG.get("counts", {}).get(key)
    if recorded != value:
        errors.append(f"counts.{key} says {recorded!r}; actual catalog contains {value}")
if errors:
    print("FAIL")
    print("\n".join(f"- {error}" for error in errors))
    raise SystemExit(1)
print("PASS: phones.json count metadata matches actual models, variants, sales listings, audit findings, and price options")
print("Catalog: {phoneModels} models / {variants} variants / {salesListings} sales listings / {priceOptions} price options".format(**actual))
