#!/usr/bin/env python3
"""Historical catalog regression audit for the sales URL inventory snapshots."""
from __future__ import annotations
import csv, json, re
from collections import Counter
from pathlib import Path

from current_version import current_version_is_valid
ROOT = Path(__file__).resolve().parents[1]
BUILD = (ROOT / 'app/build.gradle.kts').read_text(encoding='utf-8')
assert current_version_is_valid(BUILD), 'invalid active version metadata'


def inventory(version: str) -> list[dict[str, str]]:
    path = ROOT / f'SALES_URL_INVENTORY_{version}.csv'
    assert path.is_file(), f'missing historical inventory: {path.name}'
    with path.open(encoding='utf-8-sig', newline='') as f:
        return list(csv.DictReader(f))


def sales_match(row: dict[str, str], *, manufacturer: str, model: str,
                storage: str, channel: str, retailer: str | None = None,
                url: str | None = None) -> bool:
    return (row.get('manufacturer') == manufacturer and row.get('model') == model
            and row.get('storage_gb') == storage and row.get('channel') == channel
            and (retailer is None or row.get('retailer') == retailer)
            and (url is None or row.get('url') == url))

# Finding 1: four carrier sales rows for iPhone 18 Pro 2TB disappeared in 0.04.57,
# although the 0.04.57 work log describes the intended removal as Pixel 11 Pro 2TB.
carrier_rows = [
    ('DOCOMO', 'NTTドコモ', 'https://www.docomo.ne.jp/product/iphone18pro/'),
    ('AU', 'au', 'https://www.au.com/iphone/product/iphone-18-pro/'),
    ('SOFTBANK', 'ソフトバンク', 'https://www.softbank.jp/iphone/iphone-18-pro/'),
    ('RAKUTEN', '楽天モバイル', 'https://network.mobile.rakuten.co.jp/product/iphone/iphone-18-pro/'),
]
for ver in ('0.04.52',):
    rows = inventory(ver)
    for channel, retailer, url in carrier_rows:
        assert any(sales_match(r, manufacturer='Apple', model='iPhone 18 Pro', storage='2048', channel=channel, retailer=retailer, url=url) for r in rows), f'{ver}: expected historical iPhone 18 Pro 2TB {channel} row'
for ver in ('0.04.57', '0.04.59'):
    rows = inventory(ver)
    for channel, retailer, url in carrier_rows:
        assert not any(sales_match(r, manufacturer='Apple', model='iPhone 18 Pro', storage='2048', channel=channel, retailer=retailer, url=url) for r in rows), f'{ver}: expected documented historical disappearance to be represented'
for ver in ('0.04.60', '0.04.74'):
    rows = inventory(ver)
    for channel, retailer, url in carrier_rows:
        assert any(sales_match(r, manufacturer='Apple', model='iPhone 18 Pro', storage='2048', channel=channel, retailer=retailer, url=url) for r in rows), f'{ver}: iPhone 18 Pro 2TB {channel} row not restored/preserved'

# Finding 2: Xiaomi placeholder retailer records returned in 0.04.62 after being
# replaced by official SIM-free records in 0.04.61; 0.04.69 corrected them again.
xiaomi_url = 'https://www.mi.com/jp/product/redmi-note-17-pro-max-5g/buy/'
for storage in ('256', '512'):
    rows61, rows62, rows69, rows74 = (inventory(v) for v in ('0.04.61', '0.04.62', '0.04.69', '0.04.74'))
    assert any(sales_match(r, manufacturer='Xiaomi', model='REDMI Note 17 Pro Max 5G', storage=storage, channel='SIM_FREE', retailer='Xiaomi公式ストア（SIMフリー）', url=xiaomi_url) for r in rows61), f'0.04.61 missing corrected Xiaomi {storage}GB row'
    assert any(sales_match(r, manufacturer='Xiaomi', model='REDMI Note 17 Pro Max 5G', storage=storage, channel='Y_MOBILE', retailer='Y!mobile Free Style', url='') for r in rows62), f'0.04.62 historical placeholder regression not found for {storage}GB'
    assert any(sales_match(r, manufacturer='Xiaomi', model='REDMI Note 17 Pro Max 5G', storage=storage, channel='SIM_FREE', retailer='Xiaomi公式ストア（SIMフリー）', url=xiaomi_url) for r in rows69), f'0.04.69 missing corrected Xiaomi {storage}GB row'
    assert any(sales_match(r, manufacturer='Xiaomi', model='REDMI Note 17 Pro Max 5G', storage=storage, channel='SIM_FREE', retailer='Xiaomi公式ストア（SIMフリー）', url=xiaomi_url) for r in rows74), f'current Xiaomi {storage}GB row missing'
    assert not any(sales_match(r, manufacturer='Xiaomi', model='REDMI Note 17 Pro Max 5G', storage=storage, channel='Y_MOBILE', retailer='Y!mobile Free Style', url='') for r in rows74), f'current Xiaomi {storage}GB placeholder remains'

# Finding 3: actual historical ZIP phones.json files show Nothing Phone (4a) split
# through 0.04.72 and merged in 0.04.73. The generated .72 URL inventory did not
# faithfully expose the second identity, so do not use that CSV as proof of uniqueness.
history = json.loads((ROOT / 'tools/historical_catalog_facts_0_04_75.json').read_text(encoding='utf-8'))
for ver in ('0.04.70', '0.04.71', '0.04.72'):
    ids = history['nothingPhone4aModelIds'][ver]['modelIds']
    assert 'Nothing:Nothing Phone (4a):2026' in ids and 'Nothing:Phone (4a):2026' in ids, f'{ver}: historical JSON did not record both Nothing identities'
for ver in ('0.04.73', '0.04.74'):
    ids = history['nothingPhone4aModelIds'][ver]['modelIds']
    assert ids == ['Nothing:Nothing Phone (4a):2026'], f'{ver}: historical JSON identity merge not reflected: {ids}'
rows72 = inventory('0.04.72')
assert not any(r.get('model_id') == 'Nothing:Phone (4a):2026' for r in rows72), 'expected to preserve the documented discrepancy: .72 CSV masks duplicate model ID found in its actual phones.json'

# Verify current JSON itself, not only its generated inventory.
data = json.loads((ROOT / 'app/src/main/assets/phones.json').read_text(encoding='utf-8'))
phones = data['phones']
nothing = [p for p in phones if p.get('manufacturer') == 'Nothing' and p.get('model') in ('Nothing Phone (4a)', 'Phone (4a)')]
assert len(nothing) == 1 and nothing[0]['model'] == 'Nothing Phone (4a)', 'Nothing Phone (4a) model identity is not unique'
price_facts = []
for v in nothing[0].get('variants', []):
    for s in v.get('sales', []):
        if s.get('retailer') == 'Nothing Store Japan':
            for po in s.get('priceOptions', []):
                price_facts.append((v.get('storageGb'), po.get('priceYen')))
assert (128, 58800) in price_facts and (256, 64800) in price_facts, f'Nothing official prices missing: {price_facts}'

# Current JSON must retain the four known carrier sales rows for iPhone 18 Pro 2TB.
iphone = next(p for p in phones if p.get('manufacturer') == 'Apple' and p.get('model') == 'iPhone 18 Pro')
variant = next(v for v in iphone['variants'] if v.get('storageGb') == 2048)
for channel, retailer, url in carrier_rows:
    assert any(s.get('channel') == channel and s.get('retailer') == retailer and s.get('url') == url for s in variant.get('sales', [])), f'current JSON missing iPhone 18 Pro 2TB {channel}'

print('PASS: historical sales regression audit (iPhone 18 Pro 2TB disappearance/restoration; Xiaomi placeholder reintroduction; Nothing duplicate identity merge; current JSON retention)')
