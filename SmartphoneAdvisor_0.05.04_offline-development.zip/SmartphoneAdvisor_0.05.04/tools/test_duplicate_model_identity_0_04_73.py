import json, re
from collections import defaultdict
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
data=json.loads((ROOT/'app/src/main/assets/phones.json').read_text())
errors=[]
groups=defaultdict(list)
for p in data['phones']:
    model=p.get('model','').strip()
    model=re.sub(r'^(Nothing)\s+', '', model, flags=re.I)
    groups[(p.get('manufacturer','').casefold(),model.casefold(),p.get('releaseYear'),p.get('platform'))].append(p)
duplicates=[(k,v) for k,v in groups.items() if len(v)>1]
if duplicates: errors.append('duplicate model identities: '+repr([(k,[x.get('id') for x in v]) for k,v in duplicates]))
if len(data['phones'])!=195: errors.append(f'expected 195 unique model records, got {len(data["phones"])}')
if sum(len(p.get('variants',[])) for p in data['phones'])!=315: errors.append('expected 315 variants after duplicate merge')
if errors:
    print('FAIL'); print('\n'.join(errors)); raise SystemExit(1)
print('PASS: no duplicate model identities under manufacturer-prefix normalization; 195 models / 315 variants')
