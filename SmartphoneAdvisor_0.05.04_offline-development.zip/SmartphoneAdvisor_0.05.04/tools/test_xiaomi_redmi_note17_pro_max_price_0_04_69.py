#!/usr/bin/env python3
"""Verify the current official Xiaomi Japan listing and its correctly scoped price."""
import json
from pathlib import Path
from current_version import current_version_is_valid
ROOT = Path(__file__).resolve().parents[1]
BUILD = (ROOT / 'app/build.gradle.kts').read_text(encoding='utf-8')
DATA = json.loads((ROOT / 'app/src/main/assets/phones.json').read_text(encoding='utf-8'))
assert current_version_is_valid(BUILD)
phone = next(p for p in DATA['phones'] if p['model'] == 'REDMI Note 17 Pro Max 5G')
assert phone['isJapanOfficial'] is True
for variant in phone['variants']:
    sales = [s for s in variant['sales'] if s.get('channel') == 'SIM_FREE' and s.get('retailer') == 'Xiaomi公式ストア（SIMフリー）']
    assert len(sales) == 1, (variant['storageGb'], sales)
    sale = sales[0]
    assert sale['url'] == 'https://www.mi.com/jp/product/redmi-note-17-pro-max-5g/buy/'
    if variant['storageGb'] == 256:
        assert sale['availability'] == 'AVAILABLE'
        assert len(sale['priceOptions']) == 1
        option = sale['priceOptions'][0]
        assert option['priceYen'] == 79980
        assert option['priceType'] == 'NORMAL'
        assert option['sourceUrl'] == 'https://buy.mi.com/jp/products/all'
        assert option['checkedAt'] == '2026-10-17'
        assert '早割キャンペーン価格ではなく' in option['conditions']
    elif variant['storageGb'] == 512:
        assert sale['availability'] == 'UNKNOWN'
        assert not sale.get('priceOptions')
    else:
        raise AssertionError(f'unexpected storage {variant["storageGb"]}')
assert not any(s.get('channel') == 'Y_MOBILE' for v in phone['variants'] for s in v['sales'])
actual_sales = sum(len(v.get('sales', [])) for p in DATA['phones'] for v in p.get('variants', []))
actual_prices = sum(len(s.get('priceOptions', [])) for p in DATA['phones'] for v in p.get('variants', []) for s in v.get('sales', []))
assert DATA['counts']['salesListings'] == actual_sales == 511
assert DATA['counts']['priceOptions'] == actual_prices == 100
print('PASS: Xiaomi Japan SIM-free listing is registered; 256GB price is source-backed; 512GB remains unconfirmed; counts match.')
