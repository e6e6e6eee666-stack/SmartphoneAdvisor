#!/usr/bin/env python3
"""Execute getPurchaseOptions SQL against SQLite fixtures for safe price/link display."""
import sqlite3
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
dao = (ROOT / 'app/src/main/java/jp/smartphoneadvisor/app/data/PhoneDao.kt').read_text(encoding='utf-8')
method_pos = dao.find('suspend fun getPurchaseOptions(')
assert method_pos >= 0
query_start = dao.rfind('@Query("""', 0, method_pos)
assert query_start >= 0
body_start = dao.find('"""', query_start + len('@Query("""'))
assert body_start >= 0
sql = dao[query_start + len('@Query("""'):body_start].replace(':deviceVariantId', '?').strip()

conn = sqlite3.connect(':memory:')
conn.executescript('''
CREATE TABLE sales_variant (id INTEGER PRIMARY KEY, deviceVariantId INTEGER, isActive INTEGER);
CREATE TABLE product_listing (id INTEGER PRIMARY KEY, salesVariantId INTEGER, retailerId INTEGER, productUrl TEXT, availability TEXT);
CREATE TABLE retailer (id INTEGER PRIMARY KEY, name TEXT, type TEXT, official INTEGER);
CREATE TABLE price_record_v2 (id INTEGER PRIMARY KEY, productListingId INTEGER, priceType TEXT, priceYen INTEGER, pointsValueYen INTEGER, couponValueYen INTEGER, tradeInValueYen INTEGER, shippingFeeYen INTEGER, conditions TEXT, checkedAt INTEGER, color TEXT, sourceUrl TEXT);
INSERT INTO retailer VALUES (1, 'Official', 'MANUFACTURER', 1);
INSERT INTO sales_variant VALUES (1, 10, 1);
INSERT INTO product_listing VALUES (11, 1, 1, 'https://example.test/available', 'AVAILABLE');
INSERT INTO price_record_v2 VALUES (101, 11, 'NORMAL', 100000, NULL, NULL, NULL, NULL, NULL, 100, 'Black', 'https://example.test/price');
INSERT INTO sales_variant VALUES (2, 10, 1);
INSERT INTO product_listing VALUES (12, 2, 1, 'https://example.test/unknown', 'UNKNOWN');
INSERT INTO price_record_v2 VALUES (102, 12, 'NORMAL', 50000, NULL, NULL, NULL, NULL, NULL, 200, 'Black', 'https://example.test/price');
INSERT INTO sales_variant VALUES (3, 10, 1);
INSERT INTO product_listing VALUES (13, 3, 1, 'https://example.test/oos', 'OUT_OF_STOCK');
INSERT INTO price_record_v2 VALUES (103, 13, 'NORMAL', 60000, NULL, NULL, NULL, NULL, NULL, 300, 'Black', 'https://example.test/price');
INSERT INTO sales_variant VALUES (4, 10, 1);
INSERT INTO product_listing VALUES (14, 4, 1, NULL, 'UNKNOWN');
INSERT INTO price_record_v2 VALUES (104, 14, 'NORMAL', 70000, NULL, NULL, NULL, NULL, NULL, 400, 'Black', 'https://example.test/price');
INSERT INTO sales_variant VALUES (5, 10, 1);
INSERT INTO product_listing VALUES (15, 5, 1, 'https://example.test/discontinued', 'DISCONTINUED');
INSERT INTO price_record_v2 VALUES (105, 15, 'NORMAL', 80000, NULL, NULL, NULL, NULL, NULL, 500, 'Black', 'https://example.test/price');
''')
rows = conn.execute(sql, (10,)).fetchall()
assert len(rows) == 4, f'expected available, unknown, out-of-stock, and url-less rows, got {rows}'
by_url = {row[4]: row for row in rows}
available = by_url['https://example.test/available']
assert available[6] == 'NORMAL' and available[7] == 100000
unknown = by_url['https://example.test/unknown']
assert unknown[6] is None and unknown[7] is None, f'unknown price leaked: {unknown}'
oos = by_url['https://example.test/oos']
assert oos[6] is None and oos[7] is None, f'out-of-stock price leaked: {oos}'
url_less = by_url[None]
assert url_less[6] is None and url_less[7] is None, f'URL-less price leaked: {url_less}'
assert conn.execute('PRAGMA integrity_check').fetchone()[0] == 'ok'
print('PASS: purchase options query executes against SQLite fixture')
print('PASS: only AVAILABLE/LIMITED listings can contribute displayed prices')
print('PASS: UNKNOWN, OUT_OF_STOCK, URL-less listings retain status but no price')
print('PASS: DISCONTINUED listings are excluded')
print('PASS: SQLite integrity_check=ok')
