#!/usr/bin/env python3
"""Execute the getComparisonPrices SQL from PhoneDao.kt against a SQLite fixture."""
import re
import sqlite3
from pathlib import Path

root = Path(__file__).resolve().parents[1]
dao = (root / 'app/src/main/java/jp/smartphoneadvisor/app/data/PhoneDao.kt').read_text(encoding='utf-8')
method_pos = dao.find('suspend fun getComparisonPrices(')
assert method_pos >= 0, 'getComparisonPrices method not found in PhoneDao.kt'
query_start = dao.rfind('@Query("""', 0, method_pos)
assert query_start >= 0, 'getComparisonPrices @Query not found in PhoneDao.kt'
body_start = dao.find('"""', query_start + len('@Query("""'))
assert body_start >= 0, 'getComparisonPrices SQL body not found in PhoneDao.kt'
sql = dao[query_start + len('@Query("""'):body_start].replace('IN (:deviceIds)', 'IN (?)').strip()

conn = sqlite3.connect(':memory:')
conn.executescript('''
CREATE TABLE sales_variant (id INTEGER PRIMARY KEY, deviceVariantId INTEGER, isActive INTEGER);
CREATE TABLE product_listing (id INTEGER PRIMARY KEY, salesVariantId INTEGER, retailerId INTEGER, productUrl TEXT, availability TEXT);
CREATE TABLE retailer (id INTEGER PRIMARY KEY, name TEXT, official INTEGER);
CREATE TABLE price_record_v2 (id INTEGER PRIMARY KEY, productListingId INTEGER, priceType TEXT, priceYen INTEGER, checkedAt INTEGER, color TEXT, conditions TEXT, sourceUrl TEXT);
INSERT INTO sales_variant VALUES (1, 501, 1);
INSERT INTO product_listing VALUES (11, 1, 1, 'https://official.example/phone', 'AVAILABLE');
INSERT INTO retailer VALUES (1, 'Official Store', 1);
-- An older price for the same color must not replace the newest one.
INSERT INTO price_record_v2 VALUES (101, 11, 'NORMAL', 140000, 100, 'Black', NULL, 'https://official.example/price');
INSERT INTO price_record_v2 VALUES (102, 11, 'NORMAL', 139800, 200, 'Black', NULL, 'https://official.example/price');
INSERT INTO price_record_v2 VALUES (103, 11, 'NORMAL', 139800, 200, 'White', NULL, 'https://official.example/price');
INSERT INTO price_record_v2 VALUES (104, 11, 'NORMAL', 144800, 200, 'Starlight Knight', NULL, 'https://official.example/price');
INSERT INTO price_record_v2 VALUES (105, 11, 'MNP', 99800, 200, 'Black', 'MNP contract required', 'https://official.example/price');
INSERT INTO price_record_v2 VALUES (106, 11, 'NORMAL', 120000, 150, 'White', NULL, 'https://official.example/price');
-- Unknown/out-of-stock/unlinked listings must not appear as purchasable comparison prices.
INSERT INTO sales_variant VALUES (2, 501, 1);
INSERT INTO product_listing VALUES (12, 2, 1, NULL, 'UNKNOWN');
INSERT INTO price_record_v2 VALUES (107, 12, 'NORMAL', 50000, 300, 'Black', NULL, 'https://official.example/price');
INSERT INTO sales_variant VALUES (3, 501, 1);
INSERT INTO product_listing VALUES (13, 3, 1, 'https://official.example/oos', 'OUT_OF_STOCK');
INSERT INTO price_record_v2 VALUES (108, 13, 'NORMAL', 60000, 300, 'Black', NULL, 'https://official.example/price');
INSERT INTO sales_variant VALUES (4, 501, 1);
INSERT INTO product_listing VALUES (14, 4, 1, '   ', 'AVAILABLE');
INSERT INTO price_record_v2 VALUES (109, 14, 'NORMAL', 70000, 300, 'Black', NULL, 'https://official.example/price');
''')
rows = conn.execute(sql, (501,)).fetchall()
assert len(rows) == 4, f'expected 4 latest color/type rows, got {len(rows)}: {rows}'
by_key = {(row[3], row[4]): row[5] for row in rows}
assert by_key[('Black', 'NORMAL')] == 139800
assert by_key[('White', 'NORMAL')] == 139800
assert by_key[('Starlight Knight', 'NORMAL')] == 144800
assert by_key[('Black', 'MNP')] == 99800
assert all(row[0] == 501 for row in rows)
assert all(row[1] == 'Official Store' for row in rows)
assert "pl.availability IN ('AVAILABLE','LIMITED')" in sql
assert 'pl.productUrl IS NOT NULL' in sql and "TRIM(pl.productUrl) <> ''" in sql
assert not any(row[5] in (50000, 60000, 70000) for row in rows), 'unverified/unavailable prices leaked into comparison'
assert conn.execute('PRAGMA integrity_check').fetchone()[0] == 'ok'
print('PASS: DAO comparison-price SQL extracted and executed')
print('PASS: latest price selected separately for each color and price type')
print('PASS: older price records are excluded')
print('PASS: conditional MNP price remains distinct from normal prices')
print('PASS: SQLite integrity_check=ok')
