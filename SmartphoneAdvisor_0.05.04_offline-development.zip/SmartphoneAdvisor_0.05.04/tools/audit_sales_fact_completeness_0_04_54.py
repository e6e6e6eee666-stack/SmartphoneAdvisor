#!/usr/bin/env python3
"""Compatibility entry point: corrected nested price audit lives in 0.04.55."""
import subprocess, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
raise SystemExit(subprocess.call([sys.executable, str(ROOT/'tools/audit_sales_fact_completeness_0_04_55.py')]))
