import json, unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
class IIJMioS26UltraUrlRepairTest(unittest.TestCase):
 def test_exact_page_and_stock_state_are_recorded_without_guessing_model_numbers(self):
  data=json.loads((ROOT/'app/src/main/assets/phones.json').read_text(encoding='utf-8'))
  found=[]
  for phone in data['phones']:
   if phone.get('model')!='Galaxy S26 Ultra': continue
   for variant in phone.get('variants',[]):
    for sale in variant.get('sales',[]):
     if sale.get('channel')=='IIJ_MIO': found.append((variant.get('ramGb'),variant.get('storageGb'),sale))
  self.assertEqual(len(found),3)
  self.assertTrue(all(s['url']=='https://www.iijmio.jp/device/samsung/galaxy-s26-ultra.html' for _,_,s in found))
  states={(ram,storage):sale['availability'] for ram,storage,sale in found}
  self.assertEqual(states[(12,256)],'AVAILABLE')
  self.assertEqual(states[(12,512)],'AVAILABLE')
  self.assertEqual(states[(16,1024)],'OUT_OF_STOCK')
  self.assertTrue(all(s.get('modelNumber') is None for _,_,s in found))
if __name__=='__main__': unittest.main()
