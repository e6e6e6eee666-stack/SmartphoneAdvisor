#!/usr/bin/env python3
"""Report price-option coverage gaps by channel and model without inventing prices."""
import collections, json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
CATALOG=ROOT/'app/src/main/assets/phones.json'; BUILD=ROOT/'app/build.gradle.kts'
OUT=ROOT/'PRICE_COVERAGE_AUDIT_0.04.72.md'
def main():
    data=json.loads(CATALOG.read_text(encoding='utf-8')); build=BUILD.read_text(encoding='utf-8')
    if 'versionName = "0.04.76"' not in build or 'versionCode = 124' not in build: raise SystemExit('FAIL: version mismatch; expected 0.04.72 / versionCode 121')
    phones=data.get('phones',[])
    rows=[(p,v,s) for p in phones for v in p.get('variants',[]) for s in v.get('sales',[])]
    by_channel=collections.defaultdict(list)
    for p,v,s in rows: by_channel[s.get('channel','<MISSING>')].append((p,v,s))
    status_counts=collections.Counter(s.get('availability','<MISSING>') for _,_,s in rows)
    opts=[(p,v,s,o) for p,v,s in rows for o in s.get('priceOptions',[])]
    missing=[(p,v,s) for p,v,s in rows if not s.get('priceOptions')]
    available_missing=[(p,v,s) for p,v,s in missing if s.get('availability')=='AVAILABLE']
    url_missing=[(p,v,s) for p,v,s in rows if not str(s.get('url') or '').strip()]
    lines=['# 価格登録カバレッジ監査（0.04.72）','', '## 目的・判定基準','', '価格情報の登録状況を販売チャネル別に見える化し、補完対象を優先付けする。既存の価格・販売状態・URLを推測で変更せず、確認できた価格だけを根拠付きで登録する。`priceOptions` は価格候補の登録有無であり、価格の現在性・購入可能性を保証しない。','', '## 全体集計','',f'- 機種：{len(phones)}件',f'- バリエーション：{sum(len(p.get("variants",[])) for p in phones)}件',f'- 販売登録：{len(rows)}件',f'- 価格オプション：{len(opts)}件',f'- 価格未登録の販売登録：{len(missing)}件',f'- `availability=AVAILABLE` かつ価格未登録：{len(available_missing)}件',f'- URL未登録の販売登録：{len(url_missing)}件','', '## 販売チャネル別','', '| チャネル | 販売登録 | 価格あり | 価格なし | AVAILABLEかつ価格なし | URLなし |','|---|---:|---:|---:|---:|---:|']
    for ch,items in sorted(by_channel.items()):
        priced=sum(bool(s.get('priceOptions')) for _,_,s in items)
        no_price=len(items)-priced
        avail_no=sum(s.get('availability')=='AVAILABLE' and not s.get('priceOptions') for _,_,s in items)
        no_url=sum(not str(s.get('url') or '').strip() for _,_,s in items)
        lines.append(f'| {ch} | {len(items)} | {priced} | {no_price} | {avail_no} | {no_url} |')
    lines += ['', '## 販売状態別（登録値。ライブ在庫確認ではない）','']
    lines += [f'- {k}: {v}件' for k,v in sorted(status_counts.items())]
    lines += ['', '## 価格未登録の優先確認対象','', '次の一覧は「販売可能」と登録されている一方、価格オプションがない販売登録。価格が0円という意味ではなく、アプリが価格根拠を表示するための情報がカタログに未登録であることを示す。','']
    lines += [f'- {p.get("model")} / {v.get("storageGb")}GB / RAM {v.get("ramGb")}GB / {s.get("channel")} / URL: {s.get("url") or "未登録"}' for p,v,s in available_missing]
    verified=[(p,v,s,o) for p,v,s in rows for o in s.get('priceOptions',[]) if (s.get('channel')=='SIM_FREE' and s.get('retailer')=='Google Store Japan') or (s.get('channel')=='RAKUTEN' and p.get('model')=='Pixel 11' and v.get('storageGb')==256) or (s.get('channel') in ('DOCOMO','SOFTBANK','RAKUTEN') and p.get('model') in ('iPhone 18 Pro','iPhone 18 Pro Max'))]
    lines += ['', '## 確認済みの公式価格（2026-10-16確認）', '', 'Google Store Japanの構成・購入ページで確認したSIMフリー通常価格、楽天モバイルのPixel 11 256GB製品価格とiPhone 18 Pro / Pro Maxの容量別製品価格、およびドコモ・ソフトバンク公表の割引適用前一括価格（報道による公表値の照合）。下取り、返却プログラムの実質負担額、キャンペーン、ポイント還元は通常価格に含めない。', '', '| 機種 | 容量 | RAM | 通常価格 | 価格出典 |', '|---|---:|---:|---:|---|']
    lines += [f'| {p.get("model")} | {v.get("storageGb")}GB | {v.get("ramGb")}GB | ¥{o.get("priceYen"):,} | {o.get("sourceUrl")} |' for p,v,s,o in verified]
    lines += ['', '## 今回の仕様修正', '', '- 楽天モバイル公式ページでPixel 11 256GBの税込製品価格139,900円を確認し、RAKUTEN販売登録に出典URL・確認日付きで追加。', '- Apple Japanの公式購入ページでiPhone 18 Pro / Pro Maxの2TBを含む4容量を確認し、SIMフリー価格を登録。ドコモ・ソフトバンク・楽天モバイルのiPhone 18 Pro／Pro Max価格を、出典・確認日・条件付きで登録。', '']
    lines += ['', '## 次の処理','', '1. 販売先公式ページを開き、モデル・容量・色・購入方法・割引条件を照合する。', '2. 価格が確認できた場合だけ、取得日と出典URLを含めて `priceOptions` に登録する。', '3. 価格未掲載、ログイン限定、割引条件不明、またはページ到達不可の場合は価格を捏造せず未確認のまま残す。', '4. 登録後、診断・比較・購入先詳細でチャネルと容量の取り違えがないことをSQLite/Androidテストで確認する。','', '## 検証範囲','', 'JSON構造と登録件数の監査のみ。公式ページ全件照合、Gradle/KSPビルド、Roomランタイム、Android JUnit、エミュレータ・実機試験は未実施。','']
    OUT.write_text('\n'.join(lines),encoding='utf-8')
    print(f'PASS: models={len(phones)} variants={sum(len(p.get("variants",[])) for p in phones)} listings={len(rows)} options={len(opts)} missing={len(missing)} available_missing={len(available_missing)} no_url={len(url_missing)}')
if __name__=='__main__': main()
