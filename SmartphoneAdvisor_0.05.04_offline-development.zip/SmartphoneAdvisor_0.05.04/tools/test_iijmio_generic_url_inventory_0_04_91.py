#!/usr/bin/env python3
"""Guard the IIJmio generic-URL audit against stale model lists/counts."""
import hashlib, json, re
from pathlib import Path
from current_version import current_version_is_valid
ROOT = Path(__file__).resolve().parents[1]
CATALOG = ROOT / "app/src/main/assets/phones.json"
BUILD = ROOT / "app/build.gradle.kts"
REVIEW = ROOT / "IIJMIO_GENERIC_URL_REVIEW_2026-10-20.md"
PRICE_AUDIT = ROOT / "CATALOG_PRICE_GAP_FOLLOWUP_2026-10-21.md"
GENERIC = "https://www.iijmio.jp/device/"
EXPECTED = {
    ("Motorola", "motorola razr fold", 512),
    ("Xiaomi", "Xiaomi 17T", 256),
    ("Xiaomi", "Xiaomi 17T Pro", 256),
    ("Xiaomi", "Xiaomi 17 Ultra", 512),
    ("Samsung", "Galaxy S26", 512),
    ("Samsung", "Galaxy S26+", 512),
    ("OPPO", "OPPO Find X9 Ultra", 512),
}
def main():
    errors=[]
    build=BUILD.read_text(encoding="utf-8")
    if not current_version_is_valid(build): errors.append("app version metadata invalid")
    data=json.loads(CATALOG.read_text(encoding="utf-8"))
    rows=[]
    for phone in data.get("phones",[]):
        for variant in phone.get("variants",[]):
            for sale in variant.get("sales",[]):
                if (sale.get("url") or "").rstrip("/")==GENERIC.rstrip("/"):
                    if sale.get("channel")=="IIJ_MIO":
                        rows.append((phone.get("manufacturer"),phone.get("model"),variant.get("storageGb"),sale))
    actual={(m,n,storage) for m,n,storage,_ in rows}
    if len(rows)!=7: errors.append(f"generic IIJmio rows {len(rows)} != expected 7")
    if actual!=EXPECTED: errors.append(f"generic row identities mismatch; missing={sorted(EXPECTED-actual)}, extra={sorted(actual-EXPECTED)}")
    if any(s.get("priceOptions") for _,_,_,s in rows): errors.append("generic category URL row unexpectedly treated as price evidence")
    for model in ("Galaxy S26", "Galaxy S26+"):
        match = next((sale for phone in data.get("phones",[]) if phone.get("model")==model for variant in phone.get("variants",[]) if variant.get("storageGb")==256 for sale in variant.get("sales",[]) if sale.get("channel")=="IIJ_MIO"), None)
        if not match or match.get("url") != "https://www.iijmio.jp/info/iij/1772412502.html": errors.append(f"{model} 256GB sale URL does not match its official price evidence")
    review=REVIEW.read_text(encoding="utf-8")
    if "seven registrations still using the generic category URL" not in review: errors.append("review lacks current seven-row statement")
    if "REDMI Note 17 Pro Max 5G (both capacities) and OPPO Find N6 are no longer generic-URL rows" not in review: errors.append("review fails to record repaired REDMI/Find N6 URLs")
    if "The list in the prior version of this paragraph was stale and has been corrected." not in review: errors.append("review does not disclose prior stale list correction")
    audit=PRICE_AUDIT.read_text(encoding="utf-8")
    sha=hashlib.sha256(CATALOG.read_bytes()).hexdigest()
    if f"対象JSON SHA-256: `{sha}`" not in audit: errors.append("price-gap audit SHA-256 does not match current catalog")
    sales=[s for p in data.get("phones",[]) for v in p.get("variants",[]) for s in v.get("sales",[])]
    missing=sum(not s.get("priceOptions") for s in sales)
    available_missing=sum(s.get("availability")=="AVAILABLE" and not s.get("priceOptions") for s in sales)
    if f"価格未登録の販売登録: {missing}件" not in audit: errors.append("price-gap count is stale")
    if f"販売中・価格未登録: {available_missing}件" not in audit: errors.append("available price-gap count is stale")
    print(f"IIJmio generic URL rows: {len(rows)}; expected identities: {len(EXPECTED)}")
    print(f"Price gaps: {missing}; AVAILABLE price gaps: {available_missing}")
    for e in errors: print("FAIL:",e)
    if errors: return 1
    print("PASS: current catalog, generic URL review, and price-gap audit agree")
    return 0
if __name__=="__main__": raise SystemExit(main())
