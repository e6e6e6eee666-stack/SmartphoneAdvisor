#!/usr/bin/env python3
"""Regression test for SoftBank's announced iPhone 18 Pro / Pro Max list prices."""
import json
from pathlib import Path
from current_version import current_version_is_valid
ROOT=Path(__file__).resolve().parents[1]
def main():
    errors=[]
    build=(ROOT/'app/build.gradle.kts').read_text(encoding='utf-8')
    data=json.loads((ROOT/'app/src/main/assets/phones.json').read_text(encoding='utf-8'))
    if not current_version_is_valid(build): errors.append('version mismatch')
    expected={('iPhone 18 Pro',256):268560,('iPhone 18 Pro',512):315360,('iPhone 18 Pro',1024):402480,('iPhone 18 Pro',2048):532800,('iPhone 18 Pro Max',256):295920,('iPhone 18 Pro Max',512):339840,('iPhone 18 Pro Max',1024):421920,('iPhone 18 Pro Max',2048):542880}
    actual={}
    for phone in data.get('phones',[]):
        if phone.get('model') not in ('iPhone 18 Pro','iPhone 18 Pro Max'): continue
        for variant in phone.get('variants',[]):
            sale=next((s for s in variant.get('sales',[]) if s.get('channel')=='SOFTBANK'),None)
            if not sale: continue
            for option in sale.get('priceOptions',[]):
                if option.get('sourceUrl')=='https://corriente.jp/softbank-iphone-18-pro-18-pro-max-price/': actual[(phone['model'],variant['storageGb'])]=option
    if set(actual) != set(expected): errors.append(f'SoftBank capacities mismatch: expected {sorted(expected)}, got {sorted(actual)}')
    for key,price in expected.items():
        opt=actual.get(key,{})
        if opt.get('priceYen')!=price: errors.append(f'{key}: expected {price}, got {opt.get("priceYen")}')
        if opt.get('priceType')!='NORMAL': errors.append(f'{key}: not classified as NORMAL')
        if opt.get('checkedAt')!='2026-10-16': errors.append(f'{key}: missing checked date')
        if '割引適用前' not in (opt.get('conditions') or ''): errors.append(f'{key}: discount caveat missing')
    options=[o for p in data['phones'] for v in p.get('variants',[]) for s in v.get('sales',[]) for o in s.get('priceOptions',[])]
    if len(options)!=100: errors.append(f'expected 100 price options, got {len(options)}')
    print(f'0.04.62 SoftBank iPhone capacity-price regression: expected={len(expected)} options={len(options)} errors={len(errors)}')
    for error in errors: print('FAIL:',error)
    if errors: return 1
    print('PASS: all 8 SoftBank capacity prices and provenance fields match expected values.')
    return 0
if __name__=='__main__': raise SystemExit(main())
