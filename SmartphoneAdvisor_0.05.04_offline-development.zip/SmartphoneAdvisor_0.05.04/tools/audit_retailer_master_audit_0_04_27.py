from pathlib import Path

root = Path(__file__).resolve().parents[1]
main = (root / 'app/src/main/java/jp/smartphoneadvisor/app/MainActivity.kt').read_text()
dao = (root / 'app/src/main/java/jp/smartphoneadvisor/app/data/PhoneDao.kt').read_text()
auditor = (root / 'app/src/main/java/jp/smartphoneadvisor/app/data/catalog/RetailerMasterAudit.kt').read_text()
tests = (root / 'app/src/test/java/jp/smartphoneadvisor/app/data/catalog/RetailerMasterAuditTest.kt').read_text()
checks = {
    'audit reads retailer rows through DAO': 'getAllRetailersForAudit()' in dao and 'database.phoneDao().getAllRetailersForAudit()' in main,
    'audit is read-only and does not insert/update/delete': not any(token in auditor for token in ('insertRetailer', 'updateRetailer', 'deleteRetailer')),
    'blank retailer names are counted': 'blankNames = retailers.count { it.name.isBlank() }' in auditor,
    'duplicate names are reported': 'duplicateNames' in auditor and 'filterValues { it > 1 }' in auditor,
    'mixed retailer types are reported': 'mixedTypes' in auditor,
    'mixed official flags are reported': 'mixedOfficialFlags' in auditor,
    'audit is invoked after seed and before catalog import': main.index('SeedData.ensureSeeded(database)') < main.index('RetailerMasterAudit.analyze') < main.index('PhoneCatalogRoomImporter.importCatalog'),
    'duplicate and mixed metadata test cases exist': 'duplicateNameAndMixedMetadataAreReportedWithoutMerging' in tests,
    'same-type duplicate test case exists': 'duplicateSameTypeIsReportedButNotFlaggedAsMixedType' in tests,
    'version metadata updated': 'versionCode = 76' in (root / 'app/build.gradle.kts').read_text() and 'versionName = "0.04.27"' in (root / 'app/build.gradle.kts').read_text(),
}
for name, ok in checks.items():
    print(f'{"PASS" if ok else "FAIL"}: {name}')
if not all(checks.values()):
    raise SystemExit(1)
print(f'PASS: {sum(checks.values())}/{len(checks)} checks')
