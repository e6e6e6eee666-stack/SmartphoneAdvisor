#!/usr/bin/env python3
"""Regression guard for Galaxy S26 official Samsung Japan direct prices."""
import json
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
data = json.loads((ROOT / "app/src/main/assets/phones.json").read_text(encoding="utf-8"))
phone = next(p for p in data["phones"] if p["model"] == "Galaxy S26")
expected = {256: 155800, 512: 183300}
url = "https://www.samsung.com/jp/smartphones/galaxy-s26/buy/"
for storage, yen in expected.items():
    variant = next(v for v in phone["variants"] if v["storageGb"] == storage and v.get("ramGb") == 12)
    matches = [s for s in variant["sales"] if s.get("retailer") == "Samsung Japan公式オンラインショップ"]
    assert len(matches) == 1
    sale = matches[0]
    assert sale["channel"] == "SIM_FREE" and sale["availability"] == "AVAILABLE"
    assert sale["url"] == url and len(sale["priceOptions"]) == 1
    price = sale["priceOptions"][0]
    assert (price["priceYen"], price["priceType"]) == (yen, "NORMAL")
    assert price["sourceUrl"] == url and price["checkedAt"] == "2026-10-21"
    assert "税込" in price["conditions"] and "下取り" in price["conditions"]
actual = {
 "phoneModels": len(data["phones"]),
 "variants": sum(len(p.get("variants", [])) for p in data["phones"]),
 "salesListings": sum(len(v.get("sales", [])) for p in data["phones"] for v in p.get("variants", [])),
 "priceOptions": sum(len(s.get("priceOptions", [])) for p in data["phones"] for v in p.get("variants", []) for s in v.get("sales", [])),
 "auditFindings": len(data.get("auditFindings", [])),
}
assert data["counts"] == actual
assert actual["phoneModels"] == 195 and actual["variants"] == 315
assert actual["salesListings"] == 511 and actual["priceOptions"] == 100
# Plus and Ultra current official direct prices (October 2026)
for model, expected_prices, model_url in [
    ("Galaxy S26+", {256: 192130, 512: 219100}, "https://www.samsung.com/jp/smartphones/galaxy-s26-plus/buy/"),
    ("Galaxy S26 Ultra", {256: 239800, 512: 268600, 1024: 334200}, "https://www.samsung.com/jp/smartphones/galaxy-s26-ultra/buy/"),
]:
    phone = next(p for p in data["phones"] if p["model"] == model)
    for storage, yen in expected_prices.items():
        variant = next(v for v in phone["variants"] if v["storageGb"] == storage)
        sale = next(s for s in variant["sales"] if s.get("retailer") == "Samsung Japan公式オンラインショップ")
        assert sale["channel"] == "SIM_FREE" and sale["availability"] == "AVAILABLE"
        assert sale["url"] == model_url
        price = next(x for x in sale["priceOptions"] if x.get("priceType") == "NORMAL")
        assert price["priceYen"] == yen and price["sourceUrl"] == model_url
        assert price["checkedAt"] == "2026-10-21" and "下取り" in price["conditions"]
print("PASS: Galaxy S26 series official capacity prices and catalog count integrity")
