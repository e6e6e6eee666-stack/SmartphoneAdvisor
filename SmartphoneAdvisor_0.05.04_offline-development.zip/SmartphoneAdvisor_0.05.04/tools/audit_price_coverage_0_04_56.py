#!/usr/bin/env python3
"""Report price-option coverage gaps by channel and model without inventing prices."""
import collections, json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
CATALOG=ROOT/'app/src/main/assets/phones.json'; BUILD=ROOT/'app/build.gradle.kts'
OUT=ROOT/'PRICE_COVERAGE_AUDIT_0.04.56.md'
def main():
    data=json.loads(CATALOG.read_text(encoding='utf-8')); build=BUILD.read_text(encoding='utf-8')
    if 'versionName = "0.04.56"' not in build or 'versionCode = 105' not in build: raise SystemExit('FAIL: version mismatch; expected 0.04.56 / versionCode 105')
    phones=data.get('phones',[])
    rows=[(p,v,s) for p in phones for v in p.get('variants',[]) for s in v.get('sales',[])]
    by_channel=collections.defaultdict(list)
    for p,v,s in rows: by_channel[s.get('channel','<MISSING>')].append((p,v,s))
    status_counts=collections.Counter(s.get('availability','<MISSING>') for _,_,s in rows)
    opts=[(p,v,s,o) for p,v,s in rows for o in s.get('priceOptions',[])]
    missing=[(p,v,s) for p,v,s in rows if not s.get('priceOptions')]
    available_missing=[(p,v,s) for p,v,s in missing if s.get('availability')=='AVAILABLE']
    url_missing=[(p,v,s) for p,v,s in rows if not str(s.get('url','')).strip()]
    lines=['# 価格登録カバレッジ監査（0.04.56）','', '## 目的・判定基準','', '価格情報の登録状況を販売チャネル別に見える化し、補完対象を優先付けする。価格がないことだけで実売価格を推測せず、販売状態・URLも変更しない。`priceOptions` は価格候補の登録有無であり、価格の現在性・購入可能性を保証しない。','', '## 全体集計','',f'- 機種：{len(phones)}件',f'- バリエーション：{sum(len(p.get("variants",[])) for p in phones)}件',f'- 販売登録：{len(rows)}件',f'- 価格オプション：{len(opts)}件',f'- 価格未登録の販売登録：{len(missing)}件',f'- `availability=AVAILABLE` かつ価格未登録：{len(available_missing)}件',f'- URL未登録の販売登録：{len(url_missing)}件','', '## 販売チャネル別','', '| チャネル | 販売登録 | 価格あり | 価格なし | AVAILABLEかつ価格なし | URLなし |','|---|---:|---:|---:|---:|---:|']
    for ch,items in sorted(by_channel.items()):
        priced=sum(bool(s.get('priceOptions')) for _,_,s in items)
        no_price=len(items)-priced
        avail_no=sum(s.get('availability')=='AVAILABLE' and not s.get('priceOptions') for _,_,s in items)
        no_url=sum(not str(s.get('url','')).strip() for _,_,s in items)
        lines.append(f'| {ch} | {len(items)} | {priced} | {no_price} | {avail_no} | {no_url} |')
    lines += ['', '## 販売状態別（登録値。ライブ在庫確認ではない）','']
    lines += [f'- {k}: {v}件' for k,v in sorted(status_counts.items())]
    lines += ['', '## 価格未登録の優先確認対象','', '次の一覧は「販売可能」と登録されている一方、価格オプションがない販売登録。価格が0円という意味ではなく、アプリが価格根拠を表示するための情報がカタログに未登録であることを示す。','']
    lines += [f'- {p.get("model")} / {v.get("storageGb")}GB / RAM {v.get("ramGb")}GB / {s.get("channel")} / URL: {s.get("url") or "未登録"}' for p,v,s in available_missing]
    lines += ['', '## 次の処理','', '1. 販売先公式ページを開き、モデル・容量・色・購入方法・割引条件を照合する。', '2. 価格が確認できた場合だけ、取得日と出典URLを含めて `priceOptions` に登録する。', '3. 価格未掲載、ログイン限定、割引条件不明、またはページ到達不可の場合は価格を捏造せず未確認のまま残す。', '4. 登録後、診断・比較・購入先詳細でチャネルと容量の取り違えがないことをSQLite/Androidテストで確認する。','', '## 検証範囲','', 'JSON構造と登録件数の監査のみ。公式ページ全件照合、Gradle/KSPビルド、Roomランタイム、Android JUnit、エミュレータ・実機試験は未実施。','']
    OUT.write_text('\n'.join(lines),encoding='utf-8')
    print(f'PASS: models={len(phones)} variants={sum(len(p.get("variants",[])) for p in phones)} listings={len(rows)} options={len(opts)} missing={len(missing)} available_missing={len(available_missing)} no_url={len(url_missing)}')
if __name__=='__main__': main()
