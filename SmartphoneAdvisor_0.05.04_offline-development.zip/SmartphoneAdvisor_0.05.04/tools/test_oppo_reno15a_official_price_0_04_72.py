import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
data = json.loads((ROOT / "app/src/main/assets/phones.json").read_text(encoding="utf-8"))
phone = next(p for p in data["phones"] if p["model"] == "OPPO Reno15 A")
variant = next(v for v in phone["variants"] if v["storageGb"] == 128 and v["ramGb"] == 8)
sale = next(s for s in variant["sales"] if s["channel"] == "SIM_FREE" and s["retailer"] == "OPPO公式オンラインショップ")
assert sale["url"] == "https://shop.oppojapan.com/"
prices = {p["priceType"]: p for p in sale["priceOptions"]}
assert prices["NORMAL"]["priceYen"] == 64800
assert prices["SALE"]["priceYen"] == 58320
for item in prices.values():
    assert item["sourceUrl"] == sale["url"]
    assert item["checkedAt"] == "2026-10-17"
    assert isinstance(item["priceYen"], int) and item["priceYen"] > 0
assert data["counts"]["phoneModels"] == len(data["phones"])
assert data["counts"]["variants"] == sum(len(p["variants"]) for p in data["phones"])
assert data["counts"]["salesListings"] == sum(len(v["sales"]) for p in data["phones"] for v in p["variants"])
assert data["counts"]["priceOptions"] == sum(len(s.get("priceOptions", [])) for p in data["phones"] for v in p["variants"] for s in v["sales"])
print("PASS: OPPO Reno15 A official store normal/sale price and count metadata")
