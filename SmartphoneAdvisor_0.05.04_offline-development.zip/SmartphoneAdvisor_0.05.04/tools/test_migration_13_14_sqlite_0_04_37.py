#!/usr/bin/env python3
"""Execute the exact SQL statements from MIGRATION_13_14 against disposable SQLite."""
import re
import sqlite3
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
source = (ROOT / "app/src/main/java/jp/smartphoneadvisor/app/data/AppDatabase.kt").read_text(encoding="utf-8")
match = re.search(
    r"private val MIGRATION_13_14 = object : Migration\(13, 14\) \{\s*override fun migrate\(db: SupportSQLiteDatabase\) \{(.*?)\n\s*\}\n\s*\}",
    source,
    re.S,
)
assert match, "MIGRATION_13_14 not found"
statements = re.findall(r'db\.execSQL\("(.*?)"\)', match.group(1))
assert len(statements) == 3, f"expected 3 migration statements, got {len(statements)}"

db = sqlite3.connect(":memory:")
db.execute("CREATE TABLE price_record_v2 (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, productListingId INTEGER NOT NULL, priceType TEXT NOT NULL, priceYen INTEGER, pointsValueYen INTEGER, couponValueYen INTEGER, tradeInValueYen INTEGER, shippingFeeYen INTEGER, conditions TEXT, campaignId INTEGER, checkedAt INTEGER NOT NULL, sourceId INTEGER)")
db.execute("INSERT INTO price_record_v2(productListingId,priceType,priceYen,checkedAt) VALUES(1,'NORMAL',123,100)")
for statement in statements:
    db.execute(statement)
columns = {row[1] for row in db.execute("PRAGMA table_info(price_record_v2)")}
assert {"color", "sourceUrl"} <= columns
assert db.execute("SELECT priceYen,color,sourceUrl FROM price_record_v2").fetchone() == (123, None, None)
db.execute("INSERT INTO price_record_v2(productListingId,priceType,priceYen,checkedAt,color,sourceUrl) VALUES(1,'NORMAL',139800,200,'ブラック','https://example.com')")
db.execute("INSERT INTO price_record_v2(productListingId,priceType,priceYen,checkedAt,color,sourceUrl) VALUES(1,'NORMAL',139800,200,'ホワイト','https://example.com')")
db.execute("INSERT INTO price_record_v2(productListingId,priceType,priceYen,checkedAt,color,sourceUrl) VALUES(1,'NORMAL',144800,200,'スターレイナイト','https://example.com')")
assert db.execute("SELECT COUNT(*) FROM price_record_v2 WHERE color IS NOT NULL").fetchone()[0] == 3
assert db.execute("PRAGMA integrity_check").fetchone()[0] == "ok"
print("PASS: migration SQL executed")
print("PASS: existing price row preserved")
print("PASS: nullable color/sourceUrl columns added")
print("PASS: three distinct color prices coexist")
print("PASS: SQLite integrity_check=ok")
