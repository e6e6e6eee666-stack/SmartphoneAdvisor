import json
from pathlib import Path
from current_version import current_version_is_valid
ROOT=Path(__file__).resolve().parents[1]
BUILD=(ROOT/'app/build.gradle.kts').read_text()
DATA=json.loads((ROOT/'app/src/main/assets/phones.json').read_text())
errors=[]
if not current_version_is_valid(BUILD):
    errors.append('current app version metadata is invalid')
phones=[p for p in DATA['phones'] if p.get('manufacturer')=='Nothing' and ('4a' in p.get('model','')) and not p.get('model','').endswith('Pro')]
if len(phones)!=1:
    errors.append(f'expected one canonical Nothing Phone (4a) model and no duplicate identity, got {[(p.get("id"),p.get("model")) for p in phones]}')
else:
    phone=phones[0]
    if phone.get('id')!='Nothing:Nothing Phone (4a):2026' or phone.get('model')!='Nothing Phone (4a)':
        errors.append('canonical model identity was not preserved')
    for storage,price in ((128,58800),(256,64800)):
        variants=[v for v in phone.get('variants',[]) if v.get('storageGb')==storage and v.get('ramGb')==8]
        if len(variants)!=1:
            errors.append(f'expected one 8GB/{storage}GB variant')
            continue
        sales=variants[0].get('sales',[])
        if storage==128 and not any(s.get('channel')=='IIJ_MIO' and s.get('retailer')=='IIJmio' for s in sales):
            errors.append('128GB IIJmio sales listing was lost during merge')
        official=[s for s in sales if s.get('channel')=='SIM_FREE' and s.get('retailer')=='Nothing Store Japan']
        if len(official)!=1:
            errors.append(f'{storage}GB: expected one official SIM-free sales row')
            continue
        opts=official[0].get('priceOptions',[])
        if len(opts)!=1:
            errors.append(f'{storage}GB: expected one price option')
            continue
        o=opts[0]
        if o.get('priceYen')!=price: errors.append(f'{storage}GB: wrong price {o.get("priceYen")}')
        if o.get('sourceUrl')!='https://jp.nothing.tech/products/phone-4a': errors.append(f'{storage}GB: official source URL missing')
        if o.get('checkedAt')!='2026-10-17': errors.append(f'{storage}GB: checkedAt missing or wrong')
        if o.get('priceType')!='NORMAL': errors.append(f'{storage}GB: priceType must be NORMAL')
counts=DATA.get('counts',{})
actual_models=len(DATA['phones'])
actual_variants=sum(len(p.get('variants',[])) for p in DATA['phones'])
actual_sales=sum(len(v.get('sales',[])) for p in DATA['phones'] for v in p.get('variants',[]))
actual_prices=sum(len(s.get('priceOptions',[])) for p in DATA['phones'] for v in p.get('variants',[]) for s in v.get('sales',[]))
for key,actual in [('phoneModels',actual_models),('variants',actual_variants),('salesListings',actual_sales),('priceOptions',actual_prices)]:
    if counts.get(key)!=actual: errors.append(f'count metadata {key}: {counts.get(key)} != actual {actual}')
if counts.get('phoneModels')!=195 or counts.get('variants')!=315: errors.append('expected 195 unique models and 315 unique variants after duplicate merge')
if errors:
    print('FAIL'); print('\n'.join(errors)); raise SystemExit(1)
print('PASS: canonical Nothing Phone (4a) has both official price options and IIJmio listing; duplicate identity removed; counts verified')
