#!/usr/bin/env python3
"""Regression tests for official product pages that intentionally cover multiple models."""
import json
from pathlib import Path
from urllib.parse import urlparse
from current_version import current_version_is_valid
ROOT = Path(__file__).resolve().parents[1]
DATA = json.loads((ROOT / "app/src/main/assets/phones.json").read_text(encoding="utf-8"))
SOURCE = (ROOT / "app/src/main/java/jp/smartphoneadvisor/app/MainActivity.kt").read_text(encoding="utf-8")
BUILD = (ROOT / "app/build.gradle.kts").read_text(encoding="utf-8")
EXPECTED = {
    "https://www.softbank.jp/iphone/iphone-16/": {"iPhone 16", "iPhone 16 Plus"},
    "https://www.softbank.jp/mobile/products/google-pixel/google-pixel-9-pro/": {"Pixel 9 Pro", "Pixel 9 Pro XL"},
    "https://www.au.com/iphone/product/iphone-18-pro/": {"iPhone 18 Pro", "iPhone 18 Pro Max"},
    "https://www.softbank.jp/iphone/iphone-18-pro/": {"iPhone 18 Pro", "iPhone 18 Pro Max"},
    "https://rog.asus.com/jp/phones/rog-phone-9-pro/": {"ROG Phone 9 Pro", "ROG Phone 9 Pro Edition"},
}

def main():
    errors=[]
    found={url:set() for url in EXPECTED}
    for phone in DATA.get("phones",[]):
        for variant in phone.get("variants",[]):
            for sale in variant.get("sales",[]):
                url=sale.get("url")
                if url in found:
                    found[url].add(phone.get("model"))
    for url, models in EXPECTED.items():
        if found[url] != models:
            errors.append(f"catalog mapping mismatch for {url}: expected {sorted(models)}, got {sorted(found[url])}")
        parsed=urlparse(url)
        if parsed.hostname == "www.softbank.jp":
            branch = '"www.softbank.jp" -> path == "/iphone/iphone-16" || path == "/iphone/iphone-18-pro" || path == "/mobile/products/google-pixel/google-pixel-9-pro"'
        elif parsed.hostname == "www.au.com":
            branch = '"www.au.com" -> path == "/iphone/product/iphone-18-pro"'
        else:
            branch = f'"{parsed.hostname}" -> path == "{parsed.path.rstrip("/")}"'
        if branch not in SOURCE:
            errors.append(f"Kotlin listing classifier missing shared model page: {url}")
    if '"www.softbank.jp" -> path == "/iphone/iphone-16" || path == "/iphone/iphone-18-pro" || path == "/mobile/products/google-pixel/google-pixel-9-pro"' not in SOURCE:
        errors.append("SoftBank shared page rules missing")
    if '"rog.asus.com" -> path == "/jp/phones/rog-phone-9-pro"' not in SOURCE:
        errors.append("ASUS shared page rule missing")
    if not current_version_is_valid(BUILD):
        errors.append("version mismatch")
    print("SmartphoneAdvisor shared model sales-link regression test (running on 0.04.59)")
    print(f"Shared official pages checked: {len(EXPECTED)}")
    print(f"Errors: {len(errors)}")
    for error in errors: print("FAIL:", error)
    if errors: return 1
    print("PASS: shared official pages are classified as listings, not model-exclusive links")
    return 0
if __name__ == "__main__": raise SystemExit(main())
