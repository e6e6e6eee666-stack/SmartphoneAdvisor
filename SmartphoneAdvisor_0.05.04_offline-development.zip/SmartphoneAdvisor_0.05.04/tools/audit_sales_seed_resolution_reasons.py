#!/usr/bin/env python3
"""Static audit of sales-seed identity resolution safety.

This is a source-level audit, not a Room runtime test. It deliberately does not
invent manufacturer/year for seed types that do not store those fields.
"""
from pathlib import Path
import re, sys
ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "app/src/main/java/jp/smartphoneadvisor/app/data"
DAO = (DATA / "PhoneDao.kt").read_text(encoding="utf-8")
SPECS = {
    "CarrierCatalogSeed.kt": ("manufacturer", "year", "platform", "storageGb", "ramGb"),
    "SimFreeCatalogSeed.kt": (None, None, None, "storageGb", "ramGb"),
    "VerifiedSalesSeed.kt": (None, None, None, "storageGb", "ramGb"),
    "SubBrandMvnoCatalogSeed.kt": (None, None, None, "storageGb", "ramGb"),
}
issues=[]
print("SALES SEED IDENTITY AUDIT (static source inspection)")
print("="*58)
query_match = re.search(r"suspend fun getDeviceVariantIdByModelAndStorage\((.*?)\): Long\?", DAO, re.S)
query = DAO[DAO.rfind('@Query',0,query_match.start()):query_match.end()] if query_match else ""
full_identity_match = re.search(r"suspend fun getDeviceVariantIdByFullIdentity\((.*?)\): Long\?", DAO, re.S)
full_identity_query = DAO[DAO.rfind('@Query',0,full_identity_match.start()):full_identity_match.end()] if full_identity_match else ""
for filename, fields in SPECS.items():
    text=(DATA/filename).read_text(encoding="utf-8")
    uses="getDeviceVariantIdByModelAndStorage" in text
    uses_full="getDeviceVariantIdByFullIdentity" in text
    stored=[x for x in fields[:3] if x and re.search(rf"val {x}:", text)]
    print(f"{filename}: model_storage_lookup={uses}; full_identity_lookup={uses_full}; identity_fields_declared={','.join(stored) if stored else 'none'}")
    if filename == "CarrierCatalogSeed.kt" and not uses_full:
        issues.append("CarrierCatalogSeed does not use the full manufacturer/platform/year identity lookup")
    if filename != "CarrierCatalogSeed.kt" and uses and not stored:
        issues.append(f"{filename}: seed entry does not carry manufacturer/platform/year; lookup relies on model/storage/RAM")
if query:
    fallback_guard=("SELECT COUNT(*) FROM smartphone_model identityModel" in query
                    and "identityModel.modelName = :modelName AND identityModel.isActive = 1" in query)
    print(f"DAO fallback lookup independently counts active model identities: {fallback_guard}")
    print("DAO fallback lookup is intended to return NULL unless model identity and variant are unique.")
    if not fallback_guard:
        issues.append("PhoneDao.getDeviceVariantIdByModelAndStorage does not independently count model identities")
else:
    issues.append("Could not locate getDeviceVariantIdByModelAndStorage DAO query")
if full_identity_query:
    identity_filter=all(x in full_identity_query for x in ("manufacturerName", "platform", "releaseYear", "storageGb", "condition"))
    unique_model_guard=("FROM smartphone_model identityModel" in full_identity_query
                        and "identityManufacturer.name = :manufacturerName" in full_identity_query
                        and "identityModel.platform = :platform" in full_identity_query
                        and "identityModel.releaseYear = :releaseYear" in full_identity_query)
    print(f"DAO full-identity query filters manufacturer+platform+year+storage+condition: {identity_filter}")
    print(f"DAO full-identity query independently counts exact model identity: {unique_model_guard}")
    if not unique_model_guard:
        issues.append("PhoneDao.getDeviceVariantIdByFullIdentity does not independently count exact model identity")
    if not identity_filter:
        issues.append("PhoneDao.getDeviceVariantIdByFullIdentity is missing one or more required identity filters")
else:
    issues.append("Could not locate getDeviceVariantIdByFullIdentity DAO query")
identity_model_match = re.search(r"suspend fun getModelIdByIdentity\((.*?)\): Long\?", DAO, re.S)
identity_model_query = DAO[DAO.rfind('@Query', 0, identity_model_match.start()):identity_model_match.end()] if identity_model_match else ""
model_id_unique = ("COUNT(m.id) = 1" in identity_model_query and "LIMIT 1" not in identity_model_query)
print(f"Model ID identity lookup rejects duplicate exact identities: {model_id_unique}")
if not model_id_unique:
    issues.append("PhoneDao.getModelIdByIdentity may select an arbitrary duplicate exact identity")
name_model_match = re.search(r"suspend fun getModelIdByName\((.*?)\): Long\?", DAO, re.S)
name_model_query = DAO[DAO.rfind('@Query', 0, name_model_match.start()):name_model_match.end()] if name_model_match else ""
name_id_unique = ("COUNT(m.id) = 1" in name_model_query and "LIMIT 1" not in name_model_query)
print(f"Name-only model lookup rejects duplicate names: {name_id_unique}")
if not name_id_unique:
    issues.append("PhoneDao.getModelIdByName may select an arbitrary duplicate name")
print("\nFindings:",len(issues))
for i,item in enumerate(issues,1): print(f"{i}. REVIEW: {item}")
print("\nLIMITATION: does not execute SQLite/Room, parse runtime seed outcomes, compile Kotlin, or verify sales URLs/prices.")
# Current known behavior must be reviewed, not marked pass if identity is ambiguous.
print("RESULT: REVIEW REQUIRED" if issues else "RESULT: no source-level identity gaps detected")
# This audit returns success when it completes; findings are actionable output, not script failure.
sys.exit(0)
