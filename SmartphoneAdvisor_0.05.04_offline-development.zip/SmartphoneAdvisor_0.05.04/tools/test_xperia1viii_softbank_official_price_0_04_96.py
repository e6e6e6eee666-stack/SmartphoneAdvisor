#!/usr/bin/env python3
"""Regression guard for official SoftBank Xperia 1 VIII 256GB price."""
import json
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
data = json.loads((ROOT / "app/src/main/assets/phones.json").read_text(encoding="utf-8"))
phone = next(p for p in data["phones"] if p["model"] == "Xperia 1 VIII")
variant = next(v for v in phone["variants"] if v["storageGb"] == 256 and v.get("ramGb") == 12)
sale = next(s for s in variant["sales"] if s["channel"] == "SOFTBANK")
assert sale["availability"] == "AVAILABLE"
assert sale["url"] == "https://www.softbank.jp/mobile/products/smartphone/xperia1m8/"
assert len(sale["priceOptions"]) == 1
price = sale["priceOptions"][0]
assert (price["priceYen"], price["priceType"], price["color"]) == (274320, "NORMAL", "全色共通")
assert price["sourceUrl"] == "https://www.softbank.jp/corp/news/press/sbkk/2026/20260513_01/"
assert price["checkedAt"] == "2026-10-21"
assert "税込" in price["conditions"] and "新トクするサポート＋" in price["conditions"]
actual = {"phoneModels": len(data["phones"]), "variants": sum(len(p.get("variants", [])) for p in data["phones"]), "salesListings": sum(len(v.get("sales", [])) for p in data["phones"] for v in p.get("variants", [])), "priceOptions": sum(len(s.get("priceOptions", [])) for p in data["phones"] for v in p.get("variants", []) for s in v.get("sales", [])), "auditFindings": len(data.get("auditFindings", []))}
assert data["counts"] == actual
assert actual["priceOptions"] == 100
print("PASS: Xperia 1 VIII SoftBank 256GB official price provenance and catalog counts")
