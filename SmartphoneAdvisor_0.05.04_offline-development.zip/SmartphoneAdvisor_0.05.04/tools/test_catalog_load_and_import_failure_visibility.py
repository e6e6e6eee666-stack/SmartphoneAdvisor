from pathlib import Path
from current_version import current_version_is_valid
ROOT = Path(__file__).resolve().parents[1]
BUILD = (ROOT / "app/build.gradle.kts").read_text()
ACTIVITY = (ROOT / "app/src/main/java/jp/smartphoneadvisor/app/MainActivity.kt").read_text()
errors = []
if not current_version_is_valid(BUILD):
    errors.append("current app version metadata is invalid")
if 'var catalogImportWarning by remember { mutableStateOf<String?>(null) }' not in ACTIVITY:
    errors.append("no UI state for catalog warning")
if 'Catalog JSON load/validation failed; existing seed retained' not in ACTIVITY:
    errors.append("JSON loader/validation failure is not logged")
if 'catalogImportWarning = "最新カタログの読み込みに失敗しました。' not in ACTIVITY:
    errors.append("JSON loader/validation failure is not surfaced to user")
if 'if (jsonCatalog != null)' not in ACTIVITY:
    errors.append("importer is not skipped when JSON loading fails")
if 'catalogImportWarning = "最新カタログの取り込みに失敗しました。' not in ACTIVITY:
    errors.append("Room import failure is not surfaced to user")
if 'catalogImportWarning = "カタログ取込で ${result.conflicts.size} 件の競合が見つかりました。' not in ACTIVITY:
    errors.append("import conflicts are not surfaced to user")
if 'title = { Text("カタログデータの確認が必要です") }' not in ACTIVITY:
    errors.append("warning dialog is missing")
if 'Catalog import failed; existing seed retained' not in ACTIVITY:
    errors.append("import failure logging was lost")
if 'dbReady = true' not in ACTIVITY:
    errors.append("startup completion state was removed")
if errors:
    print("FAIL: " + "; ".join(errors))
    raise SystemExit(1)
print("PASS: JSON load/validation failures, Room import failures, and import conflicts are visible; startup can continue with existing data; version metadata is not pinned")
