\
#!/usr/bin/env python3
"""Single repeatable static integrity gate for SmartphoneAdvisor. Exit 2 means build/release blocker."""
from pathlib import Path
import re
ROOT = Path(__file__).resolve().parents[1]
errors, blockers, notes = [], [], []
build = (ROOT / "app/build.gradle.kts").read_text(encoding="utf-8")
name = re.search(r'versionName\s*=\s*"([^"]+)"', build)
code = re.search(r'versionCode\s*=\s*(\d+)', build)
if not name or not code:
    errors.append("Gradle app versionName/versionCode could not be parsed")
else:
    version, version_code = name.group(1), int(code.group(1))
    print(f"INFO current app version: {version} (versionCode {version_code})")
    for suffix in ("WORK_LOG", "VALIDATION", "PROJECT_MASTER_PLAN"):
        extension = "txt" if suffix == "VALIDATION" else "md"
        if not (ROOT / f"{suffix}_{version}.{extension}").is_file():
            errors.append(f"missing current {suffix} record for {version}")
    for rel in [
        "app/src/main/java/jp/smartphoneadvisor/app/MainActivity.kt",
        "app/src/main/java/jp/smartphoneadvisor/app/data/catalog/PhoneCatalogJson.kt",
        "app/src/main/java/jp/smartphoneadvisor/app/data/catalog/PhoneCatalogRoomImporter.kt",
        "app/src/test/java/jp/smartphoneadvisor/app/data/catalog/PhoneCatalogRoomImporterTest.kt",
        "app/src/test/java/jp/smartphoneadvisor/app/domain/RecommendationEngineTest.kt",
        "app/src/test/java/jp/smartphoneadvisor/app/domain/SinglePhoneDiagnosticEngineTest.kt",
        "app/src/androidTest/java/jp/smartphoneadvisor/app/data/AppDatabaseSmokeTest.kt",
        "tools/test_catalog_load_and_import_failure_visibility.py",
        "tools/test_startup_initialization_failure_visibility.py",
        "tools/test_startup_room_access_guard.py",
        "tools/current_version.py",
        "tools/current_regression_manifest.json",
        "PREPARE_GRADLE_WRAPPER_WINDOWS.ps1",
        "tools/test_gradle_wrapper_bootstrap.py",
        "ANDROID_STUDIO_BUILD_GUIDE_0.04.86.md",
        "tools/run_current_regression_suite.py",
        f"test_results_{version}.txt",
    ]:
        if not (ROOT / rel).is_file():
            errors.append(f"required source/test missing: {rel}")
    activity = (ROOT / "app/src/main/java/jp/smartphoneadvisor/app/MainActivity.kt").read_text(encoding="utf-8")
    importer = (ROOT / "app/src/main/java/jp/smartphoneadvisor/app/data/catalog/PhoneCatalogRoomImporter.kt").read_text(encoding="utf-8")
    db = (ROOT / "app/src/main/java/jp/smartphoneadvisor/app/data/AppDatabase.kt").read_text(encoding="utf-8")
    if "initializationOutcome = runCatching" not in activity or 'startupFailure = "アプリの初期化を完了できませんでした。' not in activity:
        errors.append("whole-startup failure is not visibly handled")
    if "if (dbReady) AppDatabase.getInstance(context).phoneDao().observeFavoriteDeviceIds()" not in activity or "if (dbReady) AppDatabase.getInstance(context).diagnosticDao().observeProfiles()" not in activity:
        errors.append("Room observation is not gated on successful startup")
    if "Catalog JSON load/validation failed" not in activity or "Catalog import failed; existing seed retained" not in activity:
        errors.append("catalog load/import failure paths are not both logged")
    if "db.withTransaction" not in importer:
        errors.append("catalog import is not wrapped in a Room transaction")
    m = re.search(r'version\s*=\s*(\d+)', db)
    if not m:
        errors.append("Room schema version could not be parsed")
    else:
        db_version = int(m.group(1))
        migrations = sorted({(int(a), int(b)) for a, b in re.findall(r'Migration\((\d+),\s*(\d+)\)', db)})
        if not migrations or migrations[-1][1] != db_version:
            errors.append(f"migration chain does not reach Room schema {db_version}")
        if any(b != a + 1 for a, b in migrations):
            errors.append("non-contiguous Room migration step detected")
    if not (ROOT / "gradlew").is_file() or not (ROOT / "gradle/wrapper/gradle-wrapper.jar").is_file():
        if (ROOT / "PREPARE_GRADLE_WRAPPER_WINDOWS.ps1").is_file():
            blockers.append("Gradle Wrapper has not yet been generated on Windows; run PREPARE_GRADLE_WRAPPER_WINDOWS.ps1 and then perform Android build validation")
        else:
            blockers.append("Gradle Wrapper is missing; reproducible command-line Android build is blocked")
    if not any((ROOT / "app/src/androidTest").rglob("*.kt")):
        blockers.append("No Android instrumentation tests found; Room/device runtime validation remains unautomated")
    else:
        blockers.append("Android instrumentation tests exist but were not executed in this environment; Room/device runtime validation remains unverified")
    py_count = len(list((ROOT / "tools").glob("*.py")))
    historical_count = sum(1 for p in ROOT.iterdir() if p.is_file() and re.match(r"(WORK_LOG|VALIDATION|PROJECT_MASTER_PLAN)_0\.", p.name))
    notes.append(f"repository currently has {py_count} Python tool/test scripts and {historical_count} top-level historical records; use this gate and current-version records as the starting point")
for note in notes:
    print("NOTE " + note)
for error in errors:
    print("FAIL " + error)
for blocker in blockers:
    print("BLOCKER " + blocker)
if not errors:
    print("PASS static architecture/integrity checks")
if errors:
    raise SystemExit(1)
if blockers:
    raise SystemExit(2)
print("PASS no static blockers")
