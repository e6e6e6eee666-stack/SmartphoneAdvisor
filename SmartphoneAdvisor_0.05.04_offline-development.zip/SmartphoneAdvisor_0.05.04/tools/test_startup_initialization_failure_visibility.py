from pathlib import Path
from current_version import current_version_is_valid
ROOT = Path(__file__).resolve().parents[1]
BUILD = (ROOT / "app/build.gradle.kts").read_text()
ACTIVITY = (ROOT / "app/src/main/java/jp/smartphoneadvisor/app/MainActivity.kt").read_text()
errors = []
if not current_version_is_valid(BUILD):
    errors.append("current app version metadata is invalid")
for token, message in [
    ('var startupFailure by remember { mutableStateOf<String?>(null) }', "startup failure state missing"),
    ('var startupAttempt by remember { mutableStateOf(0) }', "retry attempt state missing"),
    ('LaunchedEffect(startupAttempt)', "initialization cannot be retried"),
    ('val initializationOutcome = runCatching', "outer initialization failure is not caught"),
    ('Application initialization failed before database became ready', "startup failure is not logged"),
    ('startupFailure = "アプリの初期化を完了できませんでした。', "startup failure is not user-visible"),
    ('title = { Text("アプリを起動できませんでした") }', "startup error dialog missing"),
    ('Text("初期化を再試行")', "retry action missing"),
    ('dbReady = false', "failed startup may leave database marked ready"),
    ('dbReady = true', "successful startup does not mark database ready"),
]:
    if token not in ACTIVITY:
        errors.append(message)
if errors:
    print("FAIL: " + "; ".join(errors))
    raise SystemExit(1)
print("PASS: whole startup initialization failure is visible, logged, retryable, and does not mark DB ready; version metadata is not pinned")
