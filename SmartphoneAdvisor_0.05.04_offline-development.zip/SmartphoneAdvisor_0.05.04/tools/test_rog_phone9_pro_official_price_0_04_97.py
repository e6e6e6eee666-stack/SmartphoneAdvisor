#!/usr/bin/env python3
"""Regression guard for ASUS Japan official ROG Phone 9 Pro family prices."""
import json
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
data = json.loads((ROOT / "app/src/main/assets/phones.json").read_text(encoding="utf-8"))
expected = {
    "ROG Phone 9 Pro": (512, 16, 189800, "ROG9PRO-BK16R512"),
    "ROG Phone 9 Pro Edition": (1024, 24, 239800, "ROG9PRO-BK24R1T"),
}
for model, (storage, ram, yen, sku) in expected.items():
    phone = next(p for p in data["phones"] if p["model"] == model)
    variant = next(v for v in phone["variants"] if v["storageGb"] == storage and v.get("ramGb") == ram)
    sale = next(s for s in variant["sales"] if s["retailer"] == "ASUS Store Japan")
    assert sale["availability"] == "AVAILABLE"
    assert sale["url"] == "https://rog.asus.com/jp/phones/rog-phone-9-pro/"
    assert len(sale["priceOptions"]) == 1
    price = sale["priceOptions"][0]
    assert (price["priceYen"], price["priceType"]) == (yen, "NORMAL")
    assert price["sourceUrl"] == sale["url"]
    assert price["checkedAt"] == "2026-10-21"
    assert "税込通常価格" in price["conditions"] and "クーポン" in price["conditions"] and sku in price["conditions"]
actual = {
    "phoneModels": len(data["phones"]),
    "variants": sum(len(p.get("variants", [])) for p in data["phones"]),
    "salesListings": sum(len(v.get("sales", [])) for p in data["phones"] for v in p.get("variants", [])),
    "priceOptions": sum(len(s.get("priceOptions", [])) for p in data["phones"] for v in p.get("variants", []) for s in v.get("sales", [])),
    "auditFindings": len(data.get("auditFindings", [])),
}
assert data["counts"] == actual
assert actual["priceOptions"] == 100
print("PASS: ROG Phone 9 Pro 512GB and Pro Edition 1TB official price provenance and catalog counts")
