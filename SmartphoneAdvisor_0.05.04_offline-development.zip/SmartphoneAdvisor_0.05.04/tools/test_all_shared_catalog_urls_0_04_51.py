#!/usr/bin/env python3
"""Ensure every URL shared by multiple catalog model identities is labelled as a listing.

This is a static source/catalog regression test. It does not test URL reachability or Android UI execution.
"""
import json
from collections import defaultdict
from pathlib import Path
from urllib.parse import urlparse
from current_version import current_version_is_valid
ROOT = Path(__file__).resolve().parents[1]
CATALOG = json.loads((ROOT / 'app/src/main/assets/phones.json').read_text(encoding='utf-8'))
SOURCE = (ROOT / 'app/src/main/java/jp/smartphoneadvisor/app/MainActivity.kt').read_text(encoding='utf-8')
BUILD = (ROOT / 'app/build.gradle.kts').read_text(encoding='utf-8')

def main():
    by_url = defaultdict(set)
    for phone in CATALOG.get('phones', []):
        identity = (phone.get('manufacturer'), phone.get('model'), phone.get('platform'), phone.get('releaseYear'))
        for variant in phone.get('variants', []):
            for sale in variant.get('sales', []):
                if sale.get('url'):
                    by_url[sale['url']].add(identity)
    shared = {url: ids for url, ids in by_url.items() if len(ids) > 1}
    errors = []
    for url, ids in sorted(shared.items()):
        parsed = urlparse(url)
        host, path = parsed.hostname or '', parsed.path.rstrip('/')
        # All URLs in this catalog must be explicitly covered by the exact host/path allowlist.
        if not host or not path:
            errors.append(f'shared URL has no host/path: {url}')
            continue
        # Check exact Kotlin host branch and path literals rather than only mirroring a Python allowlist.
        host_branch_start = SOURCE.find(f'"{host}" ->')
        if host_branch_start < 0:
            errors.append(f'shared URL host not classified: {host} ({url})')
            continue
        branch_end = SOURCE.find('\n        ', host_branch_start + 1)
        branch = SOURCE[host_branch_start: branch_end if branch_end >= 0 else len(SOURCE)]
        if f'"{path}"' not in branch:
            errors.append(f'shared URL path not classified: {url} (models={len(ids)})')
    if 'private fun isGeneralSalesListingUrl(rawUrl: String): Boolean' not in SOURCE:
        errors.append('Kotlin general-listing classifier missing')
    if not current_version_is_valid(BUILD):
        errors.append('current app version metadata is invalid')
    print('SmartphoneAdvisor all-shared-URL regression audit 0.04.52')
    print(f'Unique URLs: {len(by_url)}')
    print(f'URLs shared by multiple model identities: {len(shared)}')
    for url, ids in sorted(shared.items()):
        print(f'{"PASS" if not any(url in e for e in errors) else "FAIL"} models={len(ids)} {url}')
    print(f'Errors: {len(errors)}')
    for error in errors: print('FAIL:', error)
    if errors: return 1
    print('PASS: every multi-model URL is covered by the Kotlin general-listing classifier.')
    print('LIMITATION: static source check only; no live URL check, Android build, or UI interaction test.')
    return 0
if __name__ == '__main__': raise SystemExit(main())
