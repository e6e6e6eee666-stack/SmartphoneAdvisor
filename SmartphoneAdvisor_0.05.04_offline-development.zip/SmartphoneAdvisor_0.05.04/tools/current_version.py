"""Shared helper for checks that should validate current Gradle metadata without pinning a release."""
import re

def current_version_is_valid(build_text: str) -> bool:
    name = re.search(r'versionName\s*=\s*"(\d+\.\d+\.\d+)"', build_text)
    code = re.search(r'versionCode\s*=\s*(\d+)', build_text)
    return bool(name and code and int(code.group(1)) > 0)
