#!/usr/bin/env python3
"""Regression test for verified Rakuten Pixel 11 256GB price (0.04.59)."""
import json, subprocess, sys
from pathlib import Path
from current_version import current_version_is_valid
ROOT=Path(__file__).resolve().parents[1]
def main():
    errors=[]
    build=(ROOT/'app/build.gradle.kts').read_text(encoding='utf-8')
    data=json.loads((ROOT/'app/src/main/assets/phones.json').read_text(encoding='utf-8'))
    if not current_version_is_valid(build): errors.append('version mismatch')
    rows=[(p,v,s) for p in data.get('phones',[]) for v in p.get('variants',[]) for s in v.get('sales',[])]
    options=[(p,v,s,o) for p,v,s in rows for o in s.get('priceOptions',[])]
    if len(data.get('phones',[])) != 195: errors.append(f'expected 195 models, got {len(data.get("phones",[]))}')
    if len(rows) != 511: errors.append(f'expected 511 sales listings, got {len(rows)}')
    if sum(len(s.get('priceOptions',[])) for _,_,s in rows) != 100: errors.append('expected 100 price options')
    matches=[(p,v,s,o) for p,v,s,o in options if p.get('model')=='Pixel 11' and v.get('storageGb')==256 and s.get('channel')=='RAKUTEN' and o.get('sourceUrl')=='https://network.mobile.rakuten.co.jp/product/smartphone/google-pixel-11/']
    if len(matches)!=1: errors.append(f'expected exactly one Rakuten Pixel 11 256GB option, got {len(matches)}')
    elif matches[0][3].get('priceYen')!=139900 or matches[0][3].get('checkedAt')!='2026-10-16' or matches[0][3].get('priceType')!='NORMAL': errors.append('Rakuten Pixel 11 price facts mismatch')
    if any(not isinstance(o.get('priceYen'),int) or o['priceYen']<=0 or not o.get('sourceUrl') or not o.get('checkedAt') for _,_,_,o in options): errors.append('invalid price option')
    proc=subprocess.run([sys.executable,str(ROOT/'tools/audit_price_coverage_0_04_76.py')],cwd=ROOT,text=True,capture_output=True)
    if proc.returncode: errors.append('audit failed: '+proc.stdout+proc.stderr)
    report=ROOT/'PRICE_COVERAGE_AUDIT_0.04.76.md'
    if not report.exists(): errors.append('coverage report missing')
    else:
        t=report.read_text(encoding='utf-8')
        for phrase in ('楽天モバイル','139,900','価格未登録の優先確認対象','Pixel 11 Pro Fold'):
            if phrase not in t: errors.append('report missing: '+phrase)
    print(f'0.04.61 price coverage regression: listings={len(rows)} options={sum(len(s.get("priceOptions",[])) for _,_,s in rows)} errors={len(errors)}')
    for e in errors: print('FAIL:',e)
    if errors:return 1
    print('PASS: verified Rakuten price is channel/model/storage-specific; report regenerated.')
    return 0
if __name__=='__main__': raise SystemExit(main())
