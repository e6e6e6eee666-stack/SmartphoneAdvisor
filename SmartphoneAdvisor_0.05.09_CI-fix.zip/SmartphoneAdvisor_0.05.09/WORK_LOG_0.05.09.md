# SmartphoneAdvisor 0.05.09 — CI workflow maintenance log

## Purpose
Audit suspicious issues around the recent budget-reason regression failure and the GitHub Actions source selection without changing application runtime behavior.

## Baseline and changes
- Baseline: user-provided `SmartphoneAdvisor_0.05.08.zip`; the immediate previous package `SmartphoneAdvisor_0.05.09.zip` was also inspected for the budget-test adjustment.
- Kept embedded app versionName `0.05.09` and versionCode `157`: this maintenance change modifies CI workflow, test guard, and records only; app feature code, catalog JSON, Room schema, migrations, and Gradle app configuration are unchanged.
- Fixed the included repository-root GitHub Actions workflow so it extracts `SmartphoneAdvisor_0.05.09_CI-fix.zip` rather than the stale `SmartphoneAdvisor_0.05.08.zip`.
- Fixed SDK provisioning in that workflow to install `platforms;android-37`, matching `compileSdk = 37` (the currently published repository workflow installed only API 36/35).
- The workflow now uploads the version-matched consolidated Python regression report and uses the extracted project's directory for Python, Gradle, and instrumentation commands.
- Added the missing current-version work log, validation record, and plan snapshot required by `tools/system_integrity_gate.py`.

## Validation performed
- Python regression suite: 70/70 PASS, rerun in six batches after the workflow guard was updated.
- `tools/test_android_validation_workflow.py`: PASS.
- `python3 -m compileall -q tools`: PASS.
- `tools/system_integrity_gate.py`: static architecture checks PASS; Android Wrapper/instrumentation blockers remain (see validation record).
- ZIP integrity: checked after packaging.

## Not performed
- No Gradle `assembleDebug`, JVM/JUnit, Android instrumentation, emulator, or physical-device execution was performed in this environment.

## Required external follow-up
Upload `SmartphoneAdvisor_0.05.09_CI-fix.zip` to the repository root and replace the repository-root `.github/workflows/android-validation.yml` with the copy inside this ZIP. The GitHub repository's currently published workflow is separate from the copy inside a ZIP and will not change merely by downloading this package.
