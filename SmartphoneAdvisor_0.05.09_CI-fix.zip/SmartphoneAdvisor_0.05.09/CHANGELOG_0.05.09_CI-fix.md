# SmartphoneAdvisor 0.05.09 — CI workflow maintenance

- Kept app versionName `0.05.09` / versionCode `157` because app runtime code/data/build configuration was not changed.
- Corrected the included GitHub Actions workflow to extract `SmartphoneAdvisor_0.05.09_CI-fix.zip` instead of stale `0.05.08` source.
- Added Android SDK platform 37 installation to match `compileSdk = 37`.
- Added current-version work log, validation record, and project-state snapshot.
- Re-ran the 70 maintained Python regression tests in six batches: 70/70 passed.
- Android build/JUnit/instrumentation remain unverified until the updated ZIP and workflow are uploaded and Actions is run.
