package jp.smartphoneadvisor.app

import android.os.Bundle
import android.util.Log
import android.content.Intent
import android.net.Uri
import org.json.JSONObject
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.selection.selectable
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.LaunchedEffect
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.flowOf
import androidx.compose.ui.platform.LocalContext
import jp.smartphoneadvisor.app.data.AppDatabase
import jp.smartphoneadvisor.app.data.catalog.PhoneCatalogJsonLoader
import jp.smartphoneadvisor.app.data.catalog.PhoneCatalogRoomImporter
import jp.smartphoneadvisor.app.data.catalog.RetailerMasterAudit
import jp.smartphoneadvisor.app.data.catalog.ProductListingRelationAudit
import jp.smartphoneadvisor.app.data.SeedData
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.dp
import jp.smartphoneadvisor.app.data.CandidateOs
import jp.smartphoneadvisor.app.data.PrimaryUse
import jp.smartphoneadvisor.app.data.PhoneDetailRow
import jp.smartphoneadvisor.app.data.ComparisonRow
import jp.smartphoneadvisor.app.data.ComparisonPriceRow
import jp.smartphoneadvisor.app.data.PurchaseOptionRow
import jp.smartphoneadvisor.app.data.SupportStatus
import jp.smartphoneadvisor.app.data.AttributeLevel
import jp.smartphoneadvisor.app.data.DataConflictEntity
import jp.smartphoneadvisor.app.data.ConflictSeverity
import jp.smartphoneadvisor.app.domain.BudgetRequirement
import jp.smartphoneadvisor.app.domain.MustHaveFeature
import jp.smartphoneadvisor.app.domain.RecommendationEngine
import jp.smartphoneadvisor.app.domain.RecommendationResult
import jp.smartphoneadvisor.app.domain.RecommendationConfidence
import jp.smartphoneadvisor.app.ui.SinglePhoneDiagnosticFlow

private enum class Screen { HOME, SINGLE_DIAGNOSTIC, SAVED, FAVORITES, BROWSE, OS, BUDGET, USE, GAME, CAMERA, USE_DETAIL, COMMON, BATTERY_CHARGE, SIZE, STORAGE, NICE_HAVE, PURCHASE, CONDITION, DURATION, DESIGN, MUST_HAVE, CONFIRM, RESULT, DETAIL, COMPARE }

/**
 * Some retailer links lead to a general device catalogue rather than a model-specific product page.
 * Keep the button label honest so users know they may need to select the model on the retailer site.
 */
/** Only open explicit web URLs with a real host; DB rows can predate importer validation. */
private fun safeExternalWebUri(rawUrl: String): Uri? {
    val uri = runCatching { Uri.parse(rawUrl.trim()) }.getOrNull() ?: return null
    val scheme = uri.scheme?.lowercase(java.util.Locale.ROOT)
    if (scheme != "https" && scheme != "http") return null
    if (uri.host.isNullOrBlank()) return null
    return uri
}

private fun isGeneralSalesListingUrl(rawUrl: String): Boolean {
    val uri = safeExternalWebUri(rawUrl) ?: return false
    val host = uri.host?.lowercase() ?: return false
    val path = uri.path?.trimEnd('/') ?: return false
    return when (host) {
        "www.apple.com" -> path == "/jp/shop/buy-iphone/iphone-18-pro"
        "mineo.jp" -> path == "/device/smartphone"
        "www.iijmio.jp" -> path == "/device" || path == "/info/iij/1772412502.html"
        // au's official iPhone 18 Pro / Pro Max page is shared by both models.
        "www.au.com" -> path == "/iphone/product/iphone-18-pro"
        "shop.uqmobile.jp" -> path == "/shop/lineup"
        "network.mobile.rakuten.co.jp" -> path == "/product/smartphone"
        "buy.mi.com" -> path == "/jp/products/all"
        "www.ymobile.jp" -> path == "/lineup/simfree"
        "jp.nothing.tech" -> path == "/collections/phones"
        "jp.nubia.com" -> path == "/collections/nubia-z-series"
        // SoftBank's official pages each cover two catalog models, so label them as shared model listings.
        "www.softbank.jp" -> path == "/iphone/iphone-16" || path == "/iphone/iphone-18-pro" || path == "/mobile/products/google-pixel/google-pixel-9-pro"
        // Google Store configuration page is shared by Pixel 11 Pro and Pixel 11 Pro XL.
        "store.google.com" -> path == "/jp/config/pixel_11_pro"
        // ASUS's official Pro page compares both ROG Phone 9 Pro and Pro Edition.
        "rog.asus.com" -> path == "/jp/phones/rog-phone-9-pro"
        else -> false
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SmartphoneAdvisorApp() }
    }
}

@Composable
private fun SmartphoneAdvisorApp() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var dbReady by remember { mutableStateOf(false) }
    var catalogImportWarning by remember { mutableStateOf<String?>(null) }
    var startupFailure by remember { mutableStateOf<String?>(null) }
    var startupAttempt by remember { mutableStateOf(0) }
    // Draft state must be declared before any effect that reads/writes it.
    var hasDiagnosticDraft by remember { mutableStateOf(false) }
    var draftLoaded by rememberSaveable { mutableStateOf(false) }
    LaunchedEffect(startupAttempt) {
        val initializationOutcome = runCatching {
            withContext(Dispatchers.IO) {
            // JSONカタログ読込も失敗経路として扱い、失敗時に初期化全体を止めない。
            // 既存Room/Seedデータで起動を続けつつ、最新カタログ未反映を利用者に知らせる。
            val catalogLoadOutcome = runCatching {
                PhoneCatalogJsonLoader.load(context).also { catalog ->
                    check(catalog.phones.isNotEmpty()) { "phones.json contains no phone models" }
                    check(catalog.phones.sumOf { phone -> phone.variants.sumOf { it.sales.size } } > 0) {
                        "phones.json contains no sales listings"
                    }
                }
            }
            val jsonCatalog = catalogLoadOutcome.getOrNull()
            if (jsonCatalog == null) {
                val error = catalogLoadOutcome.exceptionOrNull()
                Log.e("SmartphoneAdvisorCatalog", "Catalog JSON load/validation failed; existing seed retained", error)
                withContext(Dispatchers.Main) {
                    catalogImportWarning = "最新カタログの読み込みに失敗しました。既存データで起動を続けますが、最新の機種・販売情報が反映されていない可能性があります。phones.json の内容と読み込みエラーを確認してください。"
                }
            }
            val database = AppDatabase.getInstance(context)
            SeedData.ensureSeeded(database)
            runCatching {
                val report = RetailerMasterAudit.analyze(database.phoneDao().getAllRetailersForAudit())
                Log.i("SmartphoneAdvisorRetailerAudit", "read-only retailer audit: rows=${report.totalRows}, blankNames=${report.blankNames}, duplicateNames=${report.duplicateNames.size}, mixedTypes=${report.mixedTypes.size}, mixedOfficialFlags=${report.mixedOfficialFlags.size}, normalizedNameVariants=${report.normalizedNameVariants.size}, mixedWebsiteUrls=${report.mixedWebsiteUrls.size}, invalidWebsiteUrls=${report.invalidWebsiteUrls.size}, whitespaceWebsiteUrls=${report.whitespaceWebsiteUrls.size}")
                report.duplicateNames.entries.take(50).forEach { (name, count) -> Log.w("SmartphoneAdvisorRetailerAudit", "duplicate retailer name '$name': $count rows") }
                report.mixedTypes.entries.take(50).forEach { (name, types) -> Log.w("SmartphoneAdvisorRetailerAudit", "retailer '$name' has mixed types: ${types.sorted()}") }
                report.mixedOfficialFlags.entries.take(50).forEach { (name, flags) -> Log.w("SmartphoneAdvisorRetailerAudit", "retailer '$name' has mixed official flags: ${flags.sorted()}") }
                report.normalizedNameVariants.entries.take(50).forEach { (key, names) -> Log.w("SmartphoneAdvisorRetailerAudit", "normalized retailer-name collision '$key': ${names.sorted()}") }
                report.mixedWebsiteUrls.entries.take(50).forEach { (key, urls) -> Log.w("SmartphoneAdvisorRetailerAudit", "normalized retailer name '$key' has multiple website URLs: ${urls.sorted()}") }
                report.invalidWebsiteUrls.entries.take(50).forEach { (id, url) -> Log.w("SmartphoneAdvisorRetailerAudit", "retailer id=$id has invalid website URL: '$url'") }
                report.whitespaceWebsiteUrls.entries.take(50).forEach { (id, url) -> Log.w("SmartphoneAdvisorRetailerAudit", "retailer id=$id has whitespace around website URL: '$url'") }
            }.onFailure { error -> Log.e("SmartphoneAdvisorRetailerAudit", "Read-only retailer audit failed", error) }
            if (jsonCatalog != null) {
                val importOutcome = runCatching { PhoneCatalogRoomImporter.importCatalog(database, jsonCatalog) }
                importOutcome.onSuccess { result ->
                    Log.i("SmartphoneAdvisorCatalog", "JSON-to-Room import: modelsInserted=${result.modelsInserted}, modelsReused=${result.modelsReused}, variantsInserted=${result.variantsInserted}, variantsReused=${result.variantsReused}, salesVariantsInserted=${result.salesVariantsInserted}, salesVariantsReused=${result.salesVariantsReused}, retailersInserted=${result.retailersInserted}, retailersReused=${result.retailersReused}, listingsInserted=${result.listingsInserted}, listingsReused=${result.listingsReused}, listingsSkippedNoUrl=${result.listingsSkippedNoUrl}, conflicts=${result.conflicts.size}, skippedNonOfficial=${result.skippedNonOfficial}")
                    result.conflicts.take(50).forEach { Log.w("SmartphoneAdvisorCatalog", it) }
                    if (result.conflicts.isNotEmpty()) {
                        withContext(Dispatchers.Main) {
                            catalogImportWarning = "カタログ取込で ${result.conflicts.size} 件の競合が見つかりました。すべての機種データが登録されたとは限りません。詳細はログの SmartphoneAdvisorCatalog を確認してください。"
                        }
                    }
                }
                importOutcome.exceptionOrNull()?.let { error ->
                    Log.e("SmartphoneAdvisorCatalog", "Catalog import failed; existing seed retained", error)
                    withContext(Dispatchers.Main) {
                        catalogImportWarning = "最新カタログの取り込みに失敗しました。既存データで起動を続けますが、最新の機種・販売情報が反映されていない可能性があります。詳細はログの SmartphoneAdvisorCatalog を確認してください。"
                    }
                }
            }
            runCatching {
                val dao = database.phoneDao()
                val relationReport = ProductListingRelationAudit.analyze(
                    deviceVariants = dao.getAllDeviceVariantsForAudit(),
                    salesVariants = dao.getAllSalesVariantsForAudit(),
                    retailers = dao.getAllRetailersForAudit(),
                    listings = dao.getAllProductListingsForAudit(),
                    prices = dao.getAllPriceRecordsV2ForAudit()
                )
                Log.i("SmartphoneAdvisorListingAudit", "read-only relation audit: issueGroups=${relationReport.issueGroupCount}, issueRowIncidences=${relationReport.issueRowCount}, salesVariants=${relationReport.salesVariantRows}, listings=${relationReport.productListingRows}, prices=${relationReport.priceRecordRows}, missingDeviceVariants=${relationReport.salesVariantsMissingDeviceVariant.size}, listingsMissingSalesVariant=${relationReport.listingsMissingSalesVariant.size}, listingsMissingRetailer=${relationReport.listingsMissingRetailer.size}, blankProductUrls=${relationReport.blankProductUrls.size}, duplicateListingIdentityGroups=${relationReport.duplicateListingIdentities.size}, duplicateSalesVariantIdentityGroups=${relationReport.duplicateSalesVariantIdentities.size}, pricesMissingListing=${relationReport.priceRecordsMissingListing.size}")
                relationReport.salesVariantsMissingDeviceVariant.entries.take(50).forEach { (id, variantId) -> Log.w("SmartphoneAdvisorListingAudit", "sales variant id=$id references missing device variant id=$variantId") }
                relationReport.listingsMissingSalesVariant.entries.take(50).forEach { (id, salesId) -> Log.w("SmartphoneAdvisorListingAudit", "product listing id=$id references missing sales variant id=$salesId") }
                relationReport.listingsMissingRetailer.entries.take(50).forEach { (id, retailerId) -> Log.w("SmartphoneAdvisorListingAudit", "product listing id=$id references missing retailer id=$retailerId") }
                relationReport.blankProductUrls.entries.take(50).forEach { (id, retailerId) -> Log.w("SmartphoneAdvisorListingAudit", "product listing id=$id has blank URL (retailer id=$retailerId)") }
                relationReport.duplicateListingIdentities.entries.take(50).forEach { (identity, count) -> Log.w("SmartphoneAdvisorListingAudit", "duplicate product listing identity $identity: $count rows") }
                relationReport.duplicateSalesVariantIdentities.entries.take(50).forEach { (identity, count) -> Log.w("SmartphoneAdvisorListingAudit", "duplicate sales variant identity $identity: $count rows") }
                relationReport.priceRecordsMissingListing.entries.take(50).forEach { (id, listingId) -> Log.w("SmartphoneAdvisorListingAudit", "price record v2 id=$id references missing product listing id=$listingId") }
            }.onFailure { error -> Log.e("SmartphoneAdvisorListingAudit", "Read-only product-listing relation audit failed", error) }
            }
        }
        initializationOutcome.onSuccess {
            startupFailure = null
            dbReady = true
        }.onFailure { error ->
            Log.e("SmartphoneAdvisorStartup", "Application initialization failed before database became ready", error)
            dbReady = false
            catalogImportWarning = null
            startupFailure = "アプリの初期化を完了できませんでした。データベースや初期データの状態を確認してください。再試行しても解決しない場合は、このエラー画面を閉じずに開発担当者へ連絡してください。（原因: ${error.javaClass.simpleName}）"
        }
    }
    LaunchedEffect(dbReady) {
        if (dbReady && !draftLoaded) {
            val draftOutcome = runCatching {
                withContext(Dispatchers.IO) { AppDatabase.getInstance(context).diagnosticDao().getDraft() }
            }
            draftOutcome.onSuccess { draft ->
                hasDiagnosticDraft = draft != null
                draftLoaded = true
            }.onFailure { error ->
                Log.e("SmartphoneAdvisorStartup", "Saved diagnostic draft load failed", error)
                startupFailure = "保存済み診断の読み込みに失敗しました。データベースを確認して初期化を再試行してください。（原因: ${error.javaClass.simpleName}）"
                dbReady = false
            }
        }
    }
    var screen by rememberSaveable { mutableStateOf(Screen.HOME) }
    var os by rememberSaveable { mutableStateOf<CandidateOs?>(null) }
    var budgetTarget by rememberSaveable { mutableStateOf("") }
    var budgetMax by rememberSaveable { mutableStateOf("") }
    var primaryUse by rememberSaveable { mutableStateOf<PrimaryUse?>(null) }
    var gameType by rememberSaveable { mutableStateOf<String?>(null) }
    var cameraSubject by rememberSaveable { mutableStateOf<String?>(null) }
    var battery by rememberSaveable { mutableStateOf<String?>(null) }
    var batteryCharge by rememberSaveable { mutableStateOf<String?>(null) }
    var sizePreference by rememberSaveable { mutableStateOf<String?>(null) }
    var storageMinimum by rememberSaveable { mutableStateOf<String?>(null) }
    var niceHave by rememberSaveable { mutableStateOf<List<String>>(emptyList()) }
    var purchaseChannel by rememberSaveable { mutableStateOf<String?>(null) }
    var productCondition by rememberSaveable { mutableStateOf<String?>(null) }
    var intendedYears by rememberSaveable { mutableStateOf<String?>(null) }
    var designPreference by rememberSaveable { mutableStateOf<String?>(null) }
    var useDetail by rememberSaveable { mutableStateOf<String?>(null) }
    var mustHave by rememberSaveable { mutableStateOf<List<String>>(emptyList()) }
    var recommendationResults by remember { mutableStateOf<List<RecommendationResult>>(emptyList()) }
    var recommendationPrioritySummary by remember { mutableStateOf<List<String>>(emptyList()) }
    var noCandidateExplanation by remember { mutableStateOf<List<String>>(emptyList()) }
    var saveMessage by remember { mutableStateOf<String?>(null) }
    var editingProfileId by rememberSaveable { mutableStateOf<Long?>(null) }
    var diagnosticRunToken by rememberSaveable { mutableStateOf(0) }
    var lastRecordedRunToken by rememberSaveable { mutableStateOf(0) }
    var renameProfileId by rememberSaveable { mutableStateOf<Long?>(null) }
    var renameProfileText by rememberSaveable { mutableStateOf("") }
    var selectedDeviceId by rememberSaveable { mutableStateOf<Long?>(null) }
    var detailReturnScreen by rememberSaveable { mutableStateOf(Screen.HOME) }
    var selectedDeviceDetail by remember { mutableStateOf<PhoneDetailRow?>(null) }
    var purchaseOptions by remember { mutableStateOf<List<PurchaseOptionRow>>(emptyList()) }
    var dataConflicts by remember { mutableStateOf<List<DataConflictEntity>>(emptyList()) }
    var comparisonIds by rememberSaveable { mutableStateOf<List<Long>>(emptyList()) }
    var comparisonItems by remember { mutableStateOf<List<ComparisonRow>>(emptyList()) }
    var comparisonPrices by remember { mutableStateOf<List<ComparisonPriceRow>>(emptyList()) }
    var browseQuery by rememberSaveable { mutableStateOf("") }
    var browseOs by rememberSaveable { mutableStateOf(CandidateOs.EITHER) }
    var browseManufacturer by rememberSaveable { mutableStateOf("すべて") }
    var browseSeries by rememberSaveable { mutableStateOf("すべて") }
    var browseMaxPrice by rememberSaveable { mutableStateOf(0) }
    var browseStorage by rememberSaveable { mutableStateOf(0) }
    var browseReleaseYear by rememberSaveable { mutableStateOf(0) }
    var browseItems by remember { mutableStateOf<List<jp.smartphoneadvisor.app.data.PhoneListRow>>(emptyList()) }
    var favoriteItems by remember { mutableStateOf<List<jp.smartphoneadvisor.app.data.PhoneListRow>>(emptyList()) }
    // Do not touch Room during composition until the guarded startup path has succeeded.
    // Otherwise a database-construction failure can throw here before startupFailure is shown.
    val favoriteDeviceIdsFlow = remember(dbReady, context) {
        if (dbReady) AppDatabase.getInstance(context).phoneDao().observeFavoriteDeviceIds()
        else flowOf(emptyList<Long>())
    }
    val favoriteDeviceIds by favoriteDeviceIdsFlow.collectAsState(initial = emptyList())
    val diagnosticProfilesFlow = remember(dbReady, context) {
        if (dbReady) AppDatabase.getInstance(context).diagnosticDao().observeProfiles()
        else flowOf(emptyList<jp.smartphoneadvisor.app.data.DiagnosticProfileEntity>())
    }
    val diagnosticProfiles by diagnosticProfilesFlow.collectAsState(initial = emptyList())

    BackHandler(enabled = screen != Screen.HOME) {
        screen = when (screen) {
            Screen.DETAIL -> detailReturnScreen
            Screen.COMPARE -> Screen.RESULT
            Screen.SINGLE_DIAGNOSTIC -> Screen.HOME
            Screen.FAVORITES, Screen.BROWSE, Screen.SAVED -> Screen.HOME
            Screen.OS -> Screen.HOME
            Screen.BUDGET -> Screen.OS
            Screen.USE -> Screen.BUDGET
            Screen.GAME, Screen.CAMERA, Screen.USE_DETAIL -> Screen.USE
            Screen.COMMON -> Screen.USE
            Screen.BATTERY_CHARGE -> Screen.COMMON
            Screen.SIZE -> Screen.BATTERY_CHARGE
            Screen.STORAGE -> Screen.SIZE
            Screen.NICE_HAVE -> Screen.STORAGE
            Screen.PURCHASE -> Screen.NICE_HAVE
            Screen.CONDITION -> Screen.PURCHASE
            Screen.DURATION -> Screen.CONDITION
            Screen.DESIGN -> Screen.DURATION
            Screen.MUST_HAVE -> Screen.DESIGN
            Screen.CONFIRM -> Screen.MUST_HAVE
            Screen.RESULT -> Screen.CONFIRM
            Screen.HOME -> Screen.HOME
        }
    }

    LaunchedEffect(screen, os, dbReady, budgetTarget, budgetMax, primaryUse, mustHave, battery, purchaseChannel, diagnosticRunToken) {
        if (screen == Screen.RESULT && dbReady && os != null && primaryUse != null) {
            val maxPrice = budgetMax.toYenOrNull()
            val targetPrice = budgetTarget.toYenOrNull()
            val requiredFeatures = mustHave.mapNotNull(::featureFromLabel).toSet()
            val batteryImportance = when (battery) {
                "あまり気にしない" -> 0
                "かなり重要" -> 2
                "最重要" -> 3
                else -> 1
            }
            val rows = withContext(Dispatchers.IO) {
                AppDatabase.getInstance(context).phoneDao().searchJapanOfficialDevices(
                    os!!.name, "", purchaseChannel.orEmpty().toSalesChannelDbValue()
                )
            }
            val storageMinimumGb = when (storageMinimum) {
                "128GB以上" -> 128
                "256GB以上" -> 256
                "512GB以上" -> 512
                "1TB以上" -> 1024
                else -> null
            }
            val requirement = jp.smartphoneadvisor.app.domain.UserRequirement(
                os = os!!,
                budget = BudgetRequirement(targetPrice, maxPrice),
                primaryUse = primaryUse!!,
                gameType = activeGameType().takeIf { it.isNotBlank() },
                cameraSubject = activeCameraSubject().takeIf { it.isNotBlank() },
                useDetail = activeUseDetail().takeIf { it.isNotBlank() },
                batteryImportance = batteryImportance,
                batteryChargePreference = batteryCharge,
                sizePreference = sizePreference,
                storageMinimumGb = storageMinimumGb,
                niceHaveFeatures = niceHave.toSet(),
                purchaseChannel = purchaseChannel,
                productConditionPreference = productCondition,
                intendedUseYears = intendedYears.toIntOrNullFromLabel(),
                designPreference = designPreference,
                mustHaveFeatures = requiredFeatures
            )
            val results = RecommendationEngine.recommend(
                requirement = requirement,
                candidates = rows,
                limit = 3
            )
            recommendationResults = results
            recommendationPrioritySummary = RecommendationEngine.prioritySummary(requirement)
            noCandidateExplanation = if (results.isEmpty()) {
                RecommendationEngine.explainNoCandidates(requirement, rows).reasons +
                    RecommendationEngine.exclusionReasonSummary(requirement, rows)
            } else {
                emptyList()
            }
            if (diagnosticRunToken > lastRecordedRunToken && editingProfileId != null) {
                val runAt = System.currentTimeMillis()
                withContext(Dispatchers.IO) {
                    val dao = AppDatabase.getInstance(context).diagnosticDao()
                    dao.markRun(editingProfileId!!, runAt)
                    dao.insertRun(
                        jp.smartphoneadvisor.app.data.DiagnosticRunEntity(
                            profileId = editingProfileId!!,
                            executedAt = runAt,
                            databaseVersion = "0.2.27",
                            requirementSnapshot = buildRequirementSnapshot(
                                os, budgetTarget, budgetMax, primaryUse, gameType, cameraSubject, useDetail, battery, batteryCharge,
                                sizePreference, storageMinimum, niceHave, purchaseChannel, productCondition, intendedYears,
                                designPreference, mustHave
                            ),
                            recommendedDeviceIds = results.joinToString(",") { it.phone.deviceVariantId.toString() },
                            excludedDeviceIds = rows.filter { candidate -> results.none { it.phone.deviceVariantId == candidate.deviceVariantId } }
                                .joinToString(",") { it.deviceVariantId.toString() }
                        )
                    )
                }
                lastRecordedRunToken = diagnosticRunToken
            }
        }
    }

    LaunchedEffect(screen, selectedDeviceId, dbReady) {
        if (screen == Screen.DETAIL && dbReady && selectedDeviceId != null) {
            withContext(Dispatchers.IO) {
                val dao = AppDatabase.getInstance(context).phoneDao()
                selectedDeviceDetail = dao.getDeviceDetail(selectedDeviceId!!)
                purchaseOptions = dao.getPurchaseOptions(selectedDeviceId!!)
                dataConflicts = dao.getOpenDataConflicts(selectedDeviceId!!)
            }
        }
    }

    LaunchedEffect(screen, comparisonIds, dbReady) {
        if (screen == Screen.COMPARE && dbReady) {
            val loaded = withContext(Dispatchers.IO) {
                val dao = AppDatabase.getInstance(context).phoneDao()
                dao.getComparisonItems(comparisonIds) to dao.getComparisonPrices(comparisonIds)
            }
            comparisonItems = loaded.first
            comparisonPrices = loaded.second
        }
    }

    LaunchedEffect(screen, favoriteDeviceIds, dbReady) {
        if (screen == Screen.FAVORITES && dbReady) {
            val all = withContext(Dispatchers.IO) {
                AppDatabase.getInstance(context).phoneDao().searchJapanOfficialDevices(CandidateOs.EITHER.name, "")
            }
            favoriteItems = all.filter { it.deviceVariantId in favoriteDeviceIds }
        }
    }

    LaunchedEffect(screen, browseQuery, browseOs, dbReady) {
        if (screen == Screen.BROWSE && dbReady) {
            browseItems = withContext(Dispatchers.IO) {
                AppDatabase.getInstance(context).phoneDao().searchJapanOfficialDevices(
                    browseOs.name, browseQuery.trim()
                )
            }
        }
    }

    fun addToComparison(deviceId: Long) {
        if (deviceId !in comparisonIds && comparisonIds.size < 5) {
            comparisonIds = comparisonIds + deviceId
        }
    }

    fun activeGameType(): String = if (primaryUse == PrimaryUse.GAMING) gameType.orEmpty() else ""
    fun activeCameraSubject(): String = if (primaryUse == PrimaryUse.CAMERA) cameraSubject.orEmpty() else ""
    fun activeUseDetail(): String = when (primaryUse) {
        PrimaryUse.VIDEO, PrimaryUse.SNS, PrimaryUse.WORK, PrimaryUse.AI, PrimaryUse.VIDEO_EDITING -> useDetail.orEmpty()
        else -> ""
    }

    fun currentDiagnosticAnswers(): List<Pair<String, String>> = listOf(
        "os" to (os?.name ?: ""),
        "budget_target" to budgetTarget,
        "budget_max" to budgetMax,
        "primary_use" to (primaryUse?.name ?: ""),
        "game_type" to activeGameType(),
        "camera_subject" to activeCameraSubject(),
        "battery" to (battery ?: ""),
        "battery_charge" to (batteryCharge ?: ""),
        "size_preference" to (sizePreference ?: ""),
        "storage_minimum" to (storageMinimum ?: ""),
        "nice_have" to niceHave.joinToString(","),
        "purchase_channel" to (purchaseChannel ?: ""),
        "product_condition" to (productCondition ?: ""),
        "intended_years" to (intendedYears ?: ""),
        "design_preference" to (designPreference ?: ""),
        "use_detail" to (useDetail ?: ""),
        "must_have" to mustHave.joinToString(",")
    )

    fun draftPayload(): String = JSONObject().apply {
        put("os", os?.name ?: "")
        put("budget_target", budgetTarget)
        put("budget_max", budgetMax)
        put("primary_use", primaryUse?.name ?: "")
        put("game_type", activeGameType())
        put("camera_subject", activeCameraSubject())
        put("battery", battery ?: "")
        put("battery_charge", batteryCharge ?: "")
        put("size_preference", sizePreference ?: "")
        put("storage_minimum", storageMinimum ?: "")
        put("nice_have", niceHave.joinToString("\u001f"))
        put("purchase_channel", purchaseChannel ?: "")
        put("product_condition", productCondition ?: "")
        put("intended_years", intendedYears ?: "")
        put("design_preference", designPreference ?: "")
        put("use_detail", activeUseDetail())
        put("must_have", mustHave.joinToString("\u001f"))
        put("screen", screen.name)
    }.toString()

    fun restorePayload(payload: String, destination: Screen = Screen.OS) {
        val json = runCatching { JSONObject(payload) }.getOrNull() ?: return
        fun value(key: String) = json.optString(key, "").takeIf { it.isNotBlank() }
        os = value("os")?.let { runCatching { CandidateOs.valueOf(it) }.getOrNull() }
        budgetTarget = json.optString("budget_target", "")
        budgetMax = json.optString("budget_max", "")
        primaryUse = value("primary_use")?.let { runCatching { PrimaryUse.valueOf(it) }.getOrNull() }
        gameType = value("game_type").takeIf { primaryUse == PrimaryUse.GAMING }
        cameraSubject = value("camera_subject").takeIf { primaryUse == PrimaryUse.CAMERA }
        battery = value("battery"); batteryCharge = value("battery_charge")
        sizePreference = value("size_preference"); storageMinimum = value("storage_minimum")
        niceHave = json.optString("nice_have", "").split("\u001f").filter { it.isNotBlank() }
        purchaseChannel = value("purchase_channel"); productCondition = value("product_condition")
        intendedYears = value("intended_years"); designPreference = value("design_preference")
        useDetail = value("use_detail").takeIf {
            primaryUse in setOf(PrimaryUse.VIDEO, PrimaryUse.SNS, PrimaryUse.WORK, PrimaryUse.AI, PrimaryUse.VIDEO_EDITING)
        }
        mustHave = json.optString("must_have", "").split("\u001f").filter { it.isNotBlank() }
        screen = destination
    }

    LaunchedEffect(
        dbReady, screen, os, budgetTarget, budgetMax, primaryUse, gameType, cameraSubject, battery,
        batteryCharge, sizePreference, storageMinimum, niceHave, purchaseChannel, productCondition,
        intendedYears, designPreference, useDetail, mustHave
    ) {
        if (dbReady && screen != Screen.HOME && screen != Screen.RESULT && screen != Screen.SAVED && screen != Screen.FAVORITES && screen != Screen.BROWSE && screen != Screen.DETAIL && screen != Screen.COMPARE && os != null) {
            withContext(Dispatchers.IO) {
                AppDatabase.getInstance(context).diagnosticDao().upsertDraft(
                    jp.smartphoneadvisor.app.data.DiagnosticDraftEntity(
                        payload = draftPayload(),
                        updatedAt = System.currentTimeMillis()
                    )
                )
            }
            hasDiagnosticDraft = true
        }
    }

    suspend fun clearDiagnosticDraft() {
        AppDatabase.getInstance(context).diagnosticDao().clearDraft()
        withContext(Dispatchers.Main) { hasDiagnosticDraft = false }
    }

    suspend fun saveCurrentDiagnosis() {
        val dao = AppDatabase.getInstance(context).diagnosticDao()
        val now = System.currentTimeMillis()
        val existingId = editingProfileId
        val targetProfileId: Long
        if (existingId != null) {
            val existing = dao.getProfile(existingId)
            if (existing == null || !existing.isActive) {
                saveMessage = "保存先の診断が見つかりません。"
                return
            }
            targetProfileId = dao.upsertProfile(existing.copy(updatedAt = now, lastRunAt = now))
        } else {
            val activeCount = dao.activeProfileCount()
            if (activeCount >= 3) {
                saveMessage = "保存できる診断は3件までです。"
                return
            }
            targetProfileId = dao.upsertProfile(
                jp.smartphoneadvisor.app.data.DiagnosticProfileEntity(
                    name = "診断 ${activeCount + 1}",
                    createdAt = now,
                    updatedAt = now,
                    lastRunAt = now
                )
            )
        }
        dao.deleteAnswers(targetProfileId)
        currentDiagnosticAnswers().forEach { (questionId, value) ->
            dao.upsertAnswer(
                jp.smartphoneadvisor.app.data.DiagnosticAnswerEntity(
                    profileId = targetProfileId,
                    questionId = questionId,
                    answerValue = value
                )
            )
        }
        if (existingId == null) {
            editingProfileId = targetProfileId
            dao.insertRun(
                jp.smartphoneadvisor.app.data.DiagnosticRunEntity(
                    profileId = targetProfileId,
                    executedAt = now,
                    databaseVersion = "0.2.27",
                    requirementSnapshot = buildRequirementSnapshot(
                        os, budgetTarget, budgetMax, primaryUse, gameType, cameraSubject, useDetail, battery, batteryCharge,
                                sizePreference, storageMinimum, niceHave, purchaseChannel, productCondition, intendedYears,
                                designPreference, mustHave
                    ),
                    recommendedDeviceIds = recommendationResults.joinToString(",") { it.phone.deviceVariantId.toString() },
                    excludedDeviceIds = ""
                )
            )
        }
        saveMessage = if (existingId == null) "診断を保存しました。" else "保存した診断を更新しました。"
    }

    fun restoreDiagnostic(profileId: Long, runLatest: Boolean) {
        scope.launch(Dispatchers.IO) {
            val answers = AppDatabase.getInstance(context).diagnosticDao().getAnswers(profileId)
            val values = answers.associate { it.questionId to it.answerValue }
            withContext(Dispatchers.Main) {
                editingProfileId = profileId
                os = values["os"]?.takeIf { it.isNotBlank() }?.let { runCatching { CandidateOs.valueOf(it) }.getOrNull() }
                budgetTarget = values["budget_target"] ?: ""
                budgetMax = values["budget_max"] ?: ""
                primaryUse = values["primary_use"]?.takeIf { it.isNotBlank() }?.let { runCatching { PrimaryUse.valueOf(it) }.getOrNull() }
                gameType = values["game_type"]?.takeIf { it.isNotBlank() && primaryUse == PrimaryUse.GAMING }
                cameraSubject = values["camera_subject"]?.takeIf { it.isNotBlank() && primaryUse == PrimaryUse.CAMERA }
                battery = values["battery"]?.takeIf { it.isNotBlank() }
                batteryCharge = values["battery_charge"]?.takeIf { it.isNotBlank() }
                sizePreference = values["size_preference"]?.takeIf { it.isNotBlank() }
                storageMinimum = values["storage_minimum"]?.takeIf { it.isNotBlank() }
                niceHave = values["nice_have"].orEmpty().split(",").filter { it.isNotBlank() }
                purchaseChannel = values["purchase_channel"]?.takeIf { it.isNotBlank() }
                productCondition = values["product_condition"]?.takeIf { it.isNotBlank() }
                intendedYears = values["intended_years"]?.takeIf { it.isNotBlank() }
                designPreference = values["design_preference"]?.takeIf { it.isNotBlank() }
                useDetail = values["use_detail"]?.takeIf {
                    it.isNotBlank() && primaryUse in setOf(PrimaryUse.VIDEO, PrimaryUse.SNS, PrimaryUse.WORK, PrimaryUse.AI, PrimaryUse.VIDEO_EDITING)
                }
                mustHave = values["must_have"].orEmpty().split(",").filter { it.isNotBlank() }
                saveMessage = null
                if (runLatest) {
                    diagnosticRunToken += 1
                    screen = Screen.RESULT
                } else {
                    screen = Screen.OS
                }
            }
        }
    }

    MaterialTheme {
        if (renameProfileId != null) {
        AlertDialog(
            onDismissRequest = { renameProfileId = null },
            title = { Text("診断名を変更") },
            text = {
                OutlinedTextField(
                    value = renameProfileText,
                    onValueChange = { renameProfileText = it },
                    singleLine = true,
                    label = { Text("診断名") },
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                TextButton(
                    enabled = renameProfileText.isNotBlank(),
                    onClick = {
                        val id = renameProfileId
                        if (id != null) {
                            scope.launch(Dispatchers.IO) {
                                AppDatabase.getInstance(context).diagnosticDao().renameProfile(id, renameProfileText.trim(), System.currentTimeMillis())
                            }
                        }
                        renameProfileId = null
                    }
                ) { Text("保存") }
            },
            dismissButton = { TextButton(onClick = { renameProfileId = null }) { Text("キャンセル") } }
        )
    }
        catalogImportWarning?.let { warning ->
            AlertDialog(
                onDismissRequest = { catalogImportWarning = null },
                title = { Text("カタログデータの確認が必要です") },
                text = { Text(warning) },
                confirmButton = {
                    TextButton(onClick = { catalogImportWarning = null }) { Text("確認しました") }
                }
            )
        }
        startupFailure?.let { failure ->
            AlertDialog(
                onDismissRequest = { /* Initialization must be retried or the failure explicitly handled. */ },
                title = { Text("アプリを起動できませんでした") },
                text = { Text(failure) },
                confirmButton = {
                    TextButton(onClick = {
                        startupFailure = null
                        startupAttempt += 1
                    }) { Text("初期化を再試行") }
                }
            )
        }
        Surface(Modifier.fillMaxSize()) {
            when (screen) {
                Screen.HOME -> HomeScreen(
                    hasDraft = hasDiagnosticDraft,
                    onResumeDraft = {
                        scope.launch(Dispatchers.IO) {
                            val draft = AppDatabase.getInstance(context).diagnosticDao().getDraft()
                            withContext(Dispatchers.Main) { draft?.let { restorePayload(it.payload, Screen.OS) } }
                        }
                    },
                    onStart = {
                        editingProfileId = null
                        diagnosticRunToken = 0
                        lastRecordedRunToken = 0
                        saveMessage = null
                        scope.launch(Dispatchers.IO) { clearDiagnosticDraft() }
                        batteryCharge = null; sizePreference = null; storageMinimum = null; niceHave = emptyList()
                        purchaseChannel = null; productCondition = null; intendedYears = null; designPreference = null; useDetail = null
                        screen = Screen.OS
                    },
                    onSingleStart = { screen = Screen.SINGLE_DIAGNOSTIC },
                    onSaved = { screen = Screen.SAVED },
                    onFavorites = { screen = Screen.FAVORITES },
                    onBrowse = { browseQuery = ""; browseOs = CandidateOs.EITHER; screen = Screen.BROWSE }
                )
                Screen.SINGLE_DIAGNOSTIC -> SinglePhoneDiagnosticFlow(
                    context = context,
                    onBack = { screen = Screen.HOME }
                )
                Screen.FAVORITES -> FavoritePhonesScreen(
                    items = favoriteItems,
                    favoriteDeviceIds = favoriteDeviceIds.toSet(),
                    onOpenDetail = { id -> selectedDeviceId = id; detailReturnScreen = Screen.FAVORITES; screen = Screen.DETAIL },
                    onToggleFavorite = { id ->
                        scope.launch(Dispatchers.IO) {
                            val dao = AppDatabase.getInstance(context).phoneDao()
                            if (dao.isFavorite(id)) dao.deleteFavorite(id) else dao.insertFavorite(jp.smartphoneadvisor.app.data.FavoriteDeviceEntity(deviceVariantId = id, createdAt = System.currentTimeMillis()))
                        }
                    },
                    onAddComparison = ::addToComparison,
                    onBack = { screen = Screen.HOME }
                )
                Screen.BROWSE -> SmartphoneBrowseScreen(
                    items = browseItems, query = browseQuery, selectedOs = browseOs,
                    selectedManufacturer = browseManufacturer, selectedSeries = browseSeries,
                    maxPriceYen = browseMaxPrice, selectedStorageGb = browseStorage, selectedReleaseYear = browseReleaseYear,
                    onQueryChange = { browseQuery = it }, onOsChange = { browseOs = it },
                    onManufacturerChange = { browseManufacturer = it; browseSeries = "すべて" },
                    onSeriesChange = { browseSeries = it }, onMaxPriceChange = { browseMaxPrice = it },
                    onStorageChange = { browseStorage = it }, onReleaseYearChange = { browseReleaseYear = it },
                    onOpenDetail = { id -> selectedDeviceId = id; detailReturnScreen = Screen.BROWSE; screen = Screen.DETAIL },
                    favoriteDeviceIds = favoriteDeviceIds.toSet(),
                    onToggleFavorite = { id ->
                        scope.launch(Dispatchers.IO) {
                            val dao = AppDatabase.getInstance(context).phoneDao()
                            if (dao.isFavorite(id)) dao.deleteFavorite(id) else dao.insertFavorite(jp.smartphoneadvisor.app.data.FavoriteDeviceEntity(deviceVariantId = id, createdAt = System.currentTimeMillis()))
                        }
                    },
                    onAddComparison = ::addToComparison, onBack = { screen = Screen.HOME }
                )
                Screen.SAVED -> SavedDiagnosticsScreen(
                    profiles = diagnosticProfiles,
                    onBack = { screen = Screen.HOME },
                    onEdit = { profileId -> restoreDiagnostic(profileId, false) },
                    onRerun = { profileId -> restoreDiagnostic(profileId, true) },
                    onRename = { profile ->
                        renameProfileId = profile.id
                        renameProfileText = profile.name
                    },
                    onDelete = { profileId ->
                        scope.launch(Dispatchers.IO) {
                            AppDatabase.getInstance(context).diagnosticDao().archiveProfile(profileId, System.currentTimeMillis())
                        }
                    }
                )
                Screen.OS -> ChoiceScreen(
                    "どちらのスマホを希望しますか？", "Q1 · 1つ選んでください",
                    CandidateOs.entries.toList(), os, { it.nameLabel() },
                    { os = it }, { screen = Screen.HOME }, { screen = Screen.BUDGET }
                )
                Screen.BUDGET -> BudgetScreen(
                    target = budgetTarget,
                    max = budgetMax,
                    onTargetChange = { budgetTarget = it },
                    onMaxChange = { budgetMax = it },
                    onBack = { screen = Screen.OS },
                    onNext = { screen = Screen.USE }
                )
                Screen.USE -> ChoiceScreen(
                    "何に一番使いますか？", "Q3 · メインの用途を1つ選んでください",
                    PrimaryUse.entries.toList(), primaryUse, { it.label() },
                    {
                        primaryUse = it
                        if (it != PrimaryUse.GAMING) gameType = null
                        if (it != PrimaryUse.CAMERA) cameraSubject = null
                        if (it != PrimaryUse.VIDEO && it != PrimaryUse.SNS && it != PrimaryUse.WORK && it != PrimaryUse.AI && it != PrimaryUse.VIDEO_EDITING) useDetail = null
                    },
                    { screen = Screen.BUDGET },
                    { screen = when (primaryUse) {
                        PrimaryUse.GAMING -> Screen.GAME
                        PrimaryUse.CAMERA -> Screen.CAMERA
                        PrimaryUse.VIDEO, PrimaryUse.SNS, PrimaryUse.WORK, PrimaryUse.AI, PrimaryUse.VIDEO_EDITING -> Screen.USE_DETAIL
                        else -> Screen.COMMON
                    } }
                )
                Screen.GAME -> ChoiceScreen(
                    "どんなゲームをよくプレイしますか？", "用途別追加質問 · ゲーム",
                    listOf("軽いゲーム", "普通のゲーム", "重い3Dゲーム", "最高画質", "よく分からない"),
                    gameType, { it }, { gameType = it }, { screen = Screen.USE }, { screen = Screen.COMMON }
                )
                Screen.CAMERA -> ChoiceScreen(
                    "何を撮ることが多いですか？", "用途別追加質問 · カメラ",
                    listOf("人物", "子ども", "ペット", "風景", "旅行", "夜景", "スポーツ・動くもの"),
                    cameraSubject, { it }, { cameraSubject = it }, { screen = Screen.USE }, { screen = Screen.COMMON }
                )
                Screen.USE_DETAIL -> ChoiceScreen(
                    title = when (primaryUse) {
                        PrimaryUse.VIDEO -> "動画はどう使いますか？"
                        PrimaryUse.SNS -> "SNSでは何を重視しますか？"
                        PrimaryUse.WORK -> "仕事・学習では何をしますか？"
                        PrimaryUse.AI -> "AIをどう使いますか？"
                        PrimaryUse.VIDEO_EDITING -> "動画編集では何をしますか？"
                        else -> "追加の用途を教えてください"
                    },
                    subtitle = "用途別追加質問",
                    options = when (primaryUse) {
                        PrimaryUse.VIDEO -> listOf("見ることが中心", "撮影する", "撮影と編集の両方")
                        PrimaryUse.SNS -> listOf("見ることが中心", "写真・動画を投稿", "撮影・編集も重視")
                        PrimaryUse.WORK -> listOf("Web・メール", "PDF・Office", "オンライン会議", "長文入力", "AIも使う")
                        PrimaryUse.AI -> listOf("チャット", "文章作成", "画像生成", "音声", "端末内AI")
                        PrimaryUse.VIDEO_EDITING -> listOf("軽い編集", "SNS動画編集", "本格的な編集")
                        else -> listOf("特に決まっていない")
                    },
                    selected = useDetail,
                    label = { it }, onSelected = { useDetail = it },
                    onBack = { screen = Screen.USE }, onNext = { screen = Screen.COMMON }
                )
                Screen.COMMON -> ChoiceScreen(
                    "バッテリーはどのくらい重要ですか？", "共通質問",
                    listOf("あまり気にしない", "普通", "かなり重要", "最重要"),
                    battery, { it }, { battery = it }, { screen = Screen.USE }, { screen = Screen.BATTERY_CHARGE }
                )
                Screen.BATTERY_CHARGE -> ChoiceScreen(
                    "充電できる環境はありますか？", "共通質問 · 充電環境",
                    listOf("こまめに充電できる", "外出中はあまり充電できない", "モバイルバッテリーをよく使う", "よく分からない"),
                    batteryCharge, { it }, { batteryCharge = it }, { screen = Screen.COMMON }, { screen = Screen.SIZE }
                )
                Screen.SIZE -> ChoiceScreen(
                    "大きさ・重さの希望は？", "共通質問 · サイズ・重量",
                    listOf("小さく軽い方がいい", "標準でいい", "大きくても画面重視", "重さは気にしない"),
                    sizePreference, { it }, { sizePreference = it }, { screen = Screen.BATTERY_CHARGE }, { screen = Screen.STORAGE }
                )
                Screen.STORAGE -> ChoiceScreen(
                    "必要なストレージは？", "共通質問 · ストレージ",
                    listOf("128GB以上", "256GB以上", "512GB以上", "1TB以上", "特に決めていない"),
                    storageMinimum, { it }, { storageMinimum = it }, { screen = Screen.SIZE }, { screen = Screen.NICE_HAVE }
                )
                Screen.NICE_HAVE -> MultiChoiceScreen(
                    title = "あったら嬉しい機能は？", subtitle = "必須ではありません。おすすめの相性に影響します。",
                    options = listOf("高リフレッシュレート", "ワイヤレス充電", "指紋認証", "microSD", "イヤホンジャック", "軽量", "大画面", "望遠カメラ"),
                    selected = niceHave, onToggle = { key -> niceHave = if (key in niceHave) niceHave - key else niceHave + key },
                    onBack = { screen = Screen.STORAGE }, onNext = { screen = Screen.PURCHASE }
                )
                Screen.PURCHASE -> ChoiceScreen(
                    "どこで購入する予定ですか？", "購入条件",
                    listOf("SIMフリー", "docomo", "au", "SoftBank", "楽天モバイル", "UQ mobile", "Y!mobile", "IIJmio", "mineo", "MVNO", "特に決めていない"),
                    purchaseChannel, { it }, { purchaseChannel = it }, { screen = Screen.NICE_HAVE }, { screen = Screen.CONDITION }
                )
                Screen.CONDITION -> ChoiceScreen(
                    "新品・中古の希望は？", "購入条件",
                    listOf("新品のみ", "中古も候補", "未使用品・整備済みも候補"),
                    productCondition, { it }, { productCondition = it }, { screen = Screen.PURCHASE }, { screen = Screen.DURATION }
                )
                Screen.DURATION -> ChoiceScreen(
                    "何年くらい使う予定ですか？", "長期利用",
                    listOf("1〜2年", "3年くらい", "4〜5年", "5年以上", "決めていない"),
                    intendedYears, { it }, { intendedYears = it }, { screen = Screen.CONDITION }, { screen = Screen.DESIGN }
                )
                Screen.DESIGN -> ChoiceScreen(
                    "デザイン・画面で重視することは？", "デザイン・ディスプレイ",
                    listOf("見やすさ・大画面", "高リフレッシュレート", "明るさ", "片手で使いやすい", "デザイン重視", "特に決めていない"),
                    designPreference, { it }, { designPreference = it }, { screen = Screen.DURATION }, { screen = Screen.MUST_HAVE }
                )
                Screen.MUST_HAVE -> MustHaveScreen(
                    selected = mustHave,
                    onToggle = { key -> mustHave = if (key in mustHave) mustHave - key else mustHave + key },
                    onBack = { screen = Screen.DESIGN },
                    onNext = { screen = Screen.CONFIRM }
                )
                Screen.CONFIRM -> ConfirmScreen(
                    os = os?.nameLabel() ?: "未指定",
                    budget = if (budgetTarget.isBlank()) "未指定" else "希望 ${budgetTarget} / 上限 ${budgetMax.ifBlank { "指定なし" }}",
                    use = primaryUse?.label() ?: "未指定",
                    mustHave = mustHave,
                    summary = listOfNotNull(
                        sizePreference?.let { "サイズ・重量：$it" }, storageMinimum?.let { "ストレージ：$it" },
                        battery?.let { "バッテリー：$it" }, purchaseChannel?.let { "購入先：$it" },
                        productCondition?.let { "状態：$it" }, intendedYears?.let { "使用予定：$it" },
                        designPreference?.let { "画面・デザイン：$it" }
                    ),
                    onBack = { screen = Screen.MUST_HAVE },
                    onRun = {
                        diagnosticRunToken += 1
                        screen = Screen.RESULT
                        scope.launch(Dispatchers.IO) { clearDiagnosticDraft() }
                    }
                )
                Screen.RESULT -> ResultScreen(
                    os?.nameLabel() ?: "未指定",
                    if (budgetTarget.isBlank()) "未指定" else "希望 ${budgetTarget} / 上限 ${budgetMax.ifBlank { "指定なし" }}",
                    primaryUse?.label() ?: "未指定",
                    recommendationResults,
                    recommendationPrioritySummary,
                    onSave = {
                        scope.launch { saveCurrentDiagnosis() }
                    },
                    saveMessage = saveMessage,
                    onOpenDetail = { deviceId -> selectedDeviceId = deviceId; detailReturnScreen = Screen.RESULT; screen = Screen.DETAIL },
                    onAddCompare = ::addToComparison,
                    comparisonCount = comparisonIds.size,
                    onOpenCompare = { if (comparisonIds.size >= 2) screen = Screen.COMPARE },
                    onRestart = {
                        editingProfileId = null
                        diagnosticRunToken = 0
                        lastRecordedRunToken = 0
                        screen = Screen.HOME
                        os = null; budgetTarget = ""; budgetMax = ""; primaryUse = null
                        gameType = null; cameraSubject = null; useDetail = null; battery = null; batteryCharge = null
                        sizePreference = null; storageMinimum = null; niceHave = emptyList(); purchaseChannel = null
                        productCondition = null; intendedYears = null; designPreference = null; mustHave = emptyList()
                        recommendationResults = emptyList(); recommendationPrioritySummary = emptyList(); noCandidateExplanation = emptyList(); saveMessage = null
                        scope.launch(Dispatchers.IO) { clearDiagnosticDraft() }
                    }
                )
                Screen.COMPARE -> ComparisonScreen(
                    items = comparisonItems,
                    comparisonPrices = comparisonPrices,
                    comparisonIds = comparisonIds,
                    primaryUse = primaryUse,
                    budgetMaxYen = budgetMax.toYenOrNull(),
                    recommendationByDeviceId = recommendationResults.associateBy { it.phone.deviceVariantId },
                    mustHave = mustHave,
                    onRemove = { id -> comparisonIds = comparisonIds - id },
                    onBack = { screen = Screen.RESULT }
                )
                Screen.DETAIL -> SmartphoneDetailScreen(
                    detail = selectedDeviceDetail,
                    recommendation = selectedDeviceId?.let { id -> recommendationResults.firstOrNull { it.phone.deviceVariantId == id } },
                    purchaseOptions = purchaseOptions,
                    dataConflicts = dataConflicts,
                    isFavorite = selectedDeviceId?.let { it in favoriteDeviceIds } == true,
                    onToggleFavorite = { id ->
                        scope.launch(Dispatchers.IO) {
                            val dao = AppDatabase.getInstance(context).phoneDao()
                            if (dao.isFavorite(id)) dao.deleteFavorite(id) else dao.insertFavorite(jp.smartphoneadvisor.app.data.FavoriteDeviceEntity(deviceVariantId = id, createdAt = System.currentTimeMillis()))
                        }
                    },
                    onOpenPurchase = { url ->
                        safeExternalWebUri(url)?.let { safeUri ->
                            runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, safeUri)) }
                        }
                    },
                    onBack = { screen = detailReturnScreen }
                )
            }
        }
    }
}

private fun buildRequirementSnapshot(
    os: CandidateOs?,
    budgetTarget: String,
    budgetMax: String,
    primaryUse: PrimaryUse?,
    gameType: String?,
    cameraSubject: String?,
    useDetail: String?,
    battery: String?,
    batteryCharge: String?,
    sizePreference: String?,
    storageMinimum: String?,
    niceHave: List<String>,
    purchaseChannel: String?,
    productCondition: String?,
    intendedYears: String?,
    designPreference: String?,
    mustHave: List<String>
): String = buildString {
    append("os=").append(os?.name ?: "")
    append(";budgetTarget=").append(budgetTarget)
    append(";budgetMax=").append(budgetMax)
    append(";primaryUse=").append(primaryUse?.name ?: "")
    append(";gameType=").append(gameType ?: "")
    append(";cameraSubject=").append(cameraSubject ?: "")
    append(";useDetail=").append(useDetail ?: "")
    append(";battery=").append(battery ?: "")
    append(";batteryCharge=").append(batteryCharge ?: "")
    append(";sizePreference=").append(sizePreference ?: "")
    append(";storageMinimum=").append(storageMinimum ?: "")
    append(";niceHave=").append(niceHave.joinToString(","))
    append(";purchaseChannel=").append(purchaseChannel ?: "")
    append(";productCondition=").append(productCondition ?: "")
    append(";intendedYears=").append(intendedYears ?: "")
    append(";designPreference=").append(designPreference ?: "")
    append(";mustHave=").append(mustHave.joinToString(","))
}

private fun RecommendationConfidence.label() = when (this) {
    RecommendationConfidence.HIGH -> "高"
    RecommendationConfidence.MEDIUM -> "中"
    RecommendationConfidence.LOW -> "低"
}

private fun CandidateOs.nameLabel() = when (this) {
    CandidateOs.ANDROID -> "Android"
    CandidateOs.IPHONE -> "iPhone"
    CandidateOs.EITHER -> "どちらでもいい"
}

private fun PrimaryUse.label() = when (this) {
    PrimaryUse.GENERAL -> "普段使い"
    PrimaryUse.GAMING -> "ゲーム"
    PrimaryUse.CAMERA -> "カメラ"
    PrimaryUse.VIDEO -> "動画"
    PrimaryUse.SNS -> "SNS"
    PrimaryUse.CALLS -> "通話・LINE"
    PrimaryUse.MUSIC -> "音楽"
    PrimaryUse.EBOOK -> "電子書籍"
    PrimaryUse.WORK -> "仕事・学習"
    PrimaryUse.AI -> "AI"
    PrimaryUse.VIDEO_EDITING -> "動画編集"
    PrimaryUse.OTHER -> "その他"
}

@Composable
private fun HomeScreen(hasDraft: Boolean, onResumeDraft: () -> Unit, onStart: () -> Unit, onSingleStart: () -> Unit, onSaved: () -> Unit, onFavorites: () -> Unit, onBrowse: () -> Unit) {
    Scaffold(
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = true,
                    onClick = { },
                    icon = { Text("⌂") },
                    label = { Text("ホーム") }
                )
                NavigationBarItem(
                    selected = false,
                    onClick = onBrowse,
                    icon = { Text("⌕") },
                    label = { Text("探す") }
                )
                NavigationBarItem(
                    selected = false,
                    onClick = onFavorites,
                    icon = { Text("♡") },
                    label = { Text("お気に入り") }
                )
                NavigationBarItem(
                    selected = false,
                    onClick = onSaved,
                    icon = { Text("▣") },
                    label = { Text("保存診断") }
                )
            }
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(innerPadding),
            contentPadding = PaddingValues(24.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Spacer(Modifier.height(12.dp))
                Text("スマホ選び診断", style = MaterialTheme.typography.headlineLarge)
                Spacer(Modifier.height(8.dp))
                Text("あなたの使い方・予算・こだわりから、候補を一緒に探します。")
            }
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(20.dp)) {
                        Text("まずは診断から", style = MaterialTheme.typography.titleLarge)
                        Spacer(Modifier.height(8.dp))
                        Text("用途や予算などを答えると、条件に合うスマホを2〜5台提案します。")
                        Spacer(Modifier.height(16.dp))
                        Button(onClick = onSingleStart, Modifier.fillMaxWidth()) {
                            Text("かんたん1台診断を始める →")
                        }
                        Spacer(Modifier.height(8.dp))
                        OutlinedButton(onClick = onStart, Modifier.fillMaxWidth()) {
                            Text("詳しい診断を使う")
                        }
                    }
                }
            }
            if (hasDraft) {
                item {
                    OutlinedCard(Modifier.fillMaxWidth(), onClick = onResumeDraft) {
                        Column(Modifier.padding(18.dp)) {
                            Text("前回の診断を再開", style = MaterialTheme.typography.titleMedium)
                            Spacer(Modifier.height(4.dp))
                            Text("途中まで回答した内容を復元して続きから進めます。")
                        }
                    }
                }
            }
            item {
                OutlinedCard(Modifier.fillMaxWidth(), onClick = onBrowse) {
                    Column(Modifier.padding(18.dp)) {
                        Text("自分で探す", style = MaterialTheme.typography.titleMedium)
                        Spacer(Modifier.height(4.dp))
                        Text("メーカー・機種名・価格・ストレージなどから探せます。")
                    }
                }
            }
            item {
                Text("保存した診断やお気に入りは、下のナビゲーションからいつでも開けます。",
                    style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
private fun SmartphoneBrowseScreen(
    items: List<jp.smartphoneadvisor.app.data.PhoneListRow>, query: String, selectedOs: CandidateOs,
    selectedManufacturer: String, selectedSeries: String, maxPriceYen: Int,
    selectedStorageGb: Int, selectedReleaseYear: Int,
    onQueryChange: (String) -> Unit, onOsChange: (CandidateOs) -> Unit,
    onManufacturerChange: (String) -> Unit, onSeriesChange: (String) -> Unit,
    onMaxPriceChange: (Int) -> Unit, onStorageChange: (Int) -> Unit, onReleaseYearChange: (Int) -> Unit,
    onOpenDetail: (Long) -> Unit, favoriteDeviceIds: Set<Long>, onToggleFavorite: (Long) -> Unit, onAddComparison: (Long) -> Unit, onBack: () -> Unit
) {
    val manufacturers = listOf("すべて") + items.map { it.manufacturerName }.distinct().sorted()
    val series = listOf("すべて") + items.filter { selectedManufacturer == "すべて" || it.manufacturerName == selectedManufacturer }
        .mapNotNull { it.seriesName?.takeIf(String::isNotBlank) }.distinct().sorted()
    val filtered = items.filter { phone ->
        (selectedManufacturer == "すべて" || phone.manufacturerName == selectedManufacturer) &&
        (selectedSeries == "すべて" || phone.seriesName == selectedSeries) &&
        (maxPriceYen == 0 || (phone.normalPriceYen != null && phone.normalPriceYen <= maxPriceYen)) &&
        (selectedStorageGb == 0 || phone.storageGb == selectedStorageGb) &&
        (selectedReleaseYear == 0 || phone.releaseYear == selectedReleaseYear)
    }
    val priceOptions = listOf(0 to "指定なし", 100000 to "10万円以下", 150000 to "15万円以下", 200000 to "20万円以下", 250000 to "25万円以下")
    val storageOptions = listOf(0 to "すべて", 128 to "128GB", 256 to "256GB", 512 to "512GB", 1024 to "1TB")
    val yearOptions = listOf(0 to "すべて") + items.map { it.releaseYear }.distinct().sortedDescending().map { it to "${it}年" }

    Column(Modifier.fillMaxSize()) {
        TopAppBar(title = { Text("スマホを探す") }, navigationIcon = { TextButton(onClick = onBack) { Text("← 戻る") } })
        Column(Modifier.padding(horizontal = 16.dp)) {
            OutlinedTextField(value = query, onValueChange = onQueryChange, modifier = Modifier.fillMaxWidth(), singleLine = true,
                label = { Text("メーカー・機種名で検索") }, placeholder = { Text("例：Pixel、Xperia、Galaxy") })
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(CandidateOs.EITHER, CandidateOs.ANDROID, CandidateOs.IPHONE).forEach { option ->
                    FilterChip(selected = selectedOs == option, onClick = { onOsChange(option) }, label = { Text(option.browseLabel()) })
                }
            }
            Spacer(Modifier.height(6.dp)); Text("メーカー", style = MaterialTheme.typography.labelLarge)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                manufacturers.take(5).forEach { option -> FilterChip(selected = selectedManufacturer == option, onClick = { onManufacturerChange(option) }, label = { Text(option) }) }
            }
            if (manufacturers.size > 5) Text("メーカーは検索結果に応じて表示されます", style = MaterialTheme.typography.bodySmall)
            Spacer(Modifier.height(4.dp)); Text("シリーズ", style = MaterialTheme.typography.labelLarge)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                series.take(5).forEach { option -> FilterChip(selected = selectedSeries == option, onClick = { onSeriesChange(option) }, label = { Text(option) }) }
            }
            Spacer(Modifier.height(4.dp)); Text("価格上限", style = MaterialTheme.typography.labelLarge)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                priceOptions.forEach { (value, label) -> FilterChip(selected = maxPriceYen == value, onClick = { onMaxPriceChange(value) }, label = { Text(label) }) }
            }
            Spacer(Modifier.height(4.dp)); Text("ストレージ", style = MaterialTheme.typography.labelLarge)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                storageOptions.forEach { (value, label) -> FilterChip(selected = selectedStorageGb == value, onClick = { onStorageChange(value) }, label = { Text(label) }) }
            }
            Spacer(Modifier.height(4.dp)); Text("発売年", style = MaterialTheme.typography.labelLarge)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                yearOptions.forEach { (value, label) -> FilterChip(selected = selectedReleaseYear == value, onClick = { onReleaseYearChange(value) }, label = { Text(label) }) }
            }
            Spacer(Modifier.height(6.dp)); Text("${filtered.size}件", style = MaterialTheme.typography.labelLarge)
        }
        if (filtered.isEmpty()) {
            Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                Text("条件に一致するスマホがありません。")
                Spacer(Modifier.height(12.dp)); Text("価格上限を指定した場合、価格未確認の端末は除外されます。", style = MaterialTheme.typography.bodySmall)
            }
        } else {
            LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(filtered, key = { it.deviceVariantId }) { phone ->
                    PhoneBrowseCard(phone, phone.deviceVariantId in favoriteDeviceIds, { onOpenDetail(phone.deviceVariantId) }, { onToggleFavorite(phone.deviceVariantId) }, { onAddComparison(phone.deviceVariantId) })
                }
            }
        }
    }
}

private fun CandidateOs.browseLabel() = when (this) { CandidateOs.EITHER -> "すべて"; CandidateOs.ANDROID -> "Android"; CandidateOs.IPHONE -> "iPhone" }

@Composable
private fun PhoneBrowseCard(phone: jp.smartphoneadvisor.app.data.PhoneListRow, isFavorite: Boolean, onOpenDetail: () -> Unit, onToggleFavorite: () -> Unit, onAddComparison: () -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Text("${phone.manufacturerName} ${phone.modelName}", style = MaterialTheme.typography.titleLarge)
            phone.seriesName?.takeIf { it.isNotBlank() }?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
            Spacer(Modifier.height(4.dp))
            Text("${phone.platform} · ${phone.storageGb}GB · ${phone.releaseYear}年${phone.ramGb?.let { " · RAM ${it}GB" } ?: ""}", style = MaterialTheme.typography.bodyMedium)
            Spacer(Modifier.height(8.dp))
            Text(phone.normalPriceYen?.let { "通常価格 ${String.format(java.util.Locale.JAPAN, "%,d", it)}円" } ?: "価格未確認", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(8.dp)); Text("用途適性：${browseLevel(phone.generalLevel)} / ゲーム ${browseLevel(phone.gamingLevel)} / カメラ ${browseLevel(phone.cameraLevel)}", style = MaterialTheme.typography.bodySmall)
            Spacer(Modifier.height(10.dp)); Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = onToggleFavorite, modifier = Modifier.weight(1f)) { Text(if (isFavorite) "★ お気に入り" else "☆ お気に入り") }
                OutlinedButton(onClick = onAddComparison, modifier = Modifier.weight(1f)) { Text("比較に追加") }
                Button(onClick = onOpenDetail, modifier = Modifier.weight(1f)) { Text("詳細を見る") }
            }
        }
    }
}

private fun browseLevel(level: AttributeLevel?) = when (level) { AttributeLevel.EXCELLENT -> "非常に高い"; AttributeLevel.GOOD -> "高い"; AttributeLevel.STANDARD -> "標準"; AttributeLevel.WEAK -> "控えめ"; else -> "未確認" }

@Composable
private fun FavoritePhonesScreen(
    items: List<jp.smartphoneadvisor.app.data.PhoneListRow>,
    favoriteDeviceIds: Set<Long>,
    onOpenDetail: (Long) -> Unit,
    onToggleFavorite: (Long) -> Unit,
    onAddComparison: (Long) -> Unit,
    onBack: () -> Unit
) {
    Column(Modifier.fillMaxSize()) {
        TopAppBar(title = { Text("お気に入り") }, navigationIcon = { TextButton(onClick = onBack) { Text("← 戻る") } })
        if (items.isEmpty()) {
            Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                Text("お気に入りに登録したスマホはありません。")
                Spacer(Modifier.height(8.dp))
                Text("スマホ一覧や詳細画面から☆を押して登録できます。", style = MaterialTheme.typography.bodySmall)
            }
        } else {
            LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(items, key = { it.deviceVariantId }) { phone ->
                    PhoneBrowseCard(
                        phone = phone,
                        isFavorite = phone.deviceVariantId in favoriteDeviceIds,
                        onOpenDetail = { onOpenDetail(phone.deviceVariantId) },
                        onToggleFavorite = { onToggleFavorite(phone.deviceVariantId) },
                        onAddComparison = { onAddComparison(phone.deviceVariantId) }
                    )
                }
            }
        }
    }
}

@Composable
private fun SavedDiagnosticsScreen(
    profiles: List<jp.smartphoneadvisor.app.data.DiagnosticProfileEntity>,
    onBack: () -> Unit,
    onEdit: (Long) -> Unit,
    onRerun: (Long) -> Unit,
    onRename: (jp.smartphoneadvisor.app.data.DiagnosticProfileEntity) -> Unit,
    onDelete: (Long) -> Unit
) {
    Column(Modifier.fillMaxSize().padding(24.dp)) {
        Text("保存した診断", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(8.dp))
        Text("最大3件。回答を復元して編集したり、最新データで再診断できます。")
        Spacer(Modifier.height(20.dp))
        if (profiles.isEmpty()) {
            Text("保存した診断はありません。")
        } else {
            profiles.forEach { profile ->
                Card(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                    Column(Modifier.fillMaxWidth().padding(16.dp)) {
                        Text(profile.name, style = MaterialTheme.typography.titleMedium)
                        Spacer(Modifier.height(4.dp))
                        Text("最終更新: ${java.text.SimpleDateFormat("yyyy/MM/dd HH:mm", java.util.Locale.JAPAN).format(java.util.Date(profile.updatedAt))}")
                        profile.lastRunAt?.let {
                            Text("最終診断: ${java.text.SimpleDateFormat("yyyy/MM/dd HH:mm", java.util.Locale.JAPAN).format(java.util.Date(it))}")
                        }
                        Spacer(Modifier.height(10.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = { onEdit(profile.id) }, modifier = Modifier.weight(1f)) { Text("編集") }
                            Button(onClick = { onRerun(profile.id) }, modifier = Modifier.weight(1f)) { Text("最新データで再診断") }
                        }
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                            TextButton(onClick = { onRename(profile) }) { Text("名前変更") }
                            TextButton(onClick = { onDelete(profile.id) }) { Text("削除") }
                        }
                    }
                }
            }
        }
        Spacer(Modifier.weight(1f))
        OutlinedButton(onClick = onBack, Modifier.fillMaxWidth()) { Text("← ホームへ戻る") }
    }
}

@Composable
private fun <T> ChoiceScreen(
    title: String, subtitle: String, options: List<T>, selected: T?,
    label: (T) -> String, onSelected: (T) -> Unit,
    onBack: () -> Unit, onNext: () -> Unit
) {
    Column(Modifier.fillMaxSize().padding(24.dp)) {
        Text(subtitle, style = MaterialTheme.typography.labelLarge)
        Spacer(Modifier.height(12.dp))
        Text(title, style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(24.dp))
        options.forEach { option ->
            Card(
                Modifier.fillMaxWidth().padding(vertical = 4.dp)
                    .selectable(
                        selected == option,
                        onClick = { onSelected(option) },
                        role = Role.RadioButton
                    )
            ) {
                Row(
                    Modifier.fillMaxWidth().padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RadioButton(selected == option, onClick = null)
                    Text(label(option), Modifier.padding(start = 8.dp))
                }
            }
        }
        Spacer(Modifier.weight(1f))
        Row(Modifier.fillMaxWidth(), Arrangement.spacedBy(12.dp)) {
            OutlinedButton(onBack, Modifier.weight(1f)) { Text("← 戻る") }
            Button(onNext, Modifier.weight(1f), enabled = selected != null) { Text("次へ →") }
        }
    }
}

@Composable
private fun BudgetScreen(
    target: String, max: String,
    onTargetChange: (String) -> Unit,
    onMaxChange: (String) -> Unit,
    onBack: () -> Unit, onNext: () -> Unit
) {
    val options = listOf("10万円", "15万円", "20万円", "25万円", "30万円")
    val maxOptions = listOf("指定なし") + options.filter { it.toYenOrNull() != null && (target.toYenOrNull() == null || it.toYenOrNull()!! >= target.toYenOrNull()!!) }
    Column(Modifier.fillMaxSize().padding(24.dp)) {
        Text("Q2 · 予算", style = MaterialTheme.typography.labelLarge)
        Spacer(Modifier.height(12.dp))
        Text("希望価格と、超えてほしくない上限を決めます", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(20.dp))
        Text("できればこのくらい", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(8.dp))
        options.forEach { option ->
            OutlinedButton(
                onClick = { onTargetChange(option); if (max.toYenOrNull() != null && max.toYenOrNull()!! < option.toYenOrNull()!!) onMaxChange("") },
                Modifier.fillMaxWidth().padding(vertical = 2.dp)
            ) { Text(if (target == option) "✓ $option" else option) }
        }
        Spacer(Modifier.height(12.dp))
        Text("絶対に超えたくない上限", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(8.dp))
        maxOptions.forEach { option ->
            OutlinedButton(
                onClick = { onMaxChange(option) },
                Modifier.fillMaxWidth().padding(vertical = 2.dp)
            ) { Text(if (max == option) "✓ $option" else option) }
        }
        Spacer(Modifier.weight(1f))
        Row(Modifier.fillMaxWidth(), Arrangement.spacedBy(12.dp)) {
            OutlinedButton(onBack, Modifier.weight(1f)) { Text("← 戻る") }
            Button(onNext, Modifier.weight(1f), enabled = target.isNotBlank()) { Text("次へ →") }
        }
    }
}

private fun String?.toIntOrNullFromLabel(): Int? = when (this) {
    "1〜2年" -> 2
    "3年くらい" -> 3
    "4〜5年" -> 5
    "5年以上" -> 5
    else -> null
}

private fun String.toYenOrNull(): Int? = when (this) {
    "10万円" -> 100_000
    "15万円" -> 150_000
    "20万円" -> 200_000
    "25万円" -> 250_000
    "30万円" -> 300_000
    else -> null
}


@Composable
private fun MultiChoiceScreen(
    title: String, subtitle: String, options: List<String>, selected: List<String>,
    onToggle: (String) -> Unit, onBack: () -> Unit, onNext: () -> Unit
) {
    Column(Modifier.fillMaxSize().padding(24.dp)) {
        Text(subtitle, style = MaterialTheme.typography.labelLarge)
        Spacer(Modifier.height(12.dp))
        Text(title, style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(20.dp))
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(options) { option ->
                Card(Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = option in selected, onCheckedChange = { onToggle(option) })
                        Text(option, Modifier.padding(start = 8.dp))
                    }
                }
            }
        }
        Row(Modifier.fillMaxWidth(), Arrangement.spacedBy(12.dp)) {
            OutlinedButton(onBack, Modifier.weight(1f)) { Text("← 戻る") }
            Button(onNext, Modifier.weight(1f)) { Text("次へ →") }
        }
    }
}

@Composable
private fun MustHaveScreen(
    selected: Set<String>,
    onToggle: (String) -> Unit,
    onBack: () -> Unit, onNext: () -> Unit
) {
    val options = listOf("おサイフケータイ", "防水", "eSIM", "指紋認証", "ワイヤレス充電", "microSD", "イヤホンジャック")
    Column(Modifier.fillMaxSize().padding(24.dp)) {
        Text("必須条件", style = MaterialTheme.typography.labelLarge)
        Spacer(Modifier.height(12.dp))
        Text("絶対に欲しい機能はありますか？", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(8.dp))
        Text("選んだ条件を満たさない端末は候補から外します。")
        Spacer(Modifier.height(20.dp))
        options.forEach { option ->
            Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = option in selected, onCheckedChange = { onToggle(option) })
                    Text(option, Modifier.padding(start = 8.dp))
                }
            }
        }
        Spacer(Modifier.weight(1f))
        Row(Modifier.fillMaxWidth(), Arrangement.spacedBy(12.dp)) {
            OutlinedButton(onBack, Modifier.weight(1f)) { Text("← 戻る") }
            Button(onNext, Modifier.weight(1f)) { Text("次へ →") }
        }
    }
}

@Composable
private fun ConfirmScreen(os: String, budget: String, use: String, mustHave: List<String>, summary: List<String>, onBack: () -> Unit, onRun: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(24.dp)) {
        Text("入力内容の確認", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(20.dp))
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(20.dp)) {
                Text("OS：$os")
                Text("予算：$budget")
                Text("主な用途：$use")
                Text("必須条件：${mustHave.ifEmpty { listOf("なし") }.joinToString("、")}")
                summary.forEach { Text(it, style = MaterialTheme.typography.bodySmall) }
            }
        }
        Spacer(Modifier.weight(1f))
        Row(Modifier.fillMaxWidth(), Arrangement.spacedBy(12.dp)) {
            OutlinedButton(onBack, Modifier.weight(1f)) { Text("← 戻る") }
            Button(onRun, Modifier.weight(1f)) { Text("診断を開始する") }
        }
    }
}

private fun featureFromLabel(label: String): MustHaveFeature? = when (label) {
    "おサイフケータイ" -> MustHaveFeature.OSAIFU_KEITAI
    "防水" -> MustHaveFeature.WATERPROOF
    "eSIM" -> MustHaveFeature.ESIM
    "指紋認証" -> MustHaveFeature.FINGERPRINT
    "ワイヤレス充電" -> MustHaveFeature.WIRELESS_CHARGING
    "microSD" -> MustHaveFeature.MICRO_SD
    "イヤホンジャック" -> MustHaveFeature.HEADPHONE_JACK
    else -> null
}

@Composable
private fun SmartphoneDetailScreen(
    detail: PhoneDetailRow?,
    recommendation: RecommendationResult?,
    purchaseOptions: List<PurchaseOptionRow>,
    dataConflicts: List<DataConflictEntity>,
    isFavorite: Boolean,
    onToggleFavorite: (Long) -> Unit,
    onOpenPurchase: (String) -> Unit,
    onBack: () -> Unit
) {
    Column(Modifier.fillMaxSize()) {
        TopAppBar(
            title = { Text(detail?.modelName ?: "スマホ詳細") },
            navigationIcon = {
                TextButton(onClick = onBack) { Text("← 戻る") }
            }
        )
        if (detail == null) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
            return@Column
        }
        Column(
            Modifier.fillMaxSize().padding(horizontal = 20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            androidx.compose.foundation.lazy.LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(bottom = 28.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    DetailHeaderCard(detail)
                    recommendation?.let {
                        Spacer(Modifier.height(10.dp))
                        RecommendationRelationCard(it)
                    }
                    Spacer(Modifier.height(8.dp))
                    OutlinedButton(onClick = { onToggleFavorite(detail.deviceVariantId) }, modifier = Modifier.fillMaxWidth()) {
                        Text(if (isFavorite) "★ お気に入りから外す" else "☆ お気に入りに追加")
                    }
                }
                item {
                    DetailSectionCard("価格・購入先") {
                        DetailRow("通常価格", detail.normalPriceYen?.let { "¥%,d".format(it) } ?: "未確認")
                        if (purchaseOptions.isEmpty()) {
                            Text("現在、登録済みの購入先はありません。", style = MaterialTheme.typography.bodySmall)
                        } else {
                            purchaseOptions.forEach { option ->
                                Spacer(Modifier.height(6.dp))
                                Text(option.retailerName, style = MaterialTheme.typography.titleSmall)
                                Text(if (option.official) "メーカー公式販売" else "販売店")
                                Text(when (option.availability) {
                                    "AVAILABLE" -> "販売状態：販売確認済み"
                                    "LIMITED" -> "販売状態：販売数・在庫に制限あり"
                                    "OUT_OF_STOCK" -> "販売状態：在庫切れ"
                                    "PREORDER" -> "販売状態：予約受付"
                                    "DISCONTINUED" -> "販売状態：販売終了"
                                    else -> "販売状態：未確認"
                                }, style = MaterialTheme.typography.bodySmall)
                                if (!option.priceColor.isNullOrBlank()) Text("カラー：${option.priceColor}", style = MaterialTheme.typography.titleSmall)
                                val priceLabel = when (option.priceType) {
                                    "NORMAL" -> "通常価格"
                                    "SALE" -> "セール価格"
                                    "CAMPAIGN" -> "キャンペーン価格"
                                    "MNP" -> "MNP条件付き価格"
                                    "NEW_CONTRACT" -> "新規契約条件付き価格"
                                    "MODEL_CHANGE" -> "機種変更条件付き価格"
                                    "CONTRACT_REQUIRED" -> "契約条件付き価格"
                                    else -> "価格"
                                }
                                Text(option.priceYen?.let { "$priceLabel：¥%,d".format(it) } ?: "$priceLabel：未確認")
                                if (option.pointsValueYen != null) Text("ポイント：¥%,d相当".format(option.pointsValueYen))
                                if (option.couponValueYen != null) Text("クーポン：¥%,d相当".format(option.couponValueYen))
                                if (option.tradeInValueYen != null) Text("下取り：最大¥%,d".format(option.tradeInValueYen))
                                if (!option.priceConditions.isNullOrBlank()) Text(option.priceConditions!!, style = MaterialTheme.typography.bodySmall)
                                Text("確認：${option.checkedAt?.let { java.text.SimpleDateFormat("yyyy/MM/dd", java.util.Locale.JAPAN).format(java.util.Date(it)) } ?: "未確認"}", style = MaterialTheme.typography.bodySmall)
                                val safePriceSourceUrl = option.priceSourceUrl?.let(::safeExternalWebUri)
                                if (safePriceSourceUrl != null) {
                                    Text("価格出典サイト：${safePriceSourceUrl.host}", style = MaterialTheme.typography.bodySmall)
                                    OutlinedButton(onClick = { onOpenPurchase(safePriceSourceUrl.toString()) }, modifier = Modifier.fillMaxWidth()) {
                                        Text("価格の出典を開く")
                                    }
                                }
                                val safeProductUrl = option.productUrl?.let(::safeExternalWebUri)
                                if (safeProductUrl != null) {
                                    val isGeneralListing = isGeneralSalesListingUrl(safeProductUrl.toString())
                                    OutlinedButton(onClick = { onOpenPurchase(safeProductUrl.toString()) }, modifier = Modifier.fillMaxWidth()) {
                                        Text(if (isGeneralListing) "販売機種一覧を開く" else "販売ページを開く")
                                    }
                                    if (isGeneralListing) {
                                        Text("移動先で機種・容量・在庫を確認してください。", style = MaterialTheme.typography.bodySmall)
                                    }
                                } else {
                                    Text("販売ページURL：未登録または無効", style = MaterialTheme.typography.bodySmall)
                                }
                            }
                        }
                        Text("※ 通常価格・セール・MNP・契約条件付き価格は別々に管理し、条件付き価格を一般的な最安値として扱いません。", style = MaterialTheme.typography.bodySmall)
                    }
                }
                if (dataConflicts.isNotEmpty()) {
                    item {
                        DetailSectionCard("情報の食い違い") {
                            Text(
                                "複数の情報源で内容が一致していない項目です。どちらかを勝手に正しいと決めず、確認が必要な情報として表示しています。",
                                style = MaterialTheme.typography.bodySmall
                            )
                            dataConflicts.forEach { conflict ->
                                Spacer(Modifier.height(8.dp))
                                Text(conflict.fieldLabel, style = MaterialTheme.typography.titleSmall)
                                Text("値：${conflict.valuesSummary}")
                                Text("情報源：${conflict.sourcesSummary}", style = MaterialTheme.typography.bodySmall)
                                Text("状態：${when (conflict.severity) { ConflictSeverity.CRITICAL -> "重要"; ConflictSeverity.WARNING -> "要確認"; ConflictSeverity.INFO -> "確認推奨" }}", style = MaterialTheme.typography.bodySmall)
                                Text("検出日：${java.text.SimpleDateFormat("yyyy/MM/dd", java.util.Locale.JAPAN).format(java.util.Date(conflict.detectedAt))}", style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
                item {
                    DetailSectionCard("基本スペック") {
                        DetailRow("OS", detail.platform)
                        DetailRow("発売年", detail.releaseYear.toString())
                        DetailRow("シリーズ", detail.seriesName ?: "未登録")
                        DetailRow("RAM", detail.ramGb?.let { "${it}GB" } ?: "未確認")
                        DetailRow("ストレージ", "${detail.storageGb}GB")
                    }
                }
                item {
                    DetailSectionCard("用途別の適性") {
                        DetailRow("普段使い", detail.generalLevel.label())
                        DetailRow("ゲーム", detail.gamingLevel.label())
                        DetailRow("カメラ", detail.cameraLevel.label())
                        DetailRow("動画", detail.videoLevel.label())
                        DetailRow("仕事・学習", detail.workStudyLevel.label())
                        DetailRow("AI", detail.aiLevel.label())
                        DetailRow("バッテリー適性", detail.batterySuitability.label())
                        DetailRow("持ち運び", detail.portabilityLevel.label())
                        DetailRow("長期利用", detail.longTermSupportLevel.label())
                    }
                }
                item {
                    DetailSectionCard("機能") {
                        DetailSupportRow("おサイフケータイ", detail.osaifuKeitai)
                        DetailSupportRow("防水", detail.waterproof)
                        DetailSupportRow("eSIM", detail.esim)
                        DetailSupportRow("指紋認証", detail.fingerprint)
                        DetailSupportRow("ワイヤレス充電", detail.wirelessCharging)
                        DetailSupportRow("microSD", detail.microSd)
                        DetailSupportRow("イヤホンジャック", detail.headphoneJack)
                    }
                }
                item {
                    DetailSectionCard("本体サイズ・重量") {
                        DetailRow("高さ", detail.bodyHeightMm?.formatMm() ?: "未確認")
                        DetailRow("幅", detail.bodyWidthMm?.formatMm() ?: "未確認")
                        DetailRow("厚さ", detail.bodyThicknessMm?.formatMm() ?: "未確認")
                        DetailRow("重量", detail.weightG?.formatG() ?: "未確認")
                        Text("サイズはmm、重量はgを基本表示にします。", style = MaterialTheme.typography.bodySmall)
                    }
                }
                item {
                    DetailSectionCard("ディスプレイ") {
                        DetailRow("画面高さ", detail.displayHeightMm?.formatMm() ?: "未確認")
                        DetailRow("画面幅", detail.displayWidthMm?.formatMm() ?: "未確認")
                        DetailRow("対角", detail.displayDiagonalInch?.let { "%.2fインチ".format(it) } ?: "未確認")
                        DetailRow("解像度", detail.displayResolutionText ?: "未確認")
                        DetailRow("パネル", detail.displayPanelType ?: "未確認")
                        DetailRow("リフレッシュレート", detail.displayRefreshRateHz?.let { "${it}Hz" } ?: "未確認")
                    }
                }
                item {
                    DetailSectionCard("カメラ") {
                        DetailRow("メイン", detail.rearMainMp?.formatMp() ?: "未確認")
                        DetailRow("超広角", detail.rearUltraWideMp?.formatMp() ?: "未確認")
                        DetailRow("望遠", detail.rearTelephotoMp?.formatMp() ?: "未確認")
                        DetailRow("前面", detail.frontMp?.formatMp() ?: "未確認")
                        DetailRow("動画", detail.videoMaxText ?: "未確認")
                        DetailRow("手ぶれ補正", detail.stabilizationText ?: "未確認")
                        Text("カメラは画素数だけでなく、用途別適性・望遠・夜景・動体・動画などを別評価します。", style = MaterialTheme.typography.bodySmall)
                    }
                }
                item {
                    DetailSectionCard("バッテリー・充電") {
                        DetailRow("容量", detail.batteryCapacityMah?.let { "${it}mAh" } ?: "未確認")
                        DetailRow("充電出力", detail.chargingPowerW?.let { "最大${it}W" } ?: "未確認")
                        DetailSupportRow("ワイヤレス充電", detail.batteryWirelessCharging)
                        DetailRow("メーカー公称", detail.batteryManufacturerClaim ?: "未確認")
                        DetailRow("実測テスト", detail.batteryRealWorldTestHours?.let { "${it}時間" } ?: "未確認")
                        Text("容量・メーカー公称・実測値は混ぜずに別々に扱います。", style = MaterialTheme.typography.bodySmall)
                    }
                }
                item {
                    DetailSectionCard("通信・SIM") {
                        DetailSupportRow("5G", detail.fiveG)
                        DetailRow("SIM", detail.simCount?.let { "${it}枚" } ?: "未確認")
                        DetailSupportRow("eSIM", detail.connectivityEsim)
                        DetailRow("Wi-Fi", detail.wifiText ?: "未確認")
                        DetailRow("Bluetooth", detail.bluetoothText ?: "未確認")
                    }
                }
                item {
                    DetailSectionCard("OS・アップデート") {
                        DetailRow("OS", detail.osVersion ?: detail.platform)
                        DetailRow("更新サポート", detail.updateSupportYears?.let { "約${it}年" } ?: "未確認")
                        DetailRow("セキュリティ更新", detail.securitySupportUntil ?: "未確認")
                    }
                }
                item {
                    DetailSectionCard("データについて") {
                        Text("未確認の項目は、推測で埋めません。公式情報や信頼できる測定結果を確認したうえで登録します。", style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        }
    }
}

@Composable
private fun DetailHeaderCard(detail: PhoneDetailRow) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(20.dp)) {
            Text(detail.manufacturerName, style = MaterialTheme.typography.labelLarge)
            Spacer(Modifier.height(4.dp))
            Text(detail.modelName, style = MaterialTheme.typography.headlineSmall)
            Spacer(Modifier.height(8.dp))
            Text("${detail.storageGb}GB${detail.ramGb?.let { " / RAM ${it}GB" } ?: ""}")
            Text("日本公式モデル", style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun RecommendationRelationCard(result: RecommendationResult) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Text("今回の診断との関係", style = MaterialTheme.typography.titleMedium)
            Text("データに基づく適合度: ${result.confidence.label()}", style = MaterialTheme.typography.labelLarge)
            result.reasons.take(5).forEach { Text("✓ $it", style = MaterialTheme.typography.bodyMedium) }
            if (result.cautions.isNotEmpty()) {
                Spacer(Modifier.height(3.dp))
                Text("確認しておきたい点", style = MaterialTheme.typography.labelMedium)
                result.cautions.take(5).forEach { Text("・$it", style = MaterialTheme.typography.bodySmall) }
            }
            Text("この説明は今回の診断条件と登録済みデータの組み合わせによるもので、スペックの単純な大小だけで決めていません。", style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun DetailSectionCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            HorizontalDivider()
            content()
        }
    }
}

@Composable
private fun DetailRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, style = MaterialTheme.typography.bodyMedium)
        Text(value, style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
private fun DetailSupportRow(label: String, status: SupportStatus?) {
    DetailRow(label, status.label())
}

private fun Double.formatMm(): String = "%.1f mm".format(this)
private fun Double.formatG(): String = "%.0f g".format(this)
private fun Double.formatMp(): String = "%.1fMP".format(this)

private fun SupportStatus?.label(): String = when (this) {
    SupportStatus.SUPPORTED -> "対応"
    SupportStatus.NOT_SUPPORTED -> "非対応"
    SupportStatus.UNKNOWN, null -> "未確認"
}

private fun AttributeLevel?.label(): String = when (this) {
    AttributeLevel.EXCELLENT -> "とても得意"
    AttributeLevel.GOOD -> "得意"
    AttributeLevel.STANDARD -> "標準"
    AttributeLevel.WEAK -> "やや苦手"
    AttributeLevel.UNKNOWN, null -> "未確認"
}

@Composable
private fun ComparisonScreen(
    items: List<ComparisonRow>,
    comparisonPrices: List<ComparisonPriceRow>,
    comparisonIds: List<Long>,
    primaryUse: PrimaryUse?,
    budgetMaxYen: Int?,
    mustHave: List<String>,
    recommendationByDeviceId: Map<Long, RecommendationResult>,
    onRemove: (Long) -> Unit,
    onBack: () -> Unit
) {
    var differentOnly by rememberSaveable { mutableStateOf(false) }
    var prioritizeConditions by rememberSaveable { mutableStateOf(false) }
    val orderedItems = if (prioritizeConditions) {
        items.sortedWith(compareByDescending<ComparisonRow> {
            comparisonConditionFit(it, primaryUse, budgetMaxYen, mustHave, comparisonPriceYen(it, comparisonPrices))
        }.thenBy { comparisonPriceYen(it, comparisonPrices) ?: Int.MAX_VALUE })
    } else items
    val rows: List<Pair<String, (ComparisonRow) -> String>> = listOf(
        "通常価格（販売先・色別）" to { item ->
            val normal = comparisonPrices.filter { it.deviceVariantId == item.deviceVariantId && it.priceType == "NORMAL" }
            if (normal.isNotEmpty()) normal.take(4).joinToString("\n") { option ->
                val color = option.color?.takeIf { it.isNotBlank() }?.let { "$it：" } ?: ""
                val official = if (option.official) "公式" else option.retailerName
                "$color${"¥%,d".format(option.priceYen)}（$official）"
            } else "新価格情報：未登録\n参考・旧価格データ：${item.normalPriceYen?.let { "¥%,d".format(it) } ?: "未確認"}"
        },
        "条件付き価格（通常価格と別）" to { item ->
            comparisonPrices.filter { it.deviceVariantId == item.deviceVariantId && it.priceType != "NORMAL" }
                .take(4).joinToString("\n") { option ->
                    val color = option.color?.takeIf { it.isNotBlank() }?.let { "$it・" } ?: ""
                    val conditions = option.conditions?.takeIf { it.isNotBlank() }?.let { "（$it）" } ?: ""
                    "$color${priceTypeLabelJa(option.priceType)}：${"¥%,d".format(option.priceYen)}$conditions"
                }.ifBlank { "登録なし" }
        },
        "重量" to { item -> item.weightG?.let { "%.0fg".format(it) } ?: "未確認" },
        "本体サイズ" to { item ->
            if (item.bodyHeightMm != null && item.bodyWidthMm != null && item.bodyThicknessMm != null) "%.1f × %.1f × %.1f mm".format(item.bodyHeightMm, item.bodyWidthMm, item.bodyThicknessMm) else "未確認"
        },
        "画面" to { item -> item.displayDiagonalInch?.let { "%.1fインチ".format(it) } ?: "未確認" },
        "解像度" to { item -> item.displayResolutionText ?: "未確認" },
        "リフレッシュレート" to { item -> item.displayRefreshRateHz?.let { "${it}Hz" } ?: "未確認" },
        "RAM" to { item -> item.ramGb?.let { "${it}GB" } ?: "未確認" },
        "ストレージ" to { item -> "${item.storageGb}GB" },
        "メインカメラ" to { item -> item.rearMainMp?.let { "${it.removeTrailingZero()}MP" } ?: "未確認" },
        "超広角" to { item -> item.rearUltraWideMp?.let { "${it.removeTrailingZero()}MP" } ?: "未確認" },
        "望遠" to { item -> item.rearTelephotoMp?.let { "${it.removeTrailingZero()}MP" } ?: "未確認" },
        "バッテリー" to { item -> item.batteryCapacityMah?.let { "${it}mAh" } ?: "未確認" },
        "充電" to { item -> item.chargingPowerW?.let { "最大${it}W" } ?: "未確認" },
        "ワイヤレス充電" to { item -> item.batteryWirelessCharging.label() },
        "OS更新サポート" to { item -> item.updateSupportYears?.let { "${it}年" } ?: "未確認" },
        "おサイフケータイ" to { item -> item.osaifuKeitai.label() },
        "防水" to { item -> item.waterproof.label() },
        "eSIM" to { item -> item.esim.label() },
        "microSD" to { item -> item.microSd.label() },
        "イヤホンジャック" to { item -> item.headphoneJack.label() }
    )
    val visibleRows = if (differentOnly) rows.filter { row -> items.map(row.second).distinct().size > 1 } else rows
    Column(Modifier.fillMaxSize()) {
        TopAppBar(
            title = { Text("スマホ比較") },
            navigationIcon = { TextButton(onClick = onBack) { Text("← 戻る") } }
        )
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp, 8.dp, 16.dp, 32.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                Text("2〜5台を横並びで比較できます。数値が大きいほど良いとは限りません。", style = MaterialTheme.typography.bodyMedium)
                if (prioritizeConditions) {
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "診断条件を優先して並べています。これは比較の見やすさを変えるだけで、必須条件を勝手に変更するものではありません。",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = differentOnly, onClick = { differentOnly = !differentOnly }, label = { Text("違う項目だけ") })
                    FilterChip(selected = prioritizeConditions, onClick = { prioritizeConditions = !prioritizeConditions }, label = { Text("条件を優先") })
                }
            }
            item {
                val explained = orderedItems.mapNotNull { item -> recommendationByDeviceId[item.deviceVariantId] }
                if (explained.isNotEmpty()) {
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("今回の診断との関係", style = MaterialTheme.typography.titleSmall)
                            explained.forEach { result ->
                                val reasons = result.reasons.take(2)
                                val cautions = result.cautions.take(1)
                                Text("${result.phone.modelName}: ${result.confidence.label()}", style = MaterialTheme.typography.labelLarge)
                                reasons.forEach { Text("✓ $it", style = MaterialTheme.typography.bodySmall) }
                                cautions.forEach { Text("・$it", style = MaterialTheme.typography.bodySmall) }
                            }
                        }
                    }
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    orderedItems.forEach { item ->
                        Card(Modifier.weight(1f)) {
                            Column(Modifier.padding(10.dp)) {
                                Text(item.modelName, style = MaterialTheme.typography.titleSmall)
                                Text(item.manufacturerName, style = MaterialTheme.typography.bodySmall)
                                Text("${item.storageGb}GB", style = MaterialTheme.typography.bodySmall)
                                TextButton(onClick = { onRemove(item.deviceVariantId) }) { Text("外す") }
                            }
                        }
                    }
                }
            }
            items(visibleRows) { row ->
                val label = row.first
                val values = orderedItems.map(row.second)
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp)) {
                        Text(label, style = MaterialTheme.typography.labelLarge)
                        Spacer(Modifier.height(6.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            values.forEach { value ->
                                Text(value, modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
                            }
                        }
                    }
                }
            }
        }
    }
}

private fun priceTypeLabelJa(priceType: String): String = when (priceType) {
    "NORMAL" -> "通常価格"
    "SALE" -> "セール"
    "CAMPAIGN" -> "キャンペーン"
    "MNP" -> "乗り換え条件"
    "NEW_CONTRACT" -> "新規契約条件"
    "MODEL_CHANGE" -> "機種変更条件"
    "CONTRACT_REQUIRED" -> "契約必須価格"
    else -> "条件要確認"
}

private fun comparisonPriceYen(item: ComparisonRow, prices: List<ComparisonPriceRow>): Int? {
    val normal = prices.filter { it.deviceVariantId == item.deviceVariantId && it.priceType == "NORMAL" }
    // Prefer a listed official normal price; if none exists, use the lowest linked normal listing.
    return (normal.filter { it.official }.ifEmpty { normal }).minOfOrNull { it.priceYen }
}

private fun comparisonConditionFit(
    item: ComparisonRow,
    primaryUse: PrimaryUse?,
    budgetMaxYen: Int?,
    mustHave: List<String>,
    normalPriceYen: Int?
): Int {
    var fit = 0
    val price = normalPriceYen
    if (budgetMaxYen != null && price != null && price <= budgetMaxYen) fit += 2
    if (budgetMaxYen != null && price == null) fit -= 1
    when (primaryUse) {
        PrimaryUse.GAMING -> {
            if ((item.ramGb ?: 0) >= 12) fit += 2
            if ((item.displayRefreshRateHz ?: 0) >= 120) fit += 2
            if ((item.batteryCapacityMah ?: 0) >= 5000) fit += 1
        }
        PrimaryUse.CAMERA -> {
            if (item.rearTelephotoMp != null) fit += 2
            if (item.rearUltraWideMp != null) fit += 1
        }
        PrimaryUse.VIDEO, PrimaryUse.VIDEO_EDITING -> {
            if ((item.ramGb ?: 0) >= 12) fit += 2
            if ((item.batteryCapacityMah ?: 0) >= 5000) fit += 1
            if ((item.displayRefreshRateHz ?: 0) >= 120) fit += 1
        }
        PrimaryUse.WORK, PrimaryUse.AI -> {
            if ((item.ramGb ?: 0) >= 12) fit += 2
            if ((item.storageGb) >= 256) fit += 1
        }
        PrimaryUse.GENERAL, PrimaryUse.SNS, PrimaryUse.CALLS, PrimaryUse.MUSIC, PrimaryUse.EBOOK, PrimaryUse.OTHER, null -> {
            if ((item.batteryCapacityMah ?: 0) >= 5000) fit += 1
            if ((item.weightG ?: 999.0) <= 200.0) fit += 1
        }
    }
    mustHave.forEach { feature ->
        val supported = when (feature) {
            "おサイフケータイ" -> item.osaifuKeitai == SupportStatus.SUPPORTED
            "防水" -> item.waterproof == SupportStatus.SUPPORTED
            "eSIM" -> item.esim == SupportStatus.SUPPORTED
            "microSD" -> item.microSd == SupportStatus.SUPPORTED
            "イヤホンジャック" -> item.headphoneJack == SupportStatus.SUPPORTED
            "ワイヤレス充電" -> item.batteryWirelessCharging == SupportStatus.SUPPORTED
            else -> false
        }
        if (supported) fit += 3
    }
    return fit
}

private fun Double.removeTrailingZero(): String = if (this % 1.0 == 0.0) this.toInt().toString() else this.toString()

private fun jp.smartphoneadvisor.app.data.SupportStatus?.label(): String = when (this) {
    jp.smartphoneadvisor.app.data.SupportStatus.SUPPORTED -> "対応"
    jp.smartphoneadvisor.app.data.SupportStatus.NOT_SUPPORTED -> "非対応"
    else -> "未確認"
}

@Composable
private fun ResultScreen(
    os: String,
    budget: String,
    use: String,
    recommendations: List<RecommendationResult>,
    prioritySummary: List<String>,
    onSave: () -> Unit,
    saveMessage: String?,
    onOpenDetail: (Long) -> Unit,
    onAddCompare: (Long) -> Unit,
    comparisonCount: Int,
    onOpenCompare: () -> Unit,
    onRestart: () -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(24.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("診断結果", style = MaterialTheme.typography.headlineMedium)
            Spacer(Modifier.height(6.dp))
            Text("必須条件を先に確認し、そのうえで予算・用途・希望条件との相性を見ています。")
        }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(18.dp)) {
                    Text("今回の条件", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(8.dp))
                    Text("OS：$os")
                    Text("予算：$budget")
                    Text("主な用途：$use")
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "必須条件は候補から除外、希望条件は相性に反映しています。データが未確認の項目は対応済みとは扱いません。",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }
        if (prioritySummary.isNotEmpty()) {
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("推薦の優先順位", style = MaterialTheme.typography.titleMedium)
                        Text("必須条件は候補から除外し、それ以外は用途との相性を中心に調整しています。", style = MaterialTheme.typography.bodySmall)
                        prioritySummary.forEach { Text("・$it", style = MaterialTheme.typography.bodyMedium) }
                    }
                }
            }
        }
        item {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("おすすめ候補", style = MaterialTheme.typography.titleMedium)
                Text("比較 ${comparisonCount}/5", style = MaterialTheme.typography.labelLarge)
            }
            if (comparisonCount >= 2) {
                Spacer(Modifier.height(8.dp))
                Button(onClick = onOpenCompare, modifier = Modifier.fillMaxWidth()) {
                    Text("選んだスマホを比較する")
                }
            }
        }
        if (recommendations.isEmpty()) {
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(18.dp)) {
                        Text("現在のデータでは条件を満たす候補がありません。", style = MaterialTheme.typography.titleMedium)
                        Spacer(Modifier.height(6.dp))
                        Text("条件を勝手に緩めず、どの条件で候補がなくなったかを表示します。")
                        if (noCandidateExplanation.isNotEmpty()) {
                            Spacer(Modifier.height(12.dp))
                            Text("候補がなくなった理由", style = MaterialTheme.typography.titleSmall)
                            Spacer(Modifier.height(6.dp))
                            noCandidateExplanation.distinct().forEach { reason ->
                                Text("・$reason")
                            }
                        }
                    }
                }
            }
        } else {
            items(recommendations, key = { it.phone.deviceVariantId }) { recommendation ->
                val phone = recommendation.phone
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(18.dp)) {
                        Row(
                            Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.Top
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text(phone.modelName, style = MaterialTheme.typography.titleLarge)
                                Text("${phone.manufacturerName} / ${phone.storageGb}GB")
                            }
                            AssistChip(
                                onClick = {},
                                label = { Text(recommendation.confidence.label()) }
                            )
                        }
                        Spacer(Modifier.height(8.dp))
                        Text(
                            phone.normalPriceYen?.let { "通常価格データ：¥%,d".format(it) } ?: "価格データ：未確認",
                            style = MaterialTheme.typography.titleMedium
                        )
                        Spacer(Modifier.height(12.dp))
                        Text("あなたに合う理由", style = MaterialTheme.typography.labelLarge)
                        Spacer(Modifier.height(4.dp))
                        if (recommendation.reasons.isEmpty()) {
                            Text("現在確認できる条件からの明確な一致はありません。", style = MaterialTheme.typography.bodySmall)
                        } else {
                            recommendation.reasons.take(5).forEach { reason ->
                                Text("✓ $reason", style = MaterialTheme.typography.bodyMedium)
                            }
                        }
                        if (recommendation.cautions.isNotEmpty()) {
                            Spacer(Modifier.height(10.dp))
                            Text("確認しておきたい点", style = MaterialTheme.typography.labelLarge)
                            Spacer(Modifier.height(4.dp))
                            recommendation.cautions.take(5).forEach { caution ->
                                Text("・$caution", style = MaterialTheme.typography.bodyMedium)
                            }
                        }
                        Spacer(Modifier.height(12.dp))
                        OutlinedButton(
                            onClick = { onOpenDetail(phone.deviceVariantId) },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("このスマホの詳細を見る") }
                        Spacer(Modifier.height(6.dp))
                        OutlinedButton(
                            onClick = { onAddCompare(phone.deviceVariantId) },
                            enabled = phone.deviceVariantId !in emptyList<Long>() && comparisonCount < 5,
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("比較に追加") }
                    }
                }
            }
        }
        item {
            Spacer(Modifier.height(4.dp))
            OutlinedButton(onClick = onSave, modifier = Modifier.fillMaxWidth()) { Text("この診断を保存") }
            if (saveMessage != null) {
                Spacer(Modifier.height(6.dp))
                Text(saveMessage, style = MaterialTheme.typography.bodySmall)
            }
            Spacer(Modifier.height(4.dp))
            Button(onClick = onRestart, modifier = Modifier.fillMaxWidth()) { Text("診断をもう一度行う") }
        }
    }
}


/** Maps the questionnaire's Japanese purchase-channel labels to SalesChannel enum values stored in Room. */
private fun String.toSalesChannelDbValue(): String = when (this) {
    "SIMフリー" -> "SIM_FREE"
    "docomo" -> "DOCOMO"
    "au" -> "AU"
    "SoftBank" -> "SOFTBANK"
    "楽天モバイル" -> "RAKUTEN"
    "UQ mobile" -> "UQ_MOBILE"
    "Y!mobile" -> "Y_MOBILE"
    "IIJmio" -> "IIJ_MIO"
    "mineo" -> "MINEO"
    "MVNO" -> "MVNO"
    else -> ""
}
