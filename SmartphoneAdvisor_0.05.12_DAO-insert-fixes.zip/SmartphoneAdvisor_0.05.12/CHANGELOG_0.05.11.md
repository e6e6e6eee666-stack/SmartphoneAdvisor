# SmartphoneAdvisor 0.05.11

- App versionName `0.05.11` / versionCode `159`.
- Fixed Material 3 experimental API opt-in annotations for screens using `TopAppBar`.
- Removed the duplicate `SupportStatus?.label()` extension that caused overload ambiguity.
- Passed `noCandidateExplanation` into `ResultScreen`, fixing the unresolved reference.
- Updated the bundled GitHub Actions workflow to select the highest plain `SmartphoneAdvisor_X.Y.Z.zip` automatically and name reports from the app version, avoiding a hardcoded ZIP filename.
- Preserved catalog data and unrelated application behavior.
