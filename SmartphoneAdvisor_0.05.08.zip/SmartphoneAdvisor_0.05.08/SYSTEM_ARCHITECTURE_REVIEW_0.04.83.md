# SmartphoneAdvisor システム見直し 0.04.83

## 対象と方法
- 対象: 0.04.82 ZIPの実ソース一式、Gradle設定、Roomスキーマ、カタログローダー/Importer、起動処理、テストと作業記録。
- 検査: ソース構造確認、Pythonソース契約テスト、ZIP/ビルド構成の存在確認。Android Gradleビルドは環境にGradle/Wrapper/Android SDKがなく未実施。

## 発見した問題と修正

### A-01 起動初期化の例外が画面に伝わらない — 修正
`phones.json` 読込とJSON→Room取込は個別に処理されていた一方、`AppDatabase.getInstance()` や `SeedData.ensureSeeded()` が失敗すると、`dbReady` がfalseのまま画面側に明示的なエラーを表示できない経路があった。

**修正:** 起動初期化全体を `runCatching` で包み、ログと日本語のエラーダイアログを表示する。初期化の再試行ボタンを追加し、失敗時は `dbReady=false` を維持する。カタログ読み込み失敗は既存Seed/Roomで継続、DB/Seed初期化自体の失敗は再試行可能なブロッキングエラーとして区別する。

### A-02 検証の「合格」が実ビルドを意味しない — 未解消のリリース阻害要因
ZIP検査/PythonテストはKotlinコンパイル、KSP、Room実DB、Compose画面、端末操作を証明しない。最新版にGradle Wrapperが含まれず、Android instrumentation testも存在しない。

**対策:** 統合ゲートはこれらを`BLOCKER`として明示し、静的検査合格とリリース準備完了を混同しない。Wrapperをこの環境で生成・検証できなかったため、偽のWrapperファイルは作成しない。

### A-03 検証方法が多数の履歴ファイルに分散 — 一部改善
履歴を消さずに保持する一方、現行版に必要な最低限のソース・記録・Room migration chain・起動エラー処理を確認する `tools/system_integrity_gate.py` を追加。バージョンはGradle設定から読み取るため、現行版番号をゲート内に重複ハードコードしない。

### A-04 版番号固定テストの保守負担 — 修正
32本のPythonテスト/監査スクリプトが `0.04.82 / versionCode 130` を文字列固定しており、バージョン更新だけで偽失敗する状態だった。

**修正:** 共通の `tools/current_version.py` を追加し、現行版を確認するガードはGradle設定から版番号・コードを読み取るよう変更。過去のモデル価格・販売履歴などの期待値は固定したまま、アプリ版番号だけを動的に判定する。`tools/run_current_regression_suite.py` と `tools/current_regression_manifest.json` を追加し、現在の回帰テストを一つの入口で実行可能にした。現行版名に一致するテストは自動検出して実行対象へ加える。

## 確認できた設計上の安全策
- カタログ取込前にモデル/バリアント/販売情報/価格根拠を検証。
- JSON→Room importは `db.withTransaction` 内で実行。
- 同一候補が複数ある場合に推測で紐付けず、競合として保持。
- 既存販売情報・価格情報を無条件に上書きしない方針。
- 価格には確認日とHTTPS根拠URLを要求。
- Roomスキーマのマイグレーションを連続的に管理。

## 未確認・次の修正対象
1. Gradle Wrapperを正規手順で追加し、再現可能なビルドを確立する。
2. Android instrumentation testを追加し、Room import件数・重複・価格保持・migrationを実DBで検証する。
3. 実機/エミュレーターで診断、検索、詳細、比較、お気に入り、保存診断を試験する。
4. UIの各DB操作も失敗時に無応答/クラッシュしないか確認する。今回の修正は起動時初期化に限定。
5. 価格未登録の販売情報を根拠付きで補完する。

## 回帰検証
- 共通回帰ランナーで46テストを4バッチに分けて実行し、46/46合格。結果は `test_results_0.04.83.txt` に集約。
- `python -m compileall -q tools` 合格。
- 統合ゲートは静的検査を通過したが、Gradle Wrapperとinstrumentation testの不足により終了コード2（ブロッカーあり）。

## リリース判定
**静的検査の一部は合格。ただしリリース可能とは判定しない。** Gradle Wrapper不在とinstrumentation test不在がブロッカーで、Androidビルド・実行は未検証。
