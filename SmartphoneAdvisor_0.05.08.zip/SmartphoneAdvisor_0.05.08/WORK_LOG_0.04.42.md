# WORK LOG 0.04.42 — 価格履歴の同時刻重複を診断・一覧クエリまで統一

## 1. 目的・完了条件
同一販売掲載先・価格種別・色で確認時刻が同一の価格履歴が複数ある場合に、比較・購入先一覧だけでなく、診断/推薦候補の価格取得でも複数行や不安定な選択が発生しないようにする。

## 2. 実施内容
- `PhoneDao.kt` の診断/推薦・一覧用価格取得に残っていた `MAX(checkedAt)`との日時一致条件を、`checkedAt DESC, id DESC LIMIT 1` で決まる単一レコードIDとの一致に変更。
- 同時刻・同価格の掲載候補が並ぶ場合の選択順も `id DESC` を追加して安定化。
- 0.04.41で導入済みの比較価格・購入先一覧の選択規則と合わせた。
- `tools/test_price_history_determinism_0_04_42.py` を追加し、DAOから抽出した購入先SQLをSQLiteで実行する回帰テストを追加。
- 既存の推薦価格SQLiteテストに同時刻・同色・同価格種別の重複履歴を追加し、最大IDの行が選ばれることを確認。
- `versionName=0.04.42`、`versionCode=91` に更新。

## 3. 検証結果
- PASS: `tools/test_recommendation_price_v2_0_04_39.py`
- PASS: `tools/test_price_history_determinism_0_04_42.py`
- PASS: `tools/test_comparison_color_prices_0_04_38.py`
- PASS: 既存SQLite migrationテスト 0.04.35 / 0.04.37
- PASS: Python tools compileall
- PASS: 編集対象KotlinのSQL文字列区切りと決定的選択条件の静的検査
- NOT RUN: Android Gradle/KSPビルド、JUnit実行、Roomコンパイル検査、Android実機/エミュレータ操作。

## 4. 問題・未確認事項
- この環境にはシステムGradleとGradle Wrapperがなく、Androidビルドは実行できていない。JDK 21は存在するが、これだけではビルド成功を意味しない。
- 診断/推薦画面の表示モデル `PhoneListRow` は単一価格を保持する。購入チャネル指定時の価格選択を診断・推薦結果の表示まで一貫して伝える作業は未完了。
- `README.md` の先頭は旧版の履歴見出しを保持しているため、最新版の根拠は `app/build.gradle.kts`、本作業ログ、検証記録を参照する。

## 5. 進捗位置
主工程：大項目3「データ登録システム」。今回対象：大項目4「診断」・5「推薦」。関連：7「比較」、10「登録基盤検証」、13「価格・販売情報」、14「品質・監査」、16「テスト」。

## 6. 次工程
診断・推薦の価格モデルに購入チャネルを安全に引き継ぐ設計を確認し、選択チャネル外の価格へフォールバックしないDAO/推薦回帰テストを追加する。その後、Room/JUnit実行環境で検証できる形を維持し、実ビルドと実機テストは別の完了条件として扱う。

## 7. 証跡
- `app/src/main/java/jp/smartphoneadvisor/app/data/PhoneDao.kt`
- `app/build.gradle.kts`
- `tools/test_recommendation_price_v2_0_04_39.py`
- `tools/test_price_history_determinism_0_04_42.py`
- `tools/test_comparison_color_prices_0_04_38.py`
- `VALIDATION_0.04.42.txt`

### 追加の監査メモ（旧版固定スクリプト）
- `audit_sales_preflight_0_04_36.py` は PASS（URL監査475件、無効URL0件）。
- `audit_product_listing_relations_0_04_33.py` は機能チェック14/14 PASSだが、残り2件はスクリプトが `versionName=0.04.33` / `versionCode=82` を固定期待しているため、現行0.04.42では意図的にFAIL。
- `audit_retailer_master_audit_0_04_33.py` の監査ロジックはPASSだが、版番号を0.04.33に固定した検査だけFAIL。
- `audit_json_room_importer_0_04_36.py` の版番号固定チェックは旧版期待のためFAIL。データ集計は196機種 / 314 Variant / 477販売登録（この監査スクリプトによる構造集計）。
- `audit_room_schema_export_0_04_35.py` は旧スナップショットのschema version 13・旧版番号を固定期待するため2件FAIL。これは現行Roomスキーマ/版の妥当性を証明するテストではなく、Roomビルドや移行テストが未実施である点は継続課題。
