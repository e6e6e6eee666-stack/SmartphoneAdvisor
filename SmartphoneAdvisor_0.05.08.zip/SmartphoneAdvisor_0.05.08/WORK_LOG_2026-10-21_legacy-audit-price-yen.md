# Work log — legacy audit `price_yen` cleanup (2026-10-21)

## Purpose / completion condition
Remove the legacy `price_yen` field only from `auditFindings`, where the app parser does not model it, and prevent the CSV-to-JSON converter from reintroducing it. Preserve every finding, all other fields, and catalog counts.

## Changes
- Updated `tools/convert_carrier_seed_to_phones_json.py` to omit the exact legacy CSV column `price_yen` when creating audit findings.
- Removed `price_yen` from the existing `app/src/main/assets/phones.json` `auditFindings` objects only. No finding was deleted; all other fields were retained.
- Added `tools/test_audit_findings_legacy_price_yen.py` to exercise generation from a fixture CSV and verify that `price_yen` is omitted while other audit fields remain.

## Verification
- ZIP integrity: checked before extraction; no corrupt member reported.
- `python tools/test_audit_findings_legacy_price_yen.py`: PASS (legacy field omitted; other fields retained; rows differing only by legacy price remain separate, preserving deduplication behavior).
- `python tools/test_catalog_json_declared_counts_guard.py`: PASS.
- `python tools/test_mive_kesuma_iijmio_official_price_0_05_01.py`: PASS.
- Independent JSON recount: PASS — 195 models / 315 variants / 511 sales listings / 95 price options / 45 audit findings; declared counts unchanged.
- Remaining `price_yen` fields in current `auditFindings`: 0.
- Updated `phones.json` SHA-256: `cec7e2b5940643ba0e2ba5eb410122229e8f421c1b567b7012c1a7dc232741ad`.
- Kotlin/Gradle build, Room runtime import, emulator/device: not run in this environment.

## Scope cautions
This does not resolve the iPhone 17 duplicate variant question. No variant or audit finding was deleted. The `counts.auditFindings` value is expected to remain 45.
