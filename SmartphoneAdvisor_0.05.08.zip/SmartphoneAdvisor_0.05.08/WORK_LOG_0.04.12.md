# SmartphoneAdvisor 作業記録 0.04.12

## 1. 目的・完了条件
- 初期 Room seed で同じ機種の容量違いを別々の `smartphone_model` 行として登録してしまう構造を修正する。
- 既存の容量/RAM別 `device_variant` は保持し、同じモデルに属するようにする。
- 静的検査を追加し、モデルキーに容量/RAMが含まれないことを検査する。

## 2. 実施内容
- `SeedData.ensureSeeded` に `ModelKey(manufacturer, model, platform, releaseYear)` のモデルIDキャッシュを追加。
- 初期seedの各バリアントは同一モデルキーの既存IDを再利用する。
- アプリ版を `0.04.12`、`versionCode=61` に更新。
- `tools/audit_seed_model_grouping.py` を追加。

## 3. 検証結果
- JSON/ソース静的検査: 実施。
- ZIP整合性: `zipfile.testzip()` PASS（71エントリー、作成後に最終再検査）。
- `audit_diagnostic_catalog.py`: PASS（196モデル、313バリアント、472販売登録、エラー0・URL欠落警告2）。
- `audit_seed_model_grouping.py`: PASS。
- 追加照合: 初期 `SeedData.phones` の11バリアントキーはすべてJSONと一致。ただしJSON 313バリアントの3.51%に相当するだけで、他のSeed生成処理を含むRoom全体のカバー率ではない。
- Gradleビルド、Room実機/エミュレータ検証: 未実施。環境にGradle/Android SDKがないため成功とは扱わない。

## 4. 問題・未確認事項
- この修正は新規DBでseedが作成される経路を対象にする。既存インストールのDBにすでに作られた重複モデル行を自動統合するものではない。
- `phones.json` 196モデル/313バリアントと、Roomの詳細属性・価格データの登録件数は別。JSON全件のRoom取込みは未実装。
- 購入先URLがない販売記録は、虚偽のURLを作らないため購入リンクとして登録しない設計が必要。販売状態の確認時刻の意味も別途整理が必要。

## 5. 進捗位置
- 大項目2「アプリ基盤再設計・修正」および大項目4「診断」の前提データ整備。
- 小項目: 初期seedのモデル/バリアント分離。
- バージョン: 0.04.12 / versionCode 61。

## 6. 次工程
- JSONとRoomのモデル・バリアント紐付け監査を自動化し、未連携件数と不一致理由を出す。
- その結果を踏まえ、既存DB移行を含むカタログ登録処理を設計する。
- Gradleビルド可能な環境が整い次第、コンパイルとRoomテストを実施する。

## 7. 証跡
- `app/src/main/java/jp/smartphoneadvisor/app/data/SeedData.kt`
- `app/build.gradle.kts`
- `tools/audit_seed_model_grouping.py`
- `WORK_LOG_0.04.12.md`
