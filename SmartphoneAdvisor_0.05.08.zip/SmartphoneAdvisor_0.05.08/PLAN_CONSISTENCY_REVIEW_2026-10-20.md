# SmartphoneAdvisor 工程表・台帳整合性修正記録（2026-10-20）

## 目的
ユーザーの合意済み方針に沿い、工程表の大項目数を固定せず、既存要件・過去成果を失わず、正式工程表・台帳・進捗記録の矛盾を解消する。

## 確認した実物
- 入力ZIP：`SmartphoneAdvisor_工程表・カスタム指示再設計_2026-10-18.zip`、1,118,474 bytes。
- ZIP内エントリー：601（ディレクトリを除くファイルは601）。
- 内部 `app/build.gradle.kts`：`versionName=0.04.89`、`versionCode=137`。
- 正本候補 `PROJECT_MASTER_PLAN_V2_FORMAL_2026-10-18.md` はG0〜G8と旧20領域の追跡表を持つ一方、`PROJECT_MASTER_PLAN_CURRENT.md` と台帳冒頭に旧20項目を正式項目数として固定する記述が残っていた。

## 変更
1. `PROJECT_MASTER_PLAN_CURRENT.md` をv2のゲート方式計画に一本化し、現行正本であることを明記。
2. 旧工程表を `PROJECT_MASTER_PLAN_20_MAJOR_LEGACY_2026-10-18.md` として保存し、履歴専用と明示。
3. `PROJECT_TASK_REGISTER_0.04.90.md` 冒頭の20項目固定方針を撤去し、大項目数を固定しない運用・現在位置・ブロッカー・未検証項目を追記。
4. この修正記録を追加。READMEにも整合性修正の概要を追加。
5. アプリコード、JSON、Gradle設定、versionName/versionCodeは変更していない。

## 検証
- ZIP CRCテスト：作成後に実行。
- 正本ファイルと台帳の主要矛盾語句・正本参照を機械チェック。
- `app/src/**`、`app/build.gradle.kts`、`phones.json` の入力ZIPとのバイト一致を検査。
- SHA-256とファイル数を記録。

## 残課題
- 旧基準ZIP名と内部アプリ版の履歴統合、正式な採番規則の確定（PLN-01/VER-01）。
- Android実ビルド、Kotlin/JUnit、Room実DB、実機/エミュレーター検証は未実施。
- Python回帰51件は分割・個別PASS記録であり、一括ランナーの統合実行成功とは扱わない。
- 497販売登録中448件の価格選択肢欠損を引き続き監査。
