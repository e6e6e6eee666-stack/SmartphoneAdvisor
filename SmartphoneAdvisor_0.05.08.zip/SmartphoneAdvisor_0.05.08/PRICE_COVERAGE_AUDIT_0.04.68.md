# 価格登録カバレッジ監査（0.04.68）

## 目的・判定基準

価格情報の登録状況を販売チャネル別に見える化し、補完対象を優先付けする。既存の価格・販売状態・URLを推測で変更せず、確認できた価格だけを根拠付きで登録する。`priceOptions` は価格候補の登録有無であり、価格の現在性・購入可能性を保証しない。

## 全体集計

- 機種：196件
- バリエーション：314件
- 販売登録：495件
- 価格オプション：47件
- 価格未登録の販売登録：450件
- `availability=AVAILABLE` かつ価格未登録：405件
- URL未登録の販売登録：2件

## 販売チャネル別

| チャネル | 販売登録 | 価格あり | 価格なし | AVAILABLEかつ価格なし | URLなし |
|---|---:|---:|---:|---:|---:|
| AU | 78 | 1 | 77 | 47 | 0 |
| DOCOMO | 70 | 8 | 62 | 59 | 0 |
| IIJ_MIO | 31 | 0 | 31 | 31 | 0 |
| MINEO | 36 | 0 | 36 | 36 | 0 |
| RAKUTEN | 54 | 9 | 45 | 43 | 0 |
| SIM_FREE | 52 | 19 | 33 | 33 | 0 |
| SOFTBANK | 126 | 8 | 118 | 111 | 0 |
| UQ_MOBILE | 28 | 0 | 28 | 27 | 0 |
| Y_MOBILE | 20 | 0 | 20 | 18 | 2 |

## 販売状態別（登録値。ライブ在庫確認ではない）

- AVAILABLE: 444件
- DISCONTINUED: 10件
- OUT_OF_STOCK: 2件
- PREORDER: 10件
- UNKNOWN: 29件

## 価格未登録の優先確認対象

次の一覧は「販売可能」と登録されている一方、価格オプションがない販売登録。価格が0円という意味ではなく、アプリが価格根拠を表示するための情報がカタログに未登録であることを示す。

- iPhone 18 Pro / 512GB / RAM NoneGB / AU / URL: https://www.au.com/iphone/product/iphone-18-pro/
- iPhone 18 Pro / 1024GB / RAM NoneGB / AU / URL: https://www.au.com/iphone/product/iphone-18-pro/
- iPhone 18 Pro Max / 256GB / RAM NoneGB / AU / URL: https://www.au.com/iphone/product/iphone-18-pro/
- iPhone 18 Pro Max / 512GB / RAM NoneGB / AU / URL: https://www.au.com/iphone/product/iphone-18-pro/
- iPhone 18 Pro Max / 1024GB / RAM NoneGB / AU / URL: https://www.au.com/iphone/product/iphone-18-pro/
- Pixel 11 / 256GB / RAM 12GB / DOCOMO / URL: https://www.docomo.ne.jp/product/pixel11/
- Pixel 11 / 256GB / RAM 12GB / AU / URL: https://www.au.com/mobile/product/smartphone/pixel11/
- Pixel 11 / 256GB / RAM 12GB / SOFTBANK / URL: https://www.softbank.jp/mobile/products/smartphone/pixel11/
- Pixel 11 / 512GB / RAM 12GB / DOCOMO / URL: https://www.docomo.ne.jp/product/pixel11/
- Pixel 11 / 512GB / RAM 12GB / AU / URL: https://www.au.com/mobile/product/smartphone/pixel11/
- Pixel 11 / 512GB / RAM 12GB / SOFTBANK / URL: https://www.softbank.jp/mobile/products/google-pixel/google-pixel-11/
- Pixel 11 Pro / 256GB / RAM 12GB / DOCOMO / URL: https://www.docomo.ne.jp/product/pixel11pro/
- Pixel 11 Pro / 256GB / RAM 12GB / AU / URL: https://www.au.com/mobile/product/smartphone/pixel11p/
- Pixel 11 Pro / 256GB / RAM 12GB / SOFTBANK / URL: https://www.softbank.jp/mobile/products/smartphone/pixel11-pro/
- Pixel 11 Pro / 256GB / RAM 12GB / RAKUTEN / URL: https://network.mobile.rakuten.co.jp/product/smartphone/google-pixel-11-pro/
- Pixel 11 Pro / 512GB / RAM 16GB / DOCOMO / URL: https://www.docomo.ne.jp/product/pixel11pro/
- Pixel 11 Pro / 512GB / RAM 16GB / AU / URL: https://www.au.com/mobile/product/smartphone/pixel11p/
- Pixel 11 Pro / 512GB / RAM 16GB / SOFTBANK / URL: https://www.softbank.jp/mobile/products/google-pixel/google-pixel-11-pro/
- Pixel 11 Pro / 512GB / RAM 16GB / RAKUTEN / URL: https://network.mobile.rakuten.co.jp/product/smartphone/google-pixel-11-pro/
- Pixel 11 Pro XL / 256GB / RAM 12GB / DOCOMO / URL: https://www.docomo.ne.jp/product/pixel11proxl/
- Pixel 11 Pro XL / 256GB / RAM 12GB / AU / URL: https://www.au.com/mobile/product/smartphone/pixel11p_xl/
- Pixel 11 Pro XL / 256GB / RAM 12GB / SOFTBANK / URL: https://www.softbank.jp/mobile/products/smartphone/pixel11-pro-xl/
- Pixel 11 Pro XL / 512GB / RAM 16GB / DOCOMO / URL: https://www.docomo.ne.jp/product/pixel11proxl/
- Pixel 11 Pro XL / 512GB / RAM 16GB / SOFTBANK / URL: https://www.softbank.jp/mobile/products/smartphone/pixel11-pro-xl/
- Pixel 11 Pro Fold / 256GB / RAM 16GB / DOCOMO / URL: https://www.docomo.ne.jp/product/pixel11profold/
- Pixel 11 Pro Fold / 256GB / RAM 16GB / AU / URL: https://www.au.com/mobile/product/smartphone/pixel11p_fold/
- Pixel 11 Pro Fold / 256GB / RAM 16GB / SOFTBANK / URL: https://www.softbank.jp/mobile/products/smartphone/pixel11-pro-fold/
- Pixel 11 Pro Fold / 512GB / RAM 16GB / DOCOMO / URL: https://www.docomo.ne.jp/product/pixel11profold/
- Pixel 11 Pro Fold / 512GB / RAM 16GB / AU / URL: https://www.au.com/mobile/product/smartphone/pixel11p_fold/
- Pixel 11 Pro Fold / 512GB / RAM 16GB / SOFTBANK / URL: https://www.softbank.jp/mobile/products/google-pixel/google-pixel-11-pro-fold/
- Xperia 1 VIII / 256GB / RAM 12GB / DOCOMO / URL: https://www.docomo.ne.jp/product/so51g/
- Xperia 1 VIII / 256GB / RAM 12GB / AU / URL: https://www.au.com/mobile/product/smartphone/xperia1m8/
- Xperia 1 VIII / 256GB / RAM 12GB / SOFTBANK / URL: https://www.softbank.jp/mobile/products/smartphone/xperia1m8/
- AQUOS R11 / 256GB / RAM 12GB / DOCOMO / URL: https://www.docomo.ne.jp/product/sh51g/
- AQUOS R11 / 256GB / RAM 12GB / SOFTBANK / URL: https://www.softbank.jp/mobile/products/smartphone/aquos-r11/
- AQUOS R11 / 256GB / RAM 12GB / MINEO / URL: https://mineo.jp/device/smartphone/
- AQUOS R11 / 512GB / RAM 12GB / MINEO / URL: https://mineo.jp/device/smartphone/
- AQUOS wish6 / 128GB / RAM 4GB / RAKUTEN / URL: https://network.mobile.rakuten.co.jp/product/smartphone/
- AQUOS wish6 / 128GB / RAM 4GB / Y_MOBILE / URL: https://www.ymobile.jp/lineup/smartphone/wish6/
- AQUOS wish6 / 128GB / RAM 4GB / IIJ_MIO / URL: https://www.iijmio.jp/device/
- AQUOS wish6 / 128GB / RAM 4GB / MINEO / URL: https://mineo.jp/device/smartphone/
- AQUOS sense10 / 128GB / RAM 6GB / DOCOMO / URL: https://www.docomo.ne.jp/product/sh53f/
- AQUOS sense10 / 128GB / RAM 6GB / SOFTBANK / URL: https://www.softbank.jp/mobile/products/smartphone/aquos-sense10/
- AQUOS sense10 / 128GB / RAM 6GB / RAKUTEN / URL: https://network.mobile.rakuten.co.jp/product/smartphone/
- AQUOS sense10 / 128GB / RAM 6GB / UQ_MOBILE / URL: https://shop.uqmobile.jp/shop/lineup/
- AQUOS sense10 / 256GB / RAM 8GB / MINEO / URL: https://mineo.jp/device/smartphone/
- MIVEケースマ / 32GB / RAM 3GB / IIJ_MIO / URL: https://www.iijmio.jp/device/
- OPPO Reno16 5G / 256GB / RAM 12GB / IIJ_MIO / URL: https://www.iijmio.jp/device/
- OPPO Reno16 5G / 256GB / RAM 12GB / MINEO / URL: https://mineo.jp/device/smartphone/
- OPPO Reno15 A / 128GB / RAM 8GB / RAKUTEN / URL: https://network.mobile.rakuten.co.jp/product/smartphone/reno15-a/
- OPPO Reno15 A / 128GB / RAM 8GB / UQ_MOBILE / URL: https://shop.uqmobile.jp/detail/oppo_reno15_a/
- OPPO Reno15 A / 128GB / RAM 8GB / Y_MOBILE / URL: https://www.ymobile.jp/lineup/smartphone/reno15a/
- OPPO Reno15 A / 128GB / RAM 8GB / MINEO / URL: https://mineo.jp/device/smartphone/
- OPPO Reno15 A / 256GB / RAM 12GB / MINEO / URL: https://mineo.jp/device/smartphone/
- motorola edge 60 / 128GB / RAM 8GB / UQ_MOBILE / URL: https://shop.uqmobile.jp/shop/lineup/
- motorola edge 60 / 128GB / RAM 8GB / IIJ_MIO / URL: https://www.iijmio.jp/device/
- motorola edge 60 / 128GB / RAM 8GB / MINEO / URL: https://mineo.jp/device/smartphone/
- Nothing Phone (4a) / 128GB / RAM 8GB / IIJ_MIO / URL: https://www.iijmio.jp/device/
- motorola razr fold / 512GB / RAM 16GB / IIJ_MIO / URL: https://www.iijmio.jp/device/
- moto g37j / 128GB / RAM 4GB / RAKUTEN / URL: https://network.mobile.rakuten.co.jp/product/smartphone/
- moto g37j / 128GB / RAM 4GB / IIJ_MIO / URL: https://www.iijmio.jp/device/
- moto g37j / 128GB / RAM 4GB / MINEO / URL: https://mineo.jp/device/smartphone/
- Zenfone 12 Ultra / 256GB / RAM 12GB / SIM_FREE / URL: https://www.asus.com/jp/mobile-handhelds/phones/zenfone/zenfone-12-ultra/
- ROG Phone 9 / 256GB / RAM 12GB / SIM_FREE / URL: https://rog.asus.com/jp/phones/rog-phone-9/
- REDMAGIC 11 Pro / 256GB / RAM 12GB / SIM_FREE / URL: https://jp.redmagic.gg/pages/redmagic-11-pro
- REDMAGIC 11 Pro / 512GB / RAM 16GB / SIM_FREE / URL: https://jp.redmagic.gg/pages/redmagic-11-pro
- REDMAGIC 11 Pro / 1024GB / RAM 24GB / SIM_FREE / URL: https://jp.redmagic.gg/pages/redmagic-11-pro
- motorola razr 60 / 512GB / RAM 12GB / MINEO / URL: https://mineo.jp/device/smartphone/
- motorola razr 60 ultra / 512GB / RAM NoneGB / AU / URL: https://www.au.com/mobile/product/smartphone/razr_60_ultra/
- moto g06 / 128GB / RAM 4GB / MINEO / URL: https://mineo.jp/device/smartphone/
- ROG Phone 9 Pro / 512GB / RAM 16GB / SIM_FREE / URL: https://rog.asus.com/jp/phones/rog-phone-9-pro/
- ROG Phone 9 Pro Edition / 1024GB / RAM 24GB / SIM_FREE / URL: https://rog.asus.com/jp/phones/rog-phone-9-pro/
- Phone (4a) / 128GB / RAM 8GB / SIM_FREE / URL: https://jp.nothing.tech/products/phone-4a
- Xiaomi 17T / 256GB / RAM 12GB / IIJ_MIO / URL: https://www.iijmio.jp/device/
- Xiaomi 17T / 256GB / RAM 12GB / MINEO / URL: https://mineo.jp/device/smartphone/
- Xiaomi 17T / 512GB / RAM 12GB / SIM_FREE / URL: https://buy.mi.com/jp/products/all
- Xiaomi 17T Pro / 256GB / RAM 12GB / IIJ_MIO / URL: https://www.iijmio.jp/device/
- Xiaomi 17T Pro / 256GB / RAM 12GB / MINEO / URL: https://mineo.jp/device/smartphone/
- Xiaomi 17 Ultra / 512GB / RAM 16GB / IIJ_MIO / URL: https://www.iijmio.jp/device/
- Xiaomi 17 Ultra / 512GB / RAM 16GB / SIM_FREE / URL: https://buy.mi.com/jp/products/all
- POCO F9 Ultra / 512GB / RAM 16GB / SIM_FREE / URL: https://buy.mi.com/jp/products/all
- REDMI Note 17 Pro Max 5G / 256GB / RAM 8GB / IIJ_MIO / URL: https://www.iijmio.jp/device/
- REDMI Note 17 Pro Max 5G / 512GB / RAM 8GB / IIJ_MIO / URL: https://www.iijmio.jp/device/
- POCO M8 5G / 256GB / RAM 8GB / Y_MOBILE / URL: https://www.ymobile.jp/lineup/simfree/
- Pixel 10 Pro XL / 256GB / RAM 16GB / SOFTBANK / URL: https://www.softbank.jp/mobile/products/smartphone/pixel10-pro-xl/
- Pixel 10 Pro XL / 512GB / RAM 16GB / SOFTBANK / URL: https://www.softbank.jp/mobile/products/smartphone/pixel10-pro-xl/
- Pixel 10 Pro Fold / 256GB / RAM 16GB / SOFTBANK / URL: https://www.softbank.jp/mobile/products/smartphone/pixel10-pro-fold/
- Pixel 10 Pro Fold / 512GB / RAM 16GB / SOFTBANK / URL: https://www.softbank.jp/mobile/products/google-pixel/google-pixel-10-pro-fold/
- Google Pixel 10a / 128GB / RAM 8GB / DOCOMO / URL: https://www.docomo.ne.jp/product/pixel10a/
- Google Pixel 10a / 128GB / RAM 8GB / SOFTBANK / URL: https://www.softbank.jp/mobile/products/smartphone/pixel10a/
- Google Pixel 10a / 128GB / RAM 8GB / RAKUTEN / URL: https://network.mobile.rakuten.co.jp/product/smartphone/google-pixel-10a/
- Google Pixel 10a / 128GB / RAM 8GB / UQ_MOBILE / URL: https://shop.uqmobile.jp/detail/google_pixel10a/
- Google Pixel 10a / 128GB / RAM 8GB / Y_MOBILE / URL: https://www.ymobile.jp/lineup/smartphone/pixel10a/
- Google Pixel 10a / 256GB / RAM 8GB / DOCOMO / URL: https://www.docomo.ne.jp/product/pixel10a/
- Google Pixel 10a / 256GB / RAM 8GB / RAKUTEN / URL: https://network.mobile.rakuten.co.jp/product/smartphone/google-pixel-10a/
- Google Pixel 10a / 256GB / RAM 8GB / UQ_MOBILE / URL: https://shop.uqmobile.jp/detail/google_pixel10a/
- Google Pixel 10a / 256GB / RAM 8GB / Y_MOBILE / URL: https://www.ymobile.jp/lineup/smartphone/pixel10a/
- OPPO Reno13 A / 128GB / RAM 8GB / AU / URL: https://www.au.com/mobile/product/smartphone/oppo_reno13_a/
- OPPO Reno13 A / 128GB / RAM 8GB / RAKUTEN / URL: https://network.mobile.rakuten.co.jp/product/smartphone/
- OPPO Reno13 A / 128GB / RAM 8GB / UQ_MOBILE / URL: https://shop.uqmobile.jp/detail/oppo_reno13_a/
- OPPO Reno13 A / 128GB / RAM 8GB / Y_MOBILE / URL: https://www.ymobile.jp/lineup/smartphone/reno13a/
- moto g66y 5G / 128GB / RAM 4GB / Y_MOBILE / URL: https://www.ymobile.jp/lineup/smartphone/motog66y/
- Xperia 10 VII / 128GB / RAM 8GB / DOCOMO / URL: https://www.docomo.ne.jp/product/so52f/
- Xperia 10 VII / 128GB / RAM 8GB / SOFTBANK / URL: https://www.softbank.jp/mobile/products/smartphone/xperia10m7/
- Xperia 10 VII / 128GB / RAM 8GB / UQ_MOBILE / URL: https://shop.uqmobile.jp/detail/xperia_10_vii/
- Xperia 10 VII / 128GB / RAM 8GB / MINEO / URL: https://mineo.jp/device/smartphone/
- AQUOS R10 / 256GB / RAM 12GB / DOCOMO / URL: https://www.docomo.ne.jp/product/sh51f/
- AQUOS R10 / 256GB / RAM 12GB / SOFTBANK / URL: https://www.softbank.jp/mobile/products/smartphone/aquos-r10/
- AQUOS R10 / 256GB / RAM 12GB / RAKUTEN / URL: https://network.mobile.rakuten.co.jp/product/smartphone/
- AQUOS R10 / 256GB / RAM 12GB / MINEO / URL: https://mineo.jp/device/smartphone/
- AQUOS R10 / 512GB / RAM 12GB / MINEO / URL: https://mineo.jp/device/smartphone/
- AQUOS wish5 / 128GB / RAM 4GB / DOCOMO / URL: https://www.docomo.ne.jp/product/sh52f/
- AQUOS wish5 / 128GB / RAM 4GB / RAKUTEN / URL: https://network.mobile.rakuten.co.jp/product/smartphone/
- AQUOS wish5 / 128GB / RAM 4GB / Y_MOBILE / URL: https://www.ymobile.jp/lineup/smartphone/wish5/
- Galaxy S25 / 256GB / RAM 12GB / DOCOMO / URL: https://www.docomo.ne.jp/product/sc51f/
- Galaxy S25 / 256GB / RAM 12GB / SOFTBANK / URL: https://www.softbank.jp/mobile/products/samsung-galaxy/samsung-galaxy-s25/
- Galaxy S25 / 512GB / RAM 12GB / DOCOMO / URL: https://www.docomo.ne.jp/product/sc51f/
- Galaxy S25 Ultra / 256GB / RAM 12GB / DOCOMO / URL: https://www.docomo.ne.jp/product/sc52f/
- Galaxy S25 Ultra / 256GB / RAM 12GB / SOFTBANK / URL: https://www.softbank.jp/mobile/products/samsung-galaxy/samsung-galaxy-s25-ultra/
- Galaxy S25 Ultra / 512GB / RAM 12GB / DOCOMO / URL: https://www.docomo.ne.jp/product/sc52f/
- Galaxy S25 Ultra / 512GB / RAM 12GB / SOFTBANK / URL: https://www.softbank.jp/mobile/products/samsung-galaxy/samsung-galaxy-s25-ultra/
- Galaxy S25 Ultra / 1024GB / RAM 12GB / DOCOMO / URL: https://www.docomo.ne.jp/product/sc52f/
- Galaxy S26 / 256GB / RAM 12GB / DOCOMO / URL: https://www.docomo.ne.jp/product/sc51g/
- Galaxy S26 / 256GB / RAM 12GB / AU / URL: https://www.au.com/mobile/product/smartphone/galaxy_s26/
- Galaxy S26 / 256GB / RAM 12GB / SOFTBANK / URL: https://www.softbank.jp/mobile/products/samsung-galaxy/samsung-galaxy-s26/
- Galaxy S26 / 256GB / RAM 12GB / RAKUTEN / URL: https://network.mobile.rakuten.co.jp/product/smartphone/
- Galaxy S26 / 256GB / RAM 12GB / IIJ_MIO / URL: https://www.iijmio.jp/device/
- Galaxy S26 / 512GB / RAM 12GB / DOCOMO / URL: https://www.docomo.ne.jp/product/sc51g/
- Galaxy S26 / 512GB / RAM 12GB / AU / URL: https://www.au.com/mobile/product/smartphone/galaxy_s26/
- Galaxy S26 / 512GB / RAM 12GB / SOFTBANK / URL: https://www.softbank.jp/mobile/products/samsung-galaxy/samsung-galaxy-s26/
- Galaxy S26 / 512GB / RAM 12GB / IIJ_MIO / URL: https://www.iijmio.jp/device/
- Galaxy S26+ / 256GB / RAM 12GB / DOCOMO / URL: https://www.docomo.ne.jp/product/sc52g/
- Galaxy S26+ / 256GB / RAM 12GB / AU / URL: https://www.au.com/mobile/product/smartphone/galaxy_s26plus/
- Galaxy S26+ / 256GB / RAM 12GB / SOFTBANK / URL: https://www.softbank.jp/mobile/products/samsung-galaxy/samsung-galaxy-s26-plus/
- Galaxy S26+ / 256GB / RAM 12GB / RAKUTEN / URL: https://network.mobile.rakuten.co.jp/product/smartphone/
- Galaxy S26+ / 256GB / RAM 12GB / IIJ_MIO / URL: https://www.iijmio.jp/device/
- Galaxy S26+ / 512GB / RAM 12GB / DOCOMO / URL: https://www.docomo.ne.jp/product/sc52g/
- Galaxy S26+ / 512GB / RAM 12GB / SOFTBANK / URL: https://www.softbank.jp/mobile/products/samsung-galaxy/samsung-galaxy-s26-plus/
- Galaxy S26+ / 512GB / RAM 12GB / IIJ_MIO / URL: https://www.iijmio.jp/device/
- Galaxy S26 Ultra / 256GB / RAM 12GB / DOCOMO / URL: https://www.docomo.ne.jp/product/sc53g/
- Galaxy S26 Ultra / 256GB / RAM 12GB / AU / URL: https://www.au.com/mobile/product/smartphone/galaxy_s26ultra/
- Galaxy S26 Ultra / 256GB / RAM 12GB / SOFTBANK / URL: https://www.softbank.jp/mobile/products/samsung-galaxy/samsung-galaxy-s26-ultra/
- Galaxy S26 Ultra / 256GB / RAM 12GB / RAKUTEN / URL: https://network.mobile.rakuten.co.jp/product/smartphone/samsung-galaxy-s26-ultra/
- Galaxy S26 Ultra / 256GB / RAM 12GB / IIJ_MIO / URL: https://www.iijmio.jp/device/
- Galaxy S26 Ultra / 512GB / RAM 12GB / DOCOMO / URL: https://www.docomo.ne.jp/product/sc53g/
- Galaxy S26 Ultra / 512GB / RAM 12GB / SOFTBANK / URL: https://www.softbank.jp/mobile/products/samsung-galaxy/samsung-galaxy-s26-ultra/
- Galaxy S26 Ultra / 512GB / RAM 12GB / IIJ_MIO / URL: https://www.iijmio.jp/device/
- Galaxy S26 Ultra / 1024GB / RAM 16GB / DOCOMO / URL: https://www.docomo.ne.jp/product/sc53g/
- Galaxy S26 Ultra / 1024GB / RAM 16GB / IIJ_MIO / URL: https://www.iijmio.jp/device/
- Galaxy Z Fold8 Ultra / 256GB / RAM 12GB / DOCOMO / URL: https://www.docomo.ne.jp/product/sc56g/
- Galaxy Z Fold8 Ultra / 256GB / RAM 12GB / AU / URL: https://www.au.com/mobile/product/smartphone/galaxy_z_fold8_ultra/
- Galaxy Z Fold8 Ultra / 256GB / RAM 12GB / SOFTBANK / URL: https://www.softbank.jp/mobile/products/samsung-galaxy/samsung-galaxy-z-fold8-ultra/
- Galaxy Z Fold8 Ultra / 256GB / RAM 12GB / RAKUTEN / URL: https://network.mobile.rakuten.co.jp/product/smartphone/samsung-galaxy-z-fold8-ultra/
- Galaxy Z Fold8 Ultra / 256GB / RAM 12GB / IIJ_MIO / URL: https://www.iijmio.jp/device/
- Galaxy Z Fold8 Ultra / 512GB / RAM 12GB / DOCOMO / URL: https://www.docomo.ne.jp/product/sc56g/
- Galaxy Z Fold8 Ultra / 512GB / RAM 12GB / AU / URL: https://www.au.com/mobile/product/smartphone/galaxy_z_fold8_ultra/
- Galaxy Z Fold8 Ultra / 512GB / RAM 12GB / SOFTBANK / URL: https://www.softbank.jp/mobile/products/samsung-galaxy/samsung-galaxy-z-fold8-ultra/
- Galaxy Z Fold8 Ultra / 512GB / RAM 12GB / IIJ_MIO / URL: https://www.iijmio.jp/device/
- Galaxy Z Fold8 Ultra / 1024GB / RAM 16GB / DOCOMO / URL: https://www.docomo.ne.jp/product/sc56g/
- Galaxy Z Fold8 Ultra / 1024GB / RAM 16GB / AU / URL: https://www.au.com/mobile/product/smartphone/galaxy_z_fold8_ultra/
- Galaxy Z Fold8 Ultra / 1024GB / RAM 16GB / SOFTBANK / URL: https://www.softbank.jp/mobile/products/samsung-galaxy/samsung-galaxy-z-fold8-ultra/
- Galaxy Z Fold8 Ultra / 1024GB / RAM 16GB / IIJ_MIO / URL: https://www.iijmio.jp/device/
- Galaxy Z Fold8 / 256GB / RAM 12GB / DOCOMO / URL: https://www.docomo.ne.jp/product/sc57g/
- Galaxy Z Fold8 / 256GB / RAM 12GB / AU / URL: https://www.au.com/mobile/product/smartphone/galaxy_z_fold8/
- Galaxy Z Fold8 / 256GB / RAM 12GB / SOFTBANK / URL: https://www.softbank.jp/mobile/products/smartphone/galaxy-z-fold8/
- Galaxy Z Fold8 / 256GB / RAM 12GB / RAKUTEN / URL: https://network.mobile.rakuten.co.jp/product/smartphone/
- Galaxy Z Fold8 / 256GB / RAM 12GB / IIJ_MIO / URL: https://www.iijmio.jp/device/
- Galaxy Z Fold8 / 512GB / RAM 12GB / DOCOMO / URL: https://www.docomo.ne.jp/product/sc57g/
- Galaxy Z Fold8 / 512GB / RAM 12GB / AU / URL: https://www.au.com/mobile/product/smartphone/galaxy_z_fold8/
- Galaxy Z Fold8 / 512GB / RAM 12GB / IIJ_MIO / URL: https://www.iijmio.jp/device/
- Galaxy Z Fold8 / 1024GB / RAM 16GB / AU / URL: https://www.au.com/mobile/product/smartphone/galaxy_z_fold8/
- Galaxy Z Fold8 / 1024GB / RAM 16GB / IIJ_MIO / URL: https://www.iijmio.jp/device/
- Galaxy Z Flip8 / 256GB / RAM 12GB / DOCOMO / URL: https://www.docomo.ne.jp/product/sc55g/
- Galaxy Z Flip8 / 256GB / RAM 12GB / AU / URL: https://www.au.com/mobile/product/smartphone/galaxy_z_flip8/
- Galaxy Z Flip8 / 256GB / RAM 12GB / SOFTBANK / URL: https://www.softbank.jp/mobile/products/smartphone/galaxy-z-flip8/
- Galaxy Z Flip8 / 256GB / RAM 12GB / RAKUTEN / URL: https://network.mobile.rakuten.co.jp/product/smartphone/
- Galaxy Z Flip8 / 256GB / RAM 12GB / IIJ_MIO / URL: https://www.iijmio.jp/device/
- Galaxy Z Flip8 / 512GB / RAM 12GB / DOCOMO / URL: https://www.docomo.ne.jp/product/sc55g/
- Galaxy Z Flip8 / 512GB / RAM 12GB / AU / URL: https://www.au.com/mobile/product/smartphone/galaxy_z_flip8/
- Galaxy Z Flip8 / 512GB / RAM 12GB / IIJ_MIO / URL: https://www.iijmio.jp/device/
- Galaxy A57 5G / 128GB / RAM 8GB / DOCOMO / URL: https://www.docomo.ne.jp/product/sc54g/
- Galaxy A57 5G / 128GB / RAM 8GB / SOFTBANK / URL: https://www.softbank.jp/mobile/products/samsung-galaxy/samsung-galaxy-a57-5g/
- Galaxy A57 5G / 128GB / RAM 8GB / IIJ_MIO / URL: https://www.iijmio.jp/device/
- arrows Alpha2 / 256GB / RAM 8GB / DOCOMO / URL: https://www.docomo.ne.jp/product/f51g/
- arrows Alpha2 / 256GB / RAM 8GB / RAKUTEN / URL: https://network.mobile.rakuten.co.jp/product/smartphone/arrows-alpha2/
- arrows Alpha2 / 256GB / RAM 8GB / Y_MOBILE / URL: https://www.ymobile.jp/lineup/simfree/
- arrows Alpha2 / 256GB / RAM 8GB / IIJ_MIO / URL: https://www.iijmio.jp/device/
- arrows Alpha2 / 256GB / RAM 8GB / MINEO / URL: https://mineo.jp/device/smartphone/
- arrows Alpha2 / 512GB / RAM 12GB / DOCOMO / URL: https://www.docomo.ne.jp/product/f51g/
- arrows Alpha2 / 512GB / RAM 12GB / RAKUTEN / URL: https://network.mobile.rakuten.co.jp/product/smartphone/arrows-alpha2/
- arrows Alpha2 / 512GB / RAM 12GB / MINEO / URL: https://mineo.jp/device/smartphone/
- nubia S2 / 128GB / RAM 6GB / Y_MOBILE / URL: https://www.ymobile.jp/lineup/smartphone/nubia_s2/
- nubia S2R / 64GB / RAM 4GB / RAKUTEN / URL: https://network.mobile.rakuten.co.jp/product/smartphone/
- nubia Flip 3 / 128GB / RAM 6GB / Y_MOBILE / URL: https://www.ymobile.jp/lineup/smartphone/nubiaflip3/
- Phone (3) / 256GB / RAM 12GB / RAKUTEN / URL: https://network.mobile.rakuten.co.jp/product/smartphone/
- Phone (3) / 256GB / RAM 12GB / SIM_FREE / URL: https://jp.nothing.tech/products/phone-3
- Phone (3a) / 128GB / RAM 8GB / RAKUTEN / URL: https://network.mobile.rakuten.co.jp/product/smartphone/
- Phone (3a) Lite / 128GB / RAM 8GB / RAKUTEN / URL: https://network.mobile.rakuten.co.jp/product/smartphone/phone-3a-lite/
- Phone (3a) Lite / 128GB / RAM 8GB / SIM_FREE / URL: https://jp.nothing.tech/products/phone-3a-lite
- CMF Phone 2 Pro / 256GB / RAM 8GB / SIM_FREE / URL: https://jp.nothing.tech/products/cmf-phone-2-pro
- Phone (2a) / 256GB / RAM 12GB / SIM_FREE / URL: https://jp.nothing.tech/products/phone-2a
- CMF Phone 1 / 256GB / RAM 8GB / SIM_FREE / URL: https://jp.nothing.tech/collections/phones
- nubia Z70 Ultra / 256GB / RAM 12GB / SIM_FREE / URL: https://jp.nubia.com/pages/nubia-z70-ultra
- nubia Z70 Ultra / 512GB / RAM 16GB / SIM_FREE / URL: https://jp.nubia.com/pages/nubia-z70-ultra
- nubia Z70S Ultra / 512GB / RAM 16GB / SIM_FREE / URL: https://jp.nubia.com/collections/nubia-z-series
- Phone (4a) Pro / 256GB / RAM 12GB / RAKUTEN / URL: https://network.mobile.rakuten.co.jp/product/smartphone/
- Phone (4a) Pro / 256GB / RAM 12GB / SIM_FREE / URL: https://jp.nothing.tech/products/phone-4a-pro
- Galaxy Z Fold7 / 256GB / RAM 12GB / DOCOMO / URL: https://www.docomo.ne.jp/product/sc56f/
- Galaxy Z Fold7 / 256GB / RAM 12GB / SOFTBANK / URL: https://www.softbank.jp/mobile/products/smartphone/galaxy-z-fold7/
- Galaxy Z Fold7 / 512GB / RAM 12GB / DOCOMO / URL: https://www.docomo.ne.jp/product/sc56f/
- Galaxy Z Fold7 / 1024GB / RAM 16GB / DOCOMO / URL: https://www.docomo.ne.jp/product/sc56f/
- Galaxy Z Flip7 / 256GB / RAM 12GB / DOCOMO / URL: https://www.docomo.ne.jp/product/sc55f/
- Galaxy Z Flip7 / 256GB / RAM 12GB / SOFTBANK / URL: https://www.softbank.jp/mobile/products/smartphone/galaxy-z-flip7/
- Galaxy Z Flip7 / 512GB / RAM 12GB / DOCOMO / URL: https://www.docomo.ne.jp/product/sc55f/
- Galaxy A36 5G / 128GB / RAM 6GB / DOCOMO / URL: https://www.docomo.ne.jp/product/sc54f/
- AQUOS R9 / 256GB / RAM 12GB / SOFTBANK / URL: https://www.softbank.jp/mobile/products/smartphone/aquos-r9/
- AQUOS R9 pro / 512GB / RAM 12GB / SOFTBANK / URL: https://www.softbank.jp/mobile/products/smartphone/aquos-r9-pro/
- AQUOS sense9 / 128GB / RAM 6GB / SOFTBANK / URL: https://www.softbank.jp/mobile/products/smartphone/aquos-sense9/
- AQUOS sense9 / 128GB / RAM 6GB / RAKUTEN / URL: https://network.mobile.rakuten.co.jp/product/smartphone/aquos-sense9/
- arrows We3 / 64GB / RAM 4GB / DOCOMO / URL: https://www.docomo.ne.jp/product/f52g/
- arrows We3 / 64GB / RAM 4GB / UQ_MOBILE / URL: https://shop.uqmobile.jp/detail/arrows_we3/
- arrows We3 / 64GB / RAM 4GB / MINEO / URL: https://mineo.jp/device/smartphone/
- arrows We3 / 128GB / RAM 8GB / MINEO / URL: https://mineo.jp/device/smartphone/
- OPPO Find X9 Ultra / 512GB / RAM 12GB / IIJ_MIO / URL: https://www.iijmio.jp/device/
- OPPO Find X9 / 512GB / RAM 16GB / AU / URL: https://www.au.com/mobile/product/smartphone/oppo_find_x9/
- OPPO Find X9 / 512GB / RAM 16GB / Y_MOBILE / URL: https://www.ymobile.jp/lineup/simfree/
- OPPO Find N6 / 512GB / RAM 16GB / IIJ_MIO / URL: https://www.iijmio.jp/device/
- OPPO A5 5G / 128GB / RAM 4GB / AU / URL: https://www.au.com/mobile/product/smartphone/oppo_a5_5g/
- OPPO A5 5G / 128GB / RAM 4GB / RAKUTEN / URL: https://network.mobile.rakuten.co.jp/product/smartphone/
- OPPO A5 5G / 128GB / RAM 4GB / UQ_MOBILE / URL: https://shop.uqmobile.jp/detail/oppo_a5_5g/
- OPPO A5 5G / 128GB / RAM 4GB / MINEO / URL: https://mineo.jp/device/smartphone/
- OPPO A5x / 128GB / RAM 4GB / MINEO / URL: https://mineo.jp/device/smartphone/
- iPhone 16 / 128GB / RAM NoneGB / SOFTBANK / URL: https://www.softbank.jp/iphone/iphone-16/
- iPhone 16 / 128GB / RAM NoneGB / UQ_MOBILE / URL: https://shop.uqmobile.jp/shop/lineup/
- iPhone 16 / 256GB / RAM NoneGB / SOFTBANK / URL: https://www.softbank.jp/iphone/iphone-16/
- iPhone 16 / 256GB / RAM NoneGB / UQ_MOBILE / URL: https://shop.uqmobile.jp/shop/lineup/
- iPhone 16 / 512GB / RAM NoneGB / SOFTBANK / URL: https://www.softbank.jp/iphone/iphone-16/
- iPhone 16 / 512GB / RAM NoneGB / UQ_MOBILE / URL: https://shop.uqmobile.jp/shop/lineup/
- iPhone 16 Plus / 128GB / RAM NoneGB / SOFTBANK / URL: https://www.softbank.jp/iphone/iphone-16/
- iPhone 16 Plus / 256GB / RAM NoneGB / SOFTBANK / URL: https://www.softbank.jp/iphone/iphone-16/
- iPhone 16 Plus / 512GB / RAM NoneGB / SOFTBANK / URL: https://www.softbank.jp/iphone/iphone-16/
- iPhone 16 Pro / 128GB / RAM NoneGB / SOFTBANK / URL: https://www.softbank.jp/iphone/iphone-16-pro/
- iPhone 16 Pro / 256GB / RAM NoneGB / SOFTBANK / URL: https://www.softbank.jp/iphone/iphone-16-pro/
- iPhone 16 Pro / 512GB / RAM NoneGB / SOFTBANK / URL: https://www.softbank.jp/iphone/iphone-16-pro/
- iPhone 16 Pro / 1024GB / RAM NoneGB / SOFTBANK / URL: https://www.softbank.jp/iphone/iphone-16-pro/
- iPhone 16 Pro Max / 256GB / RAM NoneGB / SOFTBANK / URL: https://www.softbank.jp/iphone/iphone-16-pro-max/
- iPhone 16 Pro Max / 512GB / RAM NoneGB / SOFTBANK / URL: https://www.softbank.jp/iphone/iphone-16-pro-max/
- iPhone 16 Pro Max / 1024GB / RAM NoneGB / SOFTBANK / URL: https://www.softbank.jp/iphone/iphone-16-pro-max/
- iPhone 16e / 128GB / RAM NoneGB / SOFTBANK / URL: https://www.softbank.jp/iphone/iphone-16e/
- iPhone 16e / 256GB / RAM NoneGB / SOFTBANK / URL: https://www.softbank.jp/iphone/iphone-16e/
- iPhone 16e / 512GB / RAM NoneGB / SOFTBANK / URL: https://www.softbank.jp/iphone/iphone-16e/
- iPhone 17 Pro / 256GB / RAM NoneGB / DOCOMO / URL: https://www.docomo.ne.jp/product/iphone17pro/
- iPhone 17 Pro / 256GB / RAM NoneGB / AU / URL: https://www.au.com/iphone/product/iphone-17-pro/
- iPhone 17 Pro / 256GB / RAM NoneGB / SOFTBANK / URL: https://www.softbank.jp/mobile/products/iphone/iphone-17-pro/
- iPhone 17 Pro / 256GB / RAM NoneGB / RAKUTEN / URL: https://network.mobile.rakuten.co.jp/product/iphone/iphone-17-pro/
- iPhone 17 Pro / 256GB / RAM NoneGB / UQ_MOBILE / URL: https://shop.uqmobile.jp/shop/lineup/
- iPhone 17 Pro / 512GB / RAM NoneGB / DOCOMO / URL: https://www.docomo.ne.jp/product/iphone17pro/
- iPhone 17 Pro / 512GB / RAM NoneGB / AU / URL: https://www.au.com/iphone/product/iphone-17-pro/
- iPhone 17 Pro / 512GB / RAM NoneGB / SOFTBANK / URL: https://www.softbank.jp/mobile/products/iphone/iphone-17-pro/
- iPhone 17 Pro / 512GB / RAM NoneGB / RAKUTEN / URL: https://network.mobile.rakuten.co.jp/product/iphone/iphone-17-pro/
- iPhone 17 Pro / 512GB / RAM NoneGB / UQ_MOBILE / URL: https://shop.uqmobile.jp/shop/lineup/
- iPhone 17 Pro / 1024GB / RAM NoneGB / DOCOMO / URL: https://www.docomo.ne.jp/product/iphone17pro/
- iPhone 17 Pro / 1024GB / RAM NoneGB / AU / URL: https://www.au.com/iphone/product/iphone-17-pro/
- iPhone 17 Pro / 1024GB / RAM NoneGB / SOFTBANK / URL: https://www.softbank.jp/mobile/products/iphone/iphone-17-pro/
- iPhone 17 Pro / 1024GB / RAM NoneGB / RAKUTEN / URL: https://network.mobile.rakuten.co.jp/product/iphone/iphone-17-pro/
- iPhone 17 Pro / 1024GB / RAM NoneGB / UQ_MOBILE / URL: https://shop.uqmobile.jp/shop/lineup/
- iPhone 17 Pro Max / 256GB / RAM NoneGB / DOCOMO / URL: https://www.docomo.ne.jp/product/iphone17promax/
- iPhone 17 Pro Max / 256GB / RAM NoneGB / AU / URL: https://www.au.com/iphone/product/iphone-17-pro-max/
- iPhone 17 Pro Max / 256GB / RAM NoneGB / SOFTBANK / URL: https://www.softbank.jp/mobile/products/iphone/iphone-17-pro-max/
- iPhone 17 Pro Max / 256GB / RAM NoneGB / RAKUTEN / URL: https://network.mobile.rakuten.co.jp/product/iphone/iphone-17-pro-max/
- iPhone 17 Pro Max / 256GB / RAM NoneGB / UQ_MOBILE / URL: https://shop.uqmobile.jp/shop/lineup/
- iPhone 17 Pro Max / 512GB / RAM NoneGB / DOCOMO / URL: https://www.docomo.ne.jp/product/iphone17promax/
- iPhone 17 Pro Max / 512GB / RAM NoneGB / AU / URL: https://www.au.com/iphone/product/iphone-17-pro-max/
- iPhone 17 Pro Max / 512GB / RAM NoneGB / SOFTBANK / URL: https://www.softbank.jp/mobile/products/iphone/iphone-17-pro-max/
- iPhone 17 Pro Max / 512GB / RAM NoneGB / RAKUTEN / URL: https://network.mobile.rakuten.co.jp/product/iphone/iphone-17-pro-max/
- iPhone 17 Pro Max / 512GB / RAM NoneGB / UQ_MOBILE / URL: https://shop.uqmobile.jp/shop/lineup/
- iPhone 17 Pro Max / 1024GB / RAM NoneGB / AU / URL: https://www.au.com/iphone/product/iphone-17-pro-max/
- iPhone 17 Pro Max / 1024GB / RAM NoneGB / SOFTBANK / URL: https://www.softbank.jp/mobile/products/iphone/iphone-17-pro-max/
- iPhone 17 Pro Max / 1024GB / RAM NoneGB / RAKUTEN / URL: https://network.mobile.rakuten.co.jp/product/iphone/iphone-17-pro-max/
- iPhone 17 Pro Max / 1024GB / RAM NoneGB / UQ_MOBILE / URL: https://shop.uqmobile.jp/shop/lineup/
- iPhone Air / 256GB / RAM NoneGB / DOCOMO / URL: https://www.docomo.ne.jp/product/iphone-air/
- iPhone Air / 256GB / RAM NoneGB / AU / URL: https://www.au.com/iphone/product/iphone-air/
- iPhone Air / 256GB / RAM NoneGB / SOFTBANK / URL: https://www.softbank.jp/mobile/products/iphone/iphone-air/
- iPhone Air / 256GB / RAM NoneGB / RAKUTEN / URL: https://network.mobile.rakuten.co.jp/product/iphone/iphone-air/
- iPhone Air / 256GB / RAM NoneGB / UQ_MOBILE / URL: https://shop.uqmobile.jp/shop/lineup/
- iPhone Air / 512GB / RAM NoneGB / DOCOMO / URL: https://www.docomo.ne.jp/product/iphone-air/
- iPhone Air / 512GB / RAM NoneGB / AU / URL: https://www.au.com/iphone/product/iphone-air/
- iPhone Air / 512GB / RAM NoneGB / SOFTBANK / URL: https://www.softbank.jp/mobile/products/iphone/iphone-air/
- iPhone Air / 512GB / RAM NoneGB / RAKUTEN / URL: https://network.mobile.rakuten.co.jp/product/iphone/iphone-air/
- iPhone Air / 512GB / RAM NoneGB / UQ_MOBILE / URL: https://shop.uqmobile.jp/shop/lineup/
- iPhone Air / 1024GB / RAM NoneGB / DOCOMO / URL: https://www.docomo.ne.jp/product/iphone-air/
- iPhone Air / 1024GB / RAM NoneGB / AU / URL: https://www.au.com/iphone/product/iphone-air/
- iPhone Air / 1024GB / RAM NoneGB / SOFTBANK / URL: https://www.softbank.jp/mobile/products/iphone/iphone-air/
- iPhone Air / 1024GB / RAM NoneGB / RAKUTEN / URL: https://network.mobile.rakuten.co.jp/product/iphone/iphone-air/
- iPhone Air / 1024GB / RAM NoneGB / UQ_MOBILE / URL: https://shop.uqmobile.jp/shop/lineup/
- iPhone 17e / 256GB / RAM NoneGB / DOCOMO / URL: https://www.docomo.ne.jp/product/iphone17e/
- iPhone 17e / 256GB / RAM NoneGB / AU / URL: https://www.au.com/iphone/product/iphone-17e/
- iPhone 17e / 256GB / RAM NoneGB / SOFTBANK / URL: https://www.softbank.jp/mobile/products/iphone/iphone-17e/
- iPhone 17e / 256GB / RAM NoneGB / RAKUTEN / URL: https://network.mobile.rakuten.co.jp/product/iphone/iphone-17e/
- iPhone 17e / 256GB / RAM NoneGB / UQ_MOBILE / URL: https://shop.uqmobile.jp/detail/iphone17e/
- iPhone 17e / 512GB / RAM NoneGB / DOCOMO / URL: https://www.docomo.ne.jp/product/iphone17e/
- iPhone 17e / 512GB / RAM NoneGB / AU / URL: https://www.au.com/iphone/product/iphone-17e/
- iPhone 17e / 512GB / RAM NoneGB / SOFTBANK / URL: https://www.softbank.jp/mobile/products/iphone/iphone-17e/
- iPhone 17e / 512GB / RAM NoneGB / RAKUTEN / URL: https://network.mobile.rakuten.co.jp/product/iphone/iphone-17e/
- iPhone 17e / 512GB / RAM NoneGB / UQ_MOBILE / URL: https://shop.uqmobile.jp/detail/iphone17e/
- Galaxy A25 5G / 64GB / RAM 4GB / DOCOMO / URL: https://www.docomo.ne.jp/product/sc53f/
- Galaxy A25 5G / 64GB / RAM 4GB / AU / URL: https://www.au.com/mobile/product/smartphone/galaxy_a25_5g/
- Galaxy A25 5G / 64GB / RAM 4GB / SOFTBANK / URL: https://www.softbank.jp/mobile/products/smartphone/galaxy-a25-5g/
- Galaxy A25 5G / 64GB / RAM 4GB / RAKUTEN / URL: https://network.mobile.rakuten.co.jp/product/smartphone/
- Galaxy A25 5G / 64GB / RAM 4GB / UQ_MOBILE / URL: https://shop.uqmobile.jp/shop/lineup/
- Xperia 1 VI / 256GB / RAM 12GB / SOFTBANK / URL: https://www.softbank.jp/mobile/products/smartphone/xperia1m6/
- Xperia 10 VI / 128GB / RAM 6GB / MINEO / URL: https://mineo.jp/device/smartphone/
- motorola razr 50 ultra / 512GB / RAM 12GB / SOFTBANK / URL: https://www.softbank.jp/mobile/products/smartphone/motorola-razr-50-ultra/
- Xiaomi 14T / 256GB / RAM 12GB / AU / URL: https://www.au.com/mobile/product/smartphone/xiaomi_14t/
- Xiaomi 14T Pro / 512GB / RAM 12GB / SOFTBANK / URL: https://www.softbank.jp/mobile/products/smartphone/xiaomi-14t-pro/
- POCO F7 / 256GB / RAM NoneGB / SIM_FREE / URL: https://buy.mi.com/jp/products/all
- POCO F7 Pro / 256GB / RAM NoneGB / SIM_FREE / URL: https://buy.mi.com/jp/products/all
- POCO F7 Ultra / 256GB / RAM 12GB / SIM_FREE / URL: https://buy.mi.com/jp/products/all
- REDMI 15 5G / 128GB / RAM 4GB / SOFTBANK / URL: https://www.softbank.jp/mobile/products/smartphone/redmi15-5g/
- REDMI 15 5G / 128GB / RAM 4GB / MINEO / URL: https://mineo.jp/device/smartphone/
- REDMI 15 5G / 256GB / RAM 8GB / MINEO / URL: https://mineo.jp/device/smartphone/
- arrows We2 / 64GB / RAM 4GB / SOFTBANK / URL: https://www.softbank.jp/mobile/products/smartphone/arrows-we2/
- arrows We2 / 128GB / RAM 4GB / MINEO / URL: https://mineo.jp/device/smartphone/
- arrows Alpha / 256GB / RAM 12GB / DOCOMO / URL: https://www.docomo.ne.jp/product/f51f/
- arrows Alpha / 512GB / RAM 12GB / RAKUTEN / URL: https://network.mobile.rakuten.co.jp/product/smartphone/
- arrows Alpha / 512GB / RAM 12GB / MINEO / URL: https://mineo.jp/device/smartphone/
- らくらくスマートフォン Lite / 64GB / RAM 4GB / AU / URL: https://www.au.com/mobile/product/smartphone/rakuraku_smartphone_lite/
- らくらくスマートフォン Lite / 64GB / RAM 4GB / UQ_MOBILE / URL: https://shop.uqmobile.jp/shop/lineup/
- らくらくスマートフォン Lite / 64GB / RAM 4GB / MINEO / URL: https://mineo.jp/device/smartphone/
- nubia flip 2 / 128GB / RAM 8GB / SIM_FREE / URL: https://jp.nubia.com/collections/nubia-z-series
- nubia S 5G / 128GB / RAM 4GB / SIM_FREE / URL: https://jp.nubia.com/collections/nubia-z-series
- Natural AI Phone / 256GB / RAM 12GB / SOFTBANK / URL: https://www.softbank.jp/mobile/products/smartphone/natural-ai-phone/
- motorola edge 60s pro / 256GB / RAM 12GB / SOFTBANK / URL: https://www.softbank.jp/mobile/products/smartphone/motorola-edge-60s-pro/
- motorola razr 60s / 256GB / RAM 8GB / SOFTBANK / URL: https://www.softbank.jp/mobile/products/smartphone/motorola-razr-60s/
- moto g37 / 128GB / RAM 8GB / SOFTBANK / URL: https://www.softbank.jp/mobile/products/smartphone/moto-g37/
- REDMI Note 13 Pro 5G / 256GB / RAM 8GB / AU / URL: https://www.au.com/mobile/product/smartphone/redmi_note_13_pro_5g/
- Redmi 14C / 128GB / RAM 4GB / MINEO / URL: https://mineo.jp/device/smartphone/
- Redmi 14C / 256GB / RAM 8GB / MINEO / URL: https://mineo.jp/device/smartphone/
- Pixel 8a / 128GB / RAM 8GB / SOFTBANK / URL: https://www.softbank.jp/mobile/products/google-pixel/google-pixel-8a/
- Pixel 9 / 128GB / RAM 12GB / SOFTBANK / URL: https://www.softbank.jp/mobile/products/google-pixel/google-pixel-9/
- Pixel 9 / 256GB / RAM 12GB / SOFTBANK / URL: https://www.softbank.jp/mobile/products/google-pixel/google-pixel-9/
- Pixel 9 Pro / 128GB / RAM 16GB / SOFTBANK / URL: https://www.softbank.jp/mobile/products/google-pixel/google-pixel-9-pro/
- Pixel 9 Pro / 256GB / RAM 16GB / SOFTBANK / URL: https://www.softbank.jp/mobile/products/google-pixel/google-pixel-9-pro/
- Pixel 9 Pro / 512GB / RAM 16GB / SOFTBANK / URL: https://www.softbank.jp/mobile/products/google-pixel/google-pixel-9-pro/
- Pixel 9 Pro XL / 128GB / RAM 16GB / SOFTBANK / URL: https://www.softbank.jp/mobile/products/google-pixel/google-pixel-9-pro/
- Pixel 9 Pro XL / 256GB / RAM 16GB / SOFTBANK / URL: https://www.softbank.jp/mobile/products/google-pixel/google-pixel-9-pro/
- Pixel 9 Pro XL / 512GB / RAM 16GB / SOFTBANK / URL: https://www.softbank.jp/mobile/products/google-pixel/google-pixel-9-pro/
- Pixel 9 Pro Fold / 256GB / RAM 16GB / SOFTBANK / URL: https://www.softbank.jp/mobile/products/google-pixel/google-pixel-9-pro-fold/
- Pixel 9 Pro Fold / 512GB / RAM 16GB / SOFTBANK / URL: https://www.softbank.jp/mobile/products/google-pixel/google-pixel-9-pro-fold/
- Pixel 9a / 128GB / RAM 8GB / SIM_FREE / URL: https://store.google.com/jp/product/pixel_9a
- Pixel 9a / 256GB / RAM 8GB / SIM_FREE / URL: https://store.google.com/jp/product/pixel_9a
- motorola razr 50s / 256GB / RAM 8GB / SOFTBANK / URL: https://www.softbank.jp/mobile/products/smartphone/motorola-razr-50s/
- motorola edge 50s pro / 256GB / RAM 8GB / SOFTBANK / URL: https://www.softbank.jp/mobile/products/smartphone/motorola-edge-50s-pro/
- Redmi 12 5G / 128GB / RAM 4GB / SOFTBANK / URL: https://www.softbank.jp/mobile/products/smartphone/redmi12-5g/
- LEITZ PHONE 3 / 512GB / RAM 12GB / SOFTBANK / URL: https://www.softbank.jp/mobile/products/smartphone/leitz-phone3/
- DuraForce EX / 64GB / RAM 4GB / SOFTBANK / URL: https://www.softbank.jp/mobile/products/smartphone/duraforce-ex/
- あんしんファミリースマホ / 128GB / RAM 4GB / SOFTBANK / URL: https://www.softbank.jp/mobile/products/smartphone/anshin-family-smartphone/
- シンプルスマホ7 / 64GB / RAM 4GB / SOFTBANK / URL: https://www.softbank.jp/mobile/products/smartphone/simple-sumaho7/
- BASIO active3 / 64GB / RAM 4GB / AU / URL: https://www.au.com/mobile/product/smartphone/basio_active3/
- BASIO active3 / 64GB / RAM 4GB / UQ_MOBILE / URL: https://shop.uqmobile.jp/detail/basio_active3/
- TORQUE G07 / 128GB / RAM 8GB / AU / URL: https://www.au.com/mobile/product/smartphone/torque_g07/
- DIGNO BX3 カメラレス / 64GB / RAM 4GB / SOFTBANK / URL: https://www.softbank.jp/mobile/products/smartphone/digno-bx3-cameraless/
- iPhone 17 / 512GB / RAM NoneGB / DOCOMO / URL: https://www.docomo.ne.jp/product/iphone17/
- iPhone 17 / 512GB / RAM NoneGB / AU / URL: https://www.au.com/iphone/product/iphone-17/
- iPhone 17 / 512GB / RAM NoneGB / SOFTBANK / URL: https://www.softbank.jp/mobile/products/iphone/iphone-17/
- iPhone 17 / 512GB / RAM NoneGB / RAKUTEN / URL: https://network.mobile.rakuten.co.jp/product/iphone/iphone-17/
- iPhone 17 / 512GB / RAM NoneGB / UQ_MOBILE / URL: https://shop.uqmobile.jp/shop/lineup/
- Xperia 1 VII / 256GB / RAM 12GB / DOCOMO / URL: https://www.docomo.ne.jp/product/so51f/
- Xperia 1 VII / 256GB / RAM 12GB / SOFTBANK / URL: https://www.softbank.jp/mobile/products/smartphone/xperia1m7/
- POCO M7 Pro 5G / 256GB / RAM 8GB / SIM_FREE / URL: https://buy.mi.com/jp/products/all
- REDMI Note 14 Pro 5G / 256GB / RAM 8GB / MINEO / URL: https://mineo.jp/device/smartphone/redmi-note-14-pro-5g/
- REDMI Note 14 Pro 5G / 512GB / RAM 12GB / MINEO / URL: https://mineo.jp/device/smartphone/redmi-note-14-pro-5g/
- REDMI Note 15 5G / 256GB / RAM 8GB / MINEO / URL: https://mineo.jp/device/smartphone/
- POCO F6 Pro / 512GB / RAM 12GB / SIM_FREE / URL: https://buy.mi.com/jp/products/all
- POCO X8 Pro / 256GB / RAM 8GB / Y_MOBILE / URL: https://www.ymobile.jp/lineup/simfree/pocox8pro/
- POCO X8 Pro Max / 256GB / RAM 12GB / Y_MOBILE / URL: https://www.ymobile.jp/lineup/simfree/pocox8promax/
- REDMI Note 15 Pro 5G / 256GB / RAM 8GB / MINEO / URL: https://mineo.jp/device/smartphone/redmi-note-15-pro-5g-8gb-256gb/
- かんたんスマホ4 / 128GB / RAM 4GB / Y_MOBILE / URL: https://www.ymobile.jp/lineup/smartphone/kantan4/
- かんたんスマホ5 / 128GB / RAM 6GB / Y_MOBILE / URL: https://www.ymobile.jp/lineup/smartphone/kantan5/
- moto g66j 5G / 128GB / RAM 8GB / MINEO / URL: https://mineo.jp/device/smartphone/moto-g66j-5g/
- Libero Flip / 128GB / RAM 6GB / Y_MOBILE / URL: https://www.ymobile.jp/lineup/libero_flip/
- moto g64y 5G / 128GB / RAM 4GB / Y_MOBILE / URL: https://www.ymobile.jp/lineup/smartphone/motog64y/
- Mode1 Pocket / 256GB / RAM 8GB / MINEO / URL: https://mineo.jp/device/smartphone/mode1-pocket-8gb-256gb/
- Xiaomi 13T Pro / 256GB / RAM 12GB / SOFTBANK / URL: https://www.softbank.jp/mobile/products/smartphone/xiaomi-13t-pro/
- motorola razr 40s / 256GB / RAM 8GB / SOFTBANK / URL: https://www.softbank.jp/mobile/products/smartphone/motorola-razr-40s/
- AQUOS wish3 / 64GB / RAM 4GB / SOFTBANK / URL: https://www.softbank.jp/mobile/products/smartphone/aquos-wish3/
- OPPO Reno10 Pro 5G / 256GB / RAM 8GB / SOFTBANK / URL: https://www.softbank.jp/mobile/products/smartphone/oppo-reno10-pro-5g/
- AQUOS R8 pro / 256GB / RAM 12GB / SOFTBANK / URL: https://www.softbank.jp/mobile/products/smartphone/aquos-r8-pro/
- Xperia 10 V / 128GB / RAM 6GB / SOFTBANK / URL: https://www.softbank.jp/mobile/products/smartphone/xperia10m5/
- Xperia 1 V / 256GB / RAM 12GB / SOFTBANK / URL: https://www.softbank.jp/mobile/products/smartphone/xperia1m5/
- AQUOS sense7 plus / 128GB / RAM 6GB / SOFTBANK / URL: https://www.softbank.jp/mobile/products/smartphone/aquos-sense7-plus/
- Redmi Note 10T / 64GB / RAM 4GB / SOFTBANK / URL: https://www.softbank.jp/mobile/products/smartphone/redmi-note-10t/
- シンプルスマホ6 / 64GB / RAM 4GB / SOFTBANK / URL: https://www.softbank.jp/mobile/products/smartphone/simple-sumaho6/
- arrows We / 64GB / RAM 4GB / SOFTBANK / URL: https://www.softbank.jp/mobile/products/smartphone/arrows-we/
- Pixel 10 / 128GB / RAM 12GB / SOFTBANK / URL: https://www.softbank.jp/mobile/products/smartphone/pixel10/
- Pixel 10 / 128GB / RAM 12GB / RAKUTEN / URL: https://network.mobile.rakuten.co.jp/product/smartphone/google-pixel-10/
- Pixel 10 / 128GB / RAM 12GB / SIM_FREE / URL: https://store.google.com/jp/product/pixel_10
- Pixel 10 / 256GB / RAM 12GB / SOFTBANK / URL: https://www.softbank.jp/mobile/products/smartphone/pixel10/
- Pixel 10 / 256GB / RAM 12GB / RAKUTEN / URL: https://network.mobile.rakuten.co.jp/product/smartphone/google-pixel-10/
- Pixel 10 / 256GB / RAM 12GB / SIM_FREE / URL: https://store.google.com/jp/product/pixel_10
- Pixel 10 Pro / 256GB / RAM 16GB / SOFTBANK / URL: https://www.softbank.jp/mobile/products/smartphone/pixel10-pro/
- Pixel 10 Pro / 256GB / RAM 16GB / RAKUTEN / URL: https://network.mobile.rakuten.co.jp/product/smartphone/google-pixel-10-pro/
- Pixel 10 Pro / 256GB / RAM 16GB / SIM_FREE / URL: https://store.google.com/jp/product/pixel_10_pro
- Pixel 10 Pro / 512GB / RAM 16GB / SOFTBANK / URL: https://www.softbank.jp/mobile/products/smartphone/pixel10-pro/
- Pixel 10 Pro / 512GB / RAM 16GB / SIM_FREE / URL: https://store.google.com/jp/product/pixel_10_pro

## 確認済みの公式価格（2026-10-16確認）

Google Store Japanの構成・購入ページで確認したSIMフリー通常価格、楽天モバイルのPixel 11 256GB製品価格とiPhone 18 Pro / Pro Maxの容量別製品価格、およびドコモ・ソフトバンク公表の割引適用前一括価格（報道による公表値の照合）。下取り、返却プログラムの実質負担額、キャンペーン、ポイント還元は通常価格に含めない。

| 機種 | 容量 | RAM | 通常価格 | 価格出典 |
|---|---:|---:|---:|---|
| iPhone 18 Pro | 256GB | NoneGB | ¥263,230 | https://k-tai.watch.impress.co.jp/docs/news/2140379.html |
| iPhone 18 Pro | 256GB | NoneGB | ¥268,560 | https://corriente.jp/softbank-iphone-18-pro-18-pro-max-price/ |
| iPhone 18 Pro | 256GB | NoneGB | ¥255,900 | https://network.mobile.rakuten.co.jp/product/iphone/fee/ |
| iPhone 18 Pro | 512GB | NoneGB | ¥309,870 | https://k-tai.watch.impress.co.jp/docs/news/2140379.html |
| iPhone 18 Pro | 512GB | NoneGB | ¥315,360 | https://corriente.jp/softbank-iphone-18-pro-18-pro-max-price/ |
| iPhone 18 Pro | 512GB | NoneGB | ¥307,600 | https://network.mobile.rakuten.co.jp/product/iphone/fee/ |
| iPhone 18 Pro | 1024GB | NoneGB | ¥395,230 | https://k-tai.watch.impress.co.jp/docs/news/2140379.html |
| iPhone 18 Pro | 1024GB | NoneGB | ¥402,480 | https://corriente.jp/softbank-iphone-18-pro-18-pro-max-price/ |
| iPhone 18 Pro | 1024GB | NoneGB | ¥391,200 | https://network.mobile.rakuten.co.jp/product/iphone/fee/ |
| iPhone 18 Pro | 2048GB | NoneGB | ¥518,980 | https://k-tai.watch.impress.co.jp/docs/news/2140379.html |
| iPhone 18 Pro | 2048GB | NoneGB | ¥532,800 | https://corriente.jp/softbank-iphone-18-pro-18-pro-max-price/ |
| iPhone 18 Pro | 2048GB | NoneGB | ¥505,600 | https://network.mobile.rakuten.co.jp/product/iphone/fee/ |
| iPhone 18 Pro Max | 256GB | NoneGB | ¥291,500 | https://k-tai.watch.impress.co.jp/docs/news/2140379.html |
| iPhone 18 Pro Max | 256GB | NoneGB | ¥295,920 | https://corriente.jp/softbank-iphone-18-pro-18-pro-max-price/ |
| iPhone 18 Pro Max | 256GB | NoneGB | ¥288,900 | https://network.mobile.rakuten.co.jp/product/iphone/fee/ |
| iPhone 18 Pro Max | 512GB | NoneGB | ¥334,290 | https://k-tai.watch.impress.co.jp/docs/news/2140379.html |
| iPhone 18 Pro Max | 512GB | NoneGB | ¥339,840 | https://corriente.jp/softbank-iphone-18-pro-18-pro-max-price/ |
| iPhone 18 Pro Max | 512GB | NoneGB | ¥330,700 | https://network.mobile.rakuten.co.jp/product/iphone/fee/ |
| iPhone 18 Pro Max | 1024GB | NoneGB | ¥419,650 | https://k-tai.watch.impress.co.jp/docs/news/2140379.html |
| iPhone 18 Pro Max | 1024GB | NoneGB | ¥421,920 | https://corriente.jp/softbank-iphone-18-pro-18-pro-max-price/ |
| iPhone 18 Pro Max | 1024GB | NoneGB | ¥415,400 | https://network.mobile.rakuten.co.jp/product/iphone/fee/ |
| iPhone 18 Pro Max | 2048GB | NoneGB | ¥543,400 | https://k-tai.watch.impress.co.jp/docs/news/2140379.html |
| iPhone 18 Pro Max | 2048GB | NoneGB | ¥542,880 | https://corriente.jp/softbank-iphone-18-pro-18-pro-max-price/ |
| iPhone 18 Pro Max | 2048GB | NoneGB | ¥529,800 | https://network.mobile.rakuten.co.jp/product/iphone/fee/ |
| Pixel 11 | 256GB | 12GB | ¥139,900 | https://network.mobile.rakuten.co.jp/product/smartphone/google-pixel-11/ |
| Pixel 11 | 256GB | 12GB | ¥136,800 | https://store.google.com/jp/config/pixel_11?hl=ja |
| Pixel 11 | 512GB | 12GB | ¥156,800 | https://store.google.com/jp/config/pixel_11?hl=ja |
| Pixel 11 Pro | 256GB | 12GB | ¥174,800 | https://store.google.com/jp/config/pixel_11_pro?hl=ja |
| Pixel 11 Pro | 512GB | 16GB | ¥194,800 | https://store.google.com/jp/config/pixel_11_pro?hl=ja |
| Pixel 11 Pro | 1024GB | 16GB | ¥234,800 | https://store.google.com/jp/config/pixel_11_pro?hl=ja |
| Pixel 11 Pro XL | 256GB | 12GB | ¥207,800 | https://store.google.com/jp/config/pixel_11_pro?hl=ja |
| Pixel 11 Pro XL | 512GB | 16GB | ¥227,800 | https://store.google.com/jp/config/pixel_11_pro?hl=ja |
| Pixel 11 Pro XL | 1024GB | 16GB | ¥267,800 | https://store.google.com/jp/config/pixel_11_pro?hl=ja |
| Pixel 11 Pro Fold | 256GB | 16GB | ¥279,900 | https://store.google.com/jp/config/pixel_11_pro_fold?hl=ja |
| Pixel 11 Pro Fold | 512GB | 16GB | ¥299,900 | https://store.google.com/jp/config/pixel_11_pro_fold?hl=ja |

## 今回の仕様修正

- 楽天モバイル公式ページでPixel 11 256GBの税込製品価格139,900円を確認し、RAKUTEN販売登録に出典URL・確認日付きで追加。
- Apple Japanの公式購入ページでiPhone 18 Pro / Pro Maxの2TBを含む4容量を確認し、SIMフリー価格を登録。ドコモ・ソフトバンク・楽天モバイルのiPhone 18 Pro／Pro Max価格を、出典・確認日・条件付きで登録。


## 次の処理

1. 販売先公式ページを開き、モデル・容量・色・購入方法・割引条件を照合する。
2. 価格が確認できた場合だけ、取得日と出典URLを含めて `priceOptions` に登録する。
3. 価格未掲載、ログイン限定、割引条件不明、またはページ到達不可の場合は価格を捏造せず未確認のまま残す。
4. 登録後、診断・比較・購入先詳細でチャネルと容量の取り違えがないことをSQLite/Androidテストで確認する。

## 検証範囲

JSON構造と登録件数の監査のみ。公式ページ全件照合、Gradle/KSPビルド、Roomランタイム、Android JUnit、エミュレータ・実機試験は未実施。


## 0.04.68 集計メタデータ修正記録

`phones.json` の `counts.priceOptions` が38と誤記されていたため、ネストされた実レコードを再集計し47へ修正した。価格登録レコード自体は変更していない。価格未登録450件、AVAILABLEかつ価格未登録405件、URL未登録2件は引き続き未解決。
