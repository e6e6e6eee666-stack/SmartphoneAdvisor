# Seed-to-catalog coverage audit 0.04.20

Static source comparison of sales seed constructors against `phones.json` model names, storage, and declared identity fields.
This report does not verify official facts, live prices/URLs, Room runtime import, Gradle build, or device behavior.

Seed records parsed: 540

## Counts

- UNIQUE_MATCH: 540

## Records requiring review

None

## Safe interpretation

- `UNIQUE_MATCH`: one catalog model remains after all identity fields present in that seed row and its storage/RAM are checked.
- `IDENTITY_OR_RAM_CONFLICT`: model/storage candidate exists but the seed's declared year/platform/manufacturer or RAM conflicts with the catalog. Do not force-link it.
- `VARIANT_NOT_IN_CATALOG`: model exists but the requested storage is not in its catalog variants. This may be a catalog gap or seed error; verify source before changing either.
- `MODEL_NOT_IN_CATALOG`: exact model name is not in the catalog. Check naming aliases or catalog completeness; do not guess.
- `AMBIGUOUS_MATCH`: multiple candidates remain; do not auto-link.
