# Work log — Android CI SDK package correction

- **Task:** BLD-01 / A-19, remove an unsupported/unjustified SDK Build Tools package request from CI.
- **Finding:** CI requested `build-tools;37.0.0`; AGP 9.4.0 official compatibility notes list Build Tools 36.0.0 as the default and API 37 as the maximum supported API level.
- **Change:** `.github/workflows/android-validation.yml` now installs `build-tools;36.0.0`; `tools/test_android_validation_workflow.py` asserts the corrected package and rejects the previous one.
- **Documentation:** updated current inventory, formal plan, task register, and validation record.
- **Not changed:** Kotlin source, `phones.json`, Gradle plugin versions, `versionName=0.04.89`, `versionCode=137`.
- **Verification boundary:** structural test only. No CI run, SDK download, APK build, JUnit, emulator, Room runtime, or device test was executed. G1 remains blocked.
- **Source:** https://developer.android.com/build/releases/agp-9-4-0-release-notes

## Verification results after the correction

- `python tools/test_android_validation_workflow.py`: PASS.
- `python tools/test_project_dependency_order.py`: PASS.
- `python tools/test_gradle_wrapper_bootstrap.py`: PASS.
- Current Python regression suite: 51/51 PASS, 0 FAIL, freshly rerun in five batches after clearing the previous batch reports. The first combined shell invocation hit the execution time limit during batch 4; batch 4 and batch 5 were then rerun independently, and the merge guard generated the final report only after confirming all batch names/order.
- `python -m compileall -q tools`: PASS.
- Android build / JUnit / emulator / Room / physical device: NOT RUN; no Gradle/Wrapper/Android SDK/adb available in this execution environment.
