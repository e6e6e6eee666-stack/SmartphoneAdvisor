# Release diff audit: 0.05.00 → 0.05.01

## Version
- `versionName`: `0.05.00` → `0.05.01`
- `versionCode`: `148` → `149`

## Intended application-data change
- Added one price option to the existing IIJmio sale listing for ALT MIVEケースマ (3GB/32GB).
- Normal price: JPY 34,800 tax included; source: https://www.iijmio.jp/info/iij/1787302297.html; checked 2026-10-21.
- Campaign price JPY 32,800 is described as a conditional, limited-time MNP + voice SIM/eSIM price, not recorded as the normal price.
- No model, variant, or sales-listing identity added/removed; historic baseline checks passed.

## Counts after change
- Models: 195
- Variants: 315
- Sales listings: 511
- Price options: 95
- Audit findings: 45
- Unpriced listings: 434; AVAILABLE unpriced: 389.
- `phones.json` SHA-256: `b009dbf125d7d12ffd0d7fda142aab965f96bb3133dd192ffee458b8b4d012d2`

## Validation
- Current regression suite: 62/62 PASS, six batches; merged report: `test_results_0.05.01.txt`.
- Python compileall: PASS.
- Price-gap, follow-up, and sales-fact completeness audits: PASS.
- Android build and runtime/device tests remain unverified; this release must not be described as an Android-build-verified package.

## Packaging decision
No ZIP created for this individual small catalog improvement, consistent with the instruction to package only at a meaningful medium/major milestone.
