# SmartphoneAdvisor マスタープラン更新 0.04.88

## 今回の進捗
品質・監査工程の次の停止要因は、ソースの静的検査から先へ進むためのAndroid実ビルド環境がないこと。0.04.86では、Android Studioの英語UIを前提に、プロジェクトを開く位置、SDK要件、Gradle同期、ビルド、Room smoke test、主要画面の実操作と証跡の残し方を日本語で明文化した。

## 守るべき検証区分
- Pythonソース契約テスト合格 ≠ Kotlinコンパイル成功。
- ZIP整合性合格 ≠ Androidアプリがビルド可能。
- APK生成 ≠ Room登録や画面操作が正常。
- `AppDatabaseSmokeTest.kt` の存在 ≠ Android上でテスト実行済み。
- 価格や販売情報は公式根拠を確認し、未確認を推測で埋めない。

## 次工程の順序
1. Gradle WrapperをAGP/Kotlin/KSPに適合する公式Gradle版で再現可能に追加。
2. Android Gradle/KSPビルドとKotlin/JUnitを実行。
3. `AppDatabaseSmokeTest` およびJSON→Room取込、重複、価格根拠、migrationを実DBで検証。
4. 1台診断、検索、詳細、比較、お気に入り、保存診断を実機/エミュレーターで検証。
5. その後、価格未登録の販売登録を公式根拠付きで補完。

## 現在の制約
現環境ではGradle Wrapper、Gradle本体、Android SDKが利用できず、Androidビルド・ランタイム試験は未実施。詳細手順は `ANDROID_STUDIO_BUILD_GUIDE_0.04.86.md`。


## 0.04.86 追加項目：Wrapper生成手段の整備
- 公式Gradle 9.6.0配布物をSHA-256検証してからWrapperを生成するWindowsスクリプトを追加。
- Android Studioでの実ビルドは未実施。Wrapper生成、Gradle同期、Kotlin/Roomテスト、実機操作を次の検証ゲートとする。


## 0.04.87追加作業：クラウドAndroidビルド経路
- 大項目14「品質・監査」／16「テスト」／18「公開前最終確認」：Android Studioのローカル操作に依存しないよう、GitHub ActionsでGradle 9.6.0を用意してAndroid SDKをセットアップし、APKビルド・JVMテスト・API 35エミュレーターでのRoom instrumentation testを実行するワークフローを追加。
- 成功時debug APK、失敗時ビルドレポートを成果物として保存する設計。Wrapperが未同梱でもCIでGradleをセットアップして実行する。
- Python回帰テスト49/49 PASS（5バッチ）、compileall PASS。静的整合性検査は合格。
- 未完了：GitHub Actionsワークフロー自体の実行、Android Gradle/KSPビルド、Kotlin/JUnit、Room実ランタイム、実機UIテスト。ワークフロー定義の追加はビルド成功を意味しない。
- 次工程：GitHub Actions実行可能環境でCIを実行し、エラーがあれば修正してAPKとRoomテストの実結果を得る。


## 0.04.88追加作業：回帰レポートの信頼性修正
- 回帰テストのバッチ集計で古いレポートが誤って再利用される問題を修正。期待されるテスト名・順序と一致しない結果は統合しない。
- 0.04.88の回帰テスト50/50 PASS、compileall PASS。
- 次工程はクラウドビルドの実行。Actionsワークフローを追加しただけではAPK生成・Room実行を確認したことにはならない。
