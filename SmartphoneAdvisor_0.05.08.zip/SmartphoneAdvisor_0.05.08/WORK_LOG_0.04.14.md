# SmartphoneAdvisor 作業記録 0.04.14

## 1. 目的・完了条件
- Seed処理でモデル名だけを使った曖昧なモデル解決をなくし、同名モデルの誤結合リスクを低減する。
- 既存モデルが存在する場合も、容量/RAMバリアントが不足していれば追加できるようにする。
- IGNORE挿入時に無効ID（-1）を後続へ流さない。

## 2. 実施内容
- `PhoneDao.kt` にメーカーID・モデル名・OS・発売年を条件とする `getModelIdByIdentity` を追加。
- `CatalogExpansion.kt` のモデル検索をモデル名単独から完全キーへ変更。
- `SeedData.kt` の追加モデル処理をモデル単位ではなく、モデルと容量/RAMバリアント単位で存在確認する形に修正。
- IGNORE挿入戻り値が負数の場合は再検索し、解決できなければ明示的エラーにする。
- `tools/audit_seed_identity_safety.py` と監査記録を追加。
- バージョンを 0.04.14 / versionCode 63 に更新。

## 3. 検証結果
- `audit_seed_identity_safety.py`: PASS（6チェック）。
- `audit_diagnostic_catalog.py`: PASS、JSON構造エラー0、URL警告2。
- `audit_seed_model_grouping.py`: PASS。
- `audit_json_room_seed_linkage.py`: PASS（これはSeedData初期リストとの静的比較のみ）。
- Gradle/Kotlinビルド、JUnit、Room実行、実機確認: 未実施。

## 4. 問題・未確認事項
- 販売Seedの一部はモデル名・容量・RAM中心でバリアントを検索している。全販売経路でメーカー/OS/年を含めた一意性確認が必要。
- 既存データベースにある重複モデル行をこの変更だけで統合するものではない。
- JSON全313バリアントのRoom一括登録処理はまだ実装していない。

## 5. 進捗位置
- 大項目3「データ登録システム」および大項目4「診断」のデータ連携前提整備。
- 中項目: モデル/バリアント識別と登録経路の安全性。
- 小項目: 初期Seed・CatalogExpansionのモデルID解決。
- バージョン: 0.04.14 / versionCode 63。

## 6. 次工程
- 販売Seed各経路のモデル/バリアント検索条件を監査し、誤結合し得る箇所を特定。
- JSON→Room全件取込は、既存の手入力属性・価格を上書きしない設計を確定してから実装する。

## 7. 証跡
- `app/src/main/java/jp/smartphoneadvisor/app/data/PhoneDao.kt`
- `app/src/main/java/jp/smartphoneadvisor/app/data/CatalogExpansion.kt`
- `app/src/main/java/jp/smartphoneadvisor/app/data/SeedData.kt`
- `tools/audit_seed_identity_safety.py`
- `SEED_IDENTITY_SAFETY_AUDIT_0.04.14.txt`
- `PROJECT_MASTER_PLAN_0.04.14.md`
