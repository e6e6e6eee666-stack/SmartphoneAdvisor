# SmartphoneAdvisor 0.04.86 — Android Studio 実ビルド・実機確認ガイド

このガイドは、Android Studio の画面が英語でも進められるよう、表示される英語メニュー名を併記しています。アプリがビルドできたと確認するまでは「完成」と扱いません。

## 1. ZIPを展開してプロジェクトを開く

1. `SmartphoneAdvisor_0.04.86_android-studio-validation-guide.zip` をPCに保存します。
2. エクスプローラーでZIPを右クリックし、`すべて展開`（Extract All）を選びます。
3. 展開先の中にある `0.04.86` フォルダーを確認します。`app` フォルダーと `settings.gradle.kts` が同じ階層にある場所がプロジェクトのルートです。
4. Android Studio を起動し、開始画面の `Open` を選びます。開始画面でない場合は `File > Open...` を選びます。
5. 手順3の `0.04.86` フォルダーを選択して開きます。ZIPファイルそのものや、内側の `app` フォルダーだけを選ばないでください。

## 2. Gradle Wrapperを公式配布物から生成する（今回追加）

このZIPにはバイナリのWrapperを事前同梱していません。代わりに、Windows上で公式Gradle配布物を取得し、SHA-256を照合したうえで、公式の `wrapper` タスクから必要ファイルを生成するスクリプト `PREPARE_GRADLE_WRAPPER_WINDOWS.ps1` を同梱しました。Android Gradle Plugin 9.4.0の最小Gradle要件は9.6.0です（[Android Developers公式互換性表](https://developer.android.com/build/releases/about-agp)）。  

1. ZIPを展開し、`0.04.86` フォルダーを開きます。
2. フォルダー内の空白部分を右クリックし、`ターミナルで開く`（Open in Terminal）を選びます。
3. 次のコマンドを1行ずつ実行します。
   ```powershell
   Set-ExecutionPolicy -Scope Process Bypass
   .\PREPARE_GRADLE_WRAPPER_WINDOWS.ps1
   ```
4. スクリプトは公式Gradle 9.6.0配布ZIP（約135 MB）をダウンロードし、公開SHA-256を照合します。さらに生成されたWrapper JARのSHA-256も公式公開値と照合します。値が一致しなければ処理を中断します。
5. `完了` と表示され、`GRADLE_WRAPPER_SETUP_0.04.86.txt` が生成されたら、次の同期手順へ進みます。

**注意：** この操作にはインターネット接続とJava 17以上が必要です。Android Studio内蔵Javaが自動検出されない場合は、表示に従って `jbr\bin\java.exe` の場所を入力してください。スクリプトはGradle配布物を検証しますが、アプリのビルド成功までは保証しません。

## 3. 最初の同期で確認すること

Android Studio がプロジェクトを読み込んだら、`Sync Now` または `File > Sync Project with Gradle Files` が表示される場合は実行します。初回はネット接続が必要で、依存ファイルの取得に時間がかかることがあります。

**上のWrapper生成スクリプトが正常終了したことを確認してから同期してください。** スクリプトが失敗した場合は、Gradleバージョンを推測で変更せず、エラー全文を保存してください。

## 4. Android SDKの確認

このプロジェクトは `compileSdk = 37`、`targetSdk = 36`、`minSdk = 35` です。Android Studio の `Tools > SDK Manager` を開き、SDK Platforms で API 37 が提供・選択できるかを確認してください。API 37 が一覧にない場合は、無理に別APIへ書き換えず、その画面を記録してください。SDK Tools タブでは Android SDK Build-Tools と Platform-Tools が導入済みかも確認します。

## 5. ビルド（同期が正常終了した場合のみ）

1. メニュー `Build > Make Project` を選びます。
2. 下部の `Build` または `Build Output` を開き、最後に `BUILD SUCCESSFUL` と表示されたか確認します。
3. `BUILD SUCCESSFUL` 以外の場合、最初の `What went wrong`、`Caused by`、`e:` を含む箇所から最後までを保存してください。エラーを見ずに成功扱いしないでください。
4. APK生成だけを確認する場合は `Build > Build Bundle(s) / APK(s) > Build APK(s)` を選びます。ただし、APKが生成されたことだけでは、アプリが正常動作する証拠にはなりません。

## 6. RoomスキーマのAndroidテスト

同期・ビルドが成功し、API 35以上のAndroid端末またはエミュレーターが利用できる場合に実行します。

1. エミュレーターを使う場合は `Tools > Device Manager` から端末を作成します。API 35以上を選びます。
2. メニュー `Run > Edit Configurations...` で構成を追加できる場合は、Android Instrumented Tests / Android Instrumented Tests の構成を選び、`app` モジュールと `jp.smartphoneadvisor.app.data.AppDatabaseSmokeTest` を指定します。Android Studioの表示はバージョンによって多少異なります。
3. テストを実行し、`AppDatabaseSmokeTest` が成功したか確認します。このテストは現在のRoomデータベースをメモリ上で開き、主要DAOを取得できるかを検査します。
4. テスト構成を設定できない場合は、テストクラスを開いて左側の緑色の実行アイコンから実行します。

## 7. アプリを起動して確認する

ビルド成功後、API 35以上の端末またはエミュレーターを選び、上部の実行先を設定して `Run 'app'`（緑の三角）を押します。最低限、次を確認してください。

- 起動直後にクラッシュしない。
- 1台診断の質問を選び、結果と理由が表示される。
- 機種一覧・検索・詳細画面が開く。
- 比較への追加、お気に入り、診断パターン保存が行える。
- カタログの読込・登録に失敗した場合、無言で成功扱いせず警告が表示される。

画面が開いたことだけでデータの正しさを保証するものではありません。表示された機種・価格・販売情報と、登録件数や公式根拠の検証は別に行います。

## 8. こちらに返してほしい結果

次のいずれかを、そのまま返してください。

- 同期に失敗：エラー全文またはスクリーンショット
- ビルドに失敗：`Build Output` のエラー全文
- ビルド成功：`BUILD SUCCESSFUL` と表示されたこと
- Roomテスト：成功/失敗とテスト出力
- 実機確認：どの画面まで開けたか、クラッシュや警告の有無

パスワード、APIキー、個人情報が含まれていないことを確認してからログを共有してください。

## 現時点の未確認事項

この開発環境ではGradle本体・Android SDKを利用できなかったため、Wrapper生成スクリプト自体をWindows上で実行していません。Android Gradle/KSPビルド、Kotlin/JUnit、Room instrumentation test、実機操作も未実施です。上記はユーザー側で必ずビルドするよう丸投げする意図ではなく、現環境で実行できない検証を明確に分離するための手順書です。
