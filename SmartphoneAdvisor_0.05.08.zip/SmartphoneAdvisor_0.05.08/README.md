# SmartphoneAdvisor — 開発記録（最新版 0.05.06）

## 0.05.06 — MainActivity.kt のコンパイルエラー修正

- `purchaseChannel` が nullable (`String?`) であることに合わせ、DB検索前に `orEmpty()` を適用。
- `String.ifBlank { null }` は型不一致になるため、`takeIf { it.isNotBlank() }` に変更。
- `scope.launch` を使用するため `kotlinx.coroutines.launch` を import。
- versionName `0.05.06` / versionCode `154`。
- `tools/test_mainactivity_compile_regressions_0_05_06.py` を追加し、今回の修正が戻らないように検査。
- 個別のPython検査3件と `compileall` はPASS。回帰スイートは43/71件までPASSした後にタイムアウトし、全件完了は未確認。Android Gradleビルドはこの作業環境で実行できていないため、GitHub Actions上のビルド成功は未確認。

## 0.05.05 — IIJmio価格根拠と販売リンクの整合性修正

## 0.05.05 — IIJmio価格根拠と販売リンクの整合性修正

- versionName 0.05.05 / versionCode 152。
- Galaxy S26 256GB／Galaxy S26+ 256GBのIIJmio販売リンクを、両機種の税込通常価格の出典として登録済みの公式お知らせURLに揃えました。価格額・販売状態・型番欄は変更していません。
- 汎用カテゴリURLの監査対象は9登録から7登録へ減少。根拠のない容量別URLや価格は追加せず、残る512GB登録などは汎用URLのまま保留しています。
- 監査CSV/Markdown、回帰テスト、歴史的カタログ保持ガードを同期しました。価格未登録429件／販売中・価格未登録385件、カタログ195機種／315バリエーション／511販売登録／100価格選択肢／監査指摘45件を維持。
- Python回帰テストは、配布前に現行マニフェスト全件を再実行して結果を記録します。
- Android Gradle build / Kotlin JUnit / Room runtime / emulator / physical-device testing remains unverified. GitHubリポジトリ・ログインも不明のため、GitHub Actions実行済みとは扱いません。

## 0.05.03 — IIJmio／au価格選択肢追加

- versionName 0.05.03 / versionCode 151。Galaxy S26／S26+／S26 UltraのIIJmio通常価格とXperia 1 VIII／Xperia 10 VIIIのau価格情報を追加。
- この版は直前の基準版であり、最新版は0.05.06です。


## 0.05.01 — MIVEケースマのIIJmio通常価格を根拠付きで登録

- versionName 0.05.01 / versionCode 149。
- IIJmio公式のお知らせで、MIVEケースマ 3GB/32GBの通常価格34,800円（税込）を確認し、価格根拠URLと確認日を登録。MNP転入・音声SIM/eSIM同時申込時の期間限定32,800円は条件欄に分離して明記。
- 型番AT-M140Jを登録。機種・バリエーション・販売登録は維持し、価格選択肢は94件から95件に増加。
- Android Gradle build / Kotlin JUnit / Room runtime / emulator / physical-device testing remains unverified.

## 0.05.00 — Galaxy S26シリーズ公式SIMフリー価格の一括整備

- versionName 0.05.00 / versionCode 148。
- Samsung Japan公式購入ページの現行価格に基づき、Galaxy S26（256GB 155,800円 / 512GB 183,300円）、S26+（256GB 192,130円 / 512GB 219,100円）、S26 Ultra（256GB 239,800円 / 512GB 268,600円 / 1TB 334,200円）を登録。すべて税込通常価格で、下取り・キャンペーン・ポイント還元を含まない。
- 既存の機種・容量バリエーション・キャリア販売登録は維持し、S26+とS26 Ultraは公式SIMフリー販売登録を追加。
- カタログ件数：195機種 / 315バリエーション / 511販売登録 / 95価格選択肢。監査指摘45件。
- 専用回帰テストをシリーズ全体に拡張。古い件数を固定したテストと、価格根拠・既存データの検査を個別に確認。
- Android Gradle build / Kotlin JUnit / Room runtime / emulator / physical-device testing remains unverified.

## 0.04.99 — Galaxy S26公式オンラインショップ価格を追加

- versionName 0.04.99 / versionCode 147。
- Galaxy S26 12GB/256GBを155,800円、12GB/512GBを183,300円（税込）で登録。後続版0.05.00でシリーズ全体へ拡張。

## 0.04.98 — REDMAGIC 11S Pro公式販売登録・容量別通常価格追加

- versionName 0.04.98 / versionCode 146。
- REDMAGIC日本公式購入ページで確認できるREDMAGIC 11S Proの販売登録を追加。12GB/256GBは149,800円、16GB/512GBは172,800円（税込通常表示価格）。先行予約割引・クーポン価格とは分離。
- カタログ件数：195機種 / 315バリエーション / 504販売登録 / 87価格選択肢。価格未登録販売登録435件、販売中かつ価格未登録390件（再監査で確認）。
- 専用回帰テスト、現行件数の回帰期待値、価格欠損監査を更新。Android Gradle build / Kotlin JUnit / Room runtime / emulator / physical-device testing remains unverified.

## 0.04.95 — Zenfone 12 Ultra 16GB/512GBバリエーション追加

- versionName 0.04.95 / versionCode 143。
- ASUS公式店舗（ASUS Store 楽天市場店）の掲載内容に基づき、Zenfone 12 Ultra 16GB/512GBを独立バリエーションとして追加。通常価格169,800円（税込）を登録し、期間限定特別価格152,820円は条件欄で明確に区別。
- 価格オプション数85、機種195、バリエーション315、販売登録502。価格未登録販売登録435、販売中かつ価格未登録390。ROG Phone 9 Pro（512GB）とROG Phone 9 Pro Edition（1TB）のASUS公式価格を追加。
- 512GB専用回帰テストを追加し、既存テストの古いカタログ件数期待値を同期。現行回帰テスト58/58合格。価格欠損監査CSV/Markdownを現行JSONから再生成。
- Android Gradle build / Kotlin JUnit / Room runtime / emulator / physical-device testing remains unverified in this environment.

## 0.04.97 — ROG Phone 9 Proシリーズ公式価格追加
- versionName 0.04.97 / versionCode 145。
- ASUS日本公式ページに基づきROG Phone 9 Pro 16GB/512GB（189,800円）とROG Phone 9 Pro Edition 24GB/1TB（239,800円）の通常価格、型番、出典、確認日を追加。
- 価格欠損監査・回帰テストを更新。

## 0.04.94 — Zenfone 12 Ultra 12GB/256GB公式価格追加・価格監査更新

- versionName 0.04.94 / versionCode 142。
- ASUS公式店舗（ASUS Store 楽天市場店）に掲載されたZenfone 12 Ultra 12GB/256GBの通常価格149,800円（税込）を登録。期間限定特別価格134,820円は通常価格と混同しないよう条件に明記。
- 0.04.94時点の価格オプション数81、価格未登録販売登録438、販売中かつ価格未登録393。
- 回帰テストで旧カタログ件数を固定していた期待値を更新し、Zenfone 12 Ultraの出典・通常価格・条件を確認する専用テストを追加。
- Android Gradle build / Kotlin JUnit / Room runtime / emulator / physical-device testing remains unverified in this environment.

## 0.04.93 — ASUS ROG Phone 9公式価格追加・価格欠損監査の更新

- versionName 0.04.93 / versionCode 141。
- ASUS日本公式ページで確認できるROG Phone 9 12GB/256GBの税込159,800円をカタログに追加。公式ページに掲載されたブラック/ホワイトの同価格を「全色共通」の通常価格として記録し、キャンペーン・ポイント還元を含めない。
- `phones.json` の価格選択肢は79件から80件に更新。機種195、バリアント314、販売登録501、監査指摘45は維持。
- 価格欠損監査を再生成：価格未登録439件、販売中・価格未登録394件、型番未登録364件、カテゴリ/トップページURL9件。
- 価格総数79件など古い件数を固定していた回帰テストを更新し、現行回帰スイート55/55合格。
- 詳細: `WORK_LOG_0.04.93_ROG_Phone_9_ASUS_official_price.md`、`test_results_0.04.93.txt`、`RELEASE_DIFF_AUDIT_0.04.92_to_0.04.93.md`。
- Android Gradleビルド、Kotlin/JUnit実行、Room実ランタイム、エミュレーター、実機動作は未検証。

## 0.04.79 — Room取込前の価格根拠を厳格化

- `PhoneCatalogRoomImporter.validate()` が価格確認日を必須化し、実在する日付（YYYY-MM-DD）として解析できることを取込前に確認。
- 価格根拠URLを必須化し、有効なHTTPS URLでなければDBトランザクション開始前にカタログ全体を拒否するよう修正。
- これにより、確認日の欠落・不正日付・価格根拠URL欠落があっても価格レコードだけが黙ってスキップされる状況を防止。
- 現行版ガードを 0.04.79 / versionCode 127 に同期。
- Python回帰テスト43件を実行。Android Gradle/KSPビルド、Room実ランタイム、実機テストは未実施。
- 詳細: `WORK_LOG_0.04.79.md`、`VALIDATION_0.04.79.txt`、`IMPORTER_PRICE_PROVENANCE_GUARD_0.04.79.md`。


## 0.04.80 検証更新
- 価格根拠のKotlin JUnitケースを追加：実在しない日付、HTTP/ホストなしURL、根拠欠落を検証。
- Python回帰テスト44/44合格、Python compileall合格。
- Android Gradle/KSPビルド、Kotlin JUnit実行、Room実取り込み、実機テストは未実施。


## 0.04.81 — カタログ取込失敗・競合の利用者通知

- `MainActivity` はカタログ取込失敗をログに残すだけでなく、利用者に警告ダイアログを表示する。既存Seedデータで起動を継続する場合でも、最新カタログが反映されていない可能性を明示する。
- 取込結果に競合が残った場合も、競合件数を表示して完全登録と誤認させない。
- Python回帰テストはソース契約を検査するもの。Android Gradle/KSPビルド、JUnit実行、Room実ランタイム、実機試験は未実施。


## 0.04.82 — JSON読込失敗時の起動継続と警告

- `phones.json` の読み込み・内容検証も例外経路として捕捉。失敗時はログと利用者向け警告を出し、JSON→Room取込をスキップして既存Seed/Roomデータで初期化を継続する。
- Room取込の失敗・競合警告は0.04.81から維持。
- versionName 0.04.82 / versionCode 130。
- Pythonソース契約テストと回帰テストを実施。Androidビルド・JUnit・Room実ランタイム・実機試験は別途必要。

## 0.04.83 — システム見直し・起動初期化エラーの可視化

- JSON読込/Room取込以外に、データベース生成・Seed初期化などで失敗した場合も、ログと日本語ダイアログで通知し、再試行できるよう修正。
- 現行版の主要構成・記録・Room migration chain・エラー経路を検査する統合ゲート `tools/system_integrity_gate.py` を追加。
- 32本のテスト/監査スクリプトで、アプリ版番号の固定参照を動的なGradleメタデータ確認へ変更。現行回帰テスト46/46合格。
- 回帰テストは `python tools/run_current_regression_suite.py` から実行でき、必要なら `--batch-index 0`〜`3` で分割可能。
- システム監査記録: `SYSTEM_ARCHITECTURE_REVIEW_0.04.83.md`。
- 重要: Gradle WrapperとAndroid instrumentation testがなく、Androidビルド/実機実行は未検証。静的検査合格をアプリ動作確認済みとは扱わない。


## 0.04.84 — DB ready前のRoomアクセスと回帰テストの修繕
- versionName 0.04.84 / versionCode 132。
- DB初期化失敗時、画面表示前にComposable内のRoom Flow取得で例外が発生し得る経路を修正。
- 保存診断の下書き読込失敗を捕捉し、再試行可能なエラーを表示。
- バージョン固定の起動テストを版番号非依存へ変更し、回帰テストを追加。
- `AppDatabaseSmokeTest.kt` を追加。Android環境で未実行のため、Room実行確認は未完了。
- 詳細: `WORK_LOG_0.04.84.md`、`SYSTEM_ARCHITECTURE_REVIEW_0.04.84.md`。


## 0.04.85 — Android Studio実ビルド検証の手順を整備
- versionName 0.04.85 / versionCode 133。
- Android Studioが英語UIでも進められるよう、プロジェクトを開く場所、SDK要件、ビルド結果、Room instrumentation test、主要画面の確認手順を日本語で文書化。
- Gradle Wrapperが欠けていることを明示し、同期エラーを成功扱いしない手順にした。Wrapperを推測で生成したり、Android実行テスト済みと誤記したりしていない。
- 詳細: `ANDROID_STUDIO_BUILD_GUIDE_0.04.85.md`、`WORK_LOG_0.04.85.md`。


## 0.04.86 — Gradle Wrapperを安全に生成するWindowsスクリプト
- versionName 0.04.86 / versionCode 134。
- Gradle Wrapperが欠けたままの状態を改善するため、公式Gradle 9.6.0配布ZIPのSHA-256と生成後Wrapper JARのSHA-256を検証してから、`gradlew` 等をプロジェクトに追加するPowerShellスクリプトを用意。
- AGP 9.4.0の最小Gradle要件9.6.0に合わせた。Gradle 9.6.0の配布物チェックサムとWrapper JARチェックサムはGradle公式チェックサム一覧を参照。
- Python回帰テスト48/48合格を目標に検証。スクリプトはこの環境では実行しておらず、Androidビルド/JUnit/Room/実機動作も未検証。
- 詳細: `PREPARE_GRADLE_WRAPPER_WINDOWS.ps1`、`ANDROID_STUDIO_BUILD_GUIDE_0.04.86.md`、`WORK_LOG_0.04.86.md`。


## 0.04.87 — Android Studioに依存しないクラウドビルド経路を追加
- versionName 0.04.87 / versionCode 135。
- GitHub ActionsでGradle 9.6.0とAndroid SDKを準備し、Python回帰テスト、APKビルド、JVMテスト、エミュレーター上のRoom instrumentation testを順に実行するワークフローを追加。
- 成功時はdebug APKを成果物として14日間保存し、失敗時はビルドレポートを保存する。プロジェクト内にGradle Wrapperがなくても、CI側でGradleをセットアップして実行する構成。
- ワークフロー定義の構造テストを追加。ローカルでのPython回帰テストは実行するが、GitHub Actionsの実行結果を意味しない。ワークフローはリポジトリにpushされて初めて実行可能。
- Androidビルド・Kotlin/JUnit・Room実行・実機動作は、CI実行成功が確認できるまで未検証。
- 詳細: `.github/workflows/android-validation.yml`、`WORK_LOG_0.04.87.md`、`VALIDATION_0.04.87.txt`。


## 0.04.89 — JSONカタログ件数メタデータの整合性ガード
- versionName 0.04.90 / versionCode 138。
- `phones.json` の `counts` が存在する場合、読み込んだ実データの機種・バリアント・販売登録・価格選択肢・監査指摘件数と照合。不一致や必須カウントの欠落を検知したら、カタログ取込前に明示的に失敗させる。
- Kotlin/JUnitテストを追加し、件数不一致を拒否するケースと一致するケースを確認する構成にした。
- Python回帰スイートにもソース契約テストを追加。
- Androidビルド/Kotlinテストは、この実行環境にGradle/Android SDKがないため未実行。

## 0.04.88 — 回帰テスト集計の誤報防止
- versionName 0.04.88 / versionCode 136。
- 分割実行の際に古い同バージョンのバッチレポートが残っていると、テスト件数・合格数が誤って集計される問題を修正。
- 現行マニフェストの期待テスト名と各バッチ結果を照合し、不一致なら集計レポートを生成せず警告する。合格数・失敗数は検証済みの個別結果行から算出。
- 新規ガードテストを含むPython回帰テスト50/50合格（5バッチ）。Python compileall合格。
- Android Gradle/KSPビルド、Kotlin/JUnit、Room実行、GitHub Actions実行、実機動作は未確認。
- 詳細: `WORK_LOG_0.04.88.md`、`VALIDATION_0.04.88.txt`、`test_results_0.04.88.txt`。


## 2026-10-20 — 工程表・台帳の正本整合性修正（文書のみ）
- `PROJECT_MASTER_PLAN_CURRENT.md` をG0〜G8依存ゲート方式の現行正本に統一。
- 旧20大項目は追跡用領域として保持し、項目数を固定しない。旧版は `PROJECT_MASTER_PLAN_20_MAJOR_LEGACY_2026-10-18.md` に履歴保存。
- 作業台帳の矛盾する20項目固定文言を修正。
- アプリソース・JSON・Gradle設定・アプリ版は変更なし。Android実ビルド/Room/実機検証は未実施。詳細：`PLAN_CONSISTENCY_REVIEW_2026-10-20.md`。


## 過去のカタログ記録（2026-10-20時点）
- 当時の記録です。現行版の数値は本ファイル末尾の0.04.92項目を参照してください。


## 0.04.91 — 成果物の差分追跡とバージョン管理の是正
- versionName 0.04.91 / versionCode 139。
- 0.04.90の直近ZIP同士を比較し、OPPO Find N6の販売URL、Kotlin Seed、IIJmio汎用URL監査CSV/説明、価格欠損監査、販売URLインベントリ、過去データ保持ガードの変更を差分記録にまとめた。
- バージョン更新で顕在化した `test_gradle_wrapper_bootstrap.py` の古い前提（ビルドガイド名が常にアプリ版と一致する）を修正。ガイドは工程成果物として既存の0.04.85版を参照し、毎回複製しない。
- Python現行回帰スイートは54件（旧報告の59件は、`tools/test_*.py` のファイル数と現行スイート登録件数を混同していたため訂正）。
- Python回帰スイート、compileall、ZIP/チェックサム検査を実施。Androidビルド/JUnit/Room/エミュレーター/実機は未検証。
- 詳細: `RELEASE_DIFF_AUDIT_0.04.90_to_0.04.91.md`、`VALIDATION_0.04.91.txt`。


## 0.04.92 — Xperia 1 VIII ドコモ公式価格の補完と価格監査の同期
- versionName 0.04.92 / versionCode 140。
- Xperia 1 VIII（SO-51G、12GB RAM / 256GB）のドコモ公式製品ページに表示された機種代金272,910円（税込）を登録。返却プログラム適用後の実質負担額とは区別し、公式ページURLと確認日を保存。
- 収録数：195機種、314バリエーション、501販売登録、79価格オプション、45監査指摘。価格未登録は440販売登録（うちAVAILABLE 395件）。
- 価格欠損監査CSV/Markdownを再生成し、古い件数を固定していた回帰テストを更新。新規テスト `test_xperia1viii_docomo_official_price_0_04_92.py` を現行回帰スイートへ自動登録。
- 現行Python回帰スイート55/55合格（5バッチ実行）。`compileall`、カタログ件数照合、監査CSVとJSONの一致も確認。
- Android Gradle/KSPビルド、Kotlin/JUnit実行、Room実ランタイム、エミュレーター、実機動作は未検証。
- 詳細：`WORK_LOG_0.04.92_Xperia1VIII_Docomo_official_price.md`、`test_results_0.04.92.txt`、`CATALOG_PRICE_GAP_AUDIT_2026-10-20.md`。


## 0.05.02 — 比較画面の表示値生成を共通化

- versionName 0.05.02 / versionCode 150。
- 比較画面の表示値生成を単一の関数へ集約し、通常表示・条件優先表示・差分フィルターで共通利用。
- `tools/test_comparison_row_value_single_source.py` を追加。
- VER-01採番監査の結果と残存する履歴上の欠落を `VER-01_VERSIONING_AUDIT_2026-10-21.md` に記録。
- Python静的回帰テストとZIP整合性検査は記録対象。Gradle/Kotlin/JUnit/Room/CI/エミュレータ/実機は未検証。
