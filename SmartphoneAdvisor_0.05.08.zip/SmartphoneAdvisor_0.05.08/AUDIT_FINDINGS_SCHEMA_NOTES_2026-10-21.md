# auditFindings の現行スキーマ確認（2026-10-21）

## 結論

`auditFindings` は「未解決項目だけ」の配列ではなく、旧来のカタログ監査記録と、販売登録・シード紐付けの監査記録をまとめた互換用の配列です。`counts.auditFindings` は、解決状態に関係なく配列内の全レコード数を表します。現在の45件を未解決件数と解釈してはいけません。

## 現行スナップショットの内訳

- `action` 欄なし（旧形式の記録）: 27件
- `ADDED`: 1件
- `NOT_ADDED`: 1件
- `RESOLVED_SEED_LINKAGE`: 8件
- `UNRESOLVED_SEED_LINKAGE`: 8件
- 合計: 45件

## 参照調査

- `PhoneCatalogJson.kt` は `JsonAuditFinding` を生成し、`action` を任意文字列として保持します。
- アプリの他の main/test Kotlin コードでは `JsonAuditFinding.action` や `RESOLVED_SEED_LINKAGE` / `UNRESOLVED_SEED_LINKAGE` を条件分岐に使う参照は見つかりませんでした。
- 生成スクリプトはCSV行を `auditFindings` に出力し、`action` が無い旧形式のレコードも保持します。
- カウント検査は `auditFindings` 配列全体の件数を比較します。

## 安全判断

現段階では、配列名の変更、`unresolvedFindings` への改名、既存レコードの削除、解決状態フィールドの一括追加は行いません。これらは生成元CSVとの契約変更になり、現在の用途がないのに互換性リスクを増やすためです。現状を明文化し、内訳の回帰テストで不用意なレコード欠落や誤分類を検知します。将来、アプリ画面で監査結果を利用する要件ができた場合に、入力元スキーマを含めた別途の移行を行います。

## 検証範囲

この確認はZIP内ソースの静的検索とJSON集計です。Gradle/Kotlin/JUnit、Room実取込、CI、エミュレーター、実機は未実施です。
