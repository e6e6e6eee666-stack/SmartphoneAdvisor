# SmartphoneAdvisor 0.04.47 作業記録

## 目的・完了条件
購入先詳細画面で、購入リンクが機種別の販売ページなのか、販売機種一覧・カテゴリページなのかを区別して表示する。ユーザーがリンク先で機種・容量・在庫を再確認する必要がある場合、それを事前に明示する。

## 実施内容
- `MainActivity.kt` に `isGeneralSalesListingUrl` を追加。URL全体ではなく、ホストとパスの限定組み合わせで一般一覧ページを判定する。
- mineo、IIJmio、UQ mobile、楽天モバイル、Xiaomi公式ストア、Y!mobile SIMフリー一覧、Nothing公式端末一覧、nubia公式シリーズ一覧の8種を一覧ページとして分類。
- UIラベルを一覧ページでは「販売機種一覧を開く」、機種別ページでは「販売ページを開く」と分け、一覧ページには機種・容量・在庫の確認注意を追加。
- `tools/test_sales_url_labeling_0_04_47.py` を追加し、カタログの既存URLに対する分類とUI文言を検査。
- カタログ監査スクリプトを0.04.47に更新し、バージョンを `versionName=0.04.47` / `versionCode=96` に更新。

## 検証結果
- PASS: URLラベル回帰テスト。固有URL223種中、一般一覧URL8種を検出。機種別Y!mobile Pixel 10a URLを誤って一般一覧に分類しないことを確認。
- PASS: カタログ構造監査。196機種・314バリアント・477販売登録、構造エラー0件、URL未登録警告2件。
- PASS: 購入オプション可用性SQLiteテスト。
- NOT RUN: Android Gradle/KSPビルド、Roomコンパイル、Android JUnit、実機/エミュレータ試験。Gradle Wrapper/システムGradleがないため。

## 問題・未確認事項
- URL分類は限定的なホスト・パスの許可リストであり、すべての公式URLの到達性や販売情報の最新性を検証するものではない。
- AndroidのComposeコンパイルは未確認。
- URL未登録のY!mobile Free Style 2件は引き続き警告。推測URLは追加していない。

## 進捗位置
- 主工程：大項目9「販売導線」
- 関連工程：大項目3「データ登録システム」、12「販売先マスター」、14「品質・監査」、15「UI/UX」、16「テスト」
- 中工程：購入リンクの種別と説明の整合性
- 小工程：機種別ページと一般一覧ページの表示区別
- 基準版：0.04.46 → 作業版0.04.47

## 次工程
- 購入リンクと価格根拠リンクの内容・販売先・モデル名の照合を継続する。
- Android Gradle/KSPビルド、Roomコンパイル、JUnit、実機試験が可能な環境での検証を別途実施する。

## 証跡
- `app/src/main/java/jp/smartphoneadvisor/app/MainActivity.kt`
- `app/build.gradle.kts`
- `tools/test_sales_url_labeling_0_04_47.py`
- `tools/audit_catalog_integrity_0_04_47.py`
- `CATALOG_INTEGRITY_AUDIT_0.04.47.txt`
- `VALIDATION_0.04.47.txt`
- `PROJECT_MASTER_PLAN_0.04.47.md`
