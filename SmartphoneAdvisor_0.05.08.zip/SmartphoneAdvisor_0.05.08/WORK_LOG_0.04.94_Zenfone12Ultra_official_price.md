# Work log — 0.04.94 Zenfone 12 Ultra official-store price

Date: 2026-10-21

## Purpose
Add a source-backed normal price to an existing Japan-official catalog listing and keep catalog counts, gap reports, and regression expectations synchronized.

## Changes
- Added Zenfone 12 Ultra 12GB/256GB normal price: JPY 149,800 (tax included).
- Source: ASUS Store Rakuten official shop listing. The source shows normal price JPY 149,800 and time-limited special price JPY 134,820; the catalog records only the normal price and explicitly notes the promotion distinction.
- Added a dedicated test for model/variant/store/source/checked date/price type and catalog count reconciliation.
- Regenerated price-gap inventory and follow-up audit outputs.
- Updated older regression expectations that pinned the previous global count; retained ROG Phone 9 and Xperia 1 VIII focused tests in the regression manifest so later version bumps cannot silently drop them.
- Updated app versionName to 0.04.94 and versionCode to 142.

## Catalog counts after change
- Models: 195
- Variants: 314
- Sales listings: 501
- Price options: 81 (previously 80)
- Sales listings without price options: 438 (previously 439)
- AVAILABLE sales listings without price options: 393 (previously 394)
- Unpriced rows with missing model number: 363
- AVAILABLE unpriced rows with missing model number: 323
- Generic/category/top-page URLs among unpriced rows: 9

## Verification
- Current regression suite: 57/57 PASS across five batches.
- Python compileall: to be recorded in release validation.
- Catalog JSON parse and declared-count reconciliation: covered by regression suite.
- ZIP integrity and SHA-256: to be recorded after packaging.
- Not run: Android Gradle build, Kotlin/JUnit execution, Room runtime import, emulator launch, physical-device interaction. Environment does not have the verified Android build/runtime prerequisites.

## Scope note
No new phone model or variant was added; this update adds one verified price option to the existing Zenfone 12 Ultra 12GB/256GB listing. The 512GB variant is shown by official sources but is not yet present in the current catalog and remains a separate catalog completeness task.
