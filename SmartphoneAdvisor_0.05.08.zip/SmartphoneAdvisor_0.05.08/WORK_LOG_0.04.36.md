# WORK LOG 0.04.36 — 色別価格データの取り込み準備

## 1. 目的・完了条件
nubia Z80 Ultra 16GB/512GBについて、公式情報で確認できる色別の通常価格をカタログに登録し、価格を単一モデル価格として誤表示しないためのデータ形式とパーサーを追加する。

## 2. 実施内容
- `phones.json` の nubia Z80 Ultra 512GB/16GB SIMフリー販売登録に、色別価格オプションを追加。
  - ブラック：139,800円
  - ホワイト：139,800円
  - スターレイナイト：144,800円
- 各価格に色、価格種別、条件、根拠URL、確認日を保持する形にした。
- `JsonPriceOption` を追加し、JSONパーサーが価格候補を保持できるようにした。
- 価格が正数であること、価格種別が許可値であること、確認日形式と根拠URLが適切であることをカタログ検証で確認するようにした。
- 色別3価格のパーサーテストを追加。
- バージョンを `0.04.36`、versionCodeを `85` に更新。

## 3. 検証結果
- Pythonで `phones.json` を再読込し、nubia Z80 Ultra 512GB/16GBの価格候補が3件であること、価格と色の対応が一致することを確認。
- JSON内の全販売URL・価格根拠URLについてURL形式を検査。
- Kotlin/JUnitテストおよびAndroid Gradleビルドはこの環境では未実施。後述の制限を参照。

## 4. 問題・未確認事項
- 現行Roomの `price_record_v2` の一意キーは `productListingId + priceType + checkedAt` で、色が含まれない。このため同じ日付・通常価格で3色をRoomへ登録すると、色別価格が重複扱いされる危険がある。
- 今回はデータ形式とパーサーまで反映。色別価格のRoom永続化、および比較画面での表示は未完了。DB一意キーを安全に拡張する設計・マイグレーションと価格表示UIが次工程。
- 公式nubia製品情報記事は発売時の色別価格を記載している一方、現行商品ページは選択中の価格を表示するため、価格を公開日・確認日付きで扱い、販売時点の最新価格は再確認が必要。
- Gradle実ビルド、Gradle経由JUnit、実機／エミュレータテストは未実施。

## 5. 現在位置
大項目3「データ登録システム」／中項目13「価格・販売情報」／小項目：色別価格データ形式・JSONパーサー／version 0.04.36 (versionCode 85)。

## 6. 次工程
1. Room価格記録の一意キーに色・価格オプション識別子を安全に追加するDBマイグレーションを設計する。
2. JSON→Roomインポーターで色別価格を冪等に登録できるようにする。
3. 比較画面の価格欄に色・価格種別・確認日・出典リンクを表示する。
4. Gradle/JUnit/移行テストとZIP整合性検査を実行する。

## 7. 証跡
- `app/src/main/assets/phones.json`
- `app/src/main/java/jp/smartphoneadvisor/app/data/catalog/PhoneCatalogJson.kt`
- `app/src/main/java/jp/smartphoneadvisor/app/data/catalog/PhoneCatalogRoomImporter.kt`
- `app/src/test/java/jp/smartphoneadvisor/app/data/catalog/PhoneCatalogJsonParserTest.kt`
- `app/build.gradle.kts`
- `VALIDATION_0.04.36.txt`
