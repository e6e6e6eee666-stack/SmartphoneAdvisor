# SmartphoneAdvisor 0.05.05 — Gradle compatibility update

## Changes
- Updated Android app versionName to 0.05.05 and versionCode to 153.
- Removed the legacy `org.jetbrains.kotlin.android` plugin declaration from the root and app Gradle Kotlin DSL files because this project declares Android Gradle Plugin 9.4.0, which provides built-in Kotlin support.
- Kept `org.jetbrains.kotlin.plugin.compose` because the app uses Jetpack Compose.
- Updated the in-project GitHub Actions workflow to install and invoke Gradle 9.8.1 with JDK 17.
- Enabled `--warning-mode all` on Gradle tasks so the actual deprecated API/plugin source is visible in CI logs. Deprecation warnings alone are not necessarily the cause of `BUILD FAILED`; the first concrete error earlier in the log is decisive.
- Updated CI SDK package installation to request the project's declared compileSdk 37 and build-tools 36.0.0.

## Verification status
- ZIP structure and Python regression suite: to be checked when packaging.
- Gradle build, JVM tests, emulator tests: NOT RUN in this environment. No successful Android build is claimed.
- Android SDK availability for `platforms;android-37` on the GitHub runner must be confirmed by the next Actions run. If sdkmanager reports the package unavailable, that is a separate blocker and not a Gradle deprecation fix.
