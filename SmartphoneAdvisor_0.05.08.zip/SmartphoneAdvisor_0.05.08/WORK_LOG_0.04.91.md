# Work log — 0.04.91

- Fixed app metadata at versionName 0.04.91 / versionCode 139 so the current package can be distinguished from previous 0.04.90 ZIPs.
- Compared the two latest available 0.04.90 packages and documented exact file-level differences in `RELEASE_DIFF_AUDIT_0.04.90_to_0.04.91.md`.
- Fixed the regression test's stale assumption that an Android build guide must be named for every app version.
- Re-ran current registered regression suite in five batches: 54/54 PASS.
- `python -m compileall -q tools`: PASS.
- Android build and runtime tests remain not verified because Gradle/Wrapper/Android SDK/adb are unavailable in the current environment.


## Follow-up maintenance — 2026-10-21

- Re-audited current `phones.json` against the IIJmio generic-URL review and price-gap follow-up report.
- Corrected a stale model list in `IIJMIO_GENERIC_URL_REVIEW_2026-10-20.md`: the current nine generic-URL rows are motorola razr fold; Xiaomi 17T; Xiaomi 17T Pro; Xiaomi 17 Ultra; Galaxy S26 (256/512GB); Galaxy S26+ (256/512GB); OPPO Find X9 Ultra. REDMI Note 17 Pro Max 5G (256/512GB) and OPPO Find N6 already have product-specific URLs in current JSON.
- Regenerated `CATALOG_PRICE_GAP_FOLLOWUP_2026-10-20.csv/.md` from current JSON so the SHA-256 and counts are derived, not hand-maintained. Current counts: 441 price gaps; 396 AVAILABLE with no price; 365 missing model numbers (325 AVAILABLE); 9 generic-category URL rows. No prices were guessed or added.
- Added `tools/test_iijmio_generic_url_inventory_0_04_91.py` to guard the exact generic-URL row identities, REDMI/Find N6 repaired state, and audit SHA/count synchronization. Updated a stale test status line from 10 to 9 generic URLs.
- Re-ran the maintained regression suite as five batches: 55/55 PASS, 0 FAIL. The new test is included in the current-version auto-discovery set.
- Re-ran the price-gap report generator; result: `PASS: follow-up audit rows=441 available=396 missingModelNumber=365 availableMissingModelNumber=325 genericUrl=9 availableGenericUrl=9`.
- App source/catalog JSON and app version were not changed in this maintenance pass; app remains `0.04.91` / `versionCode 139`. Android Gradle build, Kotlin/JUnit execution, Room runtime, emulator and physical-device validation remain unverified.
