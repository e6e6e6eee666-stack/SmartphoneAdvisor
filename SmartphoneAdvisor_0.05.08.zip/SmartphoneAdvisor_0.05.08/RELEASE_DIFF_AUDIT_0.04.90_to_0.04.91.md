# Release diff audit: 0.04.90 → 0.04.91

## Baseline and method
- Baseline: `SmartphoneAdvisor_0.04.90_2026-10-21_59tests-rerun-build-prereq-audit.zip` (870 ZIP entries; SHA-256 `b9a73c4804d398b4ab612a068a2bfae7a309114e03037d6695baf43297f97682`).
- Compared with: `SmartphoneAdvisor_0.04.90_2026-10-21_OPPO-Find-N6公式URL修正・重点回帰検証.zip` (871 ZIP entries; SHA-256 `00ab4a9c0e13c371bea4ae4588b3ab2d010db256faf8f0a8c5c170c08594a28f`).
- Both packages declared app versionName 0.04.90 / versionCode 138. The ZIPs were not identical; the app version metadata did not reflect the follow-up edits.

## Files changed between those two 0.04.90 packages
- `app/src/main/assets/phones.json`: OPPO Find N6 sales URL updated; file changed 273351 → 273367 bytes.
- `app/src/main/java/jp/smartphoneadvisor/app/data/SubBrandMvnoCatalogSeed.kt`: matching Kotlin seed URL updated.
- `IIJMIO_GENERIC_URL_REVIEW_2026-10-20.csv` and `.md`: resolved OPPO row removed and audit narrative updated.
- `CATALOG_PRICE_GAP_AUDIT_2026-10-20.csv` and `.md`, `SALES_URL_INVENTORY_0.04.76.csv`: regenerated to reflect current URL/data facts.
- `tools/test_catalog_preservation_baseline_0_04_74.py`, `tools/test_historical_catalog_preservation_0_04_77.py`, `tools/test_iijmio_generic_url_review_0_04_89.py`: preservation guards updated for the explicit URL-only correction.
- `WORK_LOG_2026-10-21_validation-rerun.md`: expanded with OPPO correction and test scope.
- Added `VALIDATION_2026-10-21_latest-url-repair.txt`.
- Python `__pycache__` files also changed because tests were run; these are generated artifacts, not source changes.

## 0.04.91 changes
- Set `app/build.gradle.kts` to versionName `0.04.91` / versionCode `139` to identify this new packaged revision.
- Updated README's current version and appended this release note.
- Fixed `tools/test_gradle_wrapper_bootstrap.py`: build guide documents a milestone and is not required to have a filename matching every patch version; the test now falls back to the existing 0.04.90 guide.
- Re-ran the current registered regression suite in five batches: **54/54 PASS**. Note: there are 59 `tools/test_*.py` files, but only 54 are registered in `run_current_regression_suite.py`; the prior 59/59 wording conflated these counts.
- Re-ran `python -m compileall -q tools`: PASS.

## Catalog facts retained
- 195 models, 314 variants, 501 sales registrations, 78 price options.
- 9 generic IIJmio URLs remain in the latest OPPO-corrected audit; the broader price-gap report has its own `CATEGORY_OR_TOP_PAGE` count, which is a separate measure and should not be conflated with that URL-review count.
- 441 sales registrations remain without price options according to the price-gap follow-up report.

## Not verified
- Android Gradle build, Kotlin/JUnit execution, Room runtime import, emulator, physical device, and GitHub Actions execution are not verified in this environment. Python source-contract tests do not establish app runtime correctness.

## Release decision
This is a traceability/maintenance revision, not a claim that the Android app is release-ready. The version bump labels the exact packaged revision; feature completion and Android execution gates remain open.
