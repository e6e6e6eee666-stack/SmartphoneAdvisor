# Work log — IIJmio generic URL evidence refinement (2026-10-20)

## Scope
Refine the existing 30-row IIJmio generic-category-URL audit using retrieved official IIJmio lineup evidence. This is an audit/report/test-only change; app source, catalog entries, availability values, and app version were intentionally not changed.

## Changes
- Added `modelEvidence` and `evidenceNote` fields to `IIJMIO_GENERIC_URL_REVIEW_2026-10-20.csv`.
- Classified 17 registrations as model-level evidence seen but exact RAM/storage SKU, detail URL, and live orderability unresolved; 13 registrations remain unconfirmed in the retrieved official evidence.
- Rewrote the Markdown report to distinguish model-name evidence from exact-variant and stock confirmation, and explicitly state that unconfirmed does not mean not sold.
- Extended `tools/test_iijmio_generic_url_review_0_04_89.py` to guard the 30-row linkage, evidence classifications, and cautious interpretation.

## Verification
- Targeted generic URL audit test: PASS.
- Targeted verified IIJmio product registrations test: PASS (4 registrations, 4 product URLs, 10 source-backed prices, preorder guard, catalog counts).
- App version remains 0.04.90 / versionCode 138 because no app/runtime code or catalog content changed.
- Android build, Kotlin/JUnit, Room runtime, emulator, and physical-device testing remain unverified in this environment.

## Broader regression run
A broader pass over the 57 `tools/test_*.py` scripts was attempted in bounded batches. The execution environment terminated the command during the fifth batch after the first 40 scripts had passed. The remaining scripts are not reported as passed; the targeted IIJmio tests and three project/CI guard tests above completed successfully.
