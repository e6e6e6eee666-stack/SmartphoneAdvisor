# Work log — 0.04.95 Zenfone 12 Ultra 16GB/512GB official price

Date: 2026-10-21

## Purpose
Complete a previously identified missing official Japan-sale storage variant instead of only recording it as a follow-up task.

## Changes
- Added Zenfone 12 Ultra 16GB/512GB variant.
- Added ASUS Store Japan sales registration with the official ASUS Japan product page and the ASUS Store Rakuten official shop price source.
- Recorded normal tax-included price JPY 169,800; the displayed limited-time special price JPY 152,820 is explicitly separated in conditions and not stored as normal price.
- Added dedicated regression coverage for the 512GB variant, price, source, date, and catalog count reconciliation.
- Updated existing current-catalog regression expectations to account for one new variant, one sales registration, and one price option.
- Regenerated the current price-gap audit and follow-up inventory from the updated JSON.
- Bumped app versionName to 0.04.95 and versionCode to 143.

## Catalog counts
- Models: 195 (unchanged)
- Variants: 315 (previously 314)
- Sales listings: 502 (previously 501)
- Price options: 82 (previously 81)
- Price-unregistered sales listings: 438 (unchanged; the new sales listing has a price)
- AVAILABLE but unpriced listings: 393 (unchanged)

## Source
- ASUS Store Rakuten official shop listing: https://www.rakuten.ne.jp/gold/asus-store/sale/2510CP2/
- ASUS Japan product page: https://www.asus.com/jp/mobile-handhelds/phones/zenfone/zenfone-12-ultra/
- ASUS Store listing shows 16GB/512GB normal price JPY 169,800 and special price JPY 152,820. Normal price alone is recorded as NORMAL.

## Verification scope
- Current regression suite: 58/58 PASS across five batches, including the new 512GB regression guard.
- Python compileall: PASS.
- Catalog metadata reconciliation: PASS (195 models / 315 variants / 502 sales / 82 price options / 45 audit findings).
- Price-gap report reconciliation: PASS (438 unpriced sales / 393 AVAILABLE without price / 363 missing model numbers / 9 generic URLs).
- ZIP integrity and SHA-256: to be recorded after packaging.
- Android Gradle build, Kotlin/JUnit, Room runtime import, emulator, and physical-device tests remain unverified in this environment.
