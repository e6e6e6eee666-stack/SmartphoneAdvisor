# SmartphoneAdvisor 0.04.73 作業記録

## 目的・完了条件
過去に登録した販売・価格データが同一機種の別レコードへ分散していた原因を修正し、既存情報を失わずに機種レコードを統合する。重複を検出する回帰テストと再集計結果をZIPに含める。

## 実施内容
- 0.04.72の実データでNothing Phone (4a)が `Nothing:Nothing Phone (4a):2026` と `Nothing:Phone (4a):2026` に分かれていることを確認。
- IIJmioの128GB販売情報、Nothing公式ストア128GB通常価格58,800円、256GB通常価格64,800円を保持したまま1つの正規機種レコードに統合。
- アプリ版数を `0.04.73`、`versionCode=121` に更新。
- 重複機種IDを検出する回帰テストを追加し、既存のNothing価格テストを「価格が存在するか」だけでなく「正規機種へ統合されているか」も確認するよう変更。
- カタログ件数と価格・販売URL監査を再生成。古い版の件数を前提にしたテストの期待値も現行データに合わせて修正。

## 検証結果
- `python -m compileall -q tools`: PASS
- Python回帰テスト: 35/35 PASS
- 価格カバレッジ監査: 195機種、313バリエーション、497販売登録、52価格オプション、価格未登録448、AVAILABLEかつ価格未登録404、URL欠落0: PASS
- 販売情報根拠監査: 52価格オプション全件に正の整数価格・sourceUrl・checkedAtあり: PASS
- 販売URL一覧: 497/497 URLあり: PASS
- 重複機種検査（メーカー名接頭辞の正規化を含む）: PASS
- ZIP整合性: PASS（配布ZIP作成後に `unzip -t` を実行し、圧縮データの破損なしを確認）。
- Android Gradle/KSPビルド、Roomランタイム取込、Android JUnit、エミュレーター・実機試験: 未実施。

## 問題・未確認事項
- 重複レコードが発生した全履歴のコミット単位の原因までは、この環境で確認できるZIPだけでは特定できない。確認できた直接原因は、価格登録時に正規レコードを再利用せず、メーカー接頭辞の有無が異なる別モデルレコードに登録したこと。
- 同種の表記揺れが他のメーカーにもないか、今回のテストで限定的に正規化して検査した。複雑なシリーズ名・地域名・世代名の違いをすべて自動統合することは安全でないため、疑わしい一致を一律統合してはいない。
- 価格未登録の販売登録448件は残存。未登録は0円や販売終了を意味しない。

## 進捗位置
大項目13「価格・販売情報」／中項目「カタログ整合性・機種ID統合」／小項目「Nothing Phone (4a)重複統合・回帰テスト」

## 証跡
- `app/src/main/assets/phones.json`
- `app/build.gradle.kts`
- `tools/test_nothing_phone4a_official_price_0_04_70.py`
- `tools/test_duplicate_model_identity_0_04_73.py`
- `PRICE_COVERAGE_AUDIT_0.04.73.md`
- `SALES_FACT_COMPLETENESS_AUDIT_0.04.73.md`
- `SALES_URL_INVENTORY_0.04.73.csv`
