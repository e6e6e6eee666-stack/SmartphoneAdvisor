# Release diff audit: 0.04.98 → 0.04.99

## Scope
- Current baseline: uploaded `SmartphoneAdvisor_0.04.98` archive, extracted and checked before edits.
- Version metadata: `versionName=0.04.99`, `versionCode=147`.
- Catalog: Samsung Japan official direct-sale listing and price provenance for Galaxy S26.

## Intended data changes
- Galaxy S26 12GB/256GB: add one `SIM_FREE` Samsung Japan official online-store sale listing with normal price ¥155,800 incl. tax.
- Galaxy S26 12GB/512GB: add one `SIM_FREE` Samsung Japan official online-store sale listing with normal price ¥183,300 incl. tax.
- Source: https://www.samsung.com/jp/smartphones/galaxy-s26/buy/
- `checkedAt=2026-10-21`; discount/trade-in/points excluded. Current official purchase page is the source of truth; launch-time prices are not reused as current prices.
- Existing carriers, existing model identity, existing variants, and historical price entries were not changed by this feature.

## Count reconciliation
| Metric | 0.04.98 | 0.04.99 |
|---|---:|---:|
| Models | 195 | 195 |
| Variants | 315 | 315 |
| Sales listings | 504 | 506 |
| Price options | 87 | 89 |
| Audit findings | 45 | 45 |

Price-gap audit still reports 435 listings without prices and 390 AVAILABLE listings without prices. This is expected because two new priced sale listings were added, while no previously unpriced listing was removed or overwritten.

## Regression and audit changes
- Added `tools/test_galaxy_s26_samsung_official_prices_0_04_99.py`.
- Updated live catalog count expectations from 504/87 to 506/89 where the tests validate current totals; historical catalog preservation snapshots remain unchanged.
- Corrected a stale Docomo iPhone 18 Pro 512GB test expectation from ¥309,890 to the catalog/source-backed ¥309,870.
- Re-generated current price-gap and sales-fact audits from `phones.json`.

## Verification boundaries
- Python regression scripts: all 68 test scripts were run in batches; initial failures caused by stale assertions were corrected and rerun. Final relevant tests passed.
- `python -m compileall -q tools`: passed.
- Catalog audit generators and reconciliations: passed.
- ZIP creation intentionally deferred until a meaningful milestone, per workflow change.
- Android Gradle build, Kotlin/JUnit execution, Room runtime import, emulator, and physical-device execution: not verified in this environment.
