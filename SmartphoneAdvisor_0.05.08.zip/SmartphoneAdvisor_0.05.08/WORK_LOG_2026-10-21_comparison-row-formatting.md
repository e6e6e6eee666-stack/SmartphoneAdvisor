# Work log — comparison row formatter consolidation (2026-10-21)

## Purpose
Remove duplicated comparison-value formatting so the normal display, condition-priority display, and “different items only” filter cannot silently diverge because of separate implementations.

## Changes
- Changed `ComparisonScreen` row definitions from precomputed `(label, values)` pairs to `(label, formatter)` pairs.
- Both the ordinary order and condition-priority order now calculate each row's displayed values through the same formatter.
- The “different items only” filter now evaluates values through that same formatter.
- Removed the duplicate `comparisonValueForRow` `when` formatter.
- Added `tools/test_comparison_row_value_single_source.py` as a source-level regression guard.
- Did not alter catalog data or price selection rules intentionally.

## Verification
- Python source-level regression test: PASS (recorded after running against this archive).
- ZIP integrity: to be checked on the output archive.
- Gradle/Kotlin compilation, JUnit, Room runtime import, CI, emulator and physical-device checks: NOT RUN / NOT VERIFIED in this environment.

## Related static finding: `LaunchedEffect(loading)`
The current effect starts the diagnostic work only when `loading` becomes true; the subsequent `loading = false` causes another effect invocation that immediately returns. Static inspection does not show a second diagnostic run from that false transition. This is a redundant no-op effect restart, not proven duplicate execution. I am leaving it unchanged rather than replacing coroutine ownership without an Android build/runtime test. Normal diagnostic buttons are also disabled while `loading` is true. Revisit only with a buildable Android environment or a concrete reproduction.
