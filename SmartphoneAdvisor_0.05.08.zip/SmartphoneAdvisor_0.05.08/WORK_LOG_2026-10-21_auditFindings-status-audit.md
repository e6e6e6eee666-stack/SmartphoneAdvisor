# Work log — auditFindings action distribution (2026-10-21)

## Purpose / completion condition
Determine whether `auditFindings` means unresolved-only and whether status/schema migration is safe. Complete when action distribution, code references, count semantics are documented and regression guarded.

## Work performed
- Counted action values in `app/src/main/assets/phones.json`.
- Searched `app/src/main`, `app/src/test`, and `tools` for action constants and consumers.
- Added `AUDIT_FINDINGS_SCHEMA_NOTES_2026-10-21.md`.
- Added `tools/test_audit_findings_action_distribution.py`.
- No existing audit records removed or renamed; no JSON schema changed.

## Findings
- 45 total records: 27 without `action`, 1 `ADDED`, 1 `NOT_ADDED`, 8 `RESOLVED_SEED_LINKAGE`, 8 `UNRESOLVED_SEED_LINKAGE`.
- `counts.auditFindings` is the total array length, not the unresolved count.
- Kotlin parser preserves `action` as optional text; no further Kotlin consumer of that field was found in source/test search.
- The converter keeps historical CSV records, including records without `action`.

## Validation
- Python regression test: pending execution in this work unit.
- JSON parse/count: performed during script setup; final result to be recorded after test run.
- Gradle/Kotlin/JUnit/Room/CI/emulator/device: not run.

## Test results
- `test_audit_findings_action_distribution.py`: PASS (exit 0); output: `PASS: auditFindings keeps all 45 mixed-format records; action distribution is explicit`
- `test_audit_findings_legacy_price_yen.py`: PASS (exit 0); output: `{"carrierEntryRecords": 1, "phoneModels": 1, "variants": 1, "salesListings": 1, "uniqueAuditFindings": 2}
PASS: legacy price_yen is omitted while other audit finding fields are preserved`
- `test_catalog_json_declared_counts_guard.py`: PASS (exit 0); output: `PASS: parser validates all five declared catalog counts; current phones.json counts match parsed content`
- `test_mive_kesuma_iijmio_official_price_0_05_01.py`: PASS (exit 0); output: `PASS: MIVE Kesuma IIJmio normal price and source integrity`
