# Historical full-catalog preservation audit 0.04.77

## Scope

Compared complete `phones.json` snapshots from 0.04.70, 0.04.71, 0.04.72, 0.04.73, 0.04.74, 0.04.75, 0.04.76 against the current catalog using normalized model identity, variant, sales-listing, and price-option signatures. This audit is limited to these seven saved ZIP snapshots; it does not imply complete history for versions without retained JSON.

## Snapshot sizes

| Version | Models | Variants | Sales listings | Price options |
|---|---:|---:|---:|---:|
| 0.04.70 | 195 | 313 | 496 | 50 |
| 0.04.71 | 195 | 313 | 496 | 50 |
| 0.04.72 | 195 | 313 | 497 | 52 |
| 0.04.73 | 195 | 313 | 497 | 52 |
| 0.04.74 | 195 | 313 | 497 | 52 |
| 0.04.75 | 195 | 313 | 497 | 52 |
| 0.04.76 | 195 | 313 | 497 | 52 |

## Current preservation result

| Fact type | Historical unique signatures | Missing from current |
|---|---:|---:|
| models | 195 | 0 |
| variants | 313 | 0 |
| salesListings | 497 | 0 |
| priceOptions | 52 | 0 |

## Interpretation

- The historical `Nothing:Phone (4a)` alias in versions 0.04.70–0.04.72 is normalized to the canonical model identity and does not count as a missing sales listing or price option. The duplicate 8GB/128GB variant alias was merged into the canonical identity in 0.04.73.
- Sales listings and price options are compared with source URL, status, price, currency, and provenance fields included in the serialized signatures. A future change to any of those values will require explicit review.
- The comparison checks retention of historical facts; it does not verify that current prices remain live or correct today.
- Current catalog: 195 models, 313 variants, 497 sales listings, 52 price options.
