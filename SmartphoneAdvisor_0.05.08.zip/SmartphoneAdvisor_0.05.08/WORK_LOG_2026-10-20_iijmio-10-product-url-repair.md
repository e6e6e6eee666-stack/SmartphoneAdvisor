# 作業記録 — 2026-10-20 IIJmio商品別URL修正

## 目的
価格・在庫を推測で補完せず、公式ページが確認できるIIJmio販売登録の汎用一覧URLを機種別ページに置き換え、過去データ保持と回帰テストを維持する。

## 実施
- `app/src/main/assets/phones.json`：MIVE ケースマ、OPPO Reno16 5G、Galaxy Z Fold8 Ultra、Galaxy Z Fold8、Galaxy Z Flip8の計10販売登録でIIJmio URLを公式の機種別ページへ変更。
- `IIJMIO_GENERIC_URL_REVIEW_2026-10-20.csv` / `.md`：残り汎用URLを26件から16件に再集計。残件は個別に調査を続ける。
- `CATALOG_PRICE_GAP_FOLLOWUP_2026-10-20.csv` / `.md`：価格未登録行の監査を再生成。汎用/トップページURLは未価格登録の行で24件から14件に減少。
- `tools/test_iijmio_generic_url_review_0_04_89.py`：残件数と機種別URLの回帰ガードを更新。
- `tools/test_catalog_preservation_baseline_0_04_74.py` / `tools/test_historical_catalog_preservation_0_04_77.py`：今回の根拠付きURL修正だけを許可する例外を追加し、他の過去登録・価格が消えていないことを検証。
- `tools/test_price_gap_followup_0_04_89.py`：監査の期待件数を現行の14件に更新。

## 検証
- Pythonテストファイル59件すべて合格（15+15+15+14の4バッチ）。
- `python -m compileall -q tools` 合格。
- JSON件数：195機種 / 314バリエーション / 501販売登録 / 70価格選択肢 / 45監査指摘。
- Androidビルド、Kotlin/JUnit、Room実行、エミュレーター、実機動作は未検証。

## 判断
- 公式販売開始告知とそこからの公式商品詳細ページへのリンクでURLを確認した。告知は容量構成の根拠になるが、現在のリアルタイム在庫を証明するものではないため、今回の10件の在庫状態・型番・価格は変更していない。
- アプリのversionName/versionCodeは変更しない（0.04.90 / 138）。

## 次の作業
1. 残り16件のうち、公式の機種別URLと容量構成が確認できる行を順次修正する。
2. 価格未登録445件を販売条件と照合し、通常価格・キャンペーン・MNP価格を混同せず補完する。
3. Androidビルド可能環境を整備し、G1/G2（ビルドとRoom実行検証）の証跡を取得する。
