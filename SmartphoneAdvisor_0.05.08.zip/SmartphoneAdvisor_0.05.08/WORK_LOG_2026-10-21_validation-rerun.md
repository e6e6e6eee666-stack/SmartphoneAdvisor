# Work log — 2026-10-21 regression and build-environment recheck

## Purpose
Re-open the latest available 0.04.90 package and independently re-run its test files, then distinguish Python validation from Android build/runtime verification.

## Work completed
- Extracted the latest available ZIP from the Library into the current runtime.
- Enumerated 59 `tools/test_*.py` files.
- Executed sorted tests 1–42; every reported test exited 0. The orchestration command hit its overall runtime limit after test 42 had passed, so the orchestration itself is not claimed as a clean full-suite run.
- Executed sorted tests 43–59 in a second process; all 17 passed with no per-test timeout.
- Ran `python -m compileall -q tools`; PASS.
- Checked build prerequisites: Java 21 exists, but Gradle, adb, Gradle wrapper files, and Android SDK environment variables are absent.
- Added validation record with exact limitations. No source/catalog changes; version remains 0.04.90 / versionCode 138.

## Results
- Python tests combined across the two executions: 59/59 PASS, 0 failed, 0 per-test timeouts.
- compileall: PASS.
- Android build, Kotlin/JUnit, Room runtime, emulator, physical-device operation: NOT VERIFIED, not attempted because required tools were absent.

## Next
Continue source-backed IIJmio URL/price-gap resolution from this package. Separately, establish a reproducible Android build environment (Gradle wrapper + Android SDK) before claiming the app builds or runs.

## Additional catalog repair — OPPO Find N6
- Official IIJmio product page confirmed: https://www.iijmio.jp/device/oppo/findn6.html. It lists RAM 16GB / ROM 512GB and displays normal/MNP price information.
- Updated the exact OPPO Find N6 sale URL in `phones.json` and the Kotlin seed; changed any existing price-option source URLs from the generic listing to the same official detail page without changing price amounts or availability.
- Removed its row from the generic URL review; remaining generic URLs are now 9 (5 exact-variant evidence rows, 4 insufficient-evidence rows).
- Added this one exact URL correction to both historical catalog preservation guards. The first run correctly caught the missing allowlist entry; after adding the narrowly scoped correction, both preservation tests passed.
- Focused current checks PASS: generic URL review, catalog preservation baseline, historical catalog preservation, sales URL inventory, price-gap audit reconciliation, verified IIJmio registration test, and compileall.
- The prior 59/59 per-file test run was performed before this additional URL repair; the entire 59-file suite has not yet been rerun after this change.
