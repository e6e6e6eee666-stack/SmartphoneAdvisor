# SmartphoneAdvisor 現行ソースZIPについて

- 現行配布ZIP／格納フォルダー: `SmartphoneAdvisor_0.05.04`
- アプリ設定: versionName `0.05.04` / versionCode `152`（`app/build.gradle.kts`）。
- このZIPはAndroid Studio用のソースプロジェクトであり、インストール用APKではありません。
- 現行マニフェストに基づくPython回帰テストの再実行結果は、`test_results_0.05.04.txt` とバッチ別結果に記録します。
- Android Gradleビルド、Kotlin/JUnit、Room実取込、エミュレーター、実機動作は未検証です。Gradle Wrapper／Android SDKがこの実行環境にないため、ビルド成功とは表記しません。GitHubリポジトリURL・ログイン状態も未確認で、GitHub Actionsは実行していません。
