# Work log — Android CI compatibility guard

- **Task:** BLD-01, strengthen static checks before attempting a real Android build.
- **Change:** `tools/test_android_validation_workflow.py` now cross-checks the workflow's Gradle/JDK/SDK/emulator settings against the actual root and app Gradle files. It asserts AGP 9.4.0 with Gradle 9.6.0 and JDK 17, verifies compileSdk platform installation, and checks minSdk/targetSdk relationships.
- **Official reference:** https://developer.android.com/build/releases/agp-9-4-0-release-notes — AGP 9.4.0 requires Gradle 9.6.0 and JDK 17, defaults to Build Tools 36.0.0, and supports API 37.
- **Verification:** static compatibility guard PASS; Python regression suite 51/51 PASS in five fresh batches after deleting stale reports; `python -m compileall -q tools` PASS; dependency-order guard PASS; wrapper-bootstrap guard PASS.
- **Not verified:** GitHub Actions execution, SDK package download, Gradle build, APK generation, Kotlin/JUnit, emulator, Room runtime, physical device.
- **Unchanged:** Kotlin source, `phones.json`, Gradle plugin versions, `versionName=0.04.89`, `versionCode=137`.
