# Work log — 0.04.92 Xperia 1 VIII Docomo official price

- Date: 2026-10-21
- Change: added NTT Docomo official product page's listed total device price of ¥272,910 for Sony Xperia 1 VIII SO-51G, 12GB RAM / 256GB storage.
- Evidence: https://www.docomo.ne.jp/product/so51g/ (official Docomo product page; page shows 272,910 yen including tax).
- Conditions: recorded as NORMAL list/total price; no trade-in/return-program effective price was used.
- Catalog totals recalculated from source JSON: 195 models, 314 variants, 501 sales listings, 79 price options, 45 audit findings.
- Version: versionName 0.04.92, versionCode 140.
- Automated verification: see the dedicated regression test and test result file in this package.
- Not verified: Android Gradle build, Kotlin/JUnit, Room runtime, emulator, and physical-device operation.
