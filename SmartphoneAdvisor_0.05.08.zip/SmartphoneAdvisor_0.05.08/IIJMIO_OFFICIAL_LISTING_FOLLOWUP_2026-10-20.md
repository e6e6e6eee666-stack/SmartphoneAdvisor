# IIJmio official lineup follow-up — 2026-10-20

## Evidence captured

Official IIJmio device lineup (retrieved 2026-10-20): https://www.iijmio.jp/device/

The current indexed official lineup now exposes exact capacity-labelled entries for several records previously treated only as model-level evidence. Examples include Galaxy S26 [12GB/256GB], Galaxy S26 [12GB/512GB], Galaxy S26+ [12GB/256GB and 512GB], Galaxy S26 Ultra [12GB/256GB, 12GB/512GB, 16GB/1TB], Galaxy Z Fold8 [12GB/256GB, 12GB/512GB, 16GB/1TB], Galaxy Z Fold8 Ultra [12GB/256GB, 12GB/512GB, 16GB/1TB], Galaxy Z Flip8 [12GB/256GB and 512GB], and other named devices.

Official lineup evidence also displays prices and stock labels for individual configurations. For example, the official Galaxy S26 Ultra detail page lists regular and MNP prices for the 12GB/256GB, 12GB/512GB, and 16GB/1TB configurations: https://www.iijmio.jp/device/samsung/galaxy-s26-ultra.html. The official lineup currently displays several configurations as temporarily out of stock; a visible price must not be interpreted as in-stock availability.

## Decision and remaining work

- This follow-up supersedes the earlier inference that all 17 model-level entries lacked exact capacity-level evidence: the current official lineup provides exact configuration labels for many of them.
- The generic-URL audit is retained as a conservative audit of the catalog's stored URLs. A shared category URL is still not a product-specific URL, even when the category page exposes an exact configuration.
- No URLs, model numbers, prices, or stock statuses have been guessed or bulk-written into `phones.json` in this follow-up. Individual catalog updates require a verified product detail URL and a structured mapping of each exact price condition to its configuration.
- The `AVAILABLE` labels on generic-URL registrations remain a data-quality risk and should not be interpreted as independently verified in-stock status. Follow-up work should update each row only after matching its exact product/configuration and current orderability.

## Scope limitation

This is a documentation/evidence follow-up only. App source, catalog records, and app version remain unchanged. It does not establish Android build or runtime correctness.
