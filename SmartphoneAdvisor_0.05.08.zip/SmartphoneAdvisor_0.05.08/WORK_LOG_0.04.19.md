# WORK LOG 0.04.19

## 目的・完了条件
前版のSQLを再点検し、機種マスターの一意性が容量/RAMの存在する行だけを数えて誤判定されないようにする。機種ID検索も重複時に任意の1件を返さない。

## 実施内容
- `getDeviceVariantIdByFullIdentity` の一意性判定を、販売容量に一致するvariant行の集計から独立した `smartphone_model` / `manufacturer` の副問い合わせへ変更。
- `getDeviceVariantIdByModelAndStorage` も、同名の有効な機種マスター全件を独立して数える方式へ変更。
- `getModelIdByIdentity` と `getModelIdByName` を `LIMIT 1` から「一致が1件の場合のみIDを返す」集計SQLへ変更。
- 静的監査を、前版の見かけ上の `COUNT(DISTINCT m.id)` だけで合格扱いしないよう強化。
- versionName `0.04.19` / versionCode `68` に更新。

## 検証結果
- 静的監査スクリプト実行済み。
- カタログJSON監査を再実行予定・結果を同梱。
- DAOから抽出したSQLをSQLiteの合成テーブルで実行し、重複機種の拒否と一意な機種の正常解決を7 assertionで確認。
- ZIP整合性検査を実行。
- Gradle/KSPビルド、Room/SQLite統合実行、実機試験はこの環境では未実施。

## 問題・未確認事項
- SIMフリー、価格、サブブランド/MVNO seedがメーカー・platform・発売年を保持しない点は未解決。曖昧なデータを推測で補完していない。
- DAOのSQL構文・集計挙動がRoom/KSPビルドで受理されるかは未確認。

## 進捗位置
大項目3「データ登録システム」/ 関連: 大項目10「登録基盤検証」/ 小項目「重複機種マスターの任意選択防止」/ 0.04.19。

## 次工程
3経路のseedに正規機種IDまたは完全識別子を追加するため、既存データと照合し、曖昧/不一致/一致を分類する。

## 証跡
- `app/src/main/java/jp/smartphoneadvisor/app/data/PhoneDao.kt`
- `tools/audit_sales_seed_resolution_reasons.py`
- `tools/test_identity_query_sqlite.py`
- `SALES_SEED_RESOLUTION_AUDIT_0.04.19.txt`
- `CATALOG_AUDIT_0.04.19.txt`
- `PROJECT_MASTER_PLAN_0.04.19.md`
