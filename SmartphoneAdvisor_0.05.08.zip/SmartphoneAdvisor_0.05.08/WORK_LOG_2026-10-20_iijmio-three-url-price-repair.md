# 作業記録：IIJmio商品別URL・価格3機種修正（2026-10-20）

## 実施内容
- 公式IIJmio販売告知から商品詳細ページへのリンクをたどり、motorola edge 60、Nothing Phone (4a)、Galaxy A57 5Gの3販売登録をカテゴリURLから商品別URLへ変更。
- IIJmio公式の販売開始告知を通常価格の根拠、現行「スマホ大特価セール」告知をMNP価格の根拠として、税込価格を各2件ずつ追加。MNP条件と2026-11-04のキャンペーン期限を条件文に明記。
- IIJMIO_GENERIC_URL_REVIEW_2026-10-20.csv/.mdから解決済み3行を除外。残り12行、うち公式資料で構成を確認できる7行、根拠不足5行。
- 価格欠損監査を再生成し、価格未登録441件、AVAILABLEかつ価格未登録396件、価格情報78件に更新。
- 回帰テストの現行カタログ件数期待値を更新し、3機種のURL・価格専用テストを追加。アプリのversionName/versionCodeは変更していない。

## 公式根拠
- https://www.iijmio.jp/info/iij/1782785893.html （motorola edge 60）
- https://www.iijmio.jp/info/iij/1779069706.html （Nothing Phone (4a)、Galaxy A57 5G）
- https://www.iijmio.jp/device/ （現行ラインアップ・価格・キャンペーン表示）
- 商品別ページ： https://www.iijmio.jp/device/motorola/edge60.html 、 https://www.iijmio.jp/device/nothing/phone4a.html 、 https://www.iijmio.jp/device/samsung/galaxy-a57-5g.html

## 検証範囲
- Python回帰テストは全件をバッチ実行して記録を更新する。
- Android Gradleビルド、Kotlin/JUnit、Roomランタイム、エミュレーター、実機は本作業環境では未検証。
- 商品別ページURLの根拠は確認したが、現在のリアルタイム在庫と型番は未確認。
