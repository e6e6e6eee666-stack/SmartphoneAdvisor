# Work log — 0.05.05 Gradle compatibility

## Purpose / completion conditions
- Update the Android build configuration for the requested GitHub Actions environment (Gradle 9.8.1, JDK 17).
- Preserve app features/catalog and make no claim of Android build success without an actual build.

## Changes
- App versionName 0.05.05; versionCode 153.
- Removed `org.jetbrains.kotlin.android` declaration from root and app Gradle scripts because AGP 9.4.0 supplies built-in Kotlin support.
- Kept the Compose compiler plugin declaration.
- Updated the in-project CI workflow to Gradle 9.8.1, JDK 17, Android SDK platform 37/36/35, and `--warning-mode all`.
- Updated the structural workflow regression guard to allow Gradle 9.6.0 or newer and expect the selected Gradle 9.8.1.
- Updated the budget-reason static test's current app version metadata assertion.

## Verification
- PASS: ZIP source extracted successfully.
- PASS: `tools/test_android_validation_workflow.py`.
- PASS: `tools/test_current_version_helper.py`.
- PASS: `tools/test_budget_reason_amounts_0_05_04.py` (test filename is historical; assertion now tracks 0.05.05/153).
- PARTIAL: `tools/run_current_regression_suite.py` began the 70-test suite; 38 tests passed in the last run before the execution time limit. Full suite did not complete, so overall suite is NOT PASS.
- NOT RUN: Gradle configuration, APK compilation, JVM unit tests, emulator/instrumented tests. This environment did not have the project Gradle runtime/Android SDK setup needed to execute them.
- UNKNOWN: Availability of `platforms;android-37` in the current GitHub Actions SDK repository. CI will report a distinct SDK package error if unavailable.

## Important diagnostic note
The message `Deprecated Gradle features were used in this build, making it incompatible with Gradle 10` is normally a deprecation summary, not by itself the first causal compilation error. The first `What went wrong` / `Caused by` section and task failure earlier in the log are needed to identify the actual failing cause. `--warning-mode all` is enabled to expose the individual deprecations.
