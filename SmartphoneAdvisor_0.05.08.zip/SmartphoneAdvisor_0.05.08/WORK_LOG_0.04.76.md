# SmartphoneAdvisor 0.04.76 作業記録

## 目的・完了条件
保存済みの販売URLインベントリを版順に比較し、過去に修正したデータが消失・再導入された履歴を一覧化する。比較範囲の限界を明記し、現在のカタログを再集計して再現可能な監査証跡を残す。

## 実施内容
- `versionName=0.04.76`、`versionCode=124`へ更新。
- 0.04.52、.53、.57、.58、.59、.60、.61、.62、.69、.70、.71、.72、.73、.74、.75、.76の16スナップショットを論理販売登録単位で比較する `tools/audit_historical_sales_transitions_0_04_76.py` を追加。
- 販売登録の追加・削除と、availability・URLの変更を分離し、60件の実データ差分を `HISTORICAL_SALES_TRANSITIONS_0.04.76.csv` に記録。
- 読みやすい版間サマリー `HISTORICAL_SALES_TRANSITIONS_0.04.76.md` と、差分が再び消えないことを検査する `tools/test_historical_sales_transition_matrix_0_04_76.py` を追加。
- 現行版の価格カバレッジ、販売情報根拠、販売URL台帳の監査生成器を0.04.76用に分離。URL台帳テストと販売情報根拠テストが旧版の生成器・古いレポートを参照しないよう更新。
- 過去版の機能回帰テストの現行版ガードを0.04.76 / versionCode 124へ更新。

## 検証結果
- Pythonテスト：40/40 PASS（20件ずつ2回に分けて実行）。
- `python -m compileall -q tools`：PASS。
- `CatalogModelIdentity.kt`を単体Kotlinコンパイルし、実行ハーネスでメーカー接頭辞の正規化とGalaxy S26/S26+の区別を確認：PASS。
- 価格カバレッジ監査：195機種、313バリエーション、497販売登録、52価格オプション、価格未登録448件、AVAILABLEかつ価格未登録404件、URLなし0件。
- 販売情報根拠監査：価格オプション52件すべてに価格・sourceUrl・checkedAtあり。
- 販売URL台帳：497/497件にURL、229 unique URL、14 URLが複数機種IDで共有。
- 過去版差分監査：16スナップショット、15比較区間、差分60行を出力。
- Android Gradle/KSPビルド、Room実ランタイム取込、Android JUnit、エミュレーター・実機テストは未実施。Gradle WrapperとシステムGradleがないため。

## 問題・未確認事項
- 過去版台帳が存在しない版（例：0.04.54〜.56、.63〜.68）は版間の完全な差分を取れない。
- 販売URL台帳では価格オプションや仕様値の全履歴は比較できない。
- 差分の追加・削除はすべて自動的に不具合とは断定せず、作業記録・意図的な機種統合と合わせて確認する必要がある。
- 現行価格未登録448件は継続課題。未登録は0円や販売終了を意味しない。

## 進捗位置
大項目14「品質・監査」／中項目「過去版との回帰照合」／小項目「保存済み販売台帳の全区間差分化」

## 証跡
- `HISTORICAL_SALES_TRANSITIONS_0.04.76.md`
- `HISTORICAL_SALES_TRANSITIONS_0.04.76.csv`
- `tools/audit_historical_sales_transitions_0_04_76.py`
- `tools/test_historical_sales_transition_matrix_0_04_76.py`
- `PRICE_COVERAGE_AUDIT_0.04.76.md`
- `SALES_FACT_COMPLETENESS_AUDIT_0.04.76.md`
- `SALES_URL_INVENTORY_0.04.76.csv`
