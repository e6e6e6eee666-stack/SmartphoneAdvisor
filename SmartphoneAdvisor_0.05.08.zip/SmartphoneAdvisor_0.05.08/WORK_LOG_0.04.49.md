# SmartphoneAdvisor 0.04.49 作業記録

## 目的・完了条件
購入先リンクが機種名と一致しているかを確認し、別モデルの販売ページへ誘導する登録を無効化する。正しい専用URLを確認できない場合は推測で作らず、購入可能と断定しない。

## 実施内容
- `phones.json` の iPhone 18 Pro Max を容量別・販売チャネル別に調査。
- auとSoftBankの4容量ずつ、計8販売登録がiPhone 18 Pro向けURLを指していることを検出。
- 8登録のURLを空欄にし、販売状態を `UNKNOWN` に変更。正しいPro Max用URLは未確認のため登録していない。
- `tools/test_model_sales_link_identity_0_04_49.py` を追加し、8登録すべての誤リンク再発とURLなしAVAILABLEを検査。
- URLなし販売登録の回帰テストを更新し、既存のREDMI Note 17 Pro Max 5G 2件に加えて今回の8件も検出するよう変更。
- `versionName=0.04.49`、`versionCode=98` に更新。README、工程表、監査・検証記録を更新。

## 検証結果
- PASS: `tools/test_model_sales_link_identity_0_04_49.py` — 8件のPro Max AU/SoftBank登録を検査、エラー0。
- PASS: `tools/test_external_link_safety_0_04_49.py` — 外部URLの形式、一覧リンク表示、安全な出典ラベルを検査。
- PASS: カタログ構造監査 — 196機種、314バリアント、477販売登録、構造エラー0。
- URL未登録の販売登録は合計10件（今回のiPhone 18 Pro Max 8件、既存のREDMI Note 17 Pro Max 5G 2件）。いずれもUNKNOWNであり、購入可能とは断定しない。
- 関連回帰テスト群を実行。結果は `VALIDATION_0.04.49.txt`。
- NOT RUN: Android Gradle/KSPビルド、Roomコンパイル、Android JUnit、エミュレータ/実機試験。

## 問題・未確認事項
- au・SoftBankのiPhone 18 Pro Max専用URLは未確認。該当リンクを無効化したため、該当販売登録はRoom取込時に商品リンクとしてスキップされる。
- これはリンクの整合性修正であり、iPhone 18 Pro Max自体の国内販売・価格・在庫の確認を意味しない。
- Androidアプリ全体のビルドと実機動作は未確認。

## 進捗位置
- 主工程：大項目9「販売導線」
- 関連大工程：3「データ登録システム」、11「日本市場機種マスター」、12「販売先マスター」、13「価格・販売情報」、14「品質・監査」、16「テスト」
- 中工程：販売先URLと機種名の整合性
- 小工程：iPhone 18 Pro Maxの誤リンク8件を無効化し、回帰テストを追加
- 基準版：0.04.48 → 作業版0.04.49

## 次工程
- 他機種にも同様の機種名/URL不一致がないか、販売先別に監査を拡張。
- Android Gradle/KSPとRoomの統合検証は、ビルド環境を確保してから実施。

## 証跡
- `app/src/main/assets/phones.json`
- `app/build.gradle.kts`
- `tools/test_model_sales_link_identity_0_04_49.py`
- `tools/test_external_link_safety_0_04_49.py`
- `tools/audit_catalog_integrity_0_04_49.py`
- `CATALOG_INTEGRITY_AUDIT_0.04.49.txt`
- `PROJECT_MASTER_PLAN_0.04.49.md`
- `VALIDATION_0.04.49.txt`
