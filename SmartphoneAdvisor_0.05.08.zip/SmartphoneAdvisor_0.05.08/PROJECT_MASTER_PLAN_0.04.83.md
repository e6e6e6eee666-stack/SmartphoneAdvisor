# SmartphoneAdvisor マスタープラン更新 0.04.83

## システム見直しの結論
- 起動時JSON読込/Room取込の失敗だけでなく、DB生成・Seed初期化を含む初期化全体の失敗を画面に表示するよう修正。
- 現行版の静的健全性チェックを `tools/system_integrity_gate.py` に統合。
- 32本の現行版番号固定ガードを共通ヘルパーへ移行。回帰ランナーとマニフェストを追加し、46/46の現行回帰テストを確認。
- 過去記録は履歴として保持し、現行版の判定はGradle設定から自動取得する。
- ただしGradle WrapperとAndroid instrumentation testがなく、Androidビルド・Room実ランタイム・実機動作は未検証。リリース準備完了ではない。

## 次に優先すること
1. 正規のGradle Wrapperを追加し、Android Studio/Gradleでビルド・JUnitを実行。
2. Android instrumentation testでRoom取り込み、価格保持、重複処理、マイグレーションを実DB検証。
3. 1台診断、機種検索、詳細、比較、お気に入り、保存診断を実操作検証。
4. 価格未登録の販売登録を公式根拠で補完。推測価格は登録しない。
5. 現行回帰テストは `python tools/run_current_regression_suite.py` で実行。実行時間制限がある場合は `--batch-index 0` から4バッチに分け、全バッチ結果を集約する。
6. 以後は各作業で「ソース変更→回帰テスト→統合ゲート→Android実行確認→作業記録」を一連の完了条件とする。
