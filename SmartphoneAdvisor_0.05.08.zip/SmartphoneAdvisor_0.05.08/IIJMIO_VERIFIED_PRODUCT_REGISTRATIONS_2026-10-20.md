# IIJmio公式商品ページ確認・販売登録追加（2026-10-20）

## 確認元

- IIJmio公式販売開始告知（2026-10-15）：https://www.iijmio.jp/info/iij/1791342895.html
- POCO F9 Ultra：https://www.iijmio.jp/device/xiaomi/pocof9ultra.html
- Xperia 10 VIII：https://www.iijmio.jp/device/sony/xperia-10-VIII.html
- motorola edge 70 fusion：https://www.iijmio.jp/device/motorola/edge70fusion.html

## 反映内容

| 機種・容量/RAM | IIJmio登録 | 通常価格 | 条件付き価格 | 状態 |
|---|---|---:|---:|---|
| POCO F9 Ultra 16GB/512GB | 商品個別URLを登録 | 169,800円 | 149,800円（サプライサービスセール）、144,800円（MNP条件付き） | AVAILABLE |
| POCO F9 Ultra 12GB/256GB | **不足していた容量バリエーションを新規追加**し、商品個別URLを登録 | 149,800円 | 129,800円（サプライサービスセール）、124,800円（MNP条件付き） | AVAILABLE |
| Xperia 10 VIII 8GB/128GB | 商品個別URLを登録 | 99,000円 | 84,800円（MNP条件付き） | AVAILABLE |
| motorola edge 70 fusion 12GB/256GB | 商品個別URLを登録 | 79,800円 | 69,800円（MNP条件付き） | PREORDER（発売予定日 2026-10-23） |

全価格は税込。条件付き価格は公式告知の条件を `conditions` に記録し、通常価格と混同しないようにしています。全10価格オプションに公式告知URLと確認日 `2026-10-20` を記録しました。商品型番は公式告知で確認できなかったため推測登録していません。価格は2026年10月15日付の公式告知に基づき、在庫のリアルタイム保証ではありません。

## 集計差分

- 機種数：195（変更なし）
- バリエーション：313 → **314**（POCO F9 Ultra 12GB/256GBを追加）
- 販売登録：497 → **501**（IIJmio登録4件追加）
- 価格オプション：52 → **62**（公式根拠付き10件追加）
- 既存30件の汎用URL監査は、今回の4件とは別の未解決レコードを引き続き対象とします。

## 検証範囲

公式告知と公式商品URLを確認し、構造化データ・価格根拠・販売状態を回帰テストで照合します。価格表示や在庫のリアルタイム保証、Androidビルド、Room実行、エミュレータ・実機動作を意味するものではありません。

**価格区分の安全性:** MNP限定価格は `priceType=MNP` として保存し、通常価格・一般SALE価格と区別しました。推薦の予算判定でMNP条件価格を通常価格として扱わない既存ロジックに合わせています。
