# SmartphoneAdvisor 0.04.01 — 診断統合監査

## 実施内容
- 1台診断のOS選択を `searchJapanOfficialDevices(os.name, "")` に接続。
- `MainActivity` の診断下書き状態を `LaunchedEffect(dbReady)` より前に宣言。
- `versionName` を `0.04.01`、`versionCode` を50へ更新。
- `phones.json` を、Coreカタログと販売Seedの実データから再構成。
- UQ / Y!mobile / IIJmio / mineo / SIMフリーをJSON販売チャネルへ追加。
- Core Variantへ一意に結び付かなかった販売Seed 16件は推測登録せず `auditFindings` に残した。

## JSON検証結果
- 196 models
- 313 variants
- 472 sales listings
- 83 variants have no sales listings; these are now excluded from 1-device diagnosis candidates.
- 9 sales channels: DOCOMO / AU / SOFTBANK / RAKUTEN / UQ_MOBILE / Y_MOBILE / IIJ_MIO / MINEO / SIM_FREE
- mojibake: 0
- exact duplicate listings: 0
- unresolved seed linkages: 16 (audit findings total: 45; the remaining findings are historical/record metadata)

## ビルド検証
- Android Studio / Gradle実ビルド: 未実施
- 実機/エミュレータ: 未実施
- Gradle Wrapper: この作業環境にGradle本体がなく、wrapper jarを生成できないため未同梱。Android Studio側でGradle設定を解決してから実ビルドする。

## 完了条件
「ソース上の既知不整合を修正し、JSON統合を完了する」までを今回の完了条件とする。
「Android StudioでBUILD SUCCESSFUL」は次のPC検証工程でのみ完了とする。


## 追加監査・修正（2026-10-08）
- `SinglePhoneDiagnosticEngine.catalogCandidates()` が販売情報のないVariantを候補に残す問題を検出。
- 販売情報が `AVAILABLE` または `LIMITED` のVariantだけを1台診断候補として許可するよう修正。
- `DISCONTINUED` / `OUT_OF_STOCK` のみ、または販売情報なしのVariantは候補から除外。
- この変更を回帰テスト `catalogCandidatesExcludeVariantsWithoutPurchasableSales` で固定。
- 実ビルド・実機確認は引き続き未実施。
