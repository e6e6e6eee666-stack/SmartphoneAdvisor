# Validation report — SmartphoneAdvisor 0.04.91 maintenance package

Date: 2026-10-21

## Scope

This is a maintenance-only package on app versionName `0.04.91` / versionCode `139`. App Kotlin sources, catalog JSON, and Gradle app metadata were not changed in this pass. The corrections address stale audit/report content and regression protection.

## Changes

- Corrected the current IIJmio generic URL inventory narrative to match the nine generic-URL rows actually present in `app/src/main/assets/phones.json`.
- Recorded that REDMI Note 17 Pro Max 5G 256GB/512GB and OPPO Find N6 now have product-specific URLs, and removed them from the unresolved list.
- Regenerated the price-gap follow-up CSV and Markdown from the current catalog, including the exact catalog SHA-256.
- Corrected a stale test output string that still said 10 generic URLs.
- Added `tools/test_iijmio_generic_url_inventory_0_04_91.py`, auto-discovered by the current regression runner.

## Data-derived counts

- Phone models: 195
- Variants: 314
- Sales registrations: 501
- Price options: 78
- Sales registrations without price options: 441
- `AVAILABLE` sales registrations without price options: 396
- Missing model numbers among unpriced registrations: 365 (325 marked `AVAILABLE`)
- Generic/category URL rows in the price-gap follow-up report: 9 (all 9 currently marked `AVAILABLE`; this is catalog state, not independent live-stock confirmation)
- `phones.json` SHA-256: `643c3e7d020f8af22c9c57b5843e03e169176e7343e18096cafd8b94ed4535ae`

## Verification performed

- Current registered regression suite: 55/55 PASS, 0 FAIL, in five freshly run batches.
- Price-gap report generator: PASS; 441 gaps, 396 AVAILABLE gaps, 365 missing model numbers, 325 AVAILABLE missing model numbers, 9 generic URLs.
- `python -m compileall -q tools`: PASS.
- ZIP integrity and SHA-256: performed after packaging.

## Not verified

- Gradle/Android APK build, Kotlin/JUnit tests, Room runtime, emulator behavior, and physical-device operation were not run. The environment does not have a usable Gradle wrapper/Gradle installation and Android SDK/adb setup.
- No prices, model numbers, or live stock states were guessed or added.
