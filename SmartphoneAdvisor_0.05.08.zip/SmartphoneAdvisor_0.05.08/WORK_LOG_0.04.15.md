# Work log — 0.04.15

## 目的・完了条件
販売Seedがモデル名・容量・RAMの一致候補を複数見つけた場合、最小IDなどを根拠なく選ばず、誤った機種への販売情報紐付けを防ぐ。

## 実施内容
- `PhoneDao.getDeviceVariantIdByModelAndStorage` のSQLを修正。
- RAM指定時は一致する行がちょうど1件の場合のみIDを返す。0件または複数件はNULL。
- Carrier/SIMフリー/Verified sales/Sub-brand・MVNOの4登録経路がこのDAO検索を使用することを静的検査。
- `tools/audit_sales_variant_lookup_safety.py` と `SALES_VARIANT_LOOKUP_AUDIT_0.04.15.txt` を追加。
- アプリ版を0.04.15、versionCode 64へ更新。

## 検証結果
- 販売バリアント検索の静的検査: PASS
- 既存機種ID安全性の静的検査: PASS
- JSONカタログ構造検査: PASS（196モデル、313バリアント、472販売登録、構造エラー0、URL警告2）
- Kotlin/Gradleビルド、Room SQL実行、JUnit、実機/エミュレータ: 未実施

## 問題・未確認事項
- 一意に解決できない販売登録は現状 `return@forEach` で静かにスキップされる。誤結合は防ぐが、販売登録漏れが見えにくい。
- モデル名・容量・RAMが同じ別メーカー機種などを完全に解決するには、販売Entryにメーカー/OS/発売年/型番等の信頼できる識別情報を追加する必要がある。推測で補わない。
- 価格・在庫・URLの現実の正しさは検証していない。

## 進捗位置
大項目3「データ登録システム」／大項目4「診断」／小項目「販売登録の誤結合防止」／0.04.15。

## 次工程
スキップされた販売Seed項目を記録・集計できる監査経路を追加し、曖昧なレコードを識別情報の不足/機種未登録/バリアント未登録に分類する。

## 証跡
- `app/src/main/java/jp/smartphoneadvisor/app/data/PhoneDao.kt`
- `tools/audit_sales_variant_lookup_safety.py`
- `SALES_VARIANT_LOOKUP_AUDIT_0.04.15.txt`
- `CATALOG_AUDIT_0.04.14.txt`
- `WORK_LOG_0.04.15.md`
