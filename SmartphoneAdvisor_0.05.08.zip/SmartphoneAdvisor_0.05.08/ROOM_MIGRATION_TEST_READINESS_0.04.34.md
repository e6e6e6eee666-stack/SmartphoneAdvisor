# Room Migration Test Readiness — 0.04.34

## Changes made
- Enabled `exportSchema = true` in `AppDatabase`.
- Configured KSP `room.schemaLocation` to `app/schemas`.
- Added Android instrumentation runner and matching `room-testing` / AndroidX test dependencies.
- Kept Room schema version at 13 and did not add a speculative 13→14 migration.
- Did not fabricate schema JSON files. The first successful Gradle/KSP build must generate the current v13 snapshot; that snapshot then becomes the baseline for future migration tests.

## Important limitation
This source-only environment does not have a Gradle wrapper or a usable Gradle dependency cache, so the Android/KSP build and schema generation were not run here. No claim is made that the dependencies resolve or that instrumentation tests pass until an actual Android build is executed.

## Next safe steps
1. Run Gradle/KSP build in a compatible Android development environment.
2. Confirm `app/schemas/jp.smartphoneadvisor.app.data.AppDatabase/13.json` (exact generated path may vary by Room/KSP version) exists and reflects schema v13.
3. Commit the generated v13 schema snapshot.
4. Add a migration test only after a concrete schema change is designed; create a v13 test database with representative data and verify row counts, IDs, values, indexes, and foreign-key checks after migration.
5. Only then consider incrementing Room schema version to 14.
