# Work log — 0.05.03 regression expectation reconciliation

## Purpose
Resolve the three Python regression failures found after adding five price options, without altering catalog price data or hiding test failures.

## Evidence before changing expectations
- Parsed `app/src/main/assets/phones.json` and counted every `phones[].variants[].sales[]` entry.
- Sales registrations: 511. Registrations with at least one `priceOptions` entry: 82. Registrations with no `priceOptions`: 429. Total nested price options: 100.
- Catalog declared counts agree: 195 models / 315 variants / 511 sales listings / 100 price options / 45 audit findings.
- Ran `audit_catalog_price_gaps_0_04_96.py`: PASS, 429 total price gaps and 385 AVAILABLE price gaps.
- Ran `audit_price_gap_followup_0_04_96.py`: PASS, 429 gaps, 354 missing model numbers, 315 AVAILABLE rows missing model numbers, 7 generic URLs.
- Ran `audit_sales_fact_completeness_0_04_76.py`: PASS, 511 sales, 100 price options, 429 registrations without price options.
- The older `CATALOG_PRICE_GAP_AUDIT_2026-10-21.md` was stale (95 options, 434 gaps); the generator and report were refreshed from current JSON.

## Changes
- Updated `tools/test_price_gap_followup_0_04_89.py` expected counts from the old baseline to current generated report values: 434→429, 359→354, 319→315, and 9→7. Updated its success message to identify the 0.05.03 baseline.
- Updated `tools/test_sales_fact_completeness_0_04_55.py` expected generated report phrase from 434 to 429.
- No edit to `test_sales_fact_completeness_0_04_54.py`: it is only a compatibility wrapper for test 0.04.55.
- No changes to `phones.json` or its prices during this reconciliation.

## Verification
- Relevant tests: PASS (`test_price_gap_followup_0_04_89.py`, `test_sales_fact_completeness_0_04_54.py`, `test_sales_fact_completeness_0_04_55.py`, `test_catalog_price_gap_audit_0_04_89.py`).
- Full maintained Python regression suite: 63/63 PASS across 13 batches, batch size 5 (final batch 3); 0 failures; 0 timeouts. See `test_results_0.05.03.txt` and `test_results_0.05.03_batch_1.txt` … `test_results_0.05.03_batch_13.txt`.
- `python3 -m compileall -q tools`: PASS.
- Android Gradle build, Kotlin/JUnit runtime, Room runtime import, emulator, and physical device: NOT RUN.

## Versioning
Catalog/runtime data did not change in this reconciliation; app version remains `0.05.03`, versionCode `151`.
