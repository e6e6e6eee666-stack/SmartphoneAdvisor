# SmartphoneAdvisor 0.04.61 作業記録

## 1. 目的・完了条件
iPhone 18 Pro / Pro Maxのドコモ公表価格を容量別にカタログ登録し、価格の種類・条件・出典を明確化する。価格未確認の販売登録を推測で埋めない。

## 2. 基準版・版数
- 基準：0.04.60 / versionCode 109
- 今回：0.04.61 / versionCode 110

## 3. 実施内容
- ドコモの割引適用前一括価格を8件登録：iPhone 18 Pro（256GB ¥263,230、512GB ¥309,870、1TB ¥395,230、2TB ¥518,980）、iPhone 18 Pro Max（256GB ¥291,500、512GB ¥334,290、1TB ¥419,650、2TB ¥543,400）。
- 価格種別をNORMALとし、返却プログラム・MNP割引・キャンペーン・ポイント還元を含まない旨を条件欄に記録。
- 価格の発表値はケータイ Watchの2026-09-11報道で照合。ドコモ購入導線URLは既存の機種別公式ページを保持。
- 価格監査、販売情報の根拠監査、URLインベントリ、README、固定20大項目工程表、回帰テストを更新。

## 4. 検証結果
- 機種：196、バリエーション：314、販売登録：495、価格オプション：30。
- 価格オプションなし：467販売登録（前版475から8件減）。AVAILABLEかつ価格なし：418件。
- 8容量価格の数値・NORMAL区分・sourceUrl・checkedAt・割引条件を回帰テストで検証。
- Pythonテストとcompileall、JSON構文、ZIP整合性検査を実施予定。最終結果はVALIDATION_0.04.61.txt。
- Android Gradle/KSPビルド、Roomランタイム、Android JUnit、エミュレータ・実機試験は未実施。

## 5. 問題・未確認事項
- 今回の価格値はキャリア発表を報じた二次資料により照合。価格詳細のドコモ公式ページはこの実行環境から直接内容を確認できていないため、監査上はこの制約を明記。
- au・SoftBank・楽天モバイルの容量別価格、他機種・他チャネルの価格網羅は未完了。
- 価格登録はライブ在庫を意味しない。アプリのAndroidビルド・Room・実機動作は未確認。

## 6. 進捗位置
- 大項目：13 価格・販売情報
- 中項目：キャリア別価格の根拠付き登録
- 小項目：ドコモ iPhone 18 Pro / Pro Max 8容量価格
- バージョン：0.04.61 / versionCode 110

## 7. 次工程
au・SoftBank・楽天モバイルの容量別通常価格を、公式一次資料で確認できた範囲だけ登録する。次に主要Android機種の価格カバレッジを優先度順に改善する。

## 8. 証跡
- `app/src/main/assets/phones.json`
- `tools/test_docomo_iphone18pro_prices_0_04_61.py`
- `tools/audit_price_coverage_0_04_61.py`
- `PRICE_COVERAGE_AUDIT_0.04.61.md`
- `SALES_FACT_COMPLETENESS_AUDIT_0.04.61.md`
- `SALES_URL_INVENTORY_0.04.61.csv`
- `VALIDATION_0.04.61.txt`
- `SmartphoneAdvisor_0.04.61_docomo-iphone18pro-prices.zip`
