# 主要機能・画面導線のソース監査（2026-10-18）

## 判定基準
この文書はソース上の接続確認であり、Android上での操作成功を意味しない。各項目は「コード上で確認」「未検証」を分ける。

| 機能 | ソース上の入口・接続 | 静的確認 | 実操作 |
|---|---|---|---|
| 起動・初期化 | `MainActivity.onCreate` → `SmartphoneAdvisorApp` → `PhoneCatalogJsonLoader` → `SeedData.ensureSeeded` → `PhoneCatalogRoomImporter.importCatalog` | 接続あり。失敗時にログ・警告・再試行経路あり | 未検証 |
| 通常診断・推薦 | `RecommendationEngine.recommend(...)`、推薦理由・除外理由の構築 | 呼出しあり | 未検証 |
| かんたん1台診断 | `SinglePhoneDiagnosticFlow` / `SinglePhoneDiagnosticScreen.kt` / `SinglePhoneDiagnosticEngine.kt`。JSON候補とDAO検索結果を接続 | 接続あり | 未検証 |
| 機種一覧・検索 | `Screen.BROWSE`、`searchJapanOfficialDevices`、クエリ・OS・メーカー・シリーズ等のフィルター状態 | 接続あり | 未検証 |
| 機種詳細・購入選択肢 | `Screen.DETAIL` 時に `getDeviceDetail`、`getPurchaseOptions`、`getOpenDataConflicts` を取得 | 接続あり | 未検証 |
| 比較 | `Screen.COMPARE` 時に `getComparisonItems` / `getComparisonPrices`。追加時は最大5件の状態制御 | 接続あり | 未検証 |
| お気に入り | DAOからお気に入りIDをFlow取得し、一覧・検索と照合。登録/解除の処理あり | 接続あり | 未検証 |
| 診断保存・再開 | 起動時に下書きを読み、保存済み診断一覧から編集・再診断・名前変更・アーカイブを呼ぶ | 接続あり | 未検証 |
| DB移行 | `AppDatabase` version 14、migration 1→14の登録がある（過去テストはSQLite/Python契約を含む） | 宣言と静的テストは存在 | Android Room実行は未検証 |

## 監査所見
1. 主な機能のソース入口とデータ接続は存在し、直ちに全機能を作り直す根拠はない。
2. Androidビルドが未実施のため、Kotlin型・Compose API・Room生成コードを含めてコンパイルできるかは不明。
3. JSON→Roomの実投入、既存DBからの移行、再起動後のデータ保持、失敗時の回復、画面間の戻る操作は実行証跡がない。
4. 比較追加はソース上最大5件。ユーザー要件・正式仕様との整合は別途完了条件に照合する。
5. 画面と処理が存在することと、利用者が問題なく完遂できることは区別し、端末試験までは「実装済み・未検証」と扱う。

## 次の作業
- A-04：版別ログの主張を、現行ソース・テスト・現行データの証跡に紐付ける。
- A-05：画面遷移、戻る操作、エラー・空データ・失敗後再試行をテストケース化する。
- 大項目1の完了条件を満たした後に大項目2のビルドゲートへ進む。
