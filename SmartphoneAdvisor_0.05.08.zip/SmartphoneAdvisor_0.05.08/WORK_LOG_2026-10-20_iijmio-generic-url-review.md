# 作業記録：IIJmio汎用URLの追加照合（2026-10-20）

## 実施内容
- 最新配布ZIPを基準に、phones.jsonのIIJmio販売登録を再走査。
- 汎用端末一覧URL `https://www.iijmio.jp/device/` を使う登録30件を抽出し、CSV/Markdown監査表を追加。
- IIJmio公式端末一覧（https://www.iijmio.jp/device/）を確認。掲載が確認できるモデルもある一方、全30件について各RAM/ストレージ構成の個別商品ページURLを確定できる根拠は不足。
- URLや価格を推測で書き換えることはせず、確認待ちとして可視化。
- CSVとJSONの対象レコードが一致する回帰テストを追加。

## 検証
- 新規監査テスト：実行結果は検証記録参照。
- 既存Python回帰テスト53件は前版でPASS済み。新規テスト追加後は合計54件相当となるため、全件を再実行して記録する。
- Android APKビルド、Kotlin/JUnit、Room実行、エミュレーター/実機は未検証。

## Follow-up correction — 2026-10-20

- Corrected a report-generation placeholder that had been left literal in the Markdown summary; the audited count is 30 and is now asserted by the regression test.
- No catalog values or prices changed.
- Re-ran the targeted audit test and the regression runner in small batches where possible; full-suite results are recorded separately and not inferred from partial runs.

## Follow-up — current official listing evidence (2026-10-20)
- Rechecked the current official IIJmio lineup after the earlier audit. The indexed category page now exposes exact capacity labels for multiple Galaxy S26 / Z Fold8 / Z Flip8 configurations and displays prices/stock labels.
- Added `IIJMIO_OFFICIAL_LISTING_FOLLOWUP_2026-10-20.md` to document this stronger evidence and the important distinction between exact configuration displayed in a category listing and a verified product-specific URL / current in-stock status.
- No catalog availability, URL, or price fields were bulk changed because each record still needs a verified product-detail mapping and exact stock/price-condition linkage.
