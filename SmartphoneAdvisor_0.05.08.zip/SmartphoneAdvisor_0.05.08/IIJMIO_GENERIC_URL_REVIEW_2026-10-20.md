# IIJmio generic URL review — 2026-10-20 (follow-up repair)

- Official generic lineup: https://www.iijmio.jp/device/ (retrieved 2026-10-20).
- Verified earlier repair: Galaxy S26 Ultra page https://www.iijmio.jp/device/samsung/galaxy-s26-ultra.html.
- Additional exact product pages verified through IIJmio's own sale announcements and linked product detail pages:
  - Galaxy Z Fold8 Ultra: https://www.iijmio.jp/device/samsung/galaxy-z-fold8-ultra.html
  - Galaxy Z Fold8: https://www.iijmio.jp/device/samsung/galaxy-z-fold8.html
  - Galaxy Z Flip8: https://www.iijmio.jp/device/samsung/galaxy-z-flip8.html
  - OPPO Reno16 5G: https://www.iijmio.jp/device/oppo/reno16-5g.html
  - MIVE ケースマ: https://www.iijmio.jp/device/alt/mive-kesuma.html
- Remaining generic-category URL registrations: **7** (down from 9 after the Galaxy S26 256GB and Galaxy S26+ 256GB listings were linked to the official IIJmio announcement that documents their prices; the two REDMI Note 17 Pro Max 5G capacity-specific detail pages and OPPO Find N6 product page are also confirmed).
- Remaining registrations whose exact RAM/storage variant is listed in official evidence but whose individual item-level stock/model number still needs confirmation: **5**.
- Remaining registrations without sufficient retrieved official evidence: **4**.
- This is an evidence-strength classification, not a determination that unconfirmed models are not sold.
- For remaining generic-URL rows, no model numbers, prices, or live stock states were guessed. The current `AVAILABLE` state in the catalog is not independently confirmed by the generic URL or by an announcement alone.

## Additional URL repairs completed — 2026-10-20

Ten IIJmio sales registrations were changed from the generic `https://www.iijmio.jp/device/` URL to an official product-specific page: MIVE ケースマ (1), OPPO Reno16 5G (1), Galaxy Z Fold8 Ultra (3), Galaxy Z Fold8 (3), Galaxy Z Flip8 (2). The official IIJmio announcements confirm the models and RAM/storage variants:

- Samsung Galaxy Z Fold8 Ultra / Fold8 / Flip8 announcement: https://www.iijmio.jp/info/iij/1785122699.html
- OPPO Reno16 5G / MIVE ケースマ announcement: https://www.iijmio.jp/info/iij/1787302297.html

The pages and announcement links are official, but current live stock was not independently verified in this pass. Catalog model numbers and price options were left unchanged. Catalog counts remain 195 models / 314 variants / 501 sales registrations / 72 price options / 45 audit findings.

## Additional official product URL and current price repairs — 2026-10-20

The following three IIJmio registrations now use product-specific pages linked by official IIJmio announcements, and two current official listing prices (normal and MNP) were recorded for each. Prices are tax-included; MNP prices have eligibility conditions and the official listing shows the campaign through 2026-11-04.

- motorola edge 60 (8GB/128GB): https://www.iijmio.jp/device/motorola/edge60.html — normal ¥59,800 / MNP ¥37,800.
- Nothing Phone (4a) (8GB/128GB): https://www.iijmio.jp/device/nothing/phone4a.html — normal ¥59,800 / MNP ¥44,800.
- Galaxy A57 5G (8GB/128GB): https://www.iijmio.jp/device/samsung/galaxy-a57-5g.html — normal ¥79,800 / MNP ¥59,800.

Sources: https://www.iijmio.jp/info/iij/1782785893.html ; https://www.iijmio.jp/info/iij/1779069706.html ; https://www.iijmio.jp/device/ . Current live stock and model numbers remain unverified.

## Still unresolved

Current catalog re-count (phones.json in 0.04.91): the seven registrations still using the generic category URL are motorola razr fold (1), Xiaomi 17T (1), Xiaomi 17T Pro (1), Xiaomi 17 Ultra (1), Galaxy S26 (512GB only), Galaxy S26+ (512GB only), and OPPO Find X9 Ultra (1). REDMI Note 17 Pro Max 5G (both capacities) and OPPO Find N6 are no longer generic-URL rows; their product-specific URLs are present in the current JSON. The list in the prior version of this paragraph was stale and has been corrected. Current live stock and model numbers remain unverified for the seven generic-URL rows. Do not infer product-specific URLs or availability from a category listing alone.

## Additional verified repair — moto g37j

- Product-specific page linked by IIJmio official sale announcement: https://www.iijmio.jp/device/motorola/moto-g37j.html
- Official announcement confirms 4GB/128GB, normal price ¥38,800, and MNP campaign price ¥19,800 through 2026-11-04 21:59: https://www.iijmio.jp/info/iij/1784598862.html
- Both prices were added with tax-included conditions, source URL, and checkedAt 2026-10-20. This is not a live stock guarantee.


## Additional capacity-specific REDMI detail-page repair — 2026-10-21

- REDMI Note 17 Pro Max 5G [8GB/256GB]: https://www.iijmio.jp/device/detail.html?key=REDMI_Note_17_Pro_Max_5G_256GB
- REDMI Note 17 Pro Max 5G [8GB/512GB]: https://www.iijmio.jp/device/detail.html?key=REDMI_Note_17_Pro_Max_5G_512GB
- IIJmio official product detail pages explicitly show the corresponding RAM/storage variants, normal prices, sale prices, and MNP prices. The catalog sales URL and each price option sourceUrl now point to the matching capacity-specific page; price values and availability state were not changed.
- Official sources: https://www.iijmio.jp/device/detail.html?key=REDMI_Note_17_Pro_Max_5G_256GB ; https://www.iijmio.jp/device/detail.html?key=REDMI_Note_17_Pro_Max_5G_512GB ; https://www.iijmio.jp/info/iij/1788852413.html
- Historical count at that checkpoint: **10** (five exact-variant evidence rows, five insufficient-evidence rows). This count predates later URL repairs; use the current catalog-derived count above for 0.04.91. Live stock and model numbers remain unverified.


## Additional verified product page repair — OPPO Find N6 (2026-10-21)

- Official IIJmio product page: https://www.iijmio.jp/device/oppo/findn6.html
- The page identifies OPPO Find N6, RAM 16GB / ROM 512GB and lists normal price ¥314,820 and MNP price ¥299,800. The existing catalog price values were not changed in this URL-only repair; price provenance should be audited separately.
- The sale URL and any existing price option source URLs were changed from the generic category URL to the model-specific page. The catalog availability value was not changed; live orderability and model number are not independently confirmed.
- Source: https://www.iijmio.jp/device/oppo/findn6.html (official IIJmio product page, retrieved 2026-10-21).
- Remaining generic URLs: **7** (three exact-variant evidence rows, four insufficient-evidence rows).


## Official URL alignment — 2026-10-21

- Galaxy S26 256GB and Galaxy S26+ 256GB now link to the same official IIJmio announcement URL already used as the source for their recorded tax-included normal prices: https://www.iijmio.jp/info/iij/1772412502.html. No price amount, availability state, or model-number field was changed. Their 512GB registrations remain on the generic category URL because the current evidence does not establish the exact variant-specific listing.
