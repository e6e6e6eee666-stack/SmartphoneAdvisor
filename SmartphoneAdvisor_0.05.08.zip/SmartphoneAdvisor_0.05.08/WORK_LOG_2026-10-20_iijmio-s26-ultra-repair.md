# Work log — 2026-10-20: IIJmio Galaxy S26 Ultra URL and stock correction

## Work completed
- Updated the three Galaxy S26 Ultra IIJmio sales registrations from the generic `/device/` category URL to the verified product-specific page `https://www.iijmio.jp/device/samsung/galaxy-s26-ultra.html`.
- Kept 12GB/256GB and 12GB/512GB at their prior catalog availability state.
- Changed the 16GB/1TB listing from `AVAILABLE` to `OUT_OF_STOCK` because the official product page labels that capacity temporarily out of stock.
- Did not infer model numbers or add prices. The official page verifies model/capacity and stock state, but the current price facts still need a structured source-backed price entry.
- Rebuilt the generic URL review from the live catalog rows: 30 -> 27 generic IIJmio URL registrations.
- Regenerated the price-gap audit and source SHA-256 after the catalog update.
- Updated regression guards to allow this specific evidence-backed correction while retaining historical catalog facts.

## Verification
- Python regression tests: 58/58 PASS, individually run in batches of up to 10; 0 failures and 0 timeouts.
- `python -m compileall -q tools`: PASS.
- Catalog totals remain 195 models / 314 variants / 501 sales registrations / 70 price options.
- Price gaps remain 448; rows marked AVAILABLE but missing price decrease from 404 to 403 because the 1TB listing is now OUT_OF_STOCK. Missing model numbers remain 372; missing-model-number rows still marked AVAILABLE decrease from 333 to 332.
- Generic category URL rows in the price-gap follow-up audit: 27 (down from 30).
- Android build, Kotlin/JUnit execution, Room runtime, emulator, and physical-device behavior: NOT VERIFIED in this environment.

## Source evidence
- IIJmio Galaxy S26 Ultra product page: https://www.iijmio.jp/device/samsung/galaxy-s26-ultra.html (retrieved 2026-10-20; page lists the 12GB/256GB, 12GB/512GB, 16GB/1TB configurations and marks 1TB temporarily out of stock).
- IIJ corporate announcement: https://www.iij.ad.jp/news/pressrelease/2026/0312.html (model capacities and initial normal prices; not used to invent a new catalog price in this repair).
