# 0.04.89 作業記録：大項目1・基準資産と構成棚卸し（2026-10-18）

## 目的・完了条件
正式工程表の大項目1を実作業で進め、基準ZIP、アプリ版、ソース構成、データ件数、テスト/ビルド証跡を固定する。

## 実施内容
- 基準ZIPをLibraryから実ファイルとして取り出し、サイズ・SHA-256・CRCを確認。
- 工程表修正版と基準ZIPを展開し、`app/src/**`、アプリGradle設定、root Gradle設定の40対象ファイルを比較。差分0、欠落0、追加0。
- Kotlin/XML/JSONのソース構成、unit/androidTestファイル、CI設定、Manifest、Gradle依存を棚卸し。
- `phones.json` の宣言値と実際の配列件数を独立に計算し、5項目すべて一致を確認。
- 現行回帰スイートを再実行。一括実行は300秒の実行上限に達したため、12件単位に分割し、テスト1〜48を4バッチで実行。テスト49・50は最終バッチ途中までの実行でPASS、テスト51は単独実行でPASS。今回の個別実行合計は51/51 PASS。
- `MainActivity` の起動初期化、JSON→Room importer、1台診断、通常推薦、一覧検索、詳細、比較、お気に入り、保存済み診断のソース接続を静的追跡。
- `CURRENT_APP_AUDIT_INVENTORY_2026-10-18.md` と `FEATURE_FLOW_AUDIT_2026-10-18.md` を更新し、台帳A-01/A-03/A-04/A-05/A-07を更新。
- `WORK_LOG_0.04.89.md` の「大項目14」という履歴記載について、正式工程位置と混同しない訂正注記を追加。

## 検証結果
- 基準ZIP CRC：PASS
- 基準ZIP SHA-256：`1db395ba4271548454cb960a338d4d746c568212dace9866d2ebbcc45bbe3f0d`
- アプリ版：`versionName=0.04.89`, `versionCode=137`
- JSON counts：195機種、313 variants、497販売登録、52価格選択肢、45監査指摘（宣言/実測一致）
- Python回帰テスト分割再実行：51/51 PASS、0 FAIL。全件一括実行は実行時間上限で停止し、CIでの一括実行再確認を残す
- Android build / Kotlin-JUnit / Room実DB / 実機：未検証

## 問題・未確認事項
- `gradlew` と `gradle/wrapper/` が存在しない。監査環境にはJava 21はあるがGradle/adbは見つからず、Android SDKも確認できていない。
- CI定義はあるが、実行ログがないためビルド成功とはみなせない。
- 497販売登録中448件に価格選択肢がない。
- 一括実行のタイムアウト原因は確定していない。個別テストの分割実行結果とCI一括実行の結果を別々に記録する。

## 進捗位置
大項目1「現行アプリ総合監査」／A-01完了、A-03静的棚卸し済み、A-04/A-05継続／アプリ版0.04.89（文書・監査記録のみ更新）。

## 次工程
A-04の版別証跡索引を仕上げ、A-05の画面遷移・失敗時回復・戻る操作をテストケース化する。大項目1の完了条件を満たしてから大項目2のAndroid実ビルドへ進む。

## 証跡
- `CURRENT_APP_AUDIT_INVENTORY_2026-10-18.md`
- `PROJECT_TASK_REGISTER_0.04.89.md`
- `app/build.gradle.kts`
- `app/src/main/assets/phones.json`
- `.github/workflows/android-validation.yml`


## 工程位置訂正
`WORK_LOG_0.04.89.md` 本文にある「大項目14」は当時の変更テーマの分類であり、正式工程表上の現在地ではない。正式な再開位置は大項目1「現行アプリ総合監査」である。
