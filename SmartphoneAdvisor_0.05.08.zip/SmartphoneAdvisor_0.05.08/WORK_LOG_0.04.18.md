# WORK LOG 0.04.18

## 目的・完了条件
販売登録seedの機種照合で、同じ表示名を持つ複数の機種マスターが存在する場合、容量/RAMの候補がたまたま1件だけでも誤った機種に紐付けない。完全識別子検索と従来検索の両方で、機種名の一意性を確認する。

## 実施内容
- `PhoneDao.getDeviceVariantIdByFullIdentity` に `COUNT(DISTINCT m.id) = 1` の条件を追加。
- `PhoneDao.getDeviceVariantIdByModelAndStorage` にも同じ機種マスター一意性条件を追加。
- `tools/audit_sales_seed_resolution_reasons.py` を更新し、2つの検索で機種マスター一意性ガードがあるか監査。
- カタログ構造監査を再実行し、結果を保存。
- バージョンを `0.04.18` / `versionCode 67` に更新。

## 検証結果
- `python tools/audit_sales_seed_resolution_reasons.py`: 実行完了。両DAO検索の一意性ガードを検出。SIMフリー・価格・MVNOの3 seedがメーカー/platform/発売年を保持しない点は引き続き REVIEW。
- `python tools/audit_diagnostic_catalog.py`: exit 0、構造エラー0件、警告2件。警告はREDMI Note 17 Pro Max 5Gの販売URL未設定2件。
- `PhoneDao.kt`: 2つのSQLに `COUNT(DISTINCT m.id) = 1` が存在することを文字列検査。
- ZIP整合性検査: 作成後に実行。
- Kotlin/Gradleビルド、Room/SQLite実行、Android実機テスト: 未実施。成功とは扱わない。

## 問題・未確認事項
- 3経路（SIMフリー、価格、サブブランド/MVNO）はメーカー・platform・発売年をseed entryとして持たず、名前/容量/RAM検索に依存。今回はそのデータを推測で埋めていない。
- 完全識別子が一致する重複モデルが存在する場合は、`COUNT(DISTINCT m.id) = 1` により未解決になる。
- Gradle/KSPでSQL検証が通るか、Room上で集計SQLが期待通り動くかは未確認。

## 進捗位置
大項目3「データ登録システム」/ 関連: 大項目4「診断」/ 小項目「販売seedの誤紐付け防止」/ 0.04.18。

## 次工程
SIMフリー・価格・サブブランド/MVNO seedへ正規機種IDまたは完全識別子を安全に供給する方法を実装し、seedごとの未解決件数と理由を出力する。推測マッピングは行わない。

## 証跡
- `app/src/main/java/jp/smartphoneadvisor/app/data/PhoneDao.kt`
- `tools/audit_sales_seed_resolution_reasons.py`
- `SALES_SEED_RESOLUTION_AUDIT_0.04.18.txt`
- `CATALOG_AUDIT_0.04.18.txt`
- `app/build.gradle.kts`
