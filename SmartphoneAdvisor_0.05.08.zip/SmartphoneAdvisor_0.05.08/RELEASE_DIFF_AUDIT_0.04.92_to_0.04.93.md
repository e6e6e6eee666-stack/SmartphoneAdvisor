# Release diff audit: 0.04.92 → 0.04.93

## Identity
- App versionName: 0.04.93
- App versionCode: 141 (previous: 140)
- Source of truth: `app/src/main/assets/phones.json`

## Verified changes
- Added one source-backed normal price option to ASUS Store Japan's existing ROG Phone 9 12GB/256GB listing: ¥159,800 including tax.
- Official source URL: https://rog.asus.com/jp/phones/rog-phone-9/
- Source page identifies ROG9-BK12R256 and ROG9-WH12R256 as 12GB/256GB SKUs at ¥159,800 tax included.
- Added official source URL to `authoritativeSalesSources`; did not change the sales listing identity/model number.
- Updated declared catalog counts: 195 models, 314 variants, 501 sales listings, 80 price options, 45 audit findings.
- Regenerated price-gap CSV/Markdown from the current JSON. Current totals: 439 sales registrations without a price option; 394 of those marked AVAILABLE; 364 missing model numbers; 9 category/top-page URLs. No price was inferred for the remaining records.
- Updated current-data regression checks that incorrectly pinned the old 79-price / 440-gap totals. Historical preservation baselines remain intact.

## Verification
- Current Python regression suite: 55 tests, 55 passed, 0 failed.
- Python `compileall`: passed (`python -m compileall -q tools`).
- ZIP integrity and SHA-256: verified after packaging.
- Not verified: Gradle Android build, Kotlin/JUnit execution, Room runtime import, emulator instrumentation, physical device operation.
