# 作業記録 — 2026-10-20 IIJmio AQUOS wish6 / REDMI Note 17 Pro Max 5G

## 実施内容
- AQUOS wish6（4GB/128GB）のIIJmio販売URLを公式端末詳細ページへ修正。
- AQUOS wish6の通常価格49,300円、MNP価格39,800円を公式根拠付きで登録。
- REDMI Note 17 Pro Max 5G（8GB/256GB、8GB/512GB）について、IIJmio公式ラインアップに記載された通常価格・期間限定値下げ価格・MNP価格を各構成に登録。
- REDMIの直接詳細URLは確認できていないため、購入URLは汎用一覧のまま維持。公式一覧に構成と価格が表示されることと、専用URL／リアルタイム注文可能性の確認は区別した。
- IIJmio汎用URL監査を更新し、AQUOS wish6の行を除外。REDMI 2構成はモデル・構成・価格の根拠を反映しつつ、専用URL未確認として残した。
- 価格欠損監査、価格欠損フォローアップ、販売情報完全性監査を再生成。
- 過去データ保持テストに、根拠付きのAQUOS wish6 URL修正を明示的に許可する例外を追加。現在カタログの集計値を検査する回帰テストを更新・追加。

## 公式根拠
- AQUOS wish6の公式端末詳細・価格: https://www.iijmio.jp/device/detail.html?key=AQUOS_wish6
- AQUOS wish6とREDMI Note 17 Pro Max 5Gの販売開始・通常価格: https://www.iijmio.jp/info/iij/1788852413.html
- REDMI Note 17 Pro Max 5Gの通常／期間限定価格／MNP価格、2026年11月4日までの値下げ表示: https://www.iijmio.jp/device/

## 検証結果
- Python回帰テスト: 59ファイルを4バッチに分けて実行、59/59 PASS。変更後の主要テスト（IIJmio generic URL review、AQUOS/REDMI prices、price-gap follow-up、price-gap audit、sales fact completeness）も再実行してPASS。
- `python -m compileall -q tools`: PASS。
- カタログ: 195機種 / 314バリエーション / 501販売登録 / 70価格選択肢。
- 価格選択肢未登録: 445販売登録。うちAVAILABLE: 400。
- 価格未登録監査内の型番未登録: 369。AVAILABLEかつ型番未登録: 329。
- IIJmio汎用URL監査: 26登録。うち公式一覧上でRAM/容量構成を確認できるが専用URL・型番・リアルタイム注文可能性が未確認: 19、取得した公式根拠だけでは構成の裏付けが不十分: 7。
- 価格欠損フォローアップに残る汎用URL: 24（価格未登録の販売行のみを対象とするため、全体の26件とは母集団が異なる）。
- app versionName/versionCodeは doc/data修正のため変更せず、0.04.90 / 138を維持。
- Gradle build、Kotlin/JUnitの実行、Room runtime、emulator、実機動作は未検証。
