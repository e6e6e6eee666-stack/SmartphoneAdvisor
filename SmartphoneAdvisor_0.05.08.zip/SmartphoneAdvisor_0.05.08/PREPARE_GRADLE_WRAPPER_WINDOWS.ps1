﻿param(
    [string]$ProjectRoot = (Get-Location).Path
)
$ErrorActionPreference = 'Stop'
$GradleVersion = '9.6.0'
$ProjectRoot = (Resolve-Path $ProjectRoot).Path
if (!(Test-Path (Join-Path $ProjectRoot 'settings.gradle.kts')) -or !(Test-Path (Join-Path $ProjectRoot 'app/build.gradle.kts'))) {
    throw "ProjectRoot must be the SmartphoneAdvisor project root (settings.gradle.kts and app/build.gradle.kts must exist)."
}
# Derive the project version from the resolved project root to avoid stale setup logs.
$buildFile = Get-Content (Join-Path $ProjectRoot 'app/build.gradle.kts') -Raw
if ($buildFile -match 'versionName\s*=\s*"([0-9.]+)"') {
    $AppVersion = $Matches[1]
} else {
    throw 'app/build.gradle.ktsからversionNameを読み取れません。'
}
$DistributionUrl = "https://services.gradle.org/distributions/gradle-$GradleVersion-bin.zip"
$DistributionSha256 = 'bbaeb2fef8710818cf0e261201dab964c572f92b942812df0c3620d62a529a01'
$WrapperJarSha256 = '497c8c2a7e5031f6aa847f88104aa80a93532ec32ee17bdb8d1d2f67a194a9c7'

$javaPath = $null
if ($env:JAVA_HOME -and (Test-Path (Join-Path $env:JAVA_HOME 'bin/java.exe'))) {
    $javaPath = Join-Path $env:JAVA_HOME 'bin/java.exe'
}
if (!$javaPath -and (Get-Command java.exe -ErrorAction SilentlyContinue)) {
    $javaPath = (Get-Command java.exe).Source
}
$candidates = @(
    "$env:LOCALAPPDATA\Programs\Android Studio\jbr\bin\java.exe",
    "$env:ProgramFiles\Android Studio\jbr\bin\java.exe",
    "$env:ProgramFiles\Android\Android Studio\jbr\bin\java.exe",
    "$env:ProgramFiles\AndroidStudioRabbit1\jbr\bin\java.exe"
)
if (!$javaPath) {
    foreach ($candidate in $candidates) { if (Test-Path $candidate) { $javaPath = $candidate; break } }
}
if (!$javaPath) {
    $manual = Read-Host 'Android Studioのjbr\bin\java.exeのフルパスを入力してください（見つからない場合は空欄で終了）'
    if ($manual -and (Test-Path $manual)) { $javaPath = (Resolve-Path $manual).Path }
}
if (!$javaPath) { throw 'Javaが見つかりません。Android Studio内のjbr\bin\java.exeを確認してから再実行してください。' }
$javaHome = Split-Path (Split-Path $javaPath -Parent) -Parent
$env:JAVA_HOME = $javaHome
$env:Path = (Join-Path $javaHome 'bin') + ';' + $env:Path
$javaVersionOutput = (& $javaPath -version 2>&1 | Out-String)
if ($javaVersionOutput -notmatch 'version \"(?:1\.)?(\d+)') { throw 'Javaのバージョンを判定できません。Android Studio内蔵Javaを指定してください。' }
if ([int]$Matches[1] -lt 17) { throw "Java 17以上が必要です。検出したバージョン: $($Matches[1])" }

$tempRoot = Join-Path ([IO.Path]::GetTempPath()) ("SmartphoneAdvisor-GradleWrapper-" + [guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $tempRoot | Out-Null
try {
    $zipPath = Join-Path $tempRoot "gradle-$GradleVersion-bin.zip"
    $extractPath = Join-Path $tempRoot 'distribution'
    $bootstrapPath = Join-Path $tempRoot 'wrapper-bootstrap'
    New-Item -ItemType Directory -Path $extractPath, $bootstrapPath | Out-Null
    Write-Host "Gradle $GradleVersion を公式配布元からダウンロードします（約135 MB）。"
    Invoke-WebRequest -Uri $DistributionUrl -OutFile $zipPath
    $actual = (Get-FileHash $zipPath -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($actual -ne $DistributionSha256) { throw "Gradle ZIPのSHA-256が一致しません。Expected=$DistributionSha256 Actual=$actual" }
    Write-Host '公式公開SHA-256一致。展開します。'
    Expand-Archive -LiteralPath $zipPath -DestinationPath $extractPath
    $gradleBat = Join-Path $extractPath "gradle-$GradleVersion\bin\gradle.bat"
    if (!(Test-Path $gradleBat)) { throw 'Gradle配布物にgradle.batが見つかりません。' }
    Set-Content -LiteralPath (Join-Path $bootstrapPath 'settings.gradle.kts') -Value 'rootProject.name = "wrapper-bootstrap"' -Encoding UTF8
    Set-Content -LiteralPath (Join-Path $bootstrapPath 'build.gradle.kts') -Value '// Temporary empty project used only to generate official Gradle Wrapper files.' -Encoding UTF8
    Push-Location $bootstrapPath
    try {
        & $gradleBat wrapper --gradle-version $GradleVersion --distribution-type bin --gradle-distribution-sha256-sum $DistributionSha256
        if ($LASTEXITCODE -ne 0) { throw "公式Gradle配布物によるWrapper生成が失敗しました (exit $LASTEXITCODE)." }
    } finally { Pop-Location }
    $jar = Join-Path $bootstrapPath 'gradle/wrapper/gradle-wrapper.jar'
    if (!(Test-Path $jar)) { throw '生成されたgradle-wrapper.jarがありません。' }
    $jarActual = (Get-FileHash $jar -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($jarActual -ne $WrapperJarSha256) { throw "Wrapper JARのSHA-256が公式公開値と一致しません。Expected=$WrapperJarSha256 Actual=$jarActual" }
    $targetWrapper = Join-Path $ProjectRoot 'gradle/wrapper'
    New-Item -ItemType Directory -Force -Path $targetWrapper | Out-Null
    Copy-Item (Join-Path $bootstrapPath 'gradlew') $ProjectRoot -Force
    Copy-Item (Join-Path $bootstrapPath 'gradlew.bat') $ProjectRoot -Force
    Copy-Item $jar $targetWrapper -Force
    Copy-Item (Join-Path $bootstrapPath 'gradle/wrapper/gradle-wrapper.properties') $targetWrapper -Force
    $props = Get-Content (Join-Path $targetWrapper 'gradle-wrapper.properties') -Raw
    if ($props -notmatch 'gradle-9\.6\.0-bin\.zip' -or $props -notmatch [regex]::Escape($DistributionSha256)) { throw '生成したWrapper設定に想定Gradle版または配布物SHA-256がありません。' }
    $log = @(
        "SmartphoneAdvisor $AppVersion Gradle Wrapper setup",
        "Gradle distribution: $GradleVersion",
        "Distribution SHA-256: $actual (official checksum matched)",
        "Wrapper JAR SHA-256: $jarActual (official checksum matched)",
        'Generated from the official Gradle distribution using its wrapper task.',
        'Android build, Kotlin tests, Room tests, and device runtime are NOT implied by this setup.'
    ) -join "`r`n"
    Set-Content -LiteralPath (Join-Path $ProjectRoot "GRADLE_WRAPPER_SETUP_$AppVersion.txt") -Value $log -Encoding UTF8
    Write-Host '完了: gradlew / gradlew.bat / gradle/wrapper を追加し、公式SHA-256を検証しました。'
    Write-Host '次にAndroid Studioでプロジェクトを再読込し、Gradle同期とBuild > Make Projectを実行してください。'
} finally {
    Remove-Item -LiteralPath $tempRoot -Recurse -Force -ErrorAction SilentlyContinue
}
