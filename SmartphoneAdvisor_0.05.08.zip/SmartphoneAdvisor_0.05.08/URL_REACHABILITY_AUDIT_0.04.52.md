# SmartphoneAdvisor 0.04.52 — 共有販売URLの到達性・ページ種別監査

- 確認日：2026-10-16（日本時間）
- 対象：カタログ内で異なる機種identityに共有されているURL 10件
- 方法：ブラウザ取得でページ本文・タイトルを確認。これは全ユーザー環境でのHTTP疎通試験ではなく、購入可否や個別容量の在庫確認でもない。

| # | URL | 取得結果 | ページ内容から確認できたこと | アプリ上の扱い |
|---:|---|---|---|---|
| 1 | https://mineo.jp/device/smartphone/ | 取得成功 | mineoのスマートフォン端末一覧 | 一覧ページとして表示 |
| 2 | https://www.iijmio.jp/device/ | 取得成功 | IIJmioの端末ラインアップ。新品・中古の区分も掲載 | 一覧ページとして表示。個別機種・状態を断定しない |
| 3 | https://shop.uqmobile.jp/shop/lineup/ | 取得成功 | UQ mobile公式オンラインショップの製品一覧。iPhone/Android等のカテゴリを掲載 | 一覧ページとして表示 |
| 4 | https://network.mobile.rakuten.co.jp/product/smartphone/ | 取得成功 | 楽天モバイル公式のAndroidスマートフォン一覧 | 一覧ページとして表示 |
| 5 | https://buy.mi.com/jp/products/all | 取得成功 | Xiaomi公式ストアの製品一覧。スマートフォン以外のカテゴリも含む | 総合製品一覧として表示。個別機種専用ページとは表示しない |
| 6 | https://www.ymobile.jp/lineup/simfree/ | 取得環境で403 Forbidden | 取得環境からアクセス拒否。URLの無効・販売終了を示す証拠ではない | 未確認。壊れたリンク扱いにも、到達確認済み扱いにもしない |
| 7 | https://jp.nubia.com/collections/nubia-z-series | 取得成功 | nubia Zシリーズ一覧。ページ本文にZ80 Ultra、Z70S Ultra、Z70 Ultra、Flip 2、S 5G等を掲載 | 一覧ページとして表示 |
| 8 | https://www.softbank.jp/iphone/iphone-16/ | 取得成功 | SoftBank公式ページでiPhone 16とiPhone 16 Plusの両方を掲載 | 共通ページとして表示 |
| 9 | https://www.softbank.jp/mobile/products/google-pixel/google-pixel-9-pro/ | 取得成功 | SoftBank公式ページでPixel 9 ProとPixel 9 Pro XLの両方を掲載 | 共通ページとして表示 |
| 10 | https://rog.asus.com/jp/phones/rog-phone-9-pro/ | 取得成功 | ROG公式ページ。製品情報と購入先一覧等を掲載し、カタログ上はPro/Pro Editionに共有 | 共通ページとして表示。両Variantの販売可否は別途確認 |

## 結果

- 取得成功：9/10
- 取得環境で403：1/10（Y!mobile）
- 異なる機種identityに共有されるURL：10件。既存の静的回帰テストで、全件がKotlin側の一般一覧ページ分類に含まれることを確認。
- この確認だけでは、各URL配下の全機種・容量・RAM・販売チャネル・価格・在庫を保証しない。とくに共有ページは、その機種がページ上で現在購入可能であることを個別に証明するものではない。
- URLの取得失敗/403を理由にURLを削除したり、販売状態をAVAILABLE/DISCONTINUEDへ推測変更したりしていない。

## 次の照合

1. `SALES_URL_INVENTORY_0.04.52.csv` で各販売登録を機種・容量・RAM・チャネル・販売状態・URLに分けて追跡する。
2. URL到達性、機種の掲載確認、容量/RAM確認、価格/在庫確認を別々の証跡として記録する。
3. 未確認は未確認のまま保持し、機種専用URLと一覧URLの表示ラベルを混同しない。
