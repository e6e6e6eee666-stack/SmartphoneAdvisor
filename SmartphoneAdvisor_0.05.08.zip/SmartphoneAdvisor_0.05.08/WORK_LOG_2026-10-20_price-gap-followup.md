# 作業ログ：価格欠損の照合作業優先度改善（2026-10-20）

- 基準：SmartphoneAdvisor 0.04.89 / versionCode 137。
- 入力：`app/src/main/assets/phones.json`。価格を推測して書き込む変更は行っていない。
- 新規監査：`tools/audit_price_gap_followup_0_04_92.py`。価格未登録販売登録のCSV/Markdownを再生成する。
- 新規回帰テスト：`tools/test_price_gap_followup_0_04_89.py`。現行回帰ランナーに自動検出される。
- 実測：価格未登録448件、AVAILABLE 404件、型番欠損372件、AVAILABLEかつ型番欠損333件、カテゴリ/トップページURL31件（今回のデータでは全件IIJmio）。
- 検証：監査スクリプト実行PASS、独立回帰テストPASS。以降、現行テスト群を5バッチで再実行し統合レポートを生成する。
- 未実施：公式サイトへの個別アクセスによる価格・型番・販売状態の現物確認、Androidビルド、Kotlin/JUnit、Room実DB、実機動作。
