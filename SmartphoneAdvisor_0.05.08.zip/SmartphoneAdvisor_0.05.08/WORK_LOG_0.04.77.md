# SmartphoneAdvisor 0.04.77 作業記録

## 目的・完了条件
保存されている過去版の実際の `phones.json` を照合し、過去に存在したモデル・容量バリエーション・販売登録・価格情報が現行版で黙って欠落していないかを再現可能な検査にする。

## 実施内容
- 実ZIP 0.04.70〜0.04.76の7版から `phones.json` を抽出して比較。
- 正規化モデル識別子、RAM/容量、販売チャネル・販売先・型番・販売状態・URL、価格オプションを含む履歴マニフェスト `tools/historical_catalog_preservation_manifest_0_04_77.json` を作成。
- `tools/test_historical_catalog_preservation_0_04_77.py` を追加し、現行JSONが履歴シグネチャを保持するかを自動検査。
- `versionName=0.04.77`、`versionCode=125` に更新し、既存回帰テストの現行版ガードも更新。
- `HISTORICAL_CATALOG_PRESERVATION_AUDIT_0.04.77.md` を作成。

## 検証結果
- 履歴保持検査：PASS。モデル195、バリエーション313、販売登録497、価格オプション52の各シグネチャ欠落0件。
- 0.04.70〜0.04.72のNothing Phone (4a)旧表記は正規化後の同一モデルIDとして照合し、0.04.73で統合された後も販売登録・価格オプションが保持されている。
- Python回帰テスト41/41 PASS（3バッチ実行。版名ガード不整合1件を修正して再実行）、`python -m compileall -q tools` PASS。価格カバレッジ・販売根拠・URL台帳・履歴差分監査を再実行してPASS。配布ZIPを作成し、`unzip -t` で整合性PASS。展開した配布パッケージ内で履歴保持・履歴回帰・履歴差分の3テストとPython compileallもPASS。

## 問題・未確認事項
- 監査対象はZIPが保存されている0.04.70〜0.04.76の7版。0.04.69以前の完全なJSONスナップショットは含まず、全履歴の完全性を保証しない。
- 現在価格が公式サイトで今も有効かを確認する監査ではなく、過去データの保持確認。
- Android Gradle/KSPビルド、Room実ランタイム取込、Android JUnit、エミュレーター・実機試験は未実施。
- 現行価格未登録448件、AVAILABLEかつ価格未登録404件は継続課題。

## 進捗位置
大項目14「品質・監査」／中項目「過去版との回帰照合」／小項目「保存済み全カタログJSONの継続性検査」／バージョン0.04.77。

## 次工程
JSONカタログの保持監査に加え、JSON→Room取込経路の実Androidビルド・起動・DB件数照合を実施できる環境を整える。実機・エミュレーターの検証ができるまではアプリ動作確認済みと扱わない。

## 証跡
- `HISTORICAL_CATALOG_PRESERVATION_AUDIT_0.04.77.md`
- `tools/historical_catalog_preservation_manifest_0_04_77.json`
- `tools/test_historical_catalog_preservation_0_04_77.py`
- `VALIDATION_0.04.77.txt`
- `test_results_0.04.77.txt`
