# SmartphoneAdvisor 0.01.04.35 JSON migration

## Migrated data
- Source ZIPs: 0.01.04.29 through 0.01.04.34
- Authoritative cumulative carrier source: 0.01.04.34 `CarrierCatalogSeed.kt`
- Carrier sales entries: 338
- Aggregated phone models: 106
- Aggregated storage/RAM variants: 186
- Sales listings: 338
- Unique reverse-audit CSV findings retained: 29

## JSON
`app/src/main/assets/phones.json`

The JSON keeps sales listings grouped under phone -> variant -> sales. Historical audit findings are retained separately under `auditFindings`; a `NOT_ADDED` audit finding is not incorrectly converted into a sale listing.

## Android reader
`PhoneCatalogJson.kt` reads `phones.json` from `AssetManager` using the Android assets mechanism and parses it with `org.json`, avoiding a new JSON dependency.

`MainActivity.kt` loads and validates the JSON before the existing Room seed runs. The existing Room seed is intentionally not replaced in this migration step, preventing duplicate database records while the JSON format is introduced.

## Verification boundary
This migration has been statically verified. A full Gradle build and physical-device execution are still required to claim runtime/build verification.
