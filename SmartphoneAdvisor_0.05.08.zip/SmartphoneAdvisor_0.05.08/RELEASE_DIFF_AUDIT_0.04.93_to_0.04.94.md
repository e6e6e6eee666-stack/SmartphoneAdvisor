# Release diff audit: 0.04.93 → 0.04.94

- App version: 0.04.93 / versionCode 141 → 0.04.94 / versionCode 142.
- Catalog: added ASUS Store Rakuten official-shop normal price for Zenfone 12 Ultra 12GB/256GB: JPY 149,800 tax included. Source page also displays a temporary special price of JPY 134,820; that promotional price was not registered as the normal price.
- Catalog totals: models 195 unchanged; variants 314 unchanged; sales listings 501 unchanged; price options 80 → 81.
- Price-gap inventory: rows without price options 439 → 438; AVAILABLE without price 394 → 393; missing model numbers among unpriced rows 364 → 363; AVAILABLE rows with missing model numbers 324 → 323; generic/category/top-page URLs remain 9.
- Audit CSV and Markdown were regenerated from `phones.json`; regression expectations were reconciled with the regenerated reports.
- Added `tools/test_zenfone12ultra_official_price_0_04_94.py` and retained ROG Phone 9 / Xperia 1 VIII official-price regression guards in the manifest.
- Verification: 57/57 current Python regression tests passed in five batches; Python compileall and ZIP integrity checked during packaging.
- Not verified: Gradle Android build, Kotlin/JUnit execution, Room runtime import, emulator/device tests.
