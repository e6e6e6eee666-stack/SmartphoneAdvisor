# 現行アプリ総合監査・資産棚卸し（2026-10-18）

## 目的・完了条件
大項目1の基準資産を固定し、アプリ構成・データ・テスト・ビルド経路を現物で確認する。ファイルの存在と実行検証を区別し、未確認事項を次工程へ持ち越さない。

## 1. 基準資産の同一性

- 基準ZIP：`SmartphoneAdvisor_0.04.89_catalog-count-guard.zip`
- ZIPサイズ：1,534,439 bytes
- SHA-256：`1db395ba4271548454cb960a338d4d746c568212dace9866d2ebbcc45bbe3f0d`
- ZIP内エントリー：746（ディレクトリエントリー含む）
- ZIP CRC検査：成功（`ZipFile.testzip()` が `None`）
- `app/build.gradle.kts`：`versionName=0.04.89`、`versionCode=137`
- 工程表修正版とのソース比較：`app/src/**`、`app/build.gradle.kts`、root Gradle設定の対象40ファイルについて差分0・欠落0・追加0。工程表の修正がアプリソースを変更していないことを確認。

## 2. ソース構成

- `app/src/main`：28ファイル（Kotlin 23、XML 3、JSON 2）
- `app/src/test`：7 Kotlinテストファイル
- `app/src/androidTest`：1 Kotlinテストファイル
- `tools/`：Python回帰・静的検査、マニフェスト、補助スクリプトを収録
- メイン実装領域：`MainActivity`、Room/DAO/Entity、カタログJSONパーサー/バリデータ/Importer、推薦エンジン、1台診断エンジンと画面
- データ：`app/src/main/assets/phones.json`、`catalog_import_example.json`
- CI設定：`.github/workflows/android-validation.yml`

## 3. JSONの宣言件数と実測

| 項目 | 宣言値 | 実測値 | 判定 |
|---|---:|---:|---|
| 機種 | 195 | 195 | 一致 |
| バリエーション | 313 | 313 | 一致 |
| 販売登録 | 497 | 497 | 一致 |
| 価格選択肢 | 52 | 52 | 一致 |
| 監査指摘 | 45 | 45 | 一致 |

- 497販売登録のうち448件に価格選択肢がない（現行資料の記録と一致）。
- 件数一致は国内市場の網羅性、各仕様の正確性、価格の最新性を証明しない。

## 4. ビルド構成と実行可能性

- AGP `9.4.0`、Kotlin Android/Compose plugin `2.4.10`、KSP `2.3.12`、Room `2.8.5`。
- `compileSdk=37`、`minSdk=35`、`targetSdk=36`。
- `gradlew` と `gradle/wrapper/` が基準ZIP内に存在しない。
- 現監査環境ではJava 21を確認。`gradle`、`adb` はPATH上に見つからず、Android SDKの存在も確認できていない。
- CIワークフローは存在するが、この監査ではGitHub Actions実行結果を取得していない。したがって実ビルド成功の証拠ではない。
- CIはGradle 9.6.0、SDK platform android-37/android-35を指定する。初期設定ではbuild-tools 37.0.0を要求していたが、AGP 9.4.0の公式互換性表はBuild Tools 36.0.0を既定値としているため、今回36.0.0へ修正した。CI実行によるSDK取得・ビルド結果は未確認。

## 5. テスト証跡の区分

- 過去の作業記録にはPython回帰テスト51/51 PASSとcompileall PASSが記載されている。これは履歴証跡として保持する。
- 初回の一括回帰スイート実行は実行環境の300秒上限に達し、完走を確認できなかった。その後、12件単位の分割実行でテスト1〜48を確認し、テスト49・50もPASS、最後のテスト51は単独実行でPASSを確認した。今回の分割再実行は51/51 PASS。詳細は `CURRENT_REGRESSION_RERUN_2026-10-18.md`。一括実行のタイムアウト自体はCIで再確認する。
- Kotlin/JUnit、Android Gradleビルド、Room実DB取込、エミュレータ/実機操作は未検証。

## 6. 機能接続のソース追跡（A-05・一次確認）

- `MainActivity.onCreate` から `SmartphoneAdvisorApp()` を起動する。
- 起動時初期化は `PhoneCatalogJsonLoader.load(context)` でJSONを読み、`SeedData.ensureSeeded(database)` の後、`PhoneCatalogRoomImporter.importCatalog(database, jsonCatalog)` でRoomへ取り込む構造。JSON読込/取込失敗時はログと警告を出し、既存seedで継続する経路がある。
- 1台診断画面 `SinglePhoneDiagnosticScreen.kt` は `phones.json` を読み、`PhoneDao.searchJapanOfficialDevices(os.name, "")` の結果とJSONを `SinglePhoneDiagnosticEngine.catalogCandidates` で結び、診断エンジンへ渡す構造。
- 通常推薦は `MainActivity` から `RecommendationEngine.recommend(...)` を呼ぶ。
- Roomデータベースはversion 14で、migration 1→14を登録している。
- これはコード上の接続確認であり、Androidコンパイル・実行時の取込成功、候補件数、DB再投入の冪等性、実画面表示は未検証。

## 7. 監査所見・未解決課題

1. **高：再現可能なビルドゲート未通過。** Wrapper不在かつ監査環境にGradle/Android SDKが確認できず、Android実ビルドの合否が不明。
2. **高：Room実データ投入未検証。** Kotlinテストコードは存在するが、実際に実行された証跡がない。
3. **中：回帰スイート再実行がタイムアウト。** 41件のPASSは確認したが、残りのテストと全体合否は未確認。遅延・停止するテストを特定し、テスト単位で実行時間とネットワーク依存を調べる必要がある。
4. **中：価格データ不足。** 497販売登録中448件に価格選択肢がない。推測値を追加せず、販売先・容量・条件・出典単位で解消する。
5. **中：旧版ログと現行証拠の分離が必要。** 旧版の監査レポートは存在するが、最新版で再現・確認されていない結果を現行完了判定へ流用しない。さらに `WORK_LOG_0.04.89.md` は工程位置を「大項目14」と記載しており、正式工程表・現行台帳の再開位置「大項目1」と不一致。過去の作業内容は履歴として保持し、工程位置の訂正注記を追加する。
6. **中：Android SDK要件が高い。** minSdk 35のため古い実機では起動できない可能性がある。対応対象端末の要件を公開前に明示する。

## 8. この作業単位の判定

- 基準ZIP識別：完了
- ソース/設定の静的棚卸し：完了（一覧レベル。全機能の導線監査は継続）
- JSON宣言件数照合：検証済み（件数のみ）
- Python回帰スイート：今回の分割再実行は51/51 PASS。全件一括実行は300秒で停止し、CIでの再確認が必要
- Androidビルド・Kotlin/JUnit・Room実DB・端末操作：未検証

## 次工程
1. A-04として版別の過去ログを現行ソースで裏付け可能か分類する。
2. A-05の画面導線・DB・JSON取込・診断エンジンの静的追跡を続け、結果と懸念点を台帳に登録する。
3. 大項目1の完了条件が満たされた後、大項目2のAndroidビルドゲートを解消し、大項目3のRoom実DB検証へ進む。

## 証跡
- `SmartphoneAdvisor_0.04.89_catalog-count-guard.zip`
- `app/build.gradle.kts`
- `app/src/main/assets/phones.json`
- `tools/current_regression_manifest.json`
- `tools/run_current_regression_suite.py`
- `.github/workflows/android-validation.yml`


## 9. 追試・修正記録（2026-10-18、作業版0.04.90）

- `PREPARE_GRADLE_WRAPPER_WINDOWS.ps1` のログ名・ログ本文に古いアプリ版0.04.86が固定されている問題を修正。アプリ版をGradle設定から読み取り、記録に使う。
- `tools/test_gradle_wrapper_bootstrap.py` に版番号の動的参照・旧固定値不在のアサーションを追加。スクリプト構造テストPASS。
- 現行回帰マニフェスト51件を5バッチで再実行し、今回の実行結果は51/51 PASS、0 FAIL。`test_results_0.04.89.txt` はアプリ版0.04.89のテスト報告であり、0.04.90は開発補助スクリプト修正の作業版を表す。
- `python -m compileall -q tools` PASS。
- Androidビルド、Kotlin/JUnit、Room実DB、エミュレーター/実機は引き続き未検証。Gradle配布元への接続は本環境のDNS解決失敗で利用できず、Wrapper実生成も行えていない。


## 10. 工程依存関係の再監査（2026-10-18）

- 旧工程表の「大項目1→20を厳密に番号順に進める」は、診断（4）と診断に必要なデータマスター（11〜13）の依存関係と矛盾していたため修正した。
- 開発フォーカスは大項目4「診断」の実装継続段階とする。監査（大項目1）は横断作業であり、全体位置を大項目1へリセットしない。
- 大項目2のAndroid実ビルド、大項目3/10のJSON契約・Room実DB検証は未通過のブロッカー。診断/推薦の実データ統合完了とは判定しない。
- 修正詳細：`PROJECT_DEPENDENCY_REVIEW_2026-10-18.md`。アプリ本体ソース・Gradle設定・JSONは変更していない。
