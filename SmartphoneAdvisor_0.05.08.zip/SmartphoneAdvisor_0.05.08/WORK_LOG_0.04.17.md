# WORK LOG 0.04.17

## 目的・完了条件
販売登録の機種照合で、メーカー・OS・発売年が存在するキャリアseedを完全な機種識別条件で照合し、候補が一意でない場合は誤登録せず未解決として扱う。

## 実施内容
- `PhoneDao.getDeviceVariantIdByFullIdentity` を追加。メーカー名、機種名、platform、発売年、容量、販売状態、RAM一致数を条件にし、一意に解決できない場合は `null` を返す。
- `CarrierCatalogSeed.findOrCreateVariant` を完全識別子検索へ切り替え。販売seedからコア機種・バリアントを新規作成しない既存方針は維持。
- `tools/audit_sales_seed_resolution_reasons.py` を更新し、完全識別子検索の条件と残る3経路の識別情報不足を検出。
- バージョンを `0.04.17` / versionCode `66` に更新。

## 検証結果
- 静的監査スクリプト: 実行完了。キャリアseedの完全識別子検索は検出。残り3経路は要確認として正しく報告。
- カタログJSON監査: 実行予定/今回再実行結果を下記証跡に記録。
- ZIP整合性: 作成後に検査。
- Gradle/Kotlinビルド、Room/SQLite実行、Android実機テスト: 未実施。成功とは扱わない。

## 問題・未確認事項
- SIMフリー、価格、サブブランド/MVNO seedはメーカー/platform/発売年を持たないため、従来の一意性チェック付き検索を継続。現状は誤紐付け回避を優先し、曖昧な候補は登録されない可能性がある。
- Room DAOのSQLが実際のGradle/KSPビルドでコンパイルされるか未確認。
- 既存の `getDeviceVariantIdByModelAndStorage` は他seedの互換性を保つため残置。

## 進捗位置
大項目3「データ登録システム」/ 大項目4「診断」/ 小項目「販売seedの安全な機種照合」/ 0.04.17。

## 次工程
SIMフリー/価格/MVNO seedに正規の機種識別子を追加する設計を行い、既存の `phones.json` の正規モデルIDとの対応表を用意する。続いて未解決理由を「機種なし・容量なし・RAM不一致・複数候補・識別情報不足」に分類する。

## 証跡
- `app/src/main/java/jp/smartphoneadvisor/app/data/PhoneDao.kt`
- `app/src/main/java/jp/smartphoneadvisor/app/data/CarrierCatalogSeed.kt`
- `tools/audit_sales_seed_resolution_reasons.py`
- `SALES_SEED_RESOLUTION_AUDIT_0.04.17.txt`
- `WORK_LOG_0.04.17.md`
- `PROJECT_MASTER_PLAN_0.04.17.md`
