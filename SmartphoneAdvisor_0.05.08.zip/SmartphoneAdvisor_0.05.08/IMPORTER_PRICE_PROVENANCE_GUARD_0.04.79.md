# JSON→Room 価格根拠ガード監査 0.04.79

## 目的・完了条件
価格オプションの根拠が欠けている場合に、Roomへの書き込み開始後にその価格だけを黙ってスキップするのではなく、書き込み前の全体検証でカタログを拒否する。

## 実施内容
- `PhoneCatalogRoomImporter.validate()` で `checkedAt` を必須化。
- `checkedAt` を `LocalDate.parse()` で実日付として検証し、`YYYY-MM-DD` の正規形式でない値を拒否。
- `sourceUrl` を必須化し、空欄・空白・不正URL・HTTPS以外を拒否。
- 既存の `require(validationErrors.isEmpty())` が `db.withTransaction` より前に実行されることをソース契約テストで確認。
- 版数を `0.04.79` / versionCode `127` に更新し、現在の版を参照するテスト・監査スクリプトを同期。

## 検証結果
- Pythonテスト: 43/43 PASS（3バッチ）
- `python -m compileall -q tools`: PASS
- JSON→Room取込前提監査: PASS（195機種 / 497販売登録 / 52価格オプション、販売URL欠落0、確認日欠落・不正0、価格根拠URL欠落・不正0）
- 価格登録数: 52。価格未登録販売登録448、うち `AVAILABLE` 404。
- ZIP整合性: PASS

## 未実施・限界
- Android Gradle/KSPビルド、Android JUnit、Room実ランタイム、エミュレーター・実機試験は未実施。
- 新規テストはKotlinソースの静的契約と日付境界ケースを検査するもので、Kotlin validatorの実行テストではない。
- 既存Room内の競合やDB状態による販売登録・価格レコードの再利用可否は未検証。
