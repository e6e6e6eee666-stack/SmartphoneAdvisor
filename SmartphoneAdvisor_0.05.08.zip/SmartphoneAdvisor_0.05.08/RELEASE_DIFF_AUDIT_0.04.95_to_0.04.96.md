# Release diff audit: 0.04.95 → 0.04.96

## Version
- `versionName`: 0.04.95 → 0.04.96
- `versionCode`: 143 → 144

## Functional data change
- Added one price option to existing `Xperia 1 VIII`, 12GB RAM / 256GB, SOFTBANK listing.
- Normal price: ¥274,320 (tax included), from SoftBank's official press release dated 2026-05-13.
- Source: https://www.softbank.jp/corp/news/press/sbkk/2026/20260513_01/
- Conditions explicitly exclude return-program effective costs, MNP discounts, trade-in and campaign benefits.

## Reconciled counts
- 195 phone models, 315 variants, 502 sales listings unchanged.
- Price options: 82 → 83.
- Unpriced sales listings: 438 → 437.
- Available but unpriced: 393 → 392.

## Regression and audit changes
- Added `test_xperia1viii_softbank_official_price_0_04_96.py`.
- Updated current tests that hard-coded stale catalog totals.
- Regenerated `CATALOG_PRICE_GAP_AUDIT_2026-10-21.*` and `CATALOG_PRICE_GAP_FOLLOWUP_2026-10-21.*`.
- Current regression suite: 59 passed, 0 failed.

## Explicitly not verified
- Gradle/Android build, Kotlin/JUnit execution, Room runtime, emulator, physical-device behavior.
