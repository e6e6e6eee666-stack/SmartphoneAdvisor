SmartphoneAdvisor 0.04.26 JSON-to-Room importer static audit
Scope: source/preflight inspection only; not Android Room runtime or Gradle build.
JSON models: 196
JSON variants: 314
JSON sales listings: 477

Checks:
PASS: catalog IDs unique
PASS: catalog model identities unique
PASS: variant keys unique per model
PASS: Room transaction used
PASS: duplicate manufacturer blocked
PASS: same-name model/year conflict blocked
PASS: duplicate null-RAM variant detected
PASS: existing attributes not overwritten
PASS: model/variant import wired at startup
PASS: failure logged rather than silently accepted
PASS: DAO has identity lookup list
FAIL: version is 0.04.26 / code 75
PASS: sales URL/availability import implemented

Import safety rules:
- validates catalog before starting database transaction
- never deletes or replaces existing rows
- reuses only unambiguous manufacturer/model/variant identities
- leaves existing feature/specification rows untouched
- initializes missing recommendation attributes to UNKNOWN
- preserves existing listing values on conflict
- imports sales variants, retailers, and listings conservatively; skips URL-less listings
- logs conflicts and retains existing seed if import throws
