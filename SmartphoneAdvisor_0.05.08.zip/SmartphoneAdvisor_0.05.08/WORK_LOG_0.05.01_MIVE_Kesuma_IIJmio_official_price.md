# 作業記録 0.05.01 — MIVEケースマ IIJmio公式価格

- アプリ版: `versionName 0.05.01` / `versionCode 149`。
- 変更対象: `app/src/main/assets/phones.json` の `ALT:MIVEケースマ:2026` / 3GB・32GB / IIJmio販売登録。
- 公式根拠: https://www.iijmio.jp/info/iij/1787302297.html （2026年9月2日公開のお知らせ）。通常価格34,800円（税込）を登録。MNP転入かつ音声SIM/eSIM同時申込時の期間限定価格32,800円は通常価格と混同しないよう条件欄に記載。
- 既存の製品ページURLとモデル識別情報は維持。型番は本変更では追加せず、歴史的カタログ同一性の比較を壊さない。
- カタログ件数: 195機種 / 315バリエーション / 511販売登録 / 95価格オプション / 45監査指摘。価格未登録販売登録434件、AVAILABLEかつ価格未登録389件。
- JSON SHA-256: `b009dbf125d7d12ffd0d7fda142aab965f96bb3133dd192ffee458b8b4d012d2`。

## 検証結果

- 維持対象の回帰スイート: **62/62 PASS**（6バッチで実行、`test_results_0.05.01.txt` に統合）。
- 新規専用テスト `test_mive_kesuma_iijmio_official_price_0_05_01.py`: PASS。
- `python -m compileall -q tools`: PASS。
- 価格欠損監査: PASS（195 / 315 / 511 / 95、未登録434、AVAILABLE未登録389）。
- 販売事実完全性監査: PASS（95価格すべてに `sourceUrl` と `checkedAt`）。
- 歴史的カタログ保存監査: PASS。既存販売登録の識別子を変更せず価格だけを追加。
- Android Gradle build、Kotlin/JUnit実行、Room実ランタイム、エミュレーター、実機テスト: 未実施。現環境でのAndroidビルド実行結果を示す証拠はまだありません。

## 次の作業

1. 価格未登録AVAILABLE行のうち、公式販売ページで容量・通常価格を明確に確認できる機種を優先して埋める。
2. 価格を追加するたびにカタログの同一性・出典・通常価格/キャンペーン区分・Room取込前提を検証する。
3. Android CIの実際の実行結果を取得できるよう、Gradle/SDK構成とGitHub Actionsの再現性を引き続き点検する。
4. ZIPは中項目以上の区切りまで作成しない。
