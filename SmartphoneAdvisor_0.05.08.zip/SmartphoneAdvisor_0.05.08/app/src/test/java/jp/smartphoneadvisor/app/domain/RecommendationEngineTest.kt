package jp.smartphoneadvisor.app.domain

import jp.smartphoneadvisor.app.data.AttributeLevel
import jp.smartphoneadvisor.app.data.CandidateOs
import jp.smartphoneadvisor.app.data.PhoneListRow
import jp.smartphoneadvisor.app.data.PrimaryUse
import jp.smartphoneadvisor.app.data.ProductCondition
import jp.smartphoneadvisor.app.data.SupportStatus
import jp.smartphoneadvisor.app.data.PriceType
import jp.smartphoneadvisor.app.data.SalesChannel
import jp.smartphoneadvisor.app.data.SourceType
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Assert.assertFalse
import org.junit.Test

class RecommendationEngineTest {

    private fun phone(
        id: Long,
        model: String,
        manufacturer: String,
        price: Int? = 120_000,
        storage: Int = 256,
        gaming: AttributeLevel? = AttributeLevel.GOOD,
        camera: AttributeLevel? = AttributeLevel.GOOD,
        general: AttributeLevel? = AttributeLevel.GOOD,
        waterproof: SupportStatus? = SupportStatus.SUPPORTED,
        osaifu: SupportStatus? = SupportStatus.SUPPORTED,
        updateYears: Int? = 5,
        channels: String? = "SIM_FREE,DOCOMO",
        weight: Double? = 200.0,
        display: Double? = 6.6,
        battery: Int? = 5000
    ) = PhoneListRow(
        id, model, manufacturer, null, 2026, CandidateOs.ANDROID.name, storage, 12, price,
        osaifu, waterproof, SupportStatus.SUPPORTED, SupportStatus.SUPPORTED, SupportStatus.SUPPORTED,
        SupportStatus.UNKNOWN, SupportStatus.UNKNOWN, gaming, camera, general,
        AttributeLevel.GOOD, AttributeLevel.GOOD, AttributeLevel.GOOD, AttributeLevel.GOOD,
        AttributeLevel.GOOD, weight, null, null, weight, display, 120, 50.0, battery, 45,
        SupportStatus.SUPPORTED, updateYears, ProductCondition.NEW, channels,
        priceCheckedAt = System.currentTimeMillis(), availabilityStatus = "AVAILABLE", availabilityCheckedAt = System.currentTimeMillis()
    )

    @Test fun absoluteBudgetExcludesOverLimit() {
        val result = RecommendationEngine.recommend(
            UserRequirement(CandidateOs.ANDROID, BudgetRequirement(100_000, 100_000), PrimaryUse.GENERAL),
            listOf(phone(1, "A", "A社", 99_000), phone(2, "B", "B社", 101_000))
        )
        assertEquals(listOf("A"), result.map { it.phone.modelName })
    }

    @Test fun mustHaveUnknownIsNotSupported() {
        val result = RecommendationEngine.recommend(
            UserRequirement(CandidateOs.ANDROID, BudgetRequirement(null, 200_000), PrimaryUse.GENERAL,
                mustHaveFeatures = setOf(MustHaveFeature.MICRO_SD)),
            listOf(phone(1, "Unknown", "A社"))
        )
        assertTrue(result.isEmpty())
    }

    @Test fun gamingDetailChangesPriority() {
        val heavy = phone(1, "Gaming", "A社", gaming = AttributeLevel.EXCELLENT)
        val normal = phone(2, "Balanced", "B社", gaming = AttributeLevel.STANDARD)
        val result = RecommendationEngine.recommend(
            UserRequirement(CandidateOs.ANDROID, BudgetRequirement(null, 200_000), PrimaryUse.GAMING, gameType = "最高画質"),
            listOf(normal, heavy)
        )
        assertEquals("Gaming", result.first().phone.modelName)
    }

    @Test fun resultCountDoesNotPadWeakCandidates() {
        val result = RecommendationEngine.recommend(
            UserRequirement(CandidateOs.ANDROID, BudgetRequirement(null, 200_000), PrimaryUse.GENERAL),
            listOf(phone(1, "A", "A社"), phone(2, "B", "B社"))
        )
        assertEquals(2, result.size)
    }

    @Test fun sameModelStorageVariantsDoNotFillAllSlots() {
        val candidates = listOf(
            phone(1, "Same", "A社", storage = 128),
            phone(2, "Same", "A社", storage = 256),
            phone(3, "Other", "B社"),
            phone(4, "Third", "C社")
        )
        val result = RecommendationEngine.recommend(
            UserRequirement(CandidateOs.ANDROID, BudgetRequirement(null, 200_000), PrimaryUse.GENERAL),
            candidates
        )
        assertEquals(3, result.size)
        assertTrue(result.count { it.phone.modelName == "Same" } <= 1)
    }

    @Test fun unknownSourceLowersConfidence() {
        val result = RecommendationEngine.recommend(
            UserRequirement(CandidateOs.ANDROID, BudgetRequirement(null, 200_000), PrimaryUse.GENERAL),
            listOf(phone(1, "UnknownSource", "A社"))
        )
        assertTrue(result.isNotEmpty())
        assertTrue(result.first().confidence != RecommendationConfidence.HIGH)
    }

    @Test fun officialSourceCanReachHighConfidenceWhenOtherDataIsFresh() {
        val result = RecommendationEngine.recommend(
            UserRequirement(CandidateOs.ANDROID, BudgetRequirement(null, 200_000), PrimaryUse.GENERAL),
            listOf(phone(1, "Official", "A社").copy(priceSourceType = SourceType.MANUFACTURER_OFFICIAL, priceSourceName = "メーカー公式"))
        )
        assertTrue(result.isNotEmpty())
        assertEquals(RecommendationConfidence.HIGH, result.first().confidence)
    }

    @Test fun mnpPriceIsNotUsedAsGeneralBudgetPrice() {
        val result = selectUsablePrice(
            listOf(PriceOfferForRecommendation(49_800, PriceType.MNP, "MNP契約必須", SalesChannel.DOCOMO)),
            "docomo"
        )
        assertEquals(UsablePriceStatus.CONDITIONAL, result.status)
        assertEquals(null, result.priceYen)
    }

    @Test fun stalePriceIsNotUsedForBudgetFilter() {
        val old = System.currentTimeMillis() - 30L * 24L * 60L * 60L * 1000L
        val result = RecommendationEngine.recommend(
            UserRequirement(CandidateOs.ANDROID, BudgetRequirement(null, 100_000), PrimaryUse.GENERAL),
            listOf(phone(1, "OldPrice", "A社", 80_000).copy(priceCheckedAt = old))
        )
        assertTrue(result.isEmpty())
    }

    @Test fun discontinuedDeviceIsExcluded() {
        val result = RecommendationEngine.recommend(
            UserRequirement(CandidateOs.ANDROID, BudgetRequirement(null, 200_000), PrimaryUse.GENERAL),
            listOf(phone(1, "Ended", "A社").copy(availabilityStatus = "DISCONTINUED"))
        )
        assertTrue(result.isEmpty())
    }

    @Test fun staleDataLowersConfidenceAndAddsCaution() {
        val old = System.currentTimeMillis() - 30L * 24L * 60L * 60L * 1000L
        val result = RecommendationEngine.recommend(
            UserRequirement(CandidateOs.ANDROID, BudgetRequirement(null, null), PrimaryUse.GENERAL),
            listOf(phone(1, "Stale", "A社").copy(priceCheckedAt = old, availabilityCheckedAt = old))
        )
        assertFalse(result.isEmpty())
        assertTrue(result.first().confidence == RecommendationConfidence.LOW)
        assertTrue(result.first().cautions.any { it.contains("価格情報") })
    }

    @Test fun normalPriceIsPreferredOverConditionalPrice() {
        val result = selectUsablePrice(
            listOf(
                PriceOfferForRecommendation(79_800, PriceType.NORMAL, salesChannel = SalesChannel.DOCOMO),
                PriceOfferForRecommendation(39_800, PriceType.MNP, "MNP契約必須", SalesChannel.DOCOMO)
            ),
            "docomo"
        )
        assertEquals(UsablePriceStatus.NORMAL_OR_SALE, result.status)
        assertEquals(79_800, result.priceYen)
    }

    @Test fun salePriceCanBeUsedWhenItIsNotContractConditional() {
        val result = selectUsablePrice(
            listOf(PriceOfferForRecommendation(89_800, PriceType.SALE, salesChannel = SalesChannel.SIM_FREE)),
            "SIMフリー"
        )
        assertEquals(UsablePriceStatus.NORMAL_OR_SALE, result.status)
        assertEquals(89_800, result.priceYen)
    }

    @Test fun conditionalCampaignWithoutConditionsCanBeUsed() {
        val result = selectUsablePrice(
            listOf(PriceOfferForRecommendation(99_800, PriceType.CAMPAIGN, salesChannel = SalesChannel.SIM_FREE)),
            "SIMフリー"
        )
        assertEquals(UsablePriceStatus.NORMAL_OR_SALE, result.status)
        assertEquals(99_800, result.priceYen)
    }


    @Test fun explicitlyRequestedChannelDoesNotAcceptUnattributedPrice() {
        val result = selectUsablePrice(
            listOf(PriceOfferForRecommendation(79_800, PriceType.NORMAL, salesChannel = null)),
            "docomo"
        )
        assertEquals(UsablePriceStatus.UNKNOWN, result.status)
        assertEquals(null, result.priceYen)
    }

    @Test fun unsupportedExplicitChannelDoesNotFallBackToAnyChannel() {
        val result = selectUsablePrice(
            listOf(PriceOfferForRecommendation(79_800, PriceType.NORMAL, salesChannel = SalesChannel.SIM_FREE)),
            "unknown-carrier"
        )
        assertEquals(UsablePriceStatus.UNKNOWN, result.status)
        assertEquals(null, result.priceYen)
    }

    @Test fun uqMobilePriceIsSelectedForUqMobileRequest() {
        val result = selectUsablePrice(
            listOf(
                PriceOfferForRecommendation(99_800, PriceType.NORMAL, salesChannel = SalesChannel.SIM_FREE),
                PriceOfferForRecommendation(69_800, PriceType.NORMAL, salesChannel = SalesChannel.UQ_MOBILE)
            ),
            "UQ mobile"
        )
        assertEquals(UsablePriceStatus.NORMAL_OR_SALE, result.status)
        assertEquals(69_800, result.priceYen)
    }

    @Test fun recommendationDoesNotIgnoreUnsupportedExplicitChannel() {
        val result = RecommendationEngine.recommend(
            UserRequirement(CandidateOs.ANDROID, BudgetRequirement(null, 200_000), PrimaryUse.GENERAL, purchaseChannel = "unknown-carrier"),
            listOf(phone(1, "Any", "A社"))
        )
        assertTrue(result.isEmpty())
    }

    @Test fun noCandidateExplainsHardConstraint() {
        val explanation = RecommendationEngine.explainNoCandidates(
            UserRequirement(CandidateOs.ANDROID, BudgetRequirement(null, 80_000), PrimaryUse.GENERAL),
            listOf(phone(1, "A", "A社", 100_000))
        )
        assertTrue(explanation.reasons.any { it.contains("絶対上限") })
    }
}
