package jp.smartphoneadvisor.app.domain

import jp.smartphoneadvisor.app.data.AttributeLevel
import jp.smartphoneadvisor.app.data.CandidateOs
import jp.smartphoneadvisor.app.data.PhoneListRow
import jp.smartphoneadvisor.app.data.ProductCondition
import jp.smartphoneadvisor.app.data.SupportStatus
import jp.smartphoneadvisor.app.data.catalog.JsonPhone
import jp.smartphoneadvisor.app.data.catalog.JsonSalesListing
import jp.smartphoneadvisor.app.data.catalog.JsonVariant
import jp.smartphoneadvisor.app.data.catalog.JsonPhoneCatalog
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test

class SinglePhoneDiagnosticEngineTest {
    private fun row(
        price: Int = 150_000,
        storageGb: Int = 256,
        osaifu: SupportStatus? = SupportStatus.SUPPORTED,
        microSd: SupportStatus? = SupportStatus.NOT_SUPPORTED
    ) = PhoneListRow(
        deviceVariantId = storageGb.toLong(), modelName = "テストスマホ", manufacturerName = "Test", seriesName = null,
        releaseYear = 2026, platform = "ANDROID", storageGb = storageGb, ramGb = 12,
        normalPriceYen = price, osaifuKeitai = osaifu, waterproof = null, esim = null,
        fingerprint = null, wirelessCharging = null, microSd = microSd, headphoneJack = null,
        gamingLevel = AttributeLevel.GOOD, cameraLevel = AttributeLevel.STANDARD,
        generalLevel = AttributeLevel.GOOD, workStudyLevel = null, videoLevel = null,
        aiLevel = null, batterySuitability = null, portabilityLevel = null, longTermSupportLevel = null,
        bodyHeightMm = null, bodyWidthMm = null, bodyThicknessMm = null, weightG = null,
        displayDiagonalInch = null, displayRefreshRateHz = null, rearTelephotoMp = null,
        batteryCapacityMah = null, chargingPowerW = null, batteryWirelessCharging = null,
        updateSupportYears = null, productCondition = ProductCondition.NEW,
        purchaseChannels = "SOFTBANK", priceCheckedAt = System.currentTimeMillis(),
        availabilityStatus = "AVAILABLE", availabilityCheckedAt = System.currentTimeMillis()
    )

    @Test
    fun absoluteBudgetExcludesOverLimit() {
        val r = SinglePhoneDiagnosticEngine.recommend(
            SinglePhoneDiagnosticEngine.Requirement(
                os = CandidateOs.EITHER, targetBudgetYen = 150_000, absoluteMaxYen = 120_000,
                primaryUse = jp.smartphoneadvisor.app.data.PrimaryUse.GENERAL,
                mustHaveOsaifuKeitai = false, mustHaveMicroSd = false
            ), listOf(row(price = 150_000))
        )
        assertNull(r)
    }

    @Test
    fun requiredOsaifuIsHardFilter() {
        val r = SinglePhoneDiagnosticEngine.recommend(
            SinglePhoneDiagnosticEngine.Requirement(
                os = CandidateOs.EITHER, targetBudgetYen = 150_000, absoluteMaxYen = 200_000,
                primaryUse = jp.smartphoneadvisor.app.data.PrimaryUse.GENERAL,
                mustHaveOsaifuKeitai = true, mustHaveMicroSd = false
            ), listOf(row(osaifu = SupportStatus.UNKNOWN))
        )
        assertNull(r)
    }

    @Test
    fun matchingCandidateIsReturned() {
        val r = SinglePhoneDiagnosticEngine.recommend(
            SinglePhoneDiagnosticEngine.Requirement(
                os = CandidateOs.ANDROID, targetBudgetYen = 150_000, absoluteMaxYen = 200_000,
                primaryUse = jp.smartphoneadvisor.app.data.PrimaryUse.GENERAL,
                mustHaveOsaifuKeitai = true, mustHaveMicroSd = false
            ), listOf(row())
        )
        assertNotNull(r)
    }
    @Test
    fun catalogCandidatesExcludeVariantsWithoutPurchasableSales() {
        val roomRow = row()
        val catalog = JsonPhoneCatalog(
            schemaVersion = "1.1.0",
            generatedFrom = "test",
            phones = listOf(
                JsonPhone(
                    id = "test-1", manufacturer = "Test", model = "テストスマホ", series = null,
                    platform = "ANDROID", releaseYear = 2026, isJapanOfficial = true,
                    variants = listOf(
                        JsonVariant(256, 12, emptyList()),
                        JsonVariant(128, 12, listOf(JsonSalesListing("DOCOMO", "docomo", null, "DISCONTINUED", "https://example.com"))),
                        JsonVariant(256, 12, listOf(JsonSalesListing("DOCOMO", "docomo", null, "AVAILABLE", "https://example.com")))
                    )
                )
            ),
            auditFindings = emptyList()
        )

        val candidates = SinglePhoneDiagnosticEngine.catalogCandidates(
            catalog, listOf(row(storageGb = 128), roomRow)
        )
        assertNotNull(candidates.single())
        org.junit.Assert.assertEquals(256, candidates.single().storageGb)
    }

    @Test
    fun catalogCandidatesDoNotTreatUnknownRamAsWildcard() {
        val catalog = JsonPhoneCatalog(
            schemaVersion = "1.1.0",
            generatedFrom = "test",
            phones = listOf(
                JsonPhone(
                    id = "test-ram", manufacturer = "Test", model = "テストスマホ", series = null,
                    platform = "ANDROID", releaseYear = 2026, isJapanOfficial = true,
                    variants = listOf(
                        JsonVariant(256, null, listOf(JsonSalesListing("DOCOMO", "docomo", null, "AVAILABLE", "https://example.com"))),
                        JsonVariant(256, 16, listOf(JsonSalesListing("DOCOMO", "docomo", null, "AVAILABLE", "https://example.com")))
                    )
                )
            ),
            auditFindings = emptyList()
        )

        val candidates = SinglePhoneDiagnosticEngine.catalogCandidates(catalog, listOf(row(storageGb = 256)))
        org.junit.Assert.assertTrue("RAM-12GB Room row must not match an unknown-RAM catalog variant", candidates.isEmpty())
    }

    @Test
    fun unknownAvailabilityIsNotRecommendedAsCurrentlyPurchasable() {
        val r = SinglePhoneDiagnosticEngine.recommend(
            SinglePhoneDiagnosticEngine.Requirement(
                os = CandidateOs.EITHER, targetBudgetYen = 150_000, absoluteMaxYen = 200_000,
                primaryUse = jp.smartphoneadvisor.app.data.PrimaryUse.GENERAL,
                mustHaveOsaifuKeitai = false, mustHaveMicroSd = false
            ), listOf(row().copy(availabilityStatus = "UNKNOWN"))
        )
        assertNull(r)
    }

    @Test
    fun preorderIsNotRecommendedAsCurrentlyPurchasable() {
        val r = SinglePhoneDiagnosticEngine.recommend(
            SinglePhoneDiagnosticEngine.Requirement(
                os = CandidateOs.EITHER, targetBudgetYen = 150_000, absoluteMaxYen = 200_000,
                primaryUse = jp.smartphoneadvisor.app.data.PrimaryUse.GENERAL,
                mustHaveOsaifuKeitai = false, mustHaveMicroSd = false
            ), listOf(row().copy(availabilityStatus = "PREORDER"))
        )
        assertNull(r)
    }

    @Test
    fun nonJapanOfficialCatalogPhoneIsExcluded() {
        val catalog = JsonPhoneCatalog(
            schemaVersion = "1.1.0", generatedFrom = "test",
            phones = listOf(JsonPhone(
                id = "non-jp", manufacturer = "Test", model = "テストスマホ", series = null,
                platform = "ANDROID", releaseYear = 2026, isJapanOfficial = false,
                variants = listOf(JsonVariant(256, 12, listOf(JsonSalesListing("SIM_FREE", "store", null, "AVAILABLE", "https://example.com"))))
            )), auditFindings = emptyList()
        )
        val candidates = SinglePhoneDiagnosticEngine.catalogCandidates(catalog, listOf(row()))
        org.junit.Assert.assertTrue(candidates.isEmpty())
    }

    @Test
    fun requiredMicroSdIsHardFilter() {
        val r = SinglePhoneDiagnosticEngine.recommend(
            SinglePhoneDiagnosticEngine.Requirement(
                os = CandidateOs.EITHER, targetBudgetYen = 150_000, absoluteMaxYen = 200_000,
                primaryUse = jp.smartphoneadvisor.app.data.PrimaryUse.GENERAL,
                mustHaveOsaifuKeitai = false, mustHaveMicroSd = true
            ), listOf(row(microSd = SupportStatus.UNKNOWN))
        )
        assertNull(r)
    }

    @Test
    fun iphoneRequirementExcludesAndroidCandidates() {
        val r = SinglePhoneDiagnosticEngine.recommend(
            SinglePhoneDiagnosticEngine.Requirement(
                os = CandidateOs.IPHONE, targetBudgetYen = 150_000, absoluteMaxYen = 200_000,
                primaryUse = jp.smartphoneadvisor.app.data.PrimaryUse.GENERAL,
                mustHaveOsaifuKeitai = false, mustHaveMicroSd = false
            ), listOf(row())
        )
        assertNull(r)
    }

    @Test
    fun stalePriceCannotPassAnAbsoluteBudgetLimit() {
        val stale = row(price = 80_000).copy(
            priceCheckedAt = System.currentTimeMillis() - 30L * 24L * 60L * 60L * 1000L
        )
        val r = SinglePhoneDiagnosticEngine.recommend(
            SinglePhoneDiagnosticEngine.Requirement(
                os = CandidateOs.EITHER, targetBudgetYen = 150_000, absoluteMaxYen = 200_000,
                primaryUse = jp.smartphoneadvisor.app.data.PrimaryUse.GENERAL,
                mustHaveOsaifuKeitai = false, mustHaveMicroSd = false
            ), listOf(stale)
        )
        assertNull(r)
    }

    @Test
    fun unknownPriceCannotPassAnAbsoluteBudgetLimit() {
        val r = SinglePhoneDiagnosticEngine.recommend(
            SinglePhoneDiagnosticEngine.Requirement(
                os = CandidateOs.EITHER, targetBudgetYen = 150_000, absoluteMaxYen = 200_000,
                primaryUse = jp.smartphoneadvisor.app.data.PrimaryUse.GENERAL,
                mustHaveOsaifuKeitai = false, mustHaveMicroSd = false
            ), listOf(row().copy(normalPriceYen = null))
        )
        assertNull(r)
    }

    @Test
    fun photoVideoUseScoresCameraAndVideoTogether() {
        val requirement = SinglePhoneDiagnosticEngine.Requirement(
            os = CandidateOs.EITHER, targetBudgetYen = 150_000, absoluteMaxYen = 200_000,
            primaryUse = jp.smartphoneadvisor.app.data.PrimaryUse.CAMERA,
            mustHaveOsaifuKeitai = false, mustHaveMicroSd = false
        )
        val cameraOnlyStrength = row().copy(
            deviceVariantId = 1L,
            cameraLevel = AttributeLevel.EXCELLENT,
            videoLevel = AttributeLevel.UNKNOWN
        )
        val balancedPhotoVideo = row().copy(
            deviceVariantId = 2L,
            cameraLevel = AttributeLevel.GOOD,
            videoLevel = AttributeLevel.GOOD
        )

        val result = SinglePhoneDiagnosticEngine.recommend(requirement, listOf(cameraOnlyStrength, balancedPhotoVideo))

        org.junit.Assert.assertEquals(2L, result?.candidate?.deviceVariantId)
        org.junit.Assert.assertTrue(result?.reasons?.contains("写真・動画用途への適性が良好です") == true)
        org.junit.Assert.assertTrue(result?.cautions?.contains("動画性能の評価が未確認です") != true)
    }

    @Test
    fun photoVideoRecommendationWarnsWhenVideoAssessmentIsUnknown() {
        val result = SinglePhoneDiagnosticEngine.recommend(
            SinglePhoneDiagnosticEngine.Requirement(
                os = CandidateOs.EITHER, targetBudgetYen = 150_000, absoluteMaxYen = 200_000,
                primaryUse = jp.smartphoneadvisor.app.data.PrimaryUse.CAMERA,
                mustHaveOsaifuKeitai = false, mustHaveMicroSd = false
            ), listOf(row().copy(videoLevel = AttributeLevel.UNKNOWN))
        )

        org.junit.Assert.assertTrue(result?.cautions?.contains("動画性能の評価が未確認です") == true)
        org.junit.Assert.assertTrue(result?.reasons?.contains("写真・動画用途への適性が良好です") != true)
    }

    @Test
    fun usedPhoneIsExcludedByDefaultNewDeviceDiagnostic() {
        val result = SinglePhoneDiagnosticEngine.recommend(
            SinglePhoneDiagnosticEngine.Requirement(
                os = CandidateOs.EITHER, targetBudgetYen = 150_000, absoluteMaxYen = 200_000,
                primaryUse = jp.smartphoneadvisor.app.data.PrimaryUse.GENERAL,
                mustHaveOsaifuKeitai = false, mustHaveMicroSd = false
            ), listOf(row().copy(productCondition = ProductCondition.USED))
        )
        assertNull(result)
    }

    @Test
    fun refurbishedPhoneIsExcludedByDefaultNewDeviceDiagnostic() {
        val result = SinglePhoneDiagnosticEngine.recommend(
            SinglePhoneDiagnosticEngine.Requirement(
                os = CandidateOs.EITHER, targetBudgetYen = 150_000, absoluteMaxYen = 200_000,
                primaryUse = jp.smartphoneadvisor.app.data.PrimaryUse.GENERAL,
                mustHaveOsaifuKeitai = false, mustHaveMicroSd = false
            ), listOf(row().copy(productCondition = ProductCondition.REFURBISHED))
        )
        assertNull(result)
    }

    @Test
    fun missingTargetBudgetDoesNotClaimPriceExceedsTarget() {
        val result = SinglePhoneDiagnosticEngine.recommend(
            SinglePhoneDiagnosticEngine.Requirement(
                os = CandidateOs.EITHER, targetBudgetYen = null, absoluteMaxYen = 200_000,
                primaryUse = jp.smartphoneadvisor.app.data.PrimaryUse.GENERAL,
                mustHaveOsaifuKeitai = false, mustHaveMicroSd = false
            ), listOf(row(price = 150_000))
        )

        org.junit.Assert.assertTrue(result?.reasons?.contains("価格150,000円は希望価格未設定ですが、絶対上限200,000円以内です") == true)
        org.junit.Assert.assertTrue(result?.reasons?.contains("価格150,000円は希望予算未設定を超えますが、絶対上限200,000円以内です") != true)
    }

    @Test
    fun budgetReasonIncludesConcretePriceTargetAndAbsoluteLimit() {
        val result = SinglePhoneDiagnosticEngine.recommend(
            SinglePhoneDiagnosticEngine.Requirement(
                os = CandidateOs.EITHER, targetBudgetYen = 100_000, absoluteMaxYen = 200_000,
                primaryUse = jp.smartphoneadvisor.app.data.PrimaryUse.GENERAL,
                mustHaveOsaifuKeitai = false, mustHaveMicroSd = false
            ), listOf(row(price = 150_000))
        )
        org.junit.Assert.assertTrue(result?.reasons?.contains(
            "価格150,000円は希望予算100,000円を超えますが、絶対上限200,000円以内です"
        ) == true)
    }

    @Test
    fun unknownPriceExplainsWhichBudgetThresholdsCannotBeChecked() {
        val result = SinglePhoneDiagnosticEngine.recommend(
            SinglePhoneDiagnosticEngine.Requirement(
                os = CandidateOs.EITHER, targetBudgetYen = 100_000, absoluteMaxYen = 200_000,
                primaryUse = jp.smartphoneadvisor.app.data.PrimaryUse.GENERAL,
                mustHaveOsaifuKeitai = false, mustHaveMicroSd = false
            ), listOf(row().copy(normalPriceYen = null))
        )
        org.junit.Assert.assertTrue(result?.cautions?.contains(
            "価格が未確認のため、希望予算100,000円・絶対上限200,000円への適合を確認できません"
        ) == true)
    }

}
