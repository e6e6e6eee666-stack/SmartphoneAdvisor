package jp.smartphoneadvisor.app.data.catalog

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class PhoneCatalogJsonParserTest {

    @Test
    fun rejectsCatalogWhenDeclaredCountsDoNotMatchParsedData() {
        val json = """
            {
              "schemaVersion":"1.0.0",
              "generatedFrom":"test",
              "counts":{"phoneModels":2,"variants":1,"salesListings":1,"priceOptions":0,"auditFindings":0},
              "phones":[{
                "id":"Test:Phone:2026","manufacturer":"Test","model":"Phone","series":null,
                "platform":"ANDROID","releaseYear":2026,"isJapanOfficial":true,
                "variants":[{"storageGb":128,"ramGb":8,"sales":[{"channel":"SIM_FREE","retailer":"Test Store","modelNumber":null,"availability":"AVAILABLE","url":"https://example.com"}]}]
              }],
              "auditFindings":[]
            }
        """.trimIndent()

        val error = org.junit.Assert.assertThrows(IllegalArgumentException::class.java) {
            PhoneCatalogJsonParser.parse(json)
        }
        assertTrue(error.message.orEmpty().contains("counts.phoneModels=2 does not match parsed value 1"))
    }

    @Test
    fun acceptsCatalogWhenDeclaredCountsMatchParsedData() {
        val json = """
            {
              "schemaVersion":"1.0.0","generatedFrom":"test",
              "counts":{"phoneModels":1,"variants":1,"salesListings":1,"priceOptions":0,"auditFindings":0},
              "phones":[{
                "id":"Test:Phone:2026","manufacturer":"Test","model":"Phone","series":null,
                "platform":"ANDROID","releaseYear":2026,"isJapanOfficial":true,
                "variants":[{"storageGb":128,"ramGb":8,"sales":[{"channel":"SIM_FREE","retailer":"Test Store","modelNumber":null,"availability":"AVAILABLE","url":"https://example.com"}]}]
              }],
              "auditFindings":[]
            }
        """.trimIndent()
        assertEquals(1, PhoneCatalogJsonParser.parse(json).phones.size)
    }

    @Test
    fun parsesMinimalCatalogAndKeepsNullableRam() {
        val json = """
            {
              "schemaVersion":"1.0.0",
              "generatedFrom":"test",
              "phones":[{
                "id":"Apple:iPhone 17:2025",
                "manufacturer":"Apple",
                "model":"iPhone 17",
                "series":"iPhone",
                "platform":"IPHONE",
                "releaseYear":2025,
                "isJapanOfficial":true,
                "variants":[{
                  "storageGb":256,
                  "ramGb":null,
                  "sales":[{
                    "channel":"SOFTBANK",
                    "retailer":"ソフトバンク",
                    "modelNumber":null,
                    "availability":"AVAILABLE",
                    "url":"https://example.com"
                  }]
                }]
              }],
              "auditFindings":[]
            }
        """.trimIndent()

        val catalog = PhoneCatalogJsonParser.parse(json)
        assertEquals(1, catalog.phones.size)
        assertEquals("iPhone 17", catalog.phones[0].model)
        assertEquals(256, catalog.phones[0].variants[0].storageGb)
        assertNull(catalog.phones[0].variants[0].ramGb)
        assertNotNull(catalog.phones[0].variants[0].sales[0])
    }

    @Test
    fun parsesSalesListingWhenUrlIsNull() {
        val json = """
            {
              "schemaVersion":"1.0.0",
              "generatedFrom":"test",
              "phones":[{
                "id":"Xiaomi:REDMI Note 17 Pro Max 5G:2026",
                "manufacturer":"Xiaomi",
                "model":"REDMI Note 17 Pro Max 5G",
                "series":"REDMI Note",
                "platform":"ANDROID",
                "releaseYear":2026,
                "isJapanOfficial":true,
                "variants":[{
                  "storageGb":256,
                  "ramGb":8,
                  "sales":[{
                    "channel":"Y_MOBILE",
                    "retailer":"Y!mobile Free Style",
                    "modelNumber":null,
                    "availability":"AVAILABLE",
                    "url":null
                  }]
                }]
              }],
              "auditFindings":[]
            }
        """.trimIndent()
        val catalog = PhoneCatalogJsonParser.parse(json)
        assertEquals(1, catalog.phones.size)
        assertNull(catalog.phones[0].variants[0].sales[0].url)
    }

    @Test
    fun parsesColorSpecificOfficialPriceOptions() {
        val json = """
            {
              "schemaVersion":"1.1.0",
              "generatedFrom":"test",
              "phones":[{
                "id":"nubia:nubia Z80 Ultra:2026",
                "manufacturer":"nubia",
                "model":"nubia Z80 Ultra",
                "series":"Z",
                "platform":"ANDROID",
                "releaseYear":2026,
                "isJapanOfficial":true,
                "variants":[{
                  "storageGb":512,
                  "ramGb":16,
                  "sales":[{
                    "channel":"SIM_FREE",
                    "retailer":"nubia Store Japan",
                    "modelNumber":null,
                    "availability":"AVAILABLE",
                    "url":"https://jp.nubia.com/products/nubia-z80-ultra",
                    "priceOptions":[
                      {"color":"ブラック","priceYen":139800,"priceType":"NORMAL","conditions":"official list price","sourceUrl":"https://jp.nubia.com/blogs/product-information/nubia-z80-ultra","checkedAt":"2026-10-15"},
                      {"color":"ホワイト","priceYen":139800,"priceType":"NORMAL","conditions":"official list price","sourceUrl":"https://jp.nubia.com/blogs/product-information/nubia-z80-ultra","checkedAt":"2026-10-15"},
                      {"color":"スターレイナイト","priceYen":144800,"priceType":"NORMAL","conditions":"official list price","sourceUrl":"https://jp.nubia.com/blogs/product-information/nubia-z80-ultra","checkedAt":"2026-10-15"}
                    ]
                  }]
                }]
              }],
              "auditFindings":[]
            }
        """.trimIndent()
        val catalog = PhoneCatalogJsonParser.parse(json)
        val options = catalog.phones.single().variants.single().sales.single().priceOptions
        assertEquals(3, options.size)
        assertEquals(139800, options[0].priceYen)
        assertEquals("ホワイト", options[1].color)
        assertEquals(144800, options[2].priceYen)
    }


    @Test
    fun nubiaZ80UltraColorPriceOptionsRemainDistinct() {
        val json = java.io.File("src/main/assets/phones.json").readText()
        val catalog = PhoneCatalogJsonParser.parse(json)
        val phone = catalog.phones.single { it.model == "nubia Z80 Ultra" }
        val options = phone.variants.single { it.storageGb == 512 && it.ramGb == 16 }
            .sales.single { it.channel == "SIM_FREE" }.priceOptions
        assertEquals(3, options.size)
        assertEquals(mapOf("ブラック" to 139800, "ホワイト" to 139800, "スターレイナイト" to 144800), options.associate { it.color!! to it.priceYen })
        assertTrue(options.all { it.sourceUrl?.startsWith("https://") == true && it.checkedAt == "2026-10-15" })
    }
}
