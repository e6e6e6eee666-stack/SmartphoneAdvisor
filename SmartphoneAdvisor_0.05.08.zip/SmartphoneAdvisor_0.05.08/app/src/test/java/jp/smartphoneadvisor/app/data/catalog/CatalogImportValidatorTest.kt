package jp.smartphoneadvisor.app.data.catalog

import org.junit.Assert.assertTrue
import org.junit.Test

class CatalogImportValidatorTest {
    @Test fun validJapanOfficialRecordPasses() {
        val batch = CatalogImportBatch(
            catalogVersion = "test-1",
            generatedAt = "2026-09-26T00:00:00Z",
            records = listOf(
                CatalogPhoneRecord("google", "Google", "pixel", "Pixel", "pixel-test", "Pixel Test", "ANDROID", null, 2026, true,
                    listOf(CatalogVariantRecord("pixel-test-256", 256, 12)))
            )
        )
        assertTrue(CatalogImportValidator.validate(batch).isEmpty())
    }

    @Test fun overseasOnlyRecordIsRejected() {
        val batch = CatalogImportBatch(
            catalogVersion = "test-1", generatedAt = "2026-09-26T00:00:00Z",
            records = listOf(CatalogPhoneRecord("x", "X", "x", "X", "x-1", "X1", "ANDROID", null, 2026, false,
                listOf(CatalogVariantRecord("x-1-128", 128, 8))))
        )
        assertTrue(CatalogImportValidator.validate(batch).any { it.contains("Japan-official") })
    }

    @Test fun manufacturerPrefixAliasIsRejectedAsDuplicateIdentity() {
        val base = CatalogPhoneRecord("nothing", "Nothing", "phone-4a", "Phone (4a)", "nothing-phone-4a", "Nothing Phone (4a)", "ANDROID", null, 2026, true,
            listOf(CatalogVariantRecord("nothing-phone-4a-128", 128, 8)))
        val alias = base.copy(modelKey = "nothing-phone-4a-alias", modelName = "Phone (4a)", seriesKey = "phone", seriesName = "Phone")
        val errors = CatalogImportValidator.validate(CatalogImportBatch("test-1", "2026-09-26T00:00:00Z", listOf(base, alias)))
        assertTrue(errors.any { it.contains("canonical model identity") })
    }

    @Test fun punctuationMeaningIsPreservedForDifferentModels() {
        val s26 = CatalogPhoneRecord("samsung", "Samsung", "galaxy-s", "Galaxy S", "s26", "Galaxy S26", "ANDROID", null, 2026, true,
            listOf(CatalogVariantRecord("s26-256", 256, 12)))
        val s26Plus = s26.copy(modelKey = "s26-plus", modelName = "Galaxy S26+", seriesKey = "galaxy-s-plus")
        val errors = CatalogImportValidator.validate(CatalogImportBatch("test-1", "2026-09-26T00:00:00Z", listOf(s26, s26Plus)))
        assertTrue(errors.none { it.contains("canonical model identity") })
    }

    @Test fun duplicateModelKeyIsRejected() {
        val phone = CatalogPhoneRecord("x", "X", "x", "X", "x-1", "X1", "ANDROID", null, 2026, true,
            listOf(CatalogVariantRecord("x-1-128", 128, 8)))
        val batch = CatalogImportBatch("test-1", "2026-09-26T00:00:00Z", listOf(phone, phone.copy(modelName = "X1 duplicate")))
        assertTrue(CatalogImportValidator.validate(batch).any { it.contains("duplicated") })
    }
}
