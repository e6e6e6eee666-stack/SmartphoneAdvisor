package jp.smartphoneadvisor.app.data.catalog

import jp.smartphoneadvisor.app.data.AvailabilityStatus
import jp.smartphoneadvisor.app.data.DeviceVariantEntity
import jp.smartphoneadvisor.app.data.PriceRecordV2Entity
import jp.smartphoneadvisor.app.data.PriceType
import jp.smartphoneadvisor.app.data.ProductListingEntity
import jp.smartphoneadvisor.app.data.RetailerEntity
import jp.smartphoneadvisor.app.data.RetailerType
import jp.smartphoneadvisor.app.data.SalesChannel
import jp.smartphoneadvisor.app.data.SalesVariantEntity
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ProductListingRelationAuditTest {
    @Test
    fun validRelationsHaveNoIssues() {
        val report = ProductListingRelationAudit.analyze(
            deviceVariants = listOf(DeviceVariantEntity(id = 10, modelId = 1, storageGb = 128, ramGb = 8)),
            salesVariants = listOf(SalesVariantEntity(id = 20, deviceVariantId = 10, salesChannel = SalesChannel.SIM_FREE, modelNumber = "SIM-1")),
            retailers = listOf(RetailerEntity(id = 30, name = "Store", type = RetailerType.OTHER, official = false)),
            listings = listOf(ProductListingEntity(id = 40, salesVariantId = 20, retailerId = 30, productUrl = "https://example.com", checkedAt = 1)),
            prices = listOf(PriceRecordV2Entity(id = 50, productListingId = 40, priceType = PriceType.NORMAL, priceYen = 1000, checkedAt = 1))
        )
        assertEquals(0, report.issueGroupCount)
        assertEquals(0, report.issueRowCount)
        assertEquals(1, report.productListingRows)
    }

    @Test
    fun missingRelationsBlankUrlAndDuplicateListingIdentityAreReportedWithoutMutation() {
        val listings = listOf(
            ProductListingEntity(id = 41, salesVariantId = 200, retailerId = 300, productUrl = "", checkedAt = 1),
            ProductListingEntity(id = 42, salesVariantId = 200, retailerId = 300, productUrl = "https://example.com", checkedAt = 2)
        )
        val prices = listOf(PriceRecordV2Entity(id = 51, productListingId = 999, priceType = PriceType.NORMAL, priceYen = 1000, checkedAt = 1))
        val report = ProductListingRelationAudit.analyze(
            deviceVariants = emptyList(),
            salesVariants = listOf(SalesVariantEntity(id = 21, deviceVariantId = 888, salesChannel = SalesChannel.DOCOMO)),
            retailers = emptyList(), listings = listings, prices = prices
        )
        assertEquals(888L, report.salesVariantsMissingDeviceVariant[21L])
        assertEquals(200L, report.listingsMissingSalesVariant[41L])
        assertEquals(300L, report.listingsMissingRetailer[41L])
        assertEquals(300L, report.blankProductUrls[41L])
        assertEquals(2, report.duplicateListingIdentities["salesVariantId=200,retailerId=300"])
        assertEquals(999L, report.priceRecordsMissingListing[51L])
        assertEquals("", listings.first().productUrl) // read-only: input rows were not modified
        assertTrue(report.issueGroupCount >= 6)
        assertTrue(report.issueRowCount > report.issueGroupCount)
    }
    @Test
    fun duplicateSalesVariantIdentityWithNullModelNumberIsReported() {
        val report = ProductListingRelationAudit.analyze(
            deviceVariants = listOf(DeviceVariantEntity(id = 10, modelId = 1, storageGb = 128, ramGb = 8)),
            salesVariants = listOf(
                SalesVariantEntity(id = 20, deviceVariantId = 10, salesChannel = SalesChannel.DOCOMO, modelNumber = null),
                SalesVariantEntity(id = 21, deviceVariantId = 10, salesChannel = SalesChannel.DOCOMO, modelNumber = null)
            ),
            retailers = emptyList(), listings = emptyList(), prices = emptyList()
        )
        assertEquals(2, report.duplicateSalesVariantIdentities["deviceVariantId=10,salesChannel=DOCOMO,modelNumber=<NULL>"])
    }

}
