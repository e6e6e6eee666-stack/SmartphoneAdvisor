package jp.smartphoneadvisor.app.data.catalog

import jp.smartphoneadvisor.app.data.RetailerEntity
import jp.smartphoneadvisor.app.data.RetailerType
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class RetailerMasterAuditTest {
    @Test
    fun emptyMasterHasNoIssues() {
        val report = RetailerMasterAudit.analyze(emptyList())
        assertEquals(0, report.totalRows)
        assertEquals(0, report.issueCount)
    }

    @Test
    fun duplicateNameAndMixedMetadataAreReportedWithoutMerging() {
        val rows = listOf(
            RetailerEntity(id = 1, name = "Example Store", type = RetailerType.MANUFACTURER, official = true),
            RetailerEntity(id = 2, name = "Example Store", type = RetailerType.OTHER, official = false),
            RetailerEntity(id = 3, name = "   ", type = RetailerType.OTHER, official = false)
        )
        val report = RetailerMasterAudit.analyze(rows)
        assertEquals(3, report.totalRows)
        assertEquals(1, report.blankNames)
        assertEquals(2, report.duplicateNames["Example Store"])
        assertEquals(setOf("MANUFACTURER", "OTHER"), report.mixedTypes["Example Store"])
        assertEquals(setOf(true, false), report.mixedOfficialFlags["Example Store"])
        assertTrue(report.issueCount >= 4)
        assertEquals(3, rows.size) // audit is read-only; original rows remain intact
    }

    @Test
    fun normalizedNameAndWebsiteConflictsAreReportedWithoutChangingRows() {
        val rows = listOf(
            RetailerEntity(id = 21, name = "Example Store", type = RetailerType.OTHER, official = false, websiteUrl = "https://one.example"),
            RetailerEntity(id = 22, name = " example store ", type = RetailerType.OTHER, official = false, websiteUrl = "https://two.example"),
            RetailerEntity(id = 23, name = "EXAMPLE STORE", type = RetailerType.OTHER, official = false, websiteUrl = "https://one.example")
        )
        val report = RetailerMasterAudit.analyze(rows)
        assertEquals(setOf("Example Store", " example store ", "EXAMPLE STORE"), report.normalizedNameVariants["example store"])
        assertEquals(setOf("https://one.example", "https://two.example"), report.mixedWebsiteUrls["example store"])
        assertEquals("Example Store", rows.first().name)
        assertEquals(3, rows.size)
    }

    @Test
    fun invalidAndWhitespaceWebsiteUrlsAreReportedWithoutMutation() {
        val rows = listOf(
            RetailerEntity(id = 31, name = "Bad scheme", type = RetailerType.OTHER, official = false, websiteUrl = "javascript:alert(1)"),
            RetailerEntity(id = 32, name = "Missing host", type = RetailerType.OTHER, official = false, websiteUrl = "https:///path"),
            RetailerEntity(id = 33, name = "Whitespace", type = RetailerType.OTHER, official = false, websiteUrl = " https://example.com "),
            RetailerEntity(id = 34, name = "Valid", type = RetailerType.OTHER, official = false, websiteUrl = "https://example.com/path")
        )
        val report = RetailerMasterAudit.analyze(rows)
        assertEquals("javascript:alert(1)", report.invalidWebsiteUrls[31])
        assertEquals("https:///path", report.invalidWebsiteUrls[32])
        assertEquals(" https://example.com ", report.whitespaceWebsiteUrls[33])
        assertTrue(34L !in report.invalidWebsiteUrls)
        assertEquals(" https://example.com ", rows[2].websiteUrl)
    }

    @Test
    fun duplicateSameTypeIsReportedButNotFlaggedAsMixedType() {
        val rows = listOf(
            RetailerEntity(id = 10, name = "Same", type = RetailerType.CARRIER, official = false),
            RetailerEntity(id = 11, name = "Same", type = RetailerType.CARRIER, official = false)
        )
        val report = RetailerMasterAudit.analyze(rows)
        assertEquals(2, report.duplicateNames["Same"])
        assertTrue("Same" !in report.mixedTypes)
        assertTrue("Same" !in report.mixedOfficialFlags)
    }
}
