package jp.smartphoneadvisor.app.data.catalog

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PhoneCatalogRoomImporterTest {
    private fun phone(
        id: String = "google:pixel-test:2026",
        model: String = "Pixel Test",
        platform: String = "ANDROID",
        releaseYear: Int = 2026,
        variants: List<JsonVariant> = listOf(JsonVariant(128, 8, emptyList()))
    ) = JsonPhone(id, "Google", model, "Pixel", platform, releaseYear, true, variants)

    private fun catalog(vararg phones: JsonPhone) = JsonPhoneCatalog("1.1.0", "test", phones.toList(), emptyList())


    private fun priceOption(
        checkedAt: String? = "2026-10-17",
        sourceUrl: String? = "https://example.jp/price",
        priceYen: Int = 59800
    ) = JsonPriceOption(null, priceYen, "NORMAL", null, sourceUrl, checkedAt)

    @Test fun priceOptionWithImpossibleCalendarDateIsRejected() {
        val sale = JsonSalesListing("SIM_FREE", "Google Store", null, "AVAILABLE", "https://example.jp/phone",
            listOf(priceOption(checkedAt = "2026-02-30")))
        val errors = PhoneCatalogRoomImporter.validate(catalog(phone(variants = listOf(JsonVariant(128, 8, listOf(sale))))))
        assertTrue(errors.any { it.contains("checkedAt must be a real calendar date") })
    }

    @Test fun priceOptionWithNonHttpsOrHostlessSourceIsRejected() {
        val nonHttps = JsonSalesListing("SIM_FREE", "Google Store", null, "AVAILABLE", "https://example.jp/phone",
            listOf(priceOption(sourceUrl = "http://example.jp/price")))
        val hostless = JsonSalesListing("SIM_FREE", "Google Store", null, "AVAILABLE", "https://example.jp/phone",
            listOf(priceOption(sourceUrl = "https:///price")))
        val nonHttpsErrors = PhoneCatalogRoomImporter.validate(catalog(phone(variants = listOf(JsonVariant(128, 8, listOf(nonHttps))))))
        val hostlessErrors = PhoneCatalogRoomImporter.validate(catalog(phone(variants = listOf(JsonVariant(128, 8, listOf(hostless))))))
        assertTrue(nonHttpsErrors.any { it.contains("price sourceUrl must be a valid HTTPS URL") })
        assertTrue(hostlessErrors.any { it.contains("price sourceUrl must be a valid HTTPS URL") })
    }

    @Test fun priceOptionWithMissingProvenanceIsRejected() {
        val sale = JsonSalesListing("SIM_FREE", "Google Store", null, "AVAILABLE", "https://example.jp/phone",
            listOf(priceOption(checkedAt = null, sourceUrl = null)))
        val errors = PhoneCatalogRoomImporter.validate(catalog(phone(variants = listOf(JsonVariant(128, 8, listOf(sale))))))
        assertTrue(errors.any { it.contains("checkedAt is required") })
        assertTrue(errors.any { it.contains("price sourceUrl must be a valid HTTPS URL") })
    }

    @Test fun validCatalogPassesPreflight() {
        assertTrue(PhoneCatalogRoomImporter.validate(catalog(phone())).isEmpty())
    }

    @Test fun duplicateStableIdIsRejected() {
        assertTrue(PhoneCatalogRoomImporter.validate(catalog(phone(), phone(model = "Pixel Test 2")))
            .any { it.contains("duplicate id") })
    }

    @Test fun manufacturerPrefixAliasIsRejectedBeforeRoomImport() {
        val withPrefix = JsonPhone("nothing:phone-4a:2026", "Nothing", "Nothing Phone (4a)", "Phone", "ANDROID", 2026, true,
            listOf(JsonVariant(128, 8, emptyList())))
        val withoutPrefix = withPrefix.copy(id = "nothing:phone-4a-alias:2026", model = "Phone (4a)")
        val errors = PhoneCatalogRoomImporter.validate(catalog(withPrefix, withoutPrefix))
        assertTrue(errors.any { it.contains("duplicate canonical model identity") })
    }

    @Test fun modelPunctuationIsPreservedDuringIdentityCheck() {
        val s26 = JsonPhone("samsung:s26:2026", "Samsung", "Galaxy S26", "Galaxy S", "ANDROID", 2026, true,
            listOf(JsonVariant(256, 12, emptyList())))
        val s26Plus = s26.copy(id = "samsung:s26-plus:2026", model = "Galaxy S26+")
        assertTrue(PhoneCatalogRoomImporter.validate(catalog(s26, s26Plus)).isEmpty())
    }

    @Test fun duplicateVariantKeyIsRejected() {
        val variants = listOf(JsonVariant(128, 8, emptyList()), JsonVariant(128, 8, emptyList()))
        assertTrue(PhoneCatalogRoomImporter.validate(catalog(phone(variants = variants)))
            .any { it.contains("duplicate variant") })
    }

    @Test fun invalidPlatformAndStorageAreRejected() {
        val invalid = phone(platform = "UNKNOWN", variants = listOf(JsonVariant(0, 8, emptyList())))
        val errors = PhoneCatalogRoomImporter.validate(catalog(invalid))
        assertTrue(errors.any { it.contains("unsupported platform") })
        assertTrue(errors.any { it.contains("invalid storage") })
    }

    @Test fun unknownRamIsAllowedAndNotInvented() {
        assertFalse(PhoneCatalogRoomImporter.validate(catalog(phone(variants = listOf(JsonVariant(256, null, emptyList())))))
            .any { it.contains("RAM") })
    }

    @Test fun unknownSalesChannelIsRejectedBeforeImport() {
        val sale = JsonSalesListing("MYSTERY", "Carrier", null, "AVAILABLE", null)
        val errors = PhoneCatalogRoomImporter.validate(catalog(phone(variants = listOf(JsonVariant(128, 8, listOf(sale))))))
        assertTrue(errors.any { it.contains("unsupported sales channel") })
    }

    @Test fun malformedSalesUrlIsRejectedButMissingUrlIsAllowed() {
        val missing = JsonSalesListing("DOCOMO", "docomo", null, "AVAILABLE", null)
        assertTrue(PhoneCatalogRoomImporter.validate(catalog(phone(variants = listOf(JsonVariant(128, 8, listOf(missing)))))).isEmpty())
        val malformed = missing.copy(url = "javascript:alert(1)")
        assertTrue(PhoneCatalogRoomImporter.validate(catalog(phone(variants = listOf(JsonVariant(128, 8, listOf(malformed))))).any { it.contains("invalid sales URL scheme or syntax") })
        val noHost = missing.copy(url = "https:///missing-host")
        assertTrue(PhoneCatalogRoomImporter.validate(catalog(phone(variants = listOf(JsonVariant(128, 8, listOf(noHost))))).any { it.contains("no valid host") })
        val whitespace = missing.copy(url = " https://example.jp/phone ")
        assertTrue(PhoneCatalogRoomImporter.validate(catalog(phone(variants = listOf(JsonVariant(128, 8, listOf(whitespace))))).any { it.contains("leading/trailing whitespace") })
    }

    @Test fun blankModelNumberAndPaddedRetailerAreRejected() {
        val blankModel = JsonSalesListing("DOCOMO", "docomo", "   ", "AVAILABLE", null)
        val paddedRetailer = JsonSalesListing("DOCOMO", " docomo ", null, "AVAILABLE", null)
        val blankErrors = PhoneCatalogRoomImporter.validate(catalog(phone(variants = listOf(JsonVariant(128, 8, listOf(blankModel))))))
        val paddedErrors = PhoneCatalogRoomImporter.validate(catalog(phone(variants = listOf(JsonVariant(128, 8, listOf(paddedRetailer))))))
        assertTrue(blankErrors.any { it.contains("blank modelNumber") })
        assertTrue(paddedErrors.any { it.contains("retailer has leading/trailing whitespace") })
    }

    @Test fun duplicateSalesIdentityIsRejected() {
        val sale = JsonSalesListing("DOCOMO", "docomo", "ABC-123", "AVAILABLE", "https://example.jp/phone")
        val errors = PhoneCatalogRoomImporter.validate(catalog(phone(variants = listOf(JsonVariant(128, 8, listOf(sale, sale))))))
        assertTrue(errors.any { it.contains("duplicate sales identity") })
    }

    @Test fun unsupportedAvailabilityIsRejectedBeforeImport() {
        val sale = JsonSalesListing("DOCOMO", "docomo", null, "MAYBE", null)
        val errors = PhoneCatalogRoomImporter.validate(catalog(phone(variants = listOf(JsonVariant(128, 8, listOf(sale))))))
        assertTrue(errors.any { it.contains("unsupported availability") })
    }

    @Test fun missingSalesUrlIsAllowedWithoutInventingUrl() {
        val sale = JsonSalesListing("DOCOMO", "docomo", null, "UNKNOWN", null)
        assertTrue(PhoneCatalogRoomImporter.validate(catalog(phone(variants = listOf(JsonVariant(128, 8, listOf(sale)))))).isEmpty())
    }
}
