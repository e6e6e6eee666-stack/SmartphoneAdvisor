package jp.smartphoneadvisor.app.data

import androidx.room.Room
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import org.junit.Assert.assertNotNull
import org.junit.Test
import org.junit.runner.RunWith

/** Runtime smoke test: verify Room can create the current schema on Android. */
@RunWith(AndroidJUnit4::class)
class AppDatabaseSmokeTest {
    @Test
    fun currentSchemaOpensAndDaosAreAvailable() {
        val context = InstrumentationRegistry.getInstrumentation().targetContext
        val database = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        try {
            database.openHelper.writableDatabase
            assertNotNull(database.phoneDao())
            assertNotNull(database.diagnosticDao())
        } finally {
            database.close()
        }
    }
}
