package jp.smartphoneadvisor.app.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [
        ManufacturerEntity::class,
        SmartphoneModelEntity::class,
        DeviceVariantEntity::class,
        PhysicalSpecsEntity::class,
        DisplaySpecsEntity::class,
        CameraSpecsEntity::class,
        BatterySpecsEntity::class,
        ConnectivitySpecsEntity::class,
        SoftwareSpecsEntity::class,
        SalesVariantEntity::class,
        RetailerEntity::class,
        ProductListingEntity::class,
        CampaignEntity::class,
        PriceRecordV2Entity::class,
        RecommendationAttributesEntity::class,
        PriceRecordEntity::class,
        DiagnosticProfileEntity::class,
        DiagnosticAnswerEntity::class,
        DiagnosticRunEntity::class,
        DiagnosticDraftEntity::class,
        FavoriteDeviceEntity::class,
        DataSourceEntity::class,
        DataConflictEntity::class,
        PhoneSeriesEntity::class,
        DataChangeLogEntity::class
    ],
    version = 14,
    exportSchema = true
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun diagnosticDao(): DiagnosticDao
    abstract fun phoneDao(): PhoneDao

    companion object {
        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE smartphone_model ADD COLUMN platform TEXT NOT NULL DEFAULT 'ANDROID'")
            }
        }

        private val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("CREATE TABLE IF NOT EXISTS price_record (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, deviceVariantId INTEGER NOT NULL, priceType TEXT NOT NULL, priceYen INTEGER, checkedAt INTEGER NOT NULL, isCurrent INTEGER NOT NULL)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_price_record_deviceVariantId_priceType_isCurrent ON price_record(deviceVariantId, priceType, isCurrent)")
            }
        }

        private val MIGRATION_3_4 = object : Migration(3, 4) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE recommendation_attributes ADD COLUMN microSd TEXT NOT NULL DEFAULT 'UNKNOWN'")
                db.execSQL("ALTER TABLE recommendation_attributes ADD COLUMN headphoneJack TEXT NOT NULL DEFAULT 'UNKNOWN'")
            }
        }

        private val MIGRATION_4_5 = object : Migration(4, 5) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE recommendation_attributes ADD COLUMN generalLevel TEXT NOT NULL DEFAULT 'UNKNOWN'")
                db.execSQL("ALTER TABLE recommendation_attributes ADD COLUMN workStudyLevel TEXT NOT NULL DEFAULT 'UNKNOWN'")
                db.execSQL("ALTER TABLE recommendation_attributes ADD COLUMN videoLevel TEXT NOT NULL DEFAULT 'UNKNOWN'")
                db.execSQL("ALTER TABLE recommendation_attributes ADD COLUMN aiLevel TEXT NOT NULL DEFAULT 'UNKNOWN'")
            }
        }

        private val MIGRATION_5_6 = object : Migration(5, 6) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("CREATE TABLE IF NOT EXISTS physical_specs (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, deviceVariantId INTEGER NOT NULL, heightMm REAL, widthMm REAL, thicknessMm REAL, weightG REAL, measurementSource TEXT)")
                db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_physical_specs_deviceVariantId ON physical_specs(deviceVariantId)")
                db.execSQL("CREATE TABLE IF NOT EXISTS display_specs (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, deviceVariantId INTEGER NOT NULL, heightMm REAL, widthMm REAL, diagonalInch REAL, resolutionText TEXT, panelType TEXT, refreshRateHz INTEGER, measurementSource TEXT)")
                db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_display_specs_deviceVariantId ON display_specs(deviceVariantId)")
                db.execSQL("CREATE TABLE IF NOT EXISTS camera_specs (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, deviceVariantId INTEGER NOT NULL, rearMainMp REAL, rearUltraWideMp REAL, rearTelephotoMp REAL, frontMp REAL, videoMaxText TEXT, stabilizationText TEXT, sourceNote TEXT)")
                db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_camera_specs_deviceVariantId ON camera_specs(deviceVariantId)")
                db.execSQL("CREATE TABLE IF NOT EXISTS battery_specs (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, deviceVariantId INTEGER NOT NULL, capacityMah INTEGER, chargingPowerW INTEGER, wirelessCharging TEXT NOT NULL, manufacturerClaim TEXT, realWorldTestHours REAL, sourceNote TEXT)")
                db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_battery_specs_deviceVariantId ON battery_specs(deviceVariantId)")
                db.execSQL("CREATE TABLE IF NOT EXISTS connectivity_specs (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, deviceVariantId INTEGER NOT NULL, fiveG TEXT NOT NULL, simCount INTEGER, esim TEXT NOT NULL, wifiText TEXT, bluetoothText TEXT, sourceNote TEXT)")
                db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_connectivity_specs_deviceVariantId ON connectivity_specs(deviceVariantId)")
                db.execSQL("CREATE TABLE IF NOT EXISTS software_specs (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, deviceVariantId INTEGER NOT NULL, osVersion TEXT, updateSupportYears INTEGER, securitySupportUntil TEXT, sourceNote TEXT)")
                db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_software_specs_deviceVariantId ON software_specs(deviceVariantId)")
            }
        }

        private val MIGRATION_6_7 = object : Migration(6, 7) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("CREATE TABLE IF NOT EXISTS sales_variant (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, deviceVariantId INTEGER NOT NULL, salesChannel TEXT NOT NULL, modelNumber TEXT, simType TEXT, isActive INTEGER NOT NULL)")
                db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_sales_variant_deviceVariantId_salesChannel_modelNumber ON sales_variant(deviceVariantId, salesChannel, modelNumber)")
                db.execSQL("CREATE TABLE IF NOT EXISTS retailer (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, name TEXT NOT NULL, type TEXT NOT NULL, official INTEGER NOT NULL, websiteUrl TEXT)")
                db.execSQL("CREATE TABLE IF NOT EXISTS product_listing (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, salesVariantId INTEGER NOT NULL, retailerId INTEGER NOT NULL, productUrl TEXT NOT NULL, productName TEXT, availability TEXT NOT NULL, checkedAt INTEGER NOT NULL)")
                db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_product_listing_salesVariantId_retailerId ON product_listing(salesVariantId, retailerId)")
                db.execSQL("CREATE TABLE IF NOT EXISTS campaign (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, name TEXT NOT NULL, description TEXT, startsAt INTEGER, endsAt INTEGER, conditions TEXT, sourceId INTEGER, checkedAt INTEGER NOT NULL)")
                db.execSQL("CREATE TABLE IF NOT EXISTS price_record_v2 (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, productListingId INTEGER NOT NULL, priceType TEXT NOT NULL, priceYen INTEGER, pointsValueYen INTEGER, couponValueYen INTEGER, tradeInValueYen INTEGER, shippingFeeYen INTEGER, conditions TEXT, campaignId INTEGER, checkedAt INTEGER NOT NULL, sourceId INTEGER)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_price_record_v2_productListingId_priceType_checkedAt ON price_record_v2(productListingId, priceType, checkedAt)")
            }
        }

        private val MIGRATION_7_8 = object : Migration(7, 8) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("CREATE TABLE IF NOT EXISTS favorite_device (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, deviceVariantId INTEGER NOT NULL, createdAt INTEGER NOT NULL)")
                db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_favorite_device_deviceVariantId ON favorite_device(deviceVariantId)")
            }
        }

        private val MIGRATION_8_9 = object : Migration(8, 9) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("CREATE TABLE IF NOT EXISTS diagnostic_run (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, profileId INTEGER NOT NULL, executedAt INTEGER NOT NULL, databaseVersion TEXT NOT NULL, requirementSnapshot TEXT NOT NULL, recommendedDeviceIds TEXT NOT NULL, excludedDeviceIds TEXT NOT NULL)")
            }
        }

        private val MIGRATION_9_10 = object : Migration(9, 10) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("CREATE TABLE IF NOT EXISTS diagnostic_draft (id INTEGER NOT NULL PRIMARY KEY, payload TEXT NOT NULL, updatedAt INTEGER NOT NULL)")
            }
        }

        private val MIGRATION_10_11 = object : Migration(10, 11) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("CREATE TABLE IF NOT EXISTS data_source (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, name TEXT NOT NULL, sourceType TEXT NOT NULL, url TEXT, isOfficial INTEGER NOT NULL, isActive INTEGER NOT NULL)")
                db.execSQL("ALTER TABLE price_record ADD COLUMN sourceId INTEGER")
            }
        }

        private val MIGRATION_11_12 = object : Migration(11, 12) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("CREATE TABLE IF NOT EXISTS data_conflict (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, deviceVariantId INTEGER NOT NULL, fieldKey TEXT NOT NULL, fieldLabel TEXT NOT NULL, valuesSummary TEXT NOT NULL, sourcesSummary TEXT NOT NULL, severity TEXT NOT NULL, detectedAt INTEGER NOT NULL, isResolved INTEGER NOT NULL)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_data_conflict_deviceVariantId_fieldKey_detectedAt ON data_conflict(deviceVariantId, fieldKey, detectedAt)")
            }
        }

        private val MIGRATION_12_13 = object : Migration(12, 13) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("CREATE TABLE IF NOT EXISTS phone_series (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, manufacturerId INTEGER NOT NULL, name TEXT NOT NULL, officialWebsiteUrl TEXT, isActive INTEGER NOT NULL)")
                db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_phone_series_manufacturerId_name ON phone_series(manufacturerId, name)")
                db.execSQL("INSERT OR IGNORE INTO phone_series(manufacturerId, name, officialWebsiteUrl, isActive) SELECT manufacturerId, seriesName, NULL, 1 FROM smartphone_model WHERE seriesName IS NOT NULL AND TRIM(seriesName) <> ''")
                db.execSQL("ALTER TABLE smartphone_model ADD COLUMN seriesId INTEGER")
                db.execSQL("UPDATE smartphone_model SET seriesId = (SELECT ps.id FROM phone_series ps WHERE ps.manufacturerId = smartphone_model.manufacturerId AND ps.name = smartphone_model.seriesName LIMIT 1) WHERE seriesName IS NOT NULL")
                db.execSQL("CREATE TABLE IF NOT EXISTS data_change_log (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, deviceVariantId INTEGER, entityType TEXT NOT NULL, fieldKey TEXT NOT NULL, fieldLabel TEXT NOT NULL, oldValue TEXT, newValue TEXT, sourceId INTEGER, reason TEXT, changedAt INTEGER NOT NULL, status TEXT NOT NULL)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_data_change_log_deviceVariantId_changedAt ON data_change_log(deviceVariantId, changedAt)")
            }
        }

        private val MIGRATION_13_14 = object : Migration(13, 14) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE price_record_v2 ADD COLUMN color TEXT")
                db.execSQL("ALTER TABLE price_record_v2 ADD COLUMN sourceUrl TEXT")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_price_record_v2_productListingId_priceType_color_checkedAt ON price_record_v2(productListingId, priceType, color, checkedAt)")
            }
        }

        @Volatile private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "smartphone_advisor.db"
                )
                    .addMigrations(MIGRATION_1_2, MIGRATION_2_3, MIGRATION_3_4, MIGRATION_4_5, MIGRATION_5_6, MIGRATION_6_7, MIGRATION_7_8, MIGRATION_8_9, MIGRATION_9_10, MIGRATION_10_11, MIGRATION_11_12, MIGRATION_12_13, MIGRATION_13_14)
                    .build().also { INSTANCE = it }
            }
    }
}
