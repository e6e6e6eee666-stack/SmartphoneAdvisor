package jp.smartphoneadvisor.app.data

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/** Stable series master. Series is an entity so future models can be added without changing code. */
@Entity(
    tableName = "phone_series",
    indices = [Index(value = ["manufacturerId", "name"], unique = true)]
)
data class PhoneSeriesEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val manufacturerId: Long,
    val name: String,
    val officialWebsiteUrl: String? = null,
    val isActive: Boolean = true
)

@Entity(
    tableName = "data_conflict",
    indices = [Index(value = ["deviceVariantId", "fieldKey", "detectedAt"])]
)
data class DataConflictEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val deviceVariantId: Long,
    val fieldKey: String,
    val fieldLabel: String,
    val valuesSummary: String,
    val sourcesSummary: String,
    val severity: ConflictSeverity,
    val detectedAt: Long,
    val isResolved: Boolean = false
)

@Entity(
    tableName = "data_change_log",
    indices = [Index(value = ["deviceVariantId", "changedAt"])]
)
data class DataChangeLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val deviceVariantId: Long?,
    val entityType: String,
    val fieldKey: String,
    val fieldLabel: String,
    val oldValue: String?,
    val newValue: String?,
    val sourceId: Long?,
    val reason: String?,
    val changedAt: Long,
    val status: String = "RECORDED"
)
