package jp.smartphoneadvisor.app.data

import androidx.room.withTransaction

/**
 * 0.2.52: 日本の主要キャリア公式販売ページで確認した「販売チャネル」情報。
 * 価格は別管理。MNP・返却等の条件価格を通常価格へ混ぜない。
 */
object CarrierCatalogSeed {
    private const val checkedAt = 1791072000000L // 2026-10-04

    private data class Entry(
        val model: String,
        val manufacturer: String,
        val series: String?,
        val year: Int,
        val platform: String = "ANDROID",
        val storageGb: Int,
        val channel: SalesChannel,
        val retailer: String,
        val url: String,
        val modelNumber: String? = null,
        val availability: AvailabilityStatus = AvailabilityStatus.AVAILABLE,
        val ramGb: Int? = null
    )

    private val entries = listOf(
        // docomo 2026 official lineup (verified against official model/support lists)
        Entry("Galaxy S26", "Samsung", "Galaxy S", 2026, storageGb = 256, channel = SalesChannel.DOCOMO, retailer = "NTTドコモ", url = "https://www.docomo.ne.jp/product/sc51g/", modelNumber = "SC-51G", ramGb = 12),
        // 0.01.04.13 official docomo capacity audit: Galaxy S26 512GB / 12GB.
        Entry("Galaxy S26", "Samsung", "Galaxy S", 2026, storageGb = 512, channel = SalesChannel.DOCOMO, retailer = "NTTドコモ", url = "https://www.docomo.ne.jp/product/sc51g/", modelNumber = "SC-51G", ramGb = 12),
        Entry("Galaxy S26+", "Samsung", "Galaxy S", 2026, storageGb = 256, channel = SalesChannel.DOCOMO, retailer = "NTTドコモ", url = "https://www.docomo.ne.jp/product/sc52g/", modelNumber = "SC-52G", ramGb = 12),
        Entry("Galaxy S26+", "Samsung", "Galaxy S", 2026, storageGb = 512, channel = SalesChannel.DOCOMO, retailer = "NTTドコモ", url = "https://www.docomo.ne.jp/product/sc52g/", modelNumber = "SC-52G", ramGb = 12),
        Entry("Galaxy S26 Ultra", "Samsung", "Galaxy S", 2026, storageGb = 256, channel = SalesChannel.DOCOMO, retailer = "NTTドコモ", url = "https://www.docomo.ne.jp/product/sc53g/", modelNumber = "SC-53G", ramGb = 12),
        Entry("Galaxy S26 Ultra", "Samsung", "Galaxy S", 2026, storageGb = 512, channel = SalesChannel.DOCOMO, retailer = "NTTドコモ", url = "https://www.docomo.ne.jp/product/sc53g/", modelNumber = "SC-53G", ramGb = 12),
        Entry("Galaxy S26 Ultra", "Samsung", "Galaxy S", 2026, storageGb = 1024, channel = SalesChannel.DOCOMO, retailer = "NTTドコモ", url = "https://www.docomo.ne.jp/product/sc53g/", modelNumber = "SC-53G", ramGb = 16),
        Entry("Galaxy A57 5G", "Samsung", "Galaxy A", 2026, storageGb = 128, channel = SalesChannel.DOCOMO, retailer = "NTTドコモ", url = "https://www.docomo.ne.jp/product/sc54g/", modelNumber = "SC-54G", ramGb = 8),
        Entry("Galaxy Z Flip8", "Samsung", "Galaxy Z", 2026, storageGb = 256, channel = SalesChannel.DOCOMO, retailer = "NTTドコモ", url = "https://www.docomo.ne.jp/product/sc55g/", modelNumber = "SC-55G", ramGb = 12),
        Entry("Galaxy Z Flip8", "Samsung", "Galaxy Z", 2026, storageGb = 512, channel = SalesChannel.DOCOMO, retailer = "NTTドコモ", url = "https://www.docomo.ne.jp/product/sc55g/", modelNumber = "SC-55G", ramGb = 12),
        Entry("Galaxy Z Fold8 Ultra", "Samsung", "Galaxy Z", 2026, storageGb = 256, channel = SalesChannel.DOCOMO, retailer = "NTTドコモ", url = "https://www.docomo.ne.jp/product/sc56g/", modelNumber = "SC-56G", ramGb = 12),
        Entry("Galaxy Z Fold8 Ultra", "Samsung", "Galaxy Z", 2026, storageGb = 512, channel = SalesChannel.DOCOMO, retailer = "NTTドコモ", url = "https://www.docomo.ne.jp/product/sc56g/", modelNumber = "SC-56G", ramGb = 12),
        Entry("Galaxy Z Fold8 Ultra", "Samsung", "Galaxy Z", 2026, storageGb = 1024, channel = SalesChannel.DOCOMO, retailer = "NTTドコモ", url = "https://www.docomo.ne.jp/product/sc56g/", modelNumber = "SC-56G", ramGb = 16),
        Entry("Galaxy Z Fold8", "Samsung", "Galaxy Z", 2026, storageGb = 256, channel = SalesChannel.DOCOMO, retailer = "NTTドコモ", url = "https://www.docomo.ne.jp/product/sc57g/", modelNumber = "SC-57G", ramGb = 12),
        Entry("Galaxy Z Fold8", "Samsung", "Galaxy Z", 2026, storageGb = 512, channel = SalesChannel.DOCOMO, retailer = "NTTドコモ", url = "https://www.docomo.ne.jp/product/sc57g/", modelNumber = "SC-57G", ramGb = 12),
        Entry("arrows Alpha2", "FCNT", "arrows", 2026, storageGb = 256, channel = SalesChannel.DOCOMO, retailer = "NTTドコモ", url = "https://www.docomo.ne.jp/product/f51g/", modelNumber = "F-51G", ramGb = 8),
        Entry("arrows Alpha2", "FCNT", "arrows", 2026, storageGb = 512, channel = SalesChannel.DOCOMO, retailer = "NTTドコモ", url = "https://www.docomo.ne.jp/product/f51g/", modelNumber = "F-51G", ramGb = 12),
        Entry("moto g37", "Motorola", "moto g", 2026, storageGb = 128, channel = SalesChannel.DOCOMO, retailer = "NTTドコモ", url = "https://www.docomo.ne.jp/product/m51g/", modelNumber = "M-51G", availability = AvailabilityStatus.PREORDER, ramGb = 8),
        Entry("arrows We3", "FCNT", "arrows", 2026, storageGb = 64, channel = SalesChannel.DOCOMO, retailer = "NTTドコモ", url = "https://www.docomo.ne.jp/product/f52g/", modelNumber = "F-52G", ramGb = 4),
        Entry("AQUOS R11", "SHARP", "AQUOS R", 2026, storageGb = 256, channel = SalesChannel.DOCOMO, retailer = "NTTドコモ", url = "https://www.docomo.ne.jp/product/sh51g/", modelNumber = "SH-51G", ramGb = 12),
        Entry("Xperia 1 VIII", "Sony", "Xperia", 2026, storageGb = 256, channel = SalesChannel.DOCOMO, retailer = "NTTドコモ", url = "https://www.docomo.ne.jp/product/so51g/", modelNumber = "SO-51G", ramGb = 12),
        // 0.01.04.30 official reverse-audit: すみっコぐらしスマホ was a 2024-03-08 SoftBank online-shop limited release (3,000 units);
        // SoftBank later stopped online-shop/store-receipt sales, so retain the historical sales channel as DISCONTINUED.
        // Core catalog confirms 128GB / 4GB RAM. Model number is intentionally left unset because no primary SoftBank source
        // located in this audit exposed a distinct model number for the collaboration variant.
        Entry("すみっコぐらしスマホ", "ZTE", "あんしんファミリースマホ", 2024, storageGb = 128, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/mobile/support/product/sumikkogurashi-sumaho/", availability = AvailabilityStatus.DISCONTINUED, ramGb = 4),

        // 2026-10-01 official reverse-audit: Xperia 10 VIII SO-52G is reservable for 2026-10-08 launch.
        Entry("Xperia 10 VIII", "Sony", "Xperia", 2026, storageGb = 128, channel = SalesChannel.DOCOMO, retailer = "NTTドコモ", url = "https://www.docomo.ne.jp/product/so52g/", modelNumber = "SO-52G", availability = AvailabilityStatus.PREORDER, ramGb = 8),

        // docomo 2026 Apple lineup: iPhone 18 Pro / Pro Max launched 2026-09-18.
        // Storage variants are kept separately because the app selects storage after model selection.
        Entry("iPhone 18 Pro", "Apple", "iPhone", 2026, platform = "IPHONE", storageGb = 256, channel = SalesChannel.DOCOMO, retailer = "NTTドコモ", url = "https://www.docomo.ne.jp/product/iphone18pro/"),
        Entry("iPhone 18 Pro", "Apple", "iPhone", 2026, platform = "IPHONE", storageGb = 512, channel = SalesChannel.DOCOMO, retailer = "NTTドコモ", url = "https://www.docomo.ne.jp/product/iphone18pro/"),
        Entry("iPhone 18 Pro", "Apple", "iPhone", 2026, platform = "IPHONE", storageGb = 1024, channel = SalesChannel.DOCOMO, retailer = "NTTドコモ", url = "https://www.docomo.ne.jp/product/iphone18pro/"),
        Entry("iPhone 18 Pro", "Apple", "iPhone", 2026, platform = "IPHONE", storageGb = 2048, channel = SalesChannel.DOCOMO, retailer = "NTTドコモ", url = "https://www.docomo.ne.jp/product/iphone18pro/"),
        Entry("iPhone 18 Pro Max", "Apple", "iPhone", 2026, platform = "IPHONE", storageGb = 256, channel = SalesChannel.DOCOMO, retailer = "NTTドコモ", url = "https://www.docomo.ne.jp/product/iphone18promax/"),
        Entry("iPhone 18 Pro Max", "Apple", "iPhone", 2026, platform = "IPHONE", storageGb = 512, channel = SalesChannel.DOCOMO, retailer = "NTTドコモ", url = "https://www.docomo.ne.jp/product/iphone18promax/"),
        Entry("iPhone 18 Pro Max", "Apple", "iPhone", 2026, platform = "IPHONE", storageGb = 1024, channel = SalesChannel.DOCOMO, retailer = "NTTドコモ", url = "https://www.docomo.ne.jp/product/iphone18promax/"),
        Entry("iPhone 18 Pro Max", "Apple", "iPhone", 2026, platform = "IPHONE", storageGb = 2048, channel = SalesChannel.DOCOMO, retailer = "NTTドコモ", url = "https://www.docomo.ne.jp/product/iphone18promax/"),

        // 0.01.03 official reverse-audit: docomo currently sells the 2025 iPhone family.
        Entry("iPhone 17e", "Apple", "iPhone", 2026, platform = "IPHONE", storageGb = 256, channel = SalesChannel.DOCOMO, retailer = "NTTドコモ", url = "https://www.docomo.ne.jp/product/iphone17e/"),
        Entry("iPhone 17e", "Apple", "iPhone", 2026, platform = "IPHONE", storageGb = 512, channel = SalesChannel.DOCOMO, retailer = "NTTドコモ", url = "https://www.docomo.ne.jp/product/iphone17e/"),
        Entry("iPhone 17 Pro", "Apple", "iPhone", 2025, platform = "IPHONE", storageGb = 256, channel = SalesChannel.DOCOMO, retailer = "NTTドコモ", url = "https://www.docomo.ne.jp/product/iphone17pro/"),
        Entry("iPhone 17 Pro", "Apple", "iPhone", 2025, platform = "IPHONE", storageGb = 512, channel = SalesChannel.DOCOMO, retailer = "NTTドコモ", url = "https://www.docomo.ne.jp/product/iphone17pro/"),
        Entry("iPhone 17 Pro", "Apple", "iPhone", 2025, platform = "IPHONE", storageGb = 1024, channel = SalesChannel.DOCOMO, retailer = "NTTドコモ", url = "https://www.docomo.ne.jp/product/iphone17pro/"),
        Entry("iPhone 17 Pro Max", "Apple", "iPhone", 2025, platform = "IPHONE", storageGb = 256, channel = SalesChannel.DOCOMO, retailer = "NTTドコモ", url = "https://www.docomo.ne.jp/product/iphone17promax/"),
        Entry("iPhone 17 Pro Max", "Apple", "iPhone", 2025, platform = "IPHONE", storageGb = 512, channel = SalesChannel.DOCOMO, retailer = "NTTドコモ", url = "https://www.docomo.ne.jp/product/iphone17promax/"),
        Entry("iPhone 17 Pro Max", "Apple", "iPhone", 2025, platform = "IPHONE", storageGb = 2048, channel = SalesChannel.DOCOMO, retailer = "NTTドコモ", url = "https://www.docomo.ne.jp/product/iphone17promax/"),
        Entry("iPhone Air", "Apple", "iPhone", 2025, platform = "IPHONE", storageGb = 256, channel = SalesChannel.DOCOMO, retailer = "NTTドコモ", url = "https://www.docomo.ne.jp/product/iphone-air/"),
        Entry("iPhone Air", "Apple", "iPhone", 2025, platform = "IPHONE", storageGb = 512, channel = SalesChannel.DOCOMO, retailer = "NTTドコモ", url = "https://www.docomo.ne.jp/product/iphone-air/"),
        Entry("iPhone Air", "Apple", "iPhone", 2025, platform = "IPHONE", storageGb = 1024, channel = SalesChannel.DOCOMO, retailer = "NTTドコモ", url = "https://www.docomo.ne.jp/product/iphone-air/"),
        Entry("iPhone 17", "Apple", "iPhone", 2025, platform = "IPHONE", storageGb = 256, channel = SalesChannel.DOCOMO, retailer = "NTTドコモ", url = "https://www.docomo.ne.jp/product/iphone17/"),
        Entry("iPhone 17", "Apple", "iPhone", 2025, platform = "IPHONE", storageGb = 512, channel = SalesChannel.DOCOMO, retailer = "NTTドコモ", url = "https://www.docomo.ne.jp/product/iphone17/"),

        // docomo 2026 Pixel 11 series: official product pages confirm current sale.
        // SoftBank 2024 Google Pixel lineup: official current Pixel product/price materials confirm these variants.
        Entry("Pixel 8a", "Google", "Pixel", 2024, storageGb = 128, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/mobile/products/google-pixel/google-pixel-8a/", ramGb = 8, availability = AvailabilityStatus.AVAILABLE),
        Entry("Pixel 9", "Google", "Pixel", 2024, storageGb = 128, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/mobile/products/google-pixel/google-pixel-9/", ramGb = 12, availability = AvailabilityStatus.AVAILABLE),
        Entry("Pixel 9", "Google", "Pixel", 2024, storageGb = 256, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/mobile/products/google-pixel/google-pixel-9/", ramGb = 12, availability = AvailabilityStatus.AVAILABLE),
        Entry("Pixel 9 Pro", "Google", "Pixel", 2024, storageGb = 128, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/mobile/products/google-pixel/google-pixel-9-pro/", ramGb = 16, availability = AvailabilityStatus.AVAILABLE),
        Entry("Pixel 9 Pro", "Google", "Pixel", 2024, storageGb = 256, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/mobile/products/google-pixel/google-pixel-9-pro/", ramGb = 16, availability = AvailabilityStatus.AVAILABLE),
        Entry("Pixel 9 Pro", "Google", "Pixel", 2024, storageGb = 512, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/mobile/products/google-pixel/google-pixel-9-pro/", ramGb = 16, availability = AvailabilityStatus.AVAILABLE),
        Entry("Pixel 9 Pro XL", "Google", "Pixel", 2024, storageGb = 128, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/mobile/products/google-pixel/google-pixel-9-pro/", ramGb = 16, availability = AvailabilityStatus.AVAILABLE),
        Entry("Pixel 9 Pro XL", "Google", "Pixel", 2024, storageGb = 256, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/mobile/products/google-pixel/google-pixel-9-pro/", ramGb = 16, availability = AvailabilityStatus.AVAILABLE),
        Entry("Pixel 9 Pro XL", "Google", "Pixel", 2024, storageGb = 512, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/mobile/products/google-pixel/google-pixel-9-pro/", ramGb = 16, availability = AvailabilityStatus.AVAILABLE),
        Entry("Pixel 9 Pro Fold", "Google", "Pixel", 2024, storageGb = 256, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/mobile/products/google-pixel/google-pixel-9-pro-fold/", ramGb = 16, availability = AvailabilityStatus.AVAILABLE),
        Entry("Pixel 9 Pro Fold", "Google", "Pixel", 2024, storageGb = 512, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/mobile/products/google-pixel/google-pixel-9-pro-fold/", ramGb = 16, availability = AvailabilityStatus.AVAILABLE),
        Entry("Pixel 11", "Google", "Pixel", 2026, storageGb = 256, channel = SalesChannel.DOCOMO, retailer = "NTTドコモ", url = "https://www.docomo.ne.jp/product/pixel11/", ramGb = 12),
        Entry("Pixel 11", "Google", "Pixel", 2026, storageGb = 512, channel = SalesChannel.DOCOMO, retailer = "NTTドコモ", url = "https://www.docomo.ne.jp/product/pixel11/", ramGb = 12),
        Entry("Pixel 11 Pro", "Google", "Pixel", 2026, storageGb = 256, channel = SalesChannel.DOCOMO, retailer = "NTTドコモ", url = "https://www.docomo.ne.jp/product/pixel11pro/", ramGb = 12),
        Entry("Pixel 11 Pro XL", "Google", "Pixel", 2026, storageGb = 256, channel = SalesChannel.DOCOMO, retailer = "NTTドコモ", url = "https://www.docomo.ne.jp/product/pixel11proxl/", ramGb = 12),
        Entry("Pixel 11 Pro Fold", "Google", "Pixel", 2026, storageGb = 256, channel = SalesChannel.DOCOMO, retailer = "NTTドコモ", url = "https://www.docomo.ne.jp/product/pixel11profold/", ramGb = 16),

        // 2026-09-30 official reverse-audit: Google Pixel 10a is currently sold by docomo in 128GB/256GB.
        Entry("Google Pixel 10a", "Google", "Pixel", 2026, storageGb = 128, channel = SalesChannel.DOCOMO, retailer = "NTTドコモ", url = "https://www.docomo.ne.jp/product/pixel10a/", ramGb = 8),
        Entry("Google Pixel 10a", "Google", "Pixel", 2026, storageGb = 256, channel = SalesChannel.DOCOMO, retailer = "NTTドコモ", url = "https://www.docomo.ne.jp/product/pixel10a/", ramGb = 8),
        Entry("Pixel 11 Pro", "Google", "Pixel", 2026, storageGb = 512, channel = SalesChannel.DOCOMO, retailer = "NTTドコモ", url = "https://www.docomo.ne.jp/product/pixel11pro/", ramGb = 16),
        Entry("Pixel 11 Pro XL", "Google", "Pixel", 2026, storageGb = 512, channel = SalesChannel.DOCOMO, retailer = "NTTドコモ", url = "https://www.docomo.ne.jp/product/pixel11proxl/", ramGb = 16),
        Entry("Pixel 11 Pro Fold", "Google", "Pixel", 2026, storageGb = 512, channel = SalesChannel.DOCOMO, retailer = "NTTドコモ", url = "https://www.docomo.ne.jp/product/pixel11profold/", ramGb = 16),

        // docomo 2025 models still listed as on sale on the official product catalog.
        Entry("arrows Alpha", "FCNT", "arrows", 2025, storageGb = 256, channel = SalesChannel.DOCOMO, retailer = "NTTドコモ", url = "https://www.docomo.ne.jp/product/f51f/", modelNumber = "F-51F", ramGb = 12),
        Entry("motorola razr 60d", "Motorola", "razr", 2025, storageGb = 256, channel = SalesChannel.DOCOMO, retailer = "NTTドコモ", url = "https://www.docomo.ne.jp/product/m51f/", modelNumber = "M-51F", ramGb = 8),
        Entry("Galaxy S25", "Samsung", "Galaxy S", 2025, storageGb = 256, channel = SalesChannel.DOCOMO, retailer = "NTTドコモ", url = "https://www.docomo.ne.jp/product/sc51f/", modelNumber = "SC-51F", ramGb = 12),
        Entry("Galaxy S25", "Samsung", "Galaxy S", 2025, storageGb = 512, channel = SalesChannel.DOCOMO, retailer = "NTTドコモ", url = "https://www.docomo.ne.jp/product/sc51f/", modelNumber = "SC-51F", ramGb = 12),
        Entry("Galaxy S25 Ultra", "Samsung", "Galaxy S", 2025, storageGb = 256, channel = SalesChannel.DOCOMO, retailer = "NTTドコモ", url = "https://www.docomo.ne.jp/product/sc52f/", modelNumber = "SC-52F", ramGb = 12),
        Entry("Galaxy S25 Ultra", "Samsung", "Galaxy S", 2025, storageGb = 512, channel = SalesChannel.DOCOMO, retailer = "NTTドコモ", url = "https://www.docomo.ne.jp/product/sc52f/", modelNumber = "SC-52F", ramGb = 12),
        Entry("Galaxy S25 Ultra", "Samsung", "Galaxy S", 2025, storageGb = 1024, channel = SalesChannel.DOCOMO, retailer = "NTTドコモ", url = "https://www.docomo.ne.jp/product/sc52f/", modelNumber = "SC-52F", ramGb = 12),
        Entry("Galaxy A25 5G", "Samsung", "Galaxy A", 2025, storageGb = 64, channel = SalesChannel.DOCOMO, retailer = "NTTドコモ", url = "https://www.docomo.ne.jp/product/sc53f/", modelNumber = "SC-53F", ramGb = 4),
        Entry("Galaxy A36 5G", "Samsung", "Galaxy A", 2025, storageGb = 128, channel = SalesChannel.DOCOMO, retailer = "NTTドコモ", url = "https://www.docomo.ne.jp/product/sc54f/", modelNumber = "SC-54F", ramGb = 6),
        Entry("Galaxy Z Flip7", "Samsung", "Galaxy Z", 2025, storageGb = 256, channel = SalesChannel.DOCOMO, retailer = "NTTドコモ", url = "https://www.docomo.ne.jp/product/sc55f/", modelNumber = "SC-55F", ramGb = 12),
        Entry("Galaxy Z Flip7", "Samsung", "Galaxy Z", 2025, storageGb = 512, channel = SalesChannel.DOCOMO, retailer = "NTTドコモ", url = "https://www.docomo.ne.jp/product/sc55f/", modelNumber = "SC-55F", ramGb = 12),
        Entry("Galaxy Z Fold7", "Samsung", "Galaxy Z", 2025, storageGb = 256, channel = SalesChannel.DOCOMO, retailer = "NTTドコモ", url = "https://www.docomo.ne.jp/product/sc56f/", modelNumber = "SC-56F", ramGb = 12),
        Entry("Galaxy Z Fold7", "Samsung", "Galaxy Z", 2025, storageGb = 512, channel = SalesChannel.DOCOMO, retailer = "NTTドコモ", url = "https://www.docomo.ne.jp/product/sc56f/", modelNumber = "SC-56F", ramGb = 12),
        Entry("Galaxy Z Fold7", "Samsung", "Galaxy Z", 2025, storageGb = 1024, channel = SalesChannel.DOCOMO, retailer = "NTTドコモ", url = "https://www.docomo.ne.jp/product/sc56f/", modelNumber = "SC-56F", ramGb = 16),
        Entry("AQUOS R10", "SHARP", "AQUOS R", 2025, storageGb = 256, channel = SalesChannel.DOCOMO, retailer = "NTTドコモ", url = "https://www.docomo.ne.jp/product/sh51f/", modelNumber = "SH-51F", ramGb = 12),
        Entry("AQUOS wish5", "SHARP", "AQUOS wish", 2025, storageGb = 128, channel = SalesChannel.DOCOMO, retailer = "NTTドコモ", url = "https://www.docomo.ne.jp/product/sh52f/", modelNumber = "SH-52F", ramGb = 4),
        Entry("AQUOS sense10", "SHARP", "AQUOS sense", 2025, storageGb = 128, channel = SalesChannel.DOCOMO, retailer = "NTTドコモ", url = "https://www.docomo.ne.jp/product/sh53f/", modelNumber = "SH-53F", ramGb = 6),
        Entry("Xperia 1 VII", "Sony", "Xperia", 2025, storageGb = 256, channel = SalesChannel.DOCOMO, retailer = "NTTドコモ", url = "https://www.docomo.ne.jp/product/so51f/", modelNumber = "SO-51F", ramGb = 12),
        Entry("Xperia 10 VII", "Sony", "Xperia", 2025, storageGb = 128, channel = SalesChannel.DOCOMO, retailer = "NTTドコモ", url = "https://www.docomo.ne.jp/product/so52f/", modelNumber = "SO-52F", ramGb = 8),

        // au 2026 Apple lineup: iPhone 18 Pro / Pro Max launched 2026-09-18.
        Entry("iPhone 18 Pro", "Apple", "iPhone", 2026, platform = "IPHONE", storageGb = 256, channel = SalesChannel.AU, retailer = "au", url = "https://www.au.com/iphone/product/iphone-18-pro/"),
        Entry("iPhone 18 Pro", "Apple", "iPhone", 2026, platform = "IPHONE", storageGb = 512, channel = SalesChannel.AU, retailer = "au", url = "https://www.au.com/iphone/product/iphone-18-pro/"),
        Entry("iPhone 18 Pro", "Apple", "iPhone", 2026, platform = "IPHONE", storageGb = 1024, channel = SalesChannel.AU, retailer = "au", url = "https://www.au.com/iphone/product/iphone-18-pro/"),
        Entry("iPhone 18 Pro", "Apple", "iPhone", 2026, platform = "IPHONE", storageGb = 2048, channel = SalesChannel.AU, retailer = "au", url = "https://www.au.com/iphone/product/iphone-18-pro/"),
        Entry("iPhone 18 Pro Max", "Apple", "iPhone", 2026, platform = "IPHONE", storageGb = 256, channel = SalesChannel.AU, retailer = "au", url = "https://www.au.com/iphone/product/iphone-18-pro/"),
        Entry("iPhone 18 Pro Max", "Apple", "iPhone", 2026, platform = "IPHONE", storageGb = 512, channel = SalesChannel.AU, retailer = "au", url = "https://www.au.com/iphone/product/iphone-18-pro/"),
        Entry("iPhone 18 Pro Max", "Apple", "iPhone", 2026, platform = "IPHONE", storageGb = 1024, channel = SalesChannel.AU, retailer = "au", url = "https://www.au.com/iphone/product/iphone-18-pro/"),
        Entry("iPhone 18 Pro Max", "Apple", "iPhone", 2026, platform = "IPHONE", storageGb = 2048, channel = SalesChannel.AU, retailer = "au", url = "https://www.au.com/iphone/product/iphone-18-pro/"),

        // 0.01.03 official reverse-audit: au currently sells the 2025 iPhone family.
        Entry("iPhone 17", "Apple", "iPhone", 2025, platform = "IPHONE", storageGb = 256, channel = SalesChannel.AU, retailer = "au", url = "https://www.au.com/iphone/product/iphone-17/"),
        Entry("iPhone 17", "Apple", "iPhone", 2025, platform = "IPHONE", storageGb = 512, channel = SalesChannel.AU, retailer = "au", url = "https://www.au.com/iphone/product/iphone-17/"),
        Entry("iPhone 17e", "Apple", "iPhone", 2026, platform = "IPHONE", storageGb = 256, channel = SalesChannel.AU, retailer = "au", url = "https://www.au.com/iphone/product/iphone-17e/"),
        Entry("iPhone 17e", "Apple", "iPhone", 2026, platform = "IPHONE", storageGb = 512, channel = SalesChannel.AU, retailer = "au", url = "https://www.au.com/iphone/product/iphone-17e/"),
        Entry("iPhone Air", "Apple", "iPhone", 2025, platform = "IPHONE", storageGb = 256, channel = SalesChannel.AU, retailer = "au", url = "https://www.au.com/iphone/product/iphone-air/"),
        Entry("iPhone Air", "Apple", "iPhone", 2025, platform = "IPHONE", storageGb = 512, channel = SalesChannel.AU, retailer = "au", url = "https://www.au.com/iphone/product/iphone-air/"),
        Entry("iPhone Air", "Apple", "iPhone", 2025, platform = "IPHONE", storageGb = 1024, channel = SalesChannel.AU, retailer = "au", url = "https://www.au.com/iphone/product/iphone-air/"),
        Entry("iPhone 17 Pro", "Apple", "iPhone", 2025, platform = "IPHONE", storageGb = 256, channel = SalesChannel.AU, retailer = "au", url = "https://www.au.com/iphone/product/iphone-17-pro/"),
        Entry("iPhone 17 Pro", "Apple", "iPhone", 2025, platform = "IPHONE", storageGb = 512, channel = SalesChannel.AU, retailer = "au", url = "https://www.au.com/iphone/product/iphone-17-pro/"),
        Entry("iPhone 17 Pro", "Apple", "iPhone", 2025, platform = "IPHONE", storageGb = 1024, channel = SalesChannel.AU, retailer = "au", url = "https://www.au.com/iphone/product/iphone-17-pro/"),
        Entry("iPhone 17 Pro Max", "Apple", "iPhone", 2025, platform = "IPHONE", storageGb = 256, channel = SalesChannel.AU, retailer = "au", url = "https://www.au.com/iphone/product/iphone-17-pro-max/"),
        Entry("iPhone 17 Pro Max", "Apple", "iPhone", 2025, platform = "IPHONE", storageGb = 512, channel = SalesChannel.AU, retailer = "au", url = "https://www.au.com/iphone/product/iphone-17-pro-max/"),
        Entry("iPhone 17 Pro Max", "Apple", "iPhone", 2025, platform = "IPHONE", storageGb = 1024, channel = SalesChannel.AU, retailer = "au", url = "https://www.au.com/iphone/product/iphone-17-pro-max/"),
        Entry("iPhone 17 Pro Max", "Apple", "iPhone", 2025, platform = "IPHONE", storageGb = 2048, channel = SalesChannel.AU, retailer = "au", url = "https://www.au.com/iphone/product/iphone-17-pro-max/"),

        // au official product catalog: current 2026 lineup. Capacities/RAM verified against official product pages on 2026-10-04.
        Entry("Pixel 11", "Google", "Pixel", 2026, storageGb = 256, channel = SalesChannel.AU, retailer = "au", url = "https://www.au.com/mobile/product/smartphone/pixel11/", ramGb = 12),
        Entry("Pixel 11", "Google", "Pixel", 2026, storageGb = 512, channel = SalesChannel.AU, retailer = "au", url = "https://www.au.com/mobile/product/smartphone/pixel11/", ramGb = 12),
        Entry("Pixel 11 Pro", "Google", "Pixel", 2026, storageGb = 256, channel = SalesChannel.AU, retailer = "au", url = "https://www.au.com/mobile/product/smartphone/pixel11p/", ramGb = 12),
        Entry("Pixel 11 Pro XL", "Google", "Pixel", 2026, storageGb = 256, channel = SalesChannel.AU, retailer = "au", url = "https://www.au.com/mobile/product/smartphone/pixel11p_xl/", ramGb = 12),
        Entry("Galaxy S26", "Samsung", "Galaxy S", 2026, storageGb = 256, channel = SalesChannel.AU, retailer = "au", url = "https://www.au.com/mobile/product/smartphone/galaxy_s26/", ramGb = 12),
        Entry("Galaxy S26", "Samsung", "Galaxy S", 2026, storageGb = 512, channel = SalesChannel.AU, retailer = "au", url = "https://www.au.com/mobile/product/smartphone/galaxy_s26/", ramGb = 12),
        Entry("Galaxy S26+", "Samsung", "Galaxy S", 2026, storageGb = 256, channel = SalesChannel.AU, retailer = "au", url = "https://www.au.com/mobile/product/smartphone/galaxy_s26plus/", ramGb = 12),
        Entry("Galaxy S26 Ultra", "Samsung", "Galaxy S", 2026, storageGb = 256, channel = SalesChannel.AU, retailer = "au", url = "https://www.au.com/mobile/product/smartphone/galaxy_s26ultra/", ramGb = 12),
        Entry("Galaxy S26 Ultra", "Samsung", "Galaxy S", 2026, storageGb = 512, channel = SalesChannel.AU, retailer = "au", url = "https://www.au.com/mobile/product/smartphone/galaxy_s26ultra/", ramGb = 12, availability = AvailabilityStatus.OUT_OF_STOCK),
        Entry("Galaxy S26 Ultra", "Samsung", "Galaxy S", 2026, storageGb = 1024, channel = SalesChannel.AU, retailer = "au", url = "https://www.au.com/mobile/product/smartphone/galaxy_s26ultra/", ramGb = 16, availability = AvailabilityStatus.OUT_OF_STOCK),
        Entry("Galaxy Z Fold8 Ultra", "Samsung", "Galaxy Z", 2026, storageGb = 256, channel = SalesChannel.AU, retailer = "au", url = "https://www.au.com/mobile/product/smartphone/galaxy_z_fold8_ultra/", ramGb = 12),
        Entry("Galaxy Z Fold8 Ultra", "Samsung", "Galaxy Z", 2026, storageGb = 512, channel = SalesChannel.AU, retailer = "au", url = "https://www.au.com/mobile/product/smartphone/galaxy_z_fold8_ultra/", ramGb = 12),
        Entry("Galaxy Z Fold8 Ultra", "Samsung", "Galaxy Z", 2026, storageGb = 1024, channel = SalesChannel.AU, retailer = "au", url = "https://www.au.com/mobile/product/smartphone/galaxy_z_fold8_ultra/", ramGb = 16),
        Entry("Galaxy Z Fold8", "Samsung", "Galaxy Z", 2026, storageGb = 256, channel = SalesChannel.AU, retailer = "au", url = "https://www.au.com/mobile/product/smartphone/galaxy_z_fold8/", ramGb = 12),
        Entry("Galaxy Z Fold8", "Samsung", "Galaxy Z", 2026, storageGb = 512, channel = SalesChannel.AU, retailer = "au", url = "https://www.au.com/mobile/product/smartphone/galaxy_z_fold8/", ramGb = 12),
        Entry("Galaxy Z Fold8", "Samsung", "Galaxy Z", 2026, storageGb = 1024, channel = SalesChannel.AU, retailer = "au", url = "https://www.au.com/mobile/product/smartphone/galaxy_z_fold8/", ramGb = 16),
        Entry("Galaxy Z Flip8", "Samsung", "Galaxy Z", 2026, storageGb = 256, channel = SalesChannel.AU, retailer = "au", url = "https://www.au.com/mobile/product/smartphone/galaxy_z_flip8/", ramGb = 12),
        Entry("Galaxy Z Flip8", "Samsung", "Galaxy Z", 2026, storageGb = 512, channel = SalesChannel.AU, retailer = "au", url = "https://www.au.com/mobile/product/smartphone/galaxy_z_flip8/", ramGb = 12),
        Entry("Xperia 1 VIII", "Sony", "Xperia", 2026, storageGb = 256, channel = SalesChannel.AU, retailer = "au", url = "https://www.au.com/mobile/product/smartphone/xperia1m8/"),
        // 2026-10-04 official au addition: Xperia 10 VIII, 128GB/8GB, pre-release reservation.
        Entry("Xperia 10 VIII", "Sony", "Xperia", 2026, storageGb = 128, channel = SalesChannel.AU, retailer = "au", url = "https://www.au.com/mobile/product/smartphone/xperia_10_viii/", ramGb = 8, availability = AvailabilityStatus.PREORDER),

        // au official product pages / reservation catalog: additional 2024-2026 sales entries verified 2026-09-30.
        Entry("OPPO Find X9", "OPPO", "Find X", 2025, storageGb = 512, channel = SalesChannel.AU, retailer = "au", url = "https://www.au.com/mobile/product/smartphone/oppo_find_x9/"),
        Entry("TORQUE G07", "KYOCERA", "TORQUE", 2026, storageGb = 128, channel = SalesChannel.AU, retailer = "au", url = "https://www.au.com/mobile/product/smartphone/torque_g07/"),
        Entry("OPPO Reno13 A", "OPPO", "Reno", 2025, storageGb = 128, channel = SalesChannel.AU, retailer = "au", url = "https://www.au.com/mobile/product/smartphone/oppo_reno13_a/"),
        Entry("OPPO A5 5G", "OPPO", "A", 2025, storageGb = 128, channel = SalesChannel.AU, retailer = "au", url = "https://www.au.com/mobile/product/smartphone/oppo_a5_5g/"),
        Entry("motorola razr 60 ultra", "Motorola", "razr", 2025, storageGb = 512, channel = SalesChannel.AU, retailer = "au", url = "https://www.au.com/mobile/product/smartphone/razr_60_ultra/"),
        Entry("Xiaomi 14T", "Xiaomi", "Xiaomi T", 2024, storageGb = 256, channel = SalesChannel.AU, retailer = "au", url = "https://www.au.com/mobile/product/smartphone/xiaomi_14t/"),
        Entry("REDMI Note 13 Pro 5G", "Xiaomi", "Redmi Note", 2024, storageGb = 256, channel = SalesChannel.AU, retailer = "au", url = "https://www.au.com/mobile/product/smartphone/redmi_note_13_pro_5g/"),
        Entry("BASIO active3", "KYOCERA", "BASIO", 2025, storageGb = 64, channel = SalesChannel.AU, retailer = "au", url = "https://www.au.com/mobile/product/smartphone/basio_active3/"),
        Entry("らくらくスマートフォン Lite", "FCNT", "らくらくスマートフォン", 2025, storageGb = 64, channel = SalesChannel.AU, retailer = "au", url = "https://www.au.com/mobile/product/smartphone/rakuraku_smartphone_lite/"),

        // 2026-10-04 official reverse-audit: additional au capacities for Pixel 11 Pro/XL/Fold.
        Entry("Pixel 11 Pro", "Google", "Pixel", 2026, storageGb = 512, channel = SalesChannel.AU, retailer = "au", url = "https://www.au.com/mobile/product/smartphone/pixel11p/", ramGb = 16),
        Entry("Pixel 11 Pro XL", "Google", "Pixel", 2026, storageGb = 512, channel = SalesChannel.AU, retailer = "au", url = "https://www.au.com/mobile/product/smartphone/pixel11p_xl/", ramGb = 16, availability = AvailabilityStatus.PREORDER),
        Entry("Pixel 11 Pro Fold", "Google", "Pixel", 2026, storageGb = 256, channel = SalesChannel.AU, retailer = "au", url = "https://www.au.com/mobile/product/smartphone/pixel11p_fold/", ramGb = 16),
        Entry("Pixel 11 Pro Fold", "Google", "Pixel", 2026, storageGb = 512, channel = SalesChannel.AU, retailer = "au", url = "https://www.au.com/mobile/product/smartphone/pixel11p_fold/", ramGb = 16),

        // 0.01.04.16 official au reverse-audit: 2025-2026 Pixel/Galaxy lineup gaps.
        Entry("Google Pixel 10a", "Google", "Pixel", 2026, storageGb = 128, channel = SalesChannel.AU, retailer = "au", url = "https://www.au.com/mobile/product/smartphone/pixel10a/", ramGb = 8, availability = AvailabilityStatus.AVAILABLE),
        Entry("Google Pixel 10a", "Google", "Pixel", 2026, storageGb = 256, channel = SalesChannel.AU, retailer = "au", url = "https://www.au.com/mobile/product/smartphone/pixel10a/", ramGb = 8, availability = AvailabilityStatus.DISCONTINUED),
        Entry("Pixel 10", "Google", "Pixel", 2025, storageGb = 128, channel = SalesChannel.AU, retailer = "au", url = "https://www.au.com/mobile/product/smartphone/pixel10/", ramGb = 12, availability = AvailabilityStatus.UNKNOWN),
        Entry("Pixel 10", "Google", "Pixel", 2025, storageGb = 256, channel = SalesChannel.AU, retailer = "au", url = "https://www.au.com/mobile/product/smartphone/pixel10/", ramGb = 12, availability = AvailabilityStatus.UNKNOWN),
        Entry("Pixel 10 Pro", "Google", "Pixel", 2025, storageGb = 256, channel = SalesChannel.AU, retailer = "au", url = "https://www.au.com/mobile/product/smartphone/pixel10p/", ramGb = 16, availability = AvailabilityStatus.UNKNOWN),
        Entry("Pixel 10 Pro XL", "Google", "Pixel", 2025, storageGb = 256, channel = SalesChannel.AU, retailer = "au", url = "https://www.au.com/mobile/product/smartphone/pixel10p_xl/", ramGb = 16, availability = AvailabilityStatus.UNKNOWN),
        Entry("Pixel 10 Pro Fold", "Google", "Pixel", 2025, storageGb = 256, channel = SalesChannel.AU, retailer = "au", url = "https://www.au.com/mobile/product/smartphone/pixel10p_fold/", ramGb = 16, availability = AvailabilityStatus.UNKNOWN),
        Entry("Pixel 10 Pro Fold", "Google", "Pixel", 2025, storageGb = 512, channel = SalesChannel.AU, retailer = "au", url = "https://www.au.com/mobile/product/smartphone/pixel10p_fold/", ramGb = 16, availability = AvailabilityStatus.UNKNOWN),
        Entry("Galaxy S25", "Samsung", "Galaxy S", 2025, storageGb = 256, channel = SalesChannel.AU, retailer = "au", url = "https://www.au.com/mobile/product/smartphone/galaxy_s25/", ramGb = 12, availability = AvailabilityStatus.UNKNOWN),
        Entry("Galaxy S25", "Samsung", "Galaxy S", 2025, storageGb = 512, channel = SalesChannel.AU, retailer = "au", url = "https://www.au.com/mobile/product/smartphone/galaxy_s25/", ramGb = 12, availability = AvailabilityStatus.UNKNOWN),

        // 0.01.04.17 AU reverse-audit: official 2024 product pages are still present.
        // Pixel 9 Pro XL: 128GB is explicitly marked sales-ended; 256/512GB remain UNKNOWN
        // because the current page exposes the capacities but not a definitive current stock state.
        Entry("Pixel 9 Pro XL", "Google", "Pixel", 2024, storageGb = 128, channel = SalesChannel.AU, retailer = "au", url = "https://www.au.com/mobile/product/smartphone/pixel9p_xl/", ramGb = 16, availability = AvailabilityStatus.DISCONTINUED),
        Entry("Pixel 9 Pro XL", "Google", "Pixel", 2024, storageGb = 256, channel = SalesChannel.AU, retailer = "au", url = "https://www.au.com/mobile/product/smartphone/pixel9p_xl/", ramGb = 16, availability = AvailabilityStatus.UNKNOWN),
        Entry("Pixel 9 Pro XL", "Google", "Pixel", 2024, storageGb = 512, channel = SalesChannel.AU, retailer = "au", url = "https://www.au.com/mobile/product/smartphone/pixel9p_xl/", ramGb = 16, availability = AvailabilityStatus.UNKNOWN),
        // Galaxy S24 Ultra: official au page lists 256/512/1TB, all currently sales-ended.
        Entry("Galaxy S24 Ultra", "Samsung", "Galaxy S", 2024, storageGb = 256, channel = SalesChannel.AU, retailer = "au", url = "https://www.au.com/mobile/product/smartphone/galaxy_s24_ultra/", modelNumber = "SCG26", ramGb = 12, availability = AvailabilityStatus.DISCONTINUED),
        Entry("Galaxy S24 Ultra", "Samsung", "Galaxy S", 2024, storageGb = 512, channel = SalesChannel.AU, retailer = "au", url = "https://www.au.com/mobile/product/smartphone/galaxy_s24_ultra/", modelNumber = "SCG26", ramGb = 12, availability = AvailabilityStatus.DISCONTINUED),
        Entry("Galaxy S24 Ultra", "Samsung", "Galaxy S", 2024, storageGb = 1024, channel = SalesChannel.AU, retailer = "au", url = "https://www.au.com/mobile/product/smartphone/galaxy_s24_ultra/", modelNumber = "SCG26", ramGb = 12, availability = AvailabilityStatus.DISCONTINUED),
        Entry("Galaxy S25 Ultra", "Samsung", "Galaxy S", 2025, storageGb = 256, channel = SalesChannel.AU, retailer = "au", url = "https://www.au.com/mobile/product/smartphone/galaxy_s25_ultra/", ramGb = 12, availability = AvailabilityStatus.UNKNOWN),
        Entry("Galaxy S25 Ultra", "Samsung", "Galaxy S", 2025, storageGb = 512, channel = SalesChannel.AU, retailer = "au", url = "https://www.au.com/mobile/product/smartphone/galaxy_s25_ultra/", ramGb = 12, availability = AvailabilityStatus.UNKNOWN),
        Entry("Galaxy S25 Ultra", "Samsung", "Galaxy S", 2025, storageGb = 1024, channel = SalesChannel.AU, retailer = "au", url = "https://www.au.com/mobile/product/smartphone/galaxy_s25_ultra/", ramGb = 12, availability = AvailabilityStatus.UNKNOWN),
        Entry("Galaxy Z Flip7", "Samsung", "Galaxy Z", 2025, storageGb = 256, channel = SalesChannel.AU, retailer = "au", url = "https://www.au.com/mobile/product/smartphone/galaxy_z_flip7/", ramGb = 12, availability = AvailabilityStatus.DISCONTINUED),
        Entry("Galaxy Z Flip7", "Samsung", "Galaxy Z", 2025, storageGb = 512, channel = SalesChannel.AU, retailer = "au", url = "https://www.au.com/mobile/product/smartphone/galaxy_z_flip7/", ramGb = 12, availability = AvailabilityStatus.DISCONTINUED),
        Entry("Galaxy Z Fold7", "Samsung", "Galaxy Z", 2025, storageGb = 256, channel = SalesChannel.AU, retailer = "au", url = "https://www.au.com/mobile/product/smartphone/galaxy_z_fold7/", ramGb = 12, availability = AvailabilityStatus.DISCONTINUED),
        Entry("Galaxy Z Fold7", "Samsung", "Galaxy Z", 2025, storageGb = 512, channel = SalesChannel.AU, retailer = "au", url = "https://www.au.com/mobile/product/smartphone/galaxy_z_fold7/", ramGb = 12, availability = AvailabilityStatus.DISCONTINUED),
        Entry("Galaxy Z Fold7", "Samsung", "Galaxy Z", 2025, storageGb = 1024, channel = SalesChannel.AU, retailer = "au", url = "https://www.au.com/mobile/product/smartphone/galaxy_z_fold7/", ramGb = 16, availability = AvailabilityStatus.DISCONTINUED),
        Entry("Xperia 10 VII", "Sony", "Xperia", 2025, storageGb = 128, channel = SalesChannel.AU, retailer = "au", url = "https://www.au.com/mobile/product/smartphone/xperia_10_vii/", ramGb = 8, availability = AvailabilityStatus.UNKNOWN),
        Entry("Galaxy A25 5G", "Samsung", "Galaxy A", 2025, storageGb = 64, channel = SalesChannel.AU, retailer = "au", url = "https://www.au.com/mobile/product/smartphone/galaxy_a25_5g/", ramGb = 4, availability = AvailabilityStatus.AVAILABLE),

        // SoftBank official product catalog: current 2026 lineup.
        Entry("iPhone 18 Pro", "Apple", "iPhone", 2026, platform = "IPHONE", storageGb = 256, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/iphone/iphone-18-pro/", availability = AvailabilityStatus.AVAILABLE),
        Entry("iPhone 18 Pro Max", "Apple", "iPhone", 2026, platform = "IPHONE", storageGb = 256, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/iphone/iphone-18-pro/", availability = AvailabilityStatus.AVAILABLE),
        // 0.01.03 official reverse-audit: SoftBank currently sells the 2025 iPhone family.
        // 2026-10-05 official reverse-audit: SoftBank price PDF confirms all four capacities for iPhone 18 Pro / Pro Max.
        Entry("iPhone 18 Pro", "Apple", "iPhone", 2026, platform = "IPHONE", storageGb = 512, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/iphone/iphone-18-pro/", availability = AvailabilityStatus.AVAILABLE),
        Entry("iPhone 18 Pro", "Apple", "iPhone", 2026, platform = "IPHONE", storageGb = 1024, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/iphone/iphone-18-pro/", availability = AvailabilityStatus.AVAILABLE),
        Entry("iPhone 18 Pro", "Apple", "iPhone", 2026, platform = "IPHONE", storageGb = 2048, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/iphone/iphone-18-pro/", availability = AvailabilityStatus.AVAILABLE),
        Entry("iPhone 18 Pro Max", "Apple", "iPhone", 2026, platform = "IPHONE", storageGb = 512, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/iphone/iphone-18-pro/", availability = AvailabilityStatus.AVAILABLE),
        Entry("iPhone 18 Pro Max", "Apple", "iPhone", 2026, platform = "IPHONE", storageGb = 1024, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/iphone/iphone-18-pro/", availability = AvailabilityStatus.AVAILABLE),
        Entry("iPhone 18 Pro Max", "Apple", "iPhone", 2026, platform = "IPHONE", storageGb = 2048, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/iphone/iphone-18-pro/", availability = AvailabilityStatus.AVAILABLE),
        // SoftBank official announcement: iPhone Duo reservation 2026-10-16, release 2026-10-23.
        Entry("iPhone Duo", "Apple", "iPhone", 2026, platform = "IPHONE", storageGb = 256, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/iphone/iphone-duo/", availability = AvailabilityStatus.PREORDER),
        Entry("iPhone Duo", "Apple", "iPhone", 2026, platform = "IPHONE", storageGb = 512, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/iphone/iphone-duo/", availability = AvailabilityStatus.PREORDER),
        Entry("iPhone Duo", "Apple", "iPhone", 2026, platform = "IPHONE", storageGb = 1024, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/iphone/iphone-duo/", availability = AvailabilityStatus.PREORDER),
        Entry("iPhone Duo", "Apple", "iPhone", 2026, platform = "IPHONE", storageGb = 2048, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/iphone/iphone-duo/", availability = AvailabilityStatus.PREORDER),

        Entry("iPhone 17", "Apple", "iPhone", 2025, platform = "IPHONE", storageGb = 256, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/mobile/products/iphone/iphone-17/", availability = AvailabilityStatus.AVAILABLE),
        Entry("iPhone 17", "Apple", "iPhone", 2025, platform = "IPHONE", storageGb = 512, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/mobile/products/iphone/iphone-17/", availability = AvailabilityStatus.AVAILABLE),
        Entry("iPhone 17e", "Apple", "iPhone", 2026, platform = "IPHONE", storageGb = 256, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/mobile/products/iphone/iphone-17e/", availability = AvailabilityStatus.AVAILABLE),
        Entry("iPhone 17e", "Apple", "iPhone", 2026, platform = "IPHONE", storageGb = 512, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/mobile/products/iphone/iphone-17e/", availability = AvailabilityStatus.AVAILABLE),
        Entry("iPhone Air", "Apple", "iPhone", 2025, platform = "IPHONE", storageGb = 256, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/mobile/products/iphone/iphone-air/", availability = AvailabilityStatus.AVAILABLE),
        Entry("iPhone Air", "Apple", "iPhone", 2025, platform = "IPHONE", storageGb = 512, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/mobile/products/iphone/iphone-air/", availability = AvailabilityStatus.AVAILABLE),
        Entry("iPhone Air", "Apple", "iPhone", 2025, platform = "IPHONE", storageGb = 1024, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/mobile/products/iphone/iphone-air/", availability = AvailabilityStatus.AVAILABLE),
        Entry("iPhone 17 Pro", "Apple", "iPhone", 2025, platform = "IPHONE", storageGb = 256, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/mobile/products/iphone/iphone-17-pro/", availability = AvailabilityStatus.AVAILABLE),
        Entry("iPhone 17 Pro", "Apple", "iPhone", 2025, platform = "IPHONE", storageGb = 512, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/mobile/products/iphone/iphone-17-pro/", availability = AvailabilityStatus.AVAILABLE),
        Entry("iPhone 17 Pro", "Apple", "iPhone", 2025, platform = "IPHONE", storageGb = 1024, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/mobile/products/iphone/iphone-17-pro/", availability = AvailabilityStatus.AVAILABLE),
        Entry("iPhone 17 Pro Max", "Apple", "iPhone", 2025, platform = "IPHONE", storageGb = 256, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/mobile/products/iphone/iphone-17-pro-max/", availability = AvailabilityStatus.AVAILABLE),
        Entry("iPhone 17 Pro Max", "Apple", "iPhone", 2025, platform = "IPHONE", storageGb = 512, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/mobile/products/iphone/iphone-17-pro-max/", availability = AvailabilityStatus.AVAILABLE),
        Entry("iPhone 17 Pro Max", "Apple", "iPhone", 2025, platform = "IPHONE", storageGb = 1024, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/mobile/products/iphone/iphone-17-pro-max/", availability = AvailabilityStatus.AVAILABLE),
        Entry("iPhone 17 Pro Max", "Apple", "iPhone", 2025, platform = "IPHONE", storageGb = 2048, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/mobile/products/iphone/iphone-17-pro-max/", availability = AvailabilityStatus.AVAILABLE),

        Entry("Pixel 11", "Google", "Pixel", 2026, storageGb = 256, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/mobile/products/smartphone/pixel11/", ramGb = 12, availability = AvailabilityStatus.AVAILABLE),
        Entry("Pixel 11 Pro", "Google", "Pixel", 2026, storageGb = 256, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/mobile/products/smartphone/pixel11-pro/", ramGb = 12, availability = AvailabilityStatus.AVAILABLE),
        Entry("Pixel 11 Pro XL", "Google", "Pixel", 2026, storageGb = 256, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/mobile/products/smartphone/pixel11-pro-xl/", ramGb = 12, availability = AvailabilityStatus.AVAILABLE),
        Entry("Pixel 11 Pro Fold", "Google", "Pixel", 2026, storageGb = 256, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/mobile/products/smartphone/pixel11-pro-fold/", ramGb = 16, availability = AvailabilityStatus.AVAILABLE),
        Entry("Galaxy S26", "Samsung", "Galaxy S", 2026, storageGb = 256, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/mobile/products/samsung-galaxy/samsung-galaxy-s26/", ramGb = 12, availability = AvailabilityStatus.AVAILABLE),
        Entry("Galaxy S26+", "Samsung", "Galaxy S", 2026, storageGb = 256, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/mobile/products/samsung-galaxy/samsung-galaxy-s26-plus/", ramGb = 12, availability = AvailabilityStatus.AVAILABLE),
        Entry("Galaxy S26 Ultra", "Samsung", "Galaxy S", 2026, storageGb = 256, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/mobile/products/samsung-galaxy/samsung-galaxy-s26-ultra/", ramGb = 12, availability = AvailabilityStatus.AVAILABLE),
        Entry("Galaxy A57 5G", "Samsung", "Galaxy A", 2026, storageGb = 128, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/mobile/products/samsung-galaxy/samsung-galaxy-a57-5g/", ramGb = 8, availability = AvailabilityStatus.AVAILABLE),
        Entry("Galaxy Z Fold8 Ultra", "Samsung", "Galaxy Z", 2026, storageGb = 256, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/mobile/products/samsung-galaxy/samsung-galaxy-z-fold8-ultra/", ramGb = 12, availability = AvailabilityStatus.AVAILABLE),
        // 0.01.04.20 official reverse-audit: SoftBank Galaxy Z Fold8 Ultra supports 512GB/12GB and 1TB/16GB.
        Entry("Galaxy Z Fold8 Ultra", "Samsung", "Galaxy Z", 2026, storageGb = 512, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/mobile/products/samsung-galaxy/samsung-galaxy-z-fold8-ultra/", ramGb = 12, availability = AvailabilityStatus.AVAILABLE),
        Entry("Galaxy Z Fold8 Ultra", "Samsung", "Galaxy Z", 2026, storageGb = 1024, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/mobile/products/samsung-galaxy/samsung-galaxy-z-fold8-ultra/", ramGb = 16, availability = AvailabilityStatus.AVAILABLE),
        Entry("Galaxy Z Fold8", "Samsung", "Galaxy Z", 2026, storageGb = 256, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/mobile/products/smartphone/galaxy-z-fold8/", ramGb = 12, availability = AvailabilityStatus.AVAILABLE),
        Entry("Galaxy Z Flip8", "Samsung", "Galaxy Z", 2026, storageGb = 256, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/mobile/products/smartphone/galaxy-z-flip8/", ramGb = 12, availability = AvailabilityStatus.AVAILABLE),
        Entry("moto g37", "Motorola", "moto g", 2026, storageGb = 128, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/mobile/products/smartphone/moto-g37/", ramGb = 8, availability = AvailabilityStatus.AVAILABLE),
        Entry("motorola edge 60s pro", "Motorola", "edge", 2025, storageGb = 256, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/mobile/products/smartphone/motorola-edge-60s-pro/", modelNumber = "XT2507-3", ramGb = 12, availability = AvailabilityStatus.AVAILABLE),
        Entry("AQUOS R11", "SHARP", "AQUOS R", 2026, storageGb = 256, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/mobile/products/smartphone/aquos-r11/", ramGb = 12, availability = AvailabilityStatus.AVAILABLE),
        Entry("Xperia 1 VIII", "Sony", "Xperia", 2026, storageGb = 256, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/mobile/products/smartphone/xperia1m8/", ramGb = 12, availability = AvailabilityStatus.AVAILABLE),
        // 2026-10-01 official reverse-audit: Xperia 10 VIII launches 2026-10-08; reservations open 2026-10-01.
        Entry("Xperia 10 VIII", "Sony", "Xperia", 2026, storageGb = 128, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/mobile/products/smartphone/xperia10m8/", ramGb = 8, availability = AvailabilityStatus.PREORDER),
        Entry("Natural AI Phone", "Brain AI Japan", "Natural AI Phone", 2026, storageGb = 256, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/mobile/products/smartphone/natural-ai-phone/", ramGb = 12, availability = AvailabilityStatus.AVAILABLE),
        Entry("DIGNO BX3 カメラレス", "京セラ", "DIGNO", 2025, storageGb = 64, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/mobile/products/smartphone/digno-bx3-cameraless/", modelNumber = "A402KC", ramGb = 4, availability = AvailabilityStatus.AVAILABLE),
        Entry("REDMI 15 5G", "Xiaomi", "REDMI", 2025, storageGb = 128, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/mobile/products/smartphone/redmi15-5g/", modelNumber = "A501XM", ramGb = 4, availability = AvailabilityStatus.AVAILABLE),
        Entry("AQUOS sense10", "SHARP", "AQUOS sense", 2025, storageGb = 128, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/mobile/products/smartphone/aquos-sense10/", ramGb = 6, availability = AvailabilityStatus.AVAILABLE),
        Entry("Xperia 10 VII", "Sony", "Xperia", 2025, storageGb = 128, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/mobile/products/smartphone/xperia10m7/", modelNumber = "A502SO", ramGb = 8, availability = AvailabilityStatus.AVAILABLE),
        Entry("motorola razr 60s", "Motorola", "razr", 2025, storageGb = 256, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/mobile/products/smartphone/motorola-razr-60s/", modelNumber = "XT2553-6", ramGb = 8, availability = AvailabilityStatus.AVAILABLE),

        Entry("Pixel 11", "Google", "Pixel", 2026, storageGb = 512, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/mobile/products/google-pixel/google-pixel-11/", ramGb = 12, availability = AvailabilityStatus.AVAILABLE),
        Entry("Pixel 11 Pro", "Google", "Pixel", 2026, storageGb = 512, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/mobile/products/google-pixel/google-pixel-11-pro/", ramGb = 16, availability = AvailabilityStatus.AVAILABLE),
        Entry("Pixel 11 Pro XL", "Google", "Pixel", 2026, storageGb = 512, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/mobile/products/smartphone/pixel11-pro-xl/", ramGb = 16, availability = AvailabilityStatus.AVAILABLE),
        Entry("Pixel 11 Pro Fold", "Google", "Pixel", 2026, storageGb = 512, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/mobile/products/google-pixel/google-pixel-11-pro-fold/", ramGb = 16, availability = AvailabilityStatus.AVAILABLE),
        Entry("Galaxy S26+", "Samsung", "Galaxy S", 2026, storageGb = 512, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/mobile/products/samsung-galaxy/samsung-galaxy-s26-plus/", ramGb = 12, availability = AvailabilityStatus.AVAILABLE),
        Entry("Galaxy S26 Ultra", "Samsung", "Galaxy S", 2026, storageGb = 512, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/mobile/products/samsung-galaxy/samsung-galaxy-s26-ultra/", ramGb = 12, availability = AvailabilityStatus.AVAILABLE),
        // 2026-09-30 公式容量再監査: SoftBank公式料金資料/製品ページで確認した追加容量。
        Entry("Pixel 10", "Google", "Pixel", 2025, storageGb = 256, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/mobile/products/smartphone/pixel10/", ramGb = 12, availability = AvailabilityStatus.AVAILABLE),
        Entry("Pixel 10 Pro", "Google", "Pixel", 2025, storageGb = 512, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/mobile/products/smartphone/pixel10-pro/", ramGb = 16, availability = AvailabilityStatus.AVAILABLE),
        Entry("Pixel 10 Pro XL", "Google", "Pixel", 2025, storageGb = 512, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/mobile/products/smartphone/pixel10-pro-xl/", ramGb = 16, availability = AvailabilityStatus.AVAILABLE),
        Entry("Pixel 10 Pro Fold", "Google", "Pixel", 2025, storageGb = 512, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/mobile/products/google-pixel/google-pixel-10-pro-fold/", ramGb = 16, availability = AvailabilityStatus.AVAILABLE),
        Entry("Galaxy S26", "Samsung", "Galaxy S", 2026, storageGb = 512, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/mobile/products/samsung-galaxy/samsung-galaxy-s26/", ramGb = 12, availability = AvailabilityStatus.AVAILABLE),
        // SoftBank current 2024-2026 product catalog: reverse-audit additions verified 2026-09-30.
        Entry("Google Pixel 10a", "Google", "Pixel", 2026, storageGb = 128, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/mobile/products/smartphone/pixel10a/", ramGb = 8, availability = AvailabilityStatus.AVAILABLE),
        Entry("Pixel 10", "Google", "Pixel", 2025, storageGb = 128, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/mobile/products/smartphone/pixel10/", ramGb = 12, availability = AvailabilityStatus.AVAILABLE),
        Entry("Pixel 10 Pro", "Google", "Pixel", 2025, storageGb = 256, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/mobile/products/smartphone/pixel10-pro/", ramGb = 16, availability = AvailabilityStatus.AVAILABLE),
        Entry("Pixel 10 Pro XL", "Google", "Pixel", 2025, storageGb = 256, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/mobile/products/smartphone/pixel10-pro-xl/", ramGb = 16, availability = AvailabilityStatus.AVAILABLE),
        Entry("Pixel 10 Pro Fold", "Google", "Pixel", 2025, storageGb = 256, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/mobile/products/smartphone/pixel10-pro-fold/", ramGb = 16, availability = AvailabilityStatus.AVAILABLE),
        Entry("Galaxy Z Fold7", "Samsung", "Galaxy Z", 2025, storageGb = 256, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/mobile/products/smartphone/galaxy-z-fold7/", modelNumber = "SM-F966Z", ramGb = 12, availability = AvailabilityStatus.AVAILABLE),
        Entry("Galaxy Z Flip7", "Samsung", "Galaxy Z", 2025, storageGb = 256, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/mobile/products/smartphone/galaxy-z-flip7/", modelNumber = "SM-F766Z", ramGb = 12, availability = AvailabilityStatus.AVAILABLE),
        Entry("Galaxy S25", "Samsung", "Galaxy S", 2025, storageGb = 256, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/mobile/products/samsung-galaxy/samsung-galaxy-s25/", modelNumber = "SM-S931Z", ramGb = 12, availability = AvailabilityStatus.AVAILABLE),
        Entry("Galaxy S25 Ultra", "Samsung", "Galaxy S", 2025, storageGb = 256, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/mobile/products/samsung-galaxy/samsung-galaxy-s25-ultra/", modelNumber = "SM-S938Z", ramGb = 12, availability = AvailabilityStatus.AVAILABLE),
        // 0.01.04.33 official reverse-audit: SoftBank New Tokusuru Support+ lists Galaxy S25 Ultra 512GB as a supported device.
        Entry("Galaxy S25 Ultra", "Samsung", "Galaxy S", 2025, storageGb = 512, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/mobile/products/samsung-galaxy/samsung-galaxy-s25-ultra/", modelNumber = "SM-S938Z", ramGb = 12, availability = AvailabilityStatus.AVAILABLE),
        Entry("AQUOS R10", "SHARP", "AQUOS R", 2025, storageGb = 256, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/mobile/products/smartphone/aquos-r10/", modelNumber = "A501SH", ramGb = 12, availability = AvailabilityStatus.AVAILABLE),
        Entry("Xperia 1 VII", "Sony", "Xperia", 2025, storageGb = 256, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/mobile/products/smartphone/xperia1m7/", modelNumber = "A501SO", ramGb = 12, availability = AvailabilityStatus.AVAILABLE),
        Entry("AQUOS R9 pro", "SHARP", "AQUOS R", 2024, storageGb = 512, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/mobile/products/smartphone/aquos-r9-pro/", modelNumber = "A504SH", ramGb = 12, availability = AvailabilityStatus.AVAILABLE),
        // 0.01.04.26 official reverse-audit additions.
        Entry("Pixel 9a", "Google", "Pixel", 2025, storageGb = 128, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/mobile/products/smartphone/pixel9a/", ramGb = 8, availability = AvailabilityStatus.AVAILABLE),
        Entry("Pixel 9a", "Google", "Pixel", 2025, storageGb = 256, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/mobile/products/smartphone/pixel9a/", ramGb = 8, availability = AvailabilityStatus.AVAILABLE),
        Entry("Galaxy A25 5G", "Samsung", "Galaxy A", 2025, storageGb = 64, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/mobile/products/smartphone/galaxy-a25-5g/", modelNumber = "SM-A253Z", ramGb = 4, availability = AvailabilityStatus.AVAILABLE),

        // 0.01.04.26 official reverse-audit additions: SoftBank iPhone 16 series.
        Entry("iPhone 16e", "Apple", "iPhone", 2025, platform = "IPHONE", storageGb = 128, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/iphone/iphone-16e/", availability = AvailabilityStatus.AVAILABLE),
        Entry("iPhone 16e", "Apple", "iPhone", 2025, platform = "IPHONE", storageGb = 256, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/iphone/iphone-16e/", availability = AvailabilityStatus.AVAILABLE),
        Entry("iPhone 16e", "Apple", "iPhone", 2025, platform = "IPHONE", storageGb = 512, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/iphone/iphone-16e/", availability = AvailabilityStatus.AVAILABLE),
        Entry("iPhone 16", "Apple", "iPhone", 2024, platform = "IPHONE", storageGb = 128, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/iphone/iphone-16/", availability = AvailabilityStatus.AVAILABLE),
        Entry("iPhone 16", "Apple", "iPhone", 2024, platform = "IPHONE", storageGb = 256, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/iphone/iphone-16/", availability = AvailabilityStatus.AVAILABLE),
        Entry("iPhone 16", "Apple", "iPhone", 2024, platform = "IPHONE", storageGb = 512, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/iphone/iphone-16/", availability = AvailabilityStatus.AVAILABLE),
        Entry("iPhone 16 Plus", "Apple", "iPhone", 2024, platform = "IPHONE", storageGb = 128, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/iphone/iphone-16/", availability = AvailabilityStatus.AVAILABLE),
        Entry("iPhone 16 Plus", "Apple", "iPhone", 2024, platform = "IPHONE", storageGb = 256, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/iphone/iphone-16/", availability = AvailabilityStatus.AVAILABLE),
        Entry("iPhone 16 Plus", "Apple", "iPhone", 2024, platform = "IPHONE", storageGb = 512, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/iphone/iphone-16/", availability = AvailabilityStatus.AVAILABLE),
        Entry("iPhone 16 Pro", "Apple", "iPhone", 2024, platform = "IPHONE", storageGb = 128, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/iphone/iphone-16-pro/", availability = AvailabilityStatus.AVAILABLE),
        Entry("iPhone 16 Pro", "Apple", "iPhone", 2024, platform = "IPHONE", storageGb = 256, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/iphone/iphone-16-pro/", availability = AvailabilityStatus.AVAILABLE),
        Entry("iPhone 16 Pro", "Apple", "iPhone", 2024, platform = "IPHONE", storageGb = 512, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/iphone/iphone-16-pro/", availability = AvailabilityStatus.AVAILABLE),
        Entry("iPhone 16 Pro", "Apple", "iPhone", 2024, platform = "IPHONE", storageGb = 1024, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/iphone/iphone-16-pro/", availability = AvailabilityStatus.AVAILABLE),
        Entry("iPhone 16 Pro Max", "Apple", "iPhone", 2024, platform = "IPHONE", storageGb = 256, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/iphone/iphone-16-pro-max/", availability = AvailabilityStatus.AVAILABLE),
        Entry("iPhone 16 Pro Max", "Apple", "iPhone", 2024, platform = "IPHONE", storageGb = 512, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/iphone/iphone-16-pro-max/", availability = AvailabilityStatus.AVAILABLE),
        Entry("iPhone 16 Pro Max", "Apple", "iPhone", 2024, platform = "IPHONE", storageGb = 1024, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/iphone/iphone-16-pro-max/", availability = AvailabilityStatus.AVAILABLE),

        Entry("arrows We2", "FCNT", "arrows", 2024, storageGb = 64, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/mobile/products/smartphone/arrows-we2/", modelNumber = "A402FC", ramGb = 4, availability = AvailabilityStatus.AVAILABLE),
        Entry("motorola razr 50 ultra", "Motorola", "razr", 2024, storageGb = 512, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/mobile/products/smartphone/motorola-razr-50-ultra/", modelNumber = "XT2451-5", ramGb = 12, availability = AvailabilityStatus.AVAILABLE),
        Entry("AQUOS sense9", "SHARP", "AQUOS sense", 2024, storageGb = 128, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/mobile/products/smartphone/aquos-sense9/", modelNumber = "A405SH", ramGb = 6, availability = AvailabilityStatus.AVAILABLE),
        Entry("Xiaomi 14T Pro", "Xiaomi", "Xiaomi T", 2024, storageGb = 512, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/mobile/products/smartphone/xiaomi-14t-pro/", modelNumber = "A402XM", ramGb = 12, availability = AvailabilityStatus.AVAILABLE),
        Entry("motorola razr 50s", "Motorola", "razr", 2024, storageGb = 256, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/mobile/products/smartphone/motorola-razr-50s/", modelNumber = "XT2453-7", ramGb = 8, availability = AvailabilityStatus.AVAILABLE),
        Entry("motorola edge 50s pro", "Motorola", "edge", 2024, storageGb = 256, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/mobile/products/smartphone/motorola-edge-50s-pro/", modelNumber = "XT2403-5", ramGb = 8, availability = AvailabilityStatus.AVAILABLE),
        Entry("シンプルスマホ7", "SHARP", "シンプルスマホ", 2024, storageGb = 64, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/mobile/products/smartphone/simple-sumaho7/", modelNumber = "A404SH", ramGb = 4, availability = AvailabilityStatus.AVAILABLE),
        Entry("Xperia 1 VI", "Sony", "Xperia", 2024, storageGb = 256, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/mobile/products/smartphone/xperia1m6/", modelNumber = "A401SO", ramGb = 12, availability = AvailabilityStatus.AVAILABLE),
        Entry("Xperia 10 VI", "Sony", "Xperia", 2024, storageGb = 128, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/mobile/products/smartphone/xperia10m6/", modelNumber = "A402SO", ramGb = 6, availability = AvailabilityStatus.AVAILABLE),
        Entry("AQUOS R9", "SHARP", "AQUOS R", 2024, storageGb = 256, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/mobile/products/smartphone/aquos-r9/", modelNumber = "A401SH", ramGb = 12, availability = AvailabilityStatus.AVAILABLE),
        Entry("Redmi 12 5G", "Xiaomi", "Redmi", 2024, storageGb = 128, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/mobile/products/smartphone/redmi12-5g/", modelNumber = "A401XM", ramGb = 4, availability = AvailabilityStatus.AVAILABLE),
        Entry("LEITZ PHONE 3", "SHARP", "LEITZ PHONE", 2024, storageGb = 512, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/mobile/products/smartphone/leitz-phone3/", modelNumber = "LP-03", ramGb = 12, availability = AvailabilityStatus.AVAILABLE),
        Entry("DuraForce EX", "KYOCERA", "DuraForce", 2024, storageGb = 64, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/mobile/products/smartphone/duraforce-ex/", modelNumber = "A301KC", ramGb = 4, availability = AvailabilityStatus.AVAILABLE),
        Entry("あんしんファミリースマホ", "ZTE", "あんしんファミリースマホ", 2024, storageGb = 128, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/mobile/products/smartphone/anshin-family-smartphone/", modelNumber = "A303ZT", ramGb = 4, availability = AvailabilityStatus.AVAILABLE),

        // 0.2.84: SoftBank公式「製品情報」一覧の逆監査で未登録だった機種。
        Entry("Xiaomi 13T Pro", "Xiaomi", "Xiaomi T", 2023, storageGb = 256, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/mobile/products/smartphone/xiaomi-13t-pro/", ramGb = 12),
        Entry("motorola razr 40s", "Motorola", "razr", 2023, storageGb = 256, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/mobile/products/smartphone/motorola-razr-40s/", ramGb = 8),
        Entry("AQUOS wish3", "SHARP", "AQUOS wish", 2023, storageGb = 64, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/mobile/products/smartphone/aquos-wish3/", ramGb = 4),
        Entry("OPPO Reno10 Pro 5G", "OPPO", "Reno", 2023, storageGb = 256, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/mobile/products/smartphone/oppo-reno10-pro-5g/", ramGb = 8),
        Entry("AQUOS R8 pro", "SHARP", "AQUOS R", 2023, storageGb = 256, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/mobile/products/smartphone/aquos-r8-pro/", ramGb = 12),
        Entry("Xperia 10 V", "Sony", "Xperia", 2023, storageGb = 128, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/mobile/products/smartphone/xperia10m5/", ramGb = 6),
        Entry("Xperia 1 V", "Sony", "Xperia", 2023, storageGb = 256, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/mobile/products/smartphone/xperia1m5/", ramGb = 12),
        Entry("AQUOS sense7 plus", "SHARP", "AQUOS sense", 2022, storageGb = 128, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/mobile/products/smartphone/aquos-sense7-plus/", ramGb = 6),
        Entry("Redmi Note 10T", "Xiaomi", "Redmi", 2022, storageGb = 64, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/mobile/products/smartphone/redmi-note-10t/", ramGb = 4),
        Entry("シンプルスマホ6", "SHARP", "シンプルスマホ", 2022, storageGb = 64, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/mobile/products/smartphone/simple-sumaho6/", ramGb = 4),
        Entry("arrows We", "FCNT", "arrows", 2021, storageGb = 64, channel = SalesChannel.SOFTBANK, retailer = "ソフトバンク", url = "https://www.softbank.jp/mobile/products/smartphone/arrows-we/", ramGb = 4),

        // Rakuten Mobile: direct official product pages verified.
        Entry("iPhone 18 Pro", "Apple", "iPhone", 2026, platform = "IPHONE", storageGb = 256, channel = SalesChannel.RAKUTEN, retailer = "楽天モバイル", url = "https://network.mobile.rakuten.co.jp/product/iphone/iphone-18-pro/"),
        Entry("iPhone 18 Pro Max", "Apple", "iPhone", 2026, platform = "IPHONE", storageGb = 256, channel = SalesChannel.RAKUTEN, retailer = "楽天モバイル", url = "https://network.mobile.rakuten.co.jp/product/iphone/iphone-18-pro-max/"),
        Entry("Pixel 11 Pro", "Google", "Pixel", 2026, storageGb = 256, channel = SalesChannel.RAKUTEN, retailer = "楽天モバイル", url = "https://network.mobile.rakuten.co.jp/product/smartphone/google-pixel-11-pro/", ramGb = 12),
        Entry("Pixel 11 Pro", "Google", "Pixel", 2026, storageGb = 512, channel = SalesChannel.RAKUTEN, retailer = "楽天モバイル", url = "https://network.mobile.rakuten.co.jp/product/smartphone/google-pixel-11-pro/", ramGb = 16),
        Entry("iPhone 18 Pro", "Apple", "iPhone", 2026, platform = "IPHONE", storageGb = 512, channel = SalesChannel.RAKUTEN, retailer = "楽天モバイル", url = "https://network.mobile.rakuten.co.jp/product/iphone/iphone-18-pro/"),
        Entry("iPhone 18 Pro", "Apple", "iPhone", 2026, platform = "IPHONE", storageGb = 1024, channel = SalesChannel.RAKUTEN, retailer = "楽天モバイル", url = "https://network.mobile.rakuten.co.jp/product/iphone/iphone-18-pro/"),
        Entry("iPhone 18 Pro", "Apple", "iPhone", 2026, platform = "IPHONE", storageGb = 2048, channel = SalesChannel.RAKUTEN, retailer = "楽天モバイル", url = "https://network.mobile.rakuten.co.jp/product/iphone/iphone-18-pro/"),
        Entry("iPhone 18 Pro Max", "Apple", "iPhone", 2026, platform = "IPHONE", storageGb = 512, channel = SalesChannel.RAKUTEN, retailer = "楽天モバイル", url = "https://network.mobile.rakuten.co.jp/product/iphone/iphone-18-pro-max/"),
        Entry("iPhone 18 Pro Max", "Apple", "iPhone", 2026, platform = "IPHONE", storageGb = 1024, channel = SalesChannel.RAKUTEN, retailer = "楽天モバイル", url = "https://network.mobile.rakuten.co.jp/product/iphone/iphone-18-pro-max/"),
        Entry("iPhone 18 Pro Max", "Apple", "iPhone", 2026, platform = "IPHONE", storageGb = 2048, channel = SalesChannel.RAKUTEN, retailer = "楽天モバイル", url = "https://network.mobile.rakuten.co.jp/product/iphone/iphone-18-pro-max/"),

        // Rakuten Mobile official product catalog: current models highlighted on the official lineup.
        Entry("Pixel 11", "Google", "Pixel", 2026, storageGb = 256, channel = SalesChannel.RAKUTEN, retailer = "楽天モバイル", url = "https://network.mobile.rakuten.co.jp/product/smartphone/google-pixel-11/", ramGb = 12),
        Entry("Galaxy S26", "Samsung", "Galaxy S", 2026, storageGb = 256, channel = SalesChannel.RAKUTEN, retailer = "楽天モバイル", url = "https://network.mobile.rakuten.co.jp/product/smartphone/"),
        Entry("Galaxy S26+", "Samsung", "Galaxy S", 2026, storageGb = 256, channel = SalesChannel.RAKUTEN, retailer = "楽天モバイル", url = "https://network.mobile.rakuten.co.jp/product/smartphone/"),
        Entry("Galaxy S26 Ultra", "Samsung", "Galaxy S", 2026, storageGb = 256, channel = SalesChannel.RAKUTEN, retailer = "楽天モバイル", url = "https://network.mobile.rakuten.co.jp/product/smartphone/samsung-galaxy-s26-ultra/", ramGb = 12),
        Entry("Galaxy Z Fold8", "Samsung", "Galaxy Z", 2026, storageGb = 256, channel = SalesChannel.RAKUTEN, retailer = "楽天モバイル", url = "https://network.mobile.rakuten.co.jp/product/smartphone/"),
        Entry("Galaxy Z Fold8 Ultra", "Samsung", "Galaxy Z", 2026, storageGb = 256, channel = SalesChannel.RAKUTEN, retailer = "楽天モバイル", url = "https://network.mobile.rakuten.co.jp/product/smartphone/samsung-galaxy-z-fold8-ultra/", ramGb = 12),
        Entry("Galaxy Z Flip8", "Samsung", "Galaxy Z", 2026, storageGb = 256, channel = SalesChannel.RAKUTEN, retailer = "楽天モバイル", url = "https://network.mobile.rakuten.co.jp/product/smartphone/"),
        Entry("AQUOS wish6", "SHARP", "AQUOS wish", 2026, storageGb = 128, channel = SalesChannel.RAKUTEN, retailer = "楽天モバイル", url = "https://network.mobile.rakuten.co.jp/product/smartphone/"),
        Entry("arrows Alpha2", "FCNT", "arrows", 2026, storageGb = 256, channel = SalesChannel.RAKUTEN, retailer = "楽天モバイル", url = "https://network.mobile.rakuten.co.jp/product/smartphone/arrows-alpha2/", ramGb = 8),
        Entry("arrows Alpha2", "FCNT", "arrows", 2026, storageGb = 512, channel = SalesChannel.RAKUTEN, retailer = "楽天モバイル", url = "https://network.mobile.rakuten.co.jp/product/smartphone/arrows-alpha2/", ramGb = 12),
        Entry("moto g37j", "Motorola", "moto g", 2026, storageGb = 128, channel = SalesChannel.RAKUTEN, retailer = "楽天モバイル", url = "https://network.mobile.rakuten.co.jp/product/smartphone/"),
        Entry("motorola edge 70 fusion", "Motorola", "edge", 2026, storageGb = 256, channel = SalesChannel.RAKUTEN, retailer = "楽天モバイル", url = "https://network.mobile.rakuten.co.jp/product/smartphone/motorola-edge-70-fusion/", availability = AvailabilityStatus.PREORDER),
        Entry("Phone (4a) Pro", "Nothing", "Phone", 2026, storageGb = 256, channel = SalesChannel.RAKUTEN, retailer = "楽天モバイル", url = "https://network.mobile.rakuten.co.jp/product/smartphone/"),
        // 0.01.03 official reverse-audit: Rakuten Mobile currently lists the 2025 iPhone family.
        Entry("iPhone 17", "Apple", "iPhone", 2025, platform = "IPHONE", storageGb = 256, channel = SalesChannel.RAKUTEN, retailer = "楽天モバイル", url = "https://network.mobile.rakuten.co.jp/product/iphone/iphone-17/"),
        Entry("iPhone 17", "Apple", "iPhone", 2025, platform = "IPHONE", storageGb = 512, channel = SalesChannel.RAKUTEN, retailer = "楽天モバイル", url = "https://network.mobile.rakuten.co.jp/product/iphone/iphone-17/"),
        Entry("iPhone 17e", "Apple", "iPhone", 2026, platform = "IPHONE", storageGb = 256, channel = SalesChannel.RAKUTEN, retailer = "楽天モバイル", url = "https://network.mobile.rakuten.co.jp/product/iphone/iphone-17e/"),
        Entry("iPhone 17e", "Apple", "iPhone", 2026, platform = "IPHONE", storageGb = 512, channel = SalesChannel.RAKUTEN, retailer = "楽天モバイル", url = "https://network.mobile.rakuten.co.jp/product/iphone/iphone-17e/"),
        Entry("iPhone Air", "Apple", "iPhone", 2025, platform = "IPHONE", storageGb = 256, channel = SalesChannel.RAKUTEN, retailer = "楽天モバイル", url = "https://network.mobile.rakuten.co.jp/product/iphone/iphone-air/"),
        Entry("iPhone Air", "Apple", "iPhone", 2025, platform = "IPHONE", storageGb = 512, channel = SalesChannel.RAKUTEN, retailer = "楽天モバイル", url = "https://network.mobile.rakuten.co.jp/product/iphone/iphone-air/"),
        Entry("iPhone Air", "Apple", "iPhone", 2025, platform = "IPHONE", storageGb = 1024, channel = SalesChannel.RAKUTEN, retailer = "楽天モバイル", url = "https://network.mobile.rakuten.co.jp/product/iphone/iphone-air/"),
        Entry("iPhone 17 Pro", "Apple", "iPhone", 2025, platform = "IPHONE", storageGb = 256, channel = SalesChannel.RAKUTEN, retailer = "楽天モバイル", url = "https://network.mobile.rakuten.co.jp/product/iphone/iphone-17-pro/"),
        Entry("iPhone 17 Pro", "Apple", "iPhone", 2025, platform = "IPHONE", storageGb = 512, channel = SalesChannel.RAKUTEN, retailer = "楽天モバイル", url = "https://network.mobile.rakuten.co.jp/product/iphone/iphone-17-pro/"),
        Entry("iPhone 17 Pro", "Apple", "iPhone", 2025, platform = "IPHONE", storageGb = 1024, channel = SalesChannel.RAKUTEN, retailer = "楽天モバイル", url = "https://network.mobile.rakuten.co.jp/product/iphone/iphone-17-pro/"),
        Entry("iPhone 17 Pro Max", "Apple", "iPhone", 2025, platform = "IPHONE", storageGb = 256, channel = SalesChannel.RAKUTEN, retailer = "楽天モバイル", url = "https://network.mobile.rakuten.co.jp/product/iphone/iphone-17-pro-max/"),
        Entry("iPhone 17 Pro Max", "Apple", "iPhone", 2025, platform = "IPHONE", storageGb = 512, channel = SalesChannel.RAKUTEN, retailer = "楽天モバイル", url = "https://network.mobile.rakuten.co.jp/product/iphone/iphone-17-pro-max/"),
        Entry("iPhone 17 Pro Max", "Apple", "iPhone", 2025, platform = "IPHONE", storageGb = 1024, channel = SalesChannel.RAKUTEN, retailer = "楽天モバイル", url = "https://network.mobile.rakuten.co.jp/product/iphone/iphone-17-pro-max/"),
        Entry("iPhone 17 Pro Max", "Apple", "iPhone", 2025, platform = "IPHONE", storageGb = 2048, channel = SalesChannel.RAKUTEN, retailer = "楽天モバイル", url = "https://network.mobile.rakuten.co.jp/product/iphone/iphone-17-pro-max/"),

        // Rakuten Mobile current Android lineup cross-audit (2026-09-30):
        Entry("Google Pixel 10a", "Google", "Pixel", 2026, storageGb = 128, channel = SalesChannel.RAKUTEN, retailer = "楽天モバイル", url = "https://network.mobile.rakuten.co.jp/product/smartphone/google-pixel-10a/"),
        Entry("Google Pixel 10a", "Google", "Pixel", 2026, storageGb = 256, channel = SalesChannel.RAKUTEN, retailer = "楽天モバイル", url = "https://network.mobile.rakuten.co.jp/product/smartphone/google-pixel-10a/"),
        Entry("Pixel 10", "Google", "Pixel", 2025, storageGb = 128, channel = SalesChannel.RAKUTEN, retailer = "楽天モバイル", url = "https://network.mobile.rakuten.co.jp/product/smartphone/google-pixel-10/"),
        Entry("Pixel 10", "Google", "Pixel", 2025, storageGb = 256, channel = SalesChannel.RAKUTEN, retailer = "楽天モバイル", url = "https://network.mobile.rakuten.co.jp/product/smartphone/google-pixel-10/"),
        Entry("Pixel 10 Pro", "Google", "Pixel", 2025, storageGb = 256, channel = SalesChannel.RAKUTEN, retailer = "楽天モバイル", url = "https://network.mobile.rakuten.co.jp/product/smartphone/google-pixel-10-pro/"),
        Entry("Galaxy A25 5G", "Samsung", "Galaxy A", 2025, storageGb = 64, channel = SalesChannel.RAKUTEN, retailer = "楽天モバイル", url = "https://network.mobile.rakuten.co.jp/product/smartphone/"),
        Entry("OPPO A5 5G", "OPPO", "A", 2025, storageGb = 128, channel = SalesChannel.RAKUTEN, retailer = "楽天モバイル", url = "https://network.mobile.rakuten.co.jp/product/smartphone/"),
        Entry("OPPO Reno15 A", "OPPO", "Reno", 2026, storageGb = 128, channel = SalesChannel.RAKUTEN, retailer = "楽天モバイル", url = "https://network.mobile.rakuten.co.jp/product/smartphone/reno15-a/"),
        Entry("OPPO Reno13 A", "OPPO", "Reno", 2025, storageGb = 128, channel = SalesChannel.RAKUTEN, retailer = "楽天モバイル", url = "https://network.mobile.rakuten.co.jp/product/smartphone/"),
        Entry("Phone (3)", "Nothing", "Phone", 2025, storageGb = 256, channel = SalesChannel.RAKUTEN, retailer = "楽天モバイル", url = "https://network.mobile.rakuten.co.jp/product/smartphone/"),
        Entry("Phone (3a)", "Nothing", "Phone", 2025, storageGb = 128, channel = SalesChannel.RAKUTEN, retailer = "楽天モバイル", url = "https://network.mobile.rakuten.co.jp/product/smartphone/"),
        Entry("Phone (3a) Lite", "Nothing", "Phone", 2025, storageGb = 128, channel = SalesChannel.RAKUTEN, retailer = "楽天モバイル", url = "https://network.mobile.rakuten.co.jp/product/smartphone/phone-3a-lite/"),
        Entry("nubia S2R", "nubia", "S", 2025, storageGb = 64, channel = SalesChannel.RAKUTEN, retailer = "楽天モバイル", url = "https://network.mobile.rakuten.co.jp/product/smartphone/"),
        Entry("AQUOS R10", "SHARP", "AQUOS R", 2025, storageGb = 256, channel = SalesChannel.RAKUTEN, retailer = "楽天モバイル", url = "https://network.mobile.rakuten.co.jp/product/smartphone/"),
        Entry("AQUOS sense10", "SHARP", "AQUOS sense", 2025, storageGb = 128, channel = SalesChannel.RAKUTEN, retailer = "楽天モバイル", url = "https://network.mobile.rakuten.co.jp/product/smartphone/"),
        Entry("AQUOS sense9", "SHARP", "AQUOS sense", 2024, storageGb = 128, channel = SalesChannel.RAKUTEN, retailer = "楽天モバイル", url = "https://network.mobile.rakuten.co.jp/product/smartphone/aquos-sense9/"),
        Entry("AQUOS wish5", "SHARP", "AQUOS wish", 2025, storageGb = 128, channel = SalesChannel.RAKUTEN, retailer = "楽天モバイル", url = "https://network.mobile.rakuten.co.jp/product/smartphone/"),
        Entry("arrows Alpha", "FCNT", "arrows", 2025, storageGb = 512, channel = SalesChannel.RAKUTEN, retailer = "楽天モバイル", url = "https://network.mobile.rakuten.co.jp/product/smartphone/"),

    )

    suspend fun ensureSeeded(db: AppDatabase) = db.withTransaction {
        entries.forEach { entry ->
            val variantId = findOrCreateVariant(db, entry) ?: return@forEach
            val retailerId = db.phoneDao().getRetailerId(entry.retailer)
                ?: db.phoneDao().insertRetailers(listOf(RetailerEntity(
                    name = entry.retailer,
                    type = RetailerType.CARRIER,
                    official = true,
                    websiteUrl = entry.url
                ))).single()
            val salesVariantId = db.phoneDao().getSalesVariantId(variantId, entry.channel, entry.modelNumber)
                ?: db.phoneDao().insertSalesVariants(listOf(SalesVariantEntity(
                    deviceVariantId = variantId,
                    salesChannel = entry.channel,
                    modelNumber = entry.modelNumber,
                    simType = "キャリア販売"
                ))).single()
            db.phoneDao().getProductListingId(salesVariantId, retailerId)
                ?: db.phoneDao().insertProductListings(listOf(ProductListingEntity(
                    salesVariantId = salesVariantId,
                    retailerId = retailerId,
                    productUrl = entry.url,
                    productName = entry.model,
                    availability = entry.availability,
                    checkedAt = checkedAt
                )))
        }
    }

    private suspend fun findOrCreateVariant(db: AppDatabase, entry: Entry): Long? {
        // Sales data must never manufacture a Core Variant when RAM/storage cannot
        // be resolved uniquely. Core catalog registration is responsible for the
        // authoritative model/variant master.
        return db.phoneDao().getDeviceVariantIdByFullIdentity(
            modelName = entry.model,
            manufacturerName = entry.manufacturer,
            platform = entry.platform,
            releaseYear = entry.year,
            storageGb = entry.storageGb,
            ramGb = entry.ramGb
        )
    }
}
