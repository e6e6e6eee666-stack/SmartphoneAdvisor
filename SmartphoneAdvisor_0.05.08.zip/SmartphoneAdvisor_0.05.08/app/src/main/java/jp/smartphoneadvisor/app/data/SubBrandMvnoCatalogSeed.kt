package jp.smartphoneadvisor.app.data

import androidx.room.withTransaction

/**
 * 0.2.51: UQ mobile / Y!mobile / IIJmio / mineo の公式販売チャネルを追加。
 * 「動作確認済み」と「端末を販売している」は別物として扱い、販売を確認できたものだけ登録する。
 * 価格は条件付き価格と混同しないよう、今回のチャネル拡張では販売先・URL・販売状態を中心に登録する。
 */
object SubBrandMvnoCatalogSeed {
    private const val checkedAt = 1790294400000L // 2026-09-25

    private data class Entry(
        val model: String,
        val storageGb: Int,
        val channel: SalesChannel,
        val retailer: String,
        val url: String,
        val modelNumber: String? = null,
        val ramGb: Int? = null
    )

    private val entries = listOf(
        // UQ mobile official online shop: current lineup pages verified.
        Entry("Google Pixel 10a", 128, SalesChannel.UQ_MOBILE, "UQ mobile", "https://shop.uqmobile.jp/detail/google_pixel10a/"),
        Entry("Google Pixel 10a", 256, SalesChannel.UQ_MOBILE, "UQ mobile", "https://shop.uqmobile.jp/detail/google_pixel10a/"),
        Entry("AQUOS sense10", 128, SalesChannel.UQ_MOBILE, "UQ mobile", "https://shop.uqmobile.jp/shop/lineup/"),
        Entry("Xperia 10 VII", 128, SalesChannel.UQ_MOBILE, "UQ mobile", "https://shop.uqmobile.jp/detail/xperia_10_vii/"),
        Entry("arrows We3", 64, SalesChannel.UQ_MOBILE, "UQ mobile", "https://shop.uqmobile.jp/detail/arrows_we3/"),
        Entry("OPPO Reno15 A", 128, SalesChannel.UQ_MOBILE, "UQ mobile", "https://shop.uqmobile.jp/detail/oppo_reno15_a/"),
        Entry("motorola edge 60", 128, SalesChannel.UQ_MOBILE, "UQ mobile", "https://shop.uqmobile.jp/shop/lineup/"),
        Entry("OPPO A5 5G", 128, SalesChannel.UQ_MOBILE, "UQ mobile", "https://shop.uqmobile.jp/detail/oppo_a5_5g/"),
        Entry("OPPO Reno13 A", 128, SalesChannel.UQ_MOBILE, "UQ mobile", "https://shop.uqmobile.jp/detail/oppo_reno13_a/"),
        Entry("Galaxy A25 5G", 64, SalesChannel.UQ_MOBILE, "UQ mobile", "https://shop.uqmobile.jp/shop/lineup/"),
        Entry("らくらくスマートフォン Lite", 64, SalesChannel.UQ_MOBILE, "UQ mobile", "https://shop.uqmobile.jp/shop/lineup/"),
        Entry("BASIO active3", 64, SalesChannel.UQ_MOBILE, "UQ mobile", "https://shop.uqmobile.jp/detail/basio_active3/"),
        Entry("iPhone 17", 256, SalesChannel.UQ_MOBILE, "UQ mobile", "https://shop.uqmobile.jp/shop/lineup/"),
        Entry("iPhone 17", 512, SalesChannel.UQ_MOBILE, "UQ mobile", "https://shop.uqmobile.jp/shop/lineup/"),
        Entry("iPhone 17 Pro", 256, SalesChannel.UQ_MOBILE, "UQ mobile", "https://shop.uqmobile.jp/shop/lineup/"),
        Entry("iPhone 17 Pro", 512, SalesChannel.UQ_MOBILE, "UQ mobile", "https://shop.uqmobile.jp/shop/lineup/"),
        Entry("iPhone 17 Pro", 1024, SalesChannel.UQ_MOBILE, "UQ mobile", "https://shop.uqmobile.jp/shop/lineup/"),
        Entry("iPhone 17 Pro Max", 256, SalesChannel.UQ_MOBILE, "UQ mobile", "https://shop.uqmobile.jp/shop/lineup/"),
        Entry("iPhone 17 Pro Max", 512, SalesChannel.UQ_MOBILE, "UQ mobile", "https://shop.uqmobile.jp/shop/lineup/"),
        Entry("iPhone 17 Pro Max", 1024, SalesChannel.UQ_MOBILE, "UQ mobile", "https://shop.uqmobile.jp/shop/lineup/"),
        Entry("iPhone 17 Pro Max", 2048, SalesChannel.UQ_MOBILE, "UQ mobile", "https://shop.uqmobile.jp/shop/lineup/"),
        Entry("iPhone Air", 256, SalesChannel.UQ_MOBILE, "UQ mobile", "https://shop.uqmobile.jp/shop/lineup/"),
        Entry("iPhone Air", 512, SalesChannel.UQ_MOBILE, "UQ mobile", "https://shop.uqmobile.jp/shop/lineup/"),
        Entry("iPhone Air", 1024, SalesChannel.UQ_MOBILE, "UQ mobile", "https://shop.uqmobile.jp/shop/lineup/"),
        Entry("iPhone 17e", 256, SalesChannel.UQ_MOBILE, "UQ mobile", "https://shop.uqmobile.jp/detail/iphone17e/"),
        Entry("iPhone 17e", 512, SalesChannel.UQ_MOBILE, "UQ mobile", "https://shop.uqmobile.jp/detail/iphone17e/"),

        // 0.2.97 recovery: UQ mobile official lineup additions.
        Entry("iPhone 16", 128, SalesChannel.UQ_MOBILE, "UQ mobile", "https://shop.uqmobile.jp/shop/lineup/"),
        Entry("iPhone 16", 256, SalesChannel.UQ_MOBILE, "UQ mobile", "https://shop.uqmobile.jp/shop/lineup/"),
        Entry("iPhone 16", 512, SalesChannel.UQ_MOBILE, "UQ mobile", "https://shop.uqmobile.jp/shop/lineup/"),

        // Y!mobile: official pages identify these as devices sold by Y!mobile.
        // Y!mobile Free Style: 2026-07-09 first wave, official announcement verified.
        Entry("arrows Alpha2", 256, SalesChannel.Y_MOBILE, "Y!mobile Free Style", "https://www.ymobile.jp/lineup/simfree/", ramGb = 8),
        Entry("POCO M8 5G", 256, SalesChannel.Y_MOBILE, "Y!mobile Free Style", "https://www.ymobile.jp/lineup/simfree/"),
        Entry("POCO X8 Pro", 256, SalesChannel.Y_MOBILE, "Y!mobile Free Style", "https://www.ymobile.jp/lineup/simfree/pocox8pro/"),
        Entry("POCO X8 Pro Max", 256, SalesChannel.Y_MOBILE, "Y!mobile Free Style", "https://www.ymobile.jp/lineup/simfree/pocox8promax/"),
        Entry("OPPO Find X9", 512, SalesChannel.Y_MOBILE, "Y!mobile Free Style", "https://www.ymobile.jp/lineup/simfree/"),

        Entry("AQUOS wish6", 128, SalesChannel.Y_MOBILE, "Y!mobile", "https://www.ymobile.jp/lineup/smartphone/wish6/", modelNumber = "A603SH", ramGb = 4),
        Entry("REDMI Note 17 Pro Max 5G", 256, SalesChannel.Y_MOBILE, "Y!mobile Free Style", "https://order.ymobile.jp/store/CHDO0001/entry/redminote17promax/device?md=redminote17promax", ramGb = 8),
        Entry("REDMI Note 17 Pro Max 5G", 512, SalesChannel.Y_MOBILE, "Y!mobile Free Style", "https://order.ymobile.jp/store/CHDO0001/entry/redminote17promax/device?md=redminote17promax", ramGb = 8),
        Entry("かんたんスマホ4", 128, SalesChannel.Y_MOBILE, "Y!mobile", "https://www.ymobile.jp/lineup/smartphone/kantan4/", modelNumber = "A402ZT", ramGb = 4),
        Entry("かんたんスマホ5", 128, SalesChannel.Y_MOBILE, "Y!mobile", "https://www.ymobile.jp/lineup/smartphone/kantan5/", modelNumber = "A601ZT", ramGb = 6),
        Entry("OPPO Reno15 A", 128, SalesChannel.Y_MOBILE, "Y!mobile", "https://www.ymobile.jp/lineup/smartphone/reno15a/", modelNumber = "A601OP", ramGb = 8),
        Entry("moto g66y 5G", 128, SalesChannel.Y_MOBILE, "Y!mobile", "https://www.ymobile.jp/lineup/smartphone/motog66y/", ramGb = 4),
        Entry("moto g64y 5G", 128, SalesChannel.Y_MOBILE, "Y!mobile", "https://www.ymobile.jp/lineup/smartphone/motog64y/"),
        Entry("Libero Flip", 128, SalesChannel.Y_MOBILE, "Y!mobile", "https://www.ymobile.jp/lineup/libero_flip/"),
        Entry("OPPO Reno13 A", 128, SalesChannel.Y_MOBILE, "Y!mobile", "https://www.ymobile.jp/lineup/smartphone/reno13a/", ramGb = 8),
        Entry("AQUOS wish5", 128, SalesChannel.Y_MOBILE, "Y!mobile", "https://www.ymobile.jp/lineup/smartphone/wish5/", modelNumber = "A502SH", ramGb = 4),
        Entry("Google Pixel 10a", 128, SalesChannel.Y_MOBILE, "Y!mobile", "https://www.ymobile.jp/lineup/smartphone/pixel10a/", ramGb = 8),
        Entry("Google Pixel 10a", 256, SalesChannel.Y_MOBILE, "Y!mobile", "https://www.ymobile.jp/lineup/smartphone/pixel10a/", ramGb = 8),
        Entry("nubia Flip 3", 128, SalesChannel.Y_MOBILE, "Y!mobile", "https://www.ymobile.jp/lineup/smartphone/nubiaflip3/", modelNumber = "A505ZT", ramGb = 6),
        Entry("nubia S2", 128, SalesChannel.Y_MOBILE, "Y!mobile", "https://www.ymobile.jp/lineup/smartphone/nubia_s2/", ramGb = 6),

        // IIJmio official device lineup: current sales entries verified against official sales notices.
        Entry("Galaxy Z Flip8", 256, SalesChannel.IIJ_MIO, "IIJmio", "https://www.iijmio.jp/device/", ramGb = 12),
        Entry("Galaxy Z Flip8", 512, SalesChannel.IIJ_MIO, "IIJmio", "https://www.iijmio.jp/device/", ramGb = 12),
        Entry("Galaxy Z Fold8", 256, SalesChannel.IIJ_MIO, "IIJmio", "https://www.iijmio.jp/device/", ramGb = 12),
        Entry("Galaxy Z Fold8", 512, SalesChannel.IIJ_MIO, "IIJmio", "https://www.iijmio.jp/device/", ramGb = 12),
        Entry("Galaxy Z Fold8", 1024, SalesChannel.IIJ_MIO, "IIJmio", "https://www.iijmio.jp/device/", ramGb = 16),
        Entry("Galaxy Z Fold8 Ultra", 256, SalesChannel.IIJ_MIO, "IIJmio", "https://www.iijmio.jp/device/", ramGb = 12),
        Entry("Galaxy Z Fold8 Ultra", 512, SalesChannel.IIJ_MIO, "IIJmio", "https://www.iijmio.jp/device/", ramGb = 12),
        Entry("Galaxy Z Fold8 Ultra", 1024, SalesChannel.IIJ_MIO, "IIJmio", "https://www.iijmio.jp/device/", ramGb = 16),
        Entry("OPPO Find X9 Ultra", 512, SalesChannel.IIJ_MIO, "IIJmio", "https://www.iijmio.jp/device/", ramGb = 12),
        Entry("Galaxy A57 5G", 128, SalesChannel.IIJ_MIO, "IIJmio", "https://www.iijmio.jp/device/", ramGb = 8),
        Entry("Xiaomi 17T", 256, SalesChannel.IIJ_MIO, "IIJmio", "https://www.iijmio.jp/device/", ramGb = 12),
        Entry("Xiaomi 17T Pro", 256, SalesChannel.IIJ_MIO, "IIJmio", "https://www.iijmio.jp/device/", ramGb = 12),
        Entry("moto g37j", 128, SalesChannel.IIJ_MIO, "IIJmio", "https://www.iijmio.jp/device/", ramGb = 4),
        Entry("arrows Alpha2", 256, SalesChannel.IIJ_MIO, "IIJmio", "https://www.iijmio.jp/device/", ramGb = 8),
        Entry("motorola razr fold", 512, SalesChannel.IIJ_MIO, "IIJmio", "https://www.iijmio.jp/device/", ramGb = 16),
        Entry("motorola edge 60", 128, SalesChannel.IIJ_MIO, "IIJmio", "https://www.iijmio.jp/device/", ramGb = 8),
        Entry("Nothing Phone (4a)", 128, SalesChannel.IIJ_MIO, "IIJmio", "https://www.iijmio.jp/device/", ramGb = 8),
        Entry("AQUOS wish6", 128, SalesChannel.IIJ_MIO, "IIJmio", "https://www.iijmio.jp/device/", ramGb = 4),
        Entry("OPPO Reno16 5G", 256, SalesChannel.IIJ_MIO, "IIJmio", "https://www.iijmio.jp/device/", ramGb = 12),
        Entry("MIVEケースマ", 32, SalesChannel.IIJ_MIO, "IIJmio", "https://www.iijmio.jp/device/", ramGb = 3),
        Entry("Galaxy S26", 256, SalesChannel.IIJ_MIO, "IIJmio", "https://www.iijmio.jp/device/", ramGb = 12),
        Entry("Galaxy S26", 512, SalesChannel.IIJ_MIO, "IIJmio", "https://www.iijmio.jp/device/", ramGb = 12),
        Entry("Galaxy S26+", 256, SalesChannel.IIJ_MIO, "IIJmio", "https://www.iijmio.jp/device/", ramGb = 12),
        Entry("Galaxy S26+", 512, SalesChannel.IIJ_MIO, "IIJmio", "https://www.iijmio.jp/device/", ramGb = 12),
        Entry("Galaxy S26 Ultra", 256, SalesChannel.IIJ_MIO, "IIJmio", "https://www.iijmio.jp/device/", ramGb = 12),
        Entry("Galaxy S26 Ultra", 512, SalesChannel.IIJ_MIO, "IIJmio", "https://www.iijmio.jp/device/", ramGb = 12),
        Entry("Galaxy S26 Ultra", 1024, SalesChannel.IIJ_MIO, "IIJmio", "https://www.iijmio.jp/device/", ramGb = 16),
        Entry("Xiaomi 17 Ultra", 512, SalesChannel.IIJ_MIO, "IIJmio", "https://www.iijmio.jp/device/", ramGb = 16),
        Entry("OPPO Find N6", 512, SalesChannel.IIJ_MIO, "IIJmio", "https://www.iijmio.jp/device/oppo/findn6.html", ramGb = 16),
        Entry("REDMI Note 17 Pro Max 5G", 256, SalesChannel.IIJ_MIO, "IIJmio", "https://www.iijmio.jp/device/", ramGb = 8),
        Entry("REDMI Note 17 Pro Max 5G", 512, SalesChannel.IIJ_MIO, "IIJmio", "https://www.iijmio.jp/device/", ramGb = 8),

        // mineo official device lineup: currently listed devices.
        Entry("Redmi 14C", 128, SalesChannel.MINEO, "mineo", "https://mineo.jp/device/smartphone/"),
        Entry("らくらくスマートフォン Lite", 64, SalesChannel.MINEO, "mineo", "https://mineo.jp/device/smartphone/"),
        Entry("Xperia 10 VI", 128, SalesChannel.MINEO, "mineo", "https://mineo.jp/device/smartphone/"),
        Entry("arrows Alpha2", 256, SalesChannel.MINEO, "mineo", "https://mineo.jp/device/smartphone/", ramGb = 8),
        Entry("moto g66j 5G", 128, SalesChannel.MINEO, "mineo", "https://mineo.jp/device/smartphone/moto-g66j-5g/"),
        Entry("REDMI Note 14 Pro 5G", 256, SalesChannel.MINEO, "mineo", "https://mineo.jp/device/smartphone/redmi-note-14-pro-5g/"),
        Entry("REDMI Note 14 Pro 5G", 512, SalesChannel.MINEO, "mineo", "https://mineo.jp/device/smartphone/redmi-note-14-pro-5g/"),
        Entry("REDMI Note 15 Pro 5G", 256, SalesChannel.MINEO, "mineo", "https://mineo.jp/device/smartphone/redmi-note-15-pro-5g-8gb-256gb/"),
        Entry("moto g37j", 128, SalesChannel.MINEO, "mineo", "https://mineo.jp/device/smartphone/"),
        Entry("motorola edge 60", 128, SalesChannel.MINEO, "mineo", "https://mineo.jp/device/smartphone/"),
        Entry("AQUOS R11", 256, SalesChannel.MINEO, "mineo", "https://mineo.jp/device/smartphone/", ramGb = 12),
        Entry("AQUOS R11", 512, SalesChannel.MINEO, "mineo", "https://mineo.jp/device/smartphone/", ramGb = 12),
        Entry("AQUOS wish6", 128, SalesChannel.MINEO, "mineo", "https://mineo.jp/device/smartphone/", ramGb = 4),
        Entry("OPPO Reno16 5G", 256, SalesChannel.MINEO, "mineo", "https://mineo.jp/device/smartphone/", ramGb = 12),
        Entry("OPPO Reno15 A", 256, SalesChannel.MINEO, "mineo", "https://mineo.jp/device/smartphone/", ramGb = 12),
        Entry("OPPO Reno15 A", 128, SalesChannel.MINEO, "mineo", "https://mineo.jp/device/smartphone/", ramGb = 8),
        Entry("arrows Alpha2", 512, SalesChannel.MINEO, "mineo", "https://mineo.jp/device/smartphone/", ramGb = 12),
        Entry("arrows We3", 64, SalesChannel.MINEO, "mineo", "https://mineo.jp/device/smartphone/"),
        Entry("arrows We3", 128, SalesChannel.MINEO, "mineo", "https://mineo.jp/device/smartphone/"),
        Entry("AQUOS sense10", 256, SalesChannel.MINEO, "mineo", "https://mineo.jp/device/smartphone/"),
        Entry("motorola razr 60", 512, SalesChannel.MINEO, "mineo", "https://mineo.jp/device/smartphone/"),
        Entry("moto g06", 128, SalesChannel.MINEO, "mineo", "https://mineo.jp/device/smartphone/"),
        Entry("Xiaomi 17T", 256, SalesChannel.MINEO, "mineo", "https://mineo.jp/device/smartphone/"),
        Entry("Xiaomi 17T Pro", 256, SalesChannel.MINEO, "mineo", "https://mineo.jp/device/smartphone/"),
        Entry("Mode1 Pocket", 256, SalesChannel.MINEO, "mineo", "https://mineo.jp/device/smartphone/mode1-pocket-8gb-256gb/"),
        Entry("AQUOS R10", 256, SalesChannel.MINEO, "mineo", "https://mineo.jp/device/smartphone/"),
        Entry("AQUOS R10", 512, SalesChannel.MINEO, "mineo", "https://mineo.jp/device/smartphone/"),
        Entry("REDMI Note 15 5G", 256, SalesChannel.MINEO, "mineo", "https://mineo.jp/device/smartphone/"),
        Entry("REDMI 15 5G", 128, SalesChannel.MINEO, "mineo", "https://mineo.jp/device/smartphone/"),
        Entry("REDMI 15 5G", 256, SalesChannel.MINEO, "mineo", "https://mineo.jp/device/smartphone/"),
        Entry("Redmi 14C", 256, SalesChannel.MINEO, "mineo", "https://mineo.jp/device/smartphone/"),
        Entry("OPPO A5x", 128, SalesChannel.MINEO, "mineo", "https://mineo.jp/device/smartphone/"),
        Entry("arrows Alpha", 512, SalesChannel.MINEO, "mineo", "https://mineo.jp/device/smartphone/"),
    Entry("Xperia 10 VII", 128, SalesChannel.MINEO, "mineo", "https://mineo.jp/device/smartphone/", ramGb = 8),
    Entry("OPPO A5 5G", 128, SalesChannel.MINEO, "mineo", "https://mineo.jp/device/smartphone/"),
    Entry("arrows We2", 128, SalesChannel.MINEO, "mineo", "https://mineo.jp/device/smartphone/"),
    )

    suspend fun ensureSeeded(db: AppDatabase) = db.withTransaction {
        entries.forEach { entry ->
            val variantId = db.phoneDao().getDeviceVariantIdByModelAndStorage(entry.model, entry.storageGb, entry.ramGb) ?: return@forEach
            val retailerId = db.phoneDao().getRetailerId(entry.retailer)
                ?: db.phoneDao().insertRetailers(listOf(
                    RetailerEntity(
                        name = entry.retailer,
                        type = when (entry.channel) {
                            SalesChannel.UQ_MOBILE, SalesChannel.Y_MOBILE -> RetailerType.CARRIER
                            else -> RetailerType.MVNO
                        },
                        official = true,
                        websiteUrl = entry.url
                    )
                )).single()
            val salesVariantId = db.phoneDao().getSalesVariantId(variantId, entry.channel, entry.modelNumber)
                ?: db.phoneDao().insertSalesVariants(listOf(
                    SalesVariantEntity(
                        deviceVariantId = variantId,
                        salesChannel = entry.channel,
                        modelNumber = entry.modelNumber,
                        simType = "SIMフリー/回線セット"
                    )
                )).single()
            if (db.phoneDao().getProductListingId(salesVariantId, retailerId) == null) {
                db.phoneDao().insertProductListings(listOf(
                    ProductListingEntity(
                        salesVariantId = salesVariantId,
                        retailerId = retailerId,
                        productUrl = entry.url,
                        productName = entry.model,
                        availability = AvailabilityStatus.AVAILABLE,
                        checkedAt = checkedAt
                    )
                ))
            }
        }
    }
}
