package jp.smartphoneadvisor.app.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Upsert
import kotlinx.coroutines.flow.Flow

@Dao
interface DiagnosticDao {
    @Query("SELECT * FROM diagnostic_profile WHERE isActive = 1 ORDER BY updatedAt DESC")
    fun observeProfiles(): Flow<List<DiagnosticProfileEntity>>

    @Query("SELECT COUNT(*) FROM diagnostic_profile WHERE isActive = 1")
    suspend fun activeProfileCount(): Int

    @Upsert
    suspend fun upsertProfile(profile: DiagnosticProfileEntity): Long

    @Upsert
    suspend fun upsertAnswer(answer: DiagnosticAnswerEntity)

    @Query("SELECT * FROM diagnostic_answer WHERE profileId = :profileId")
    suspend fun getAnswers(profileId: Long): List<DiagnosticAnswerEntity>

    @Query("SELECT * FROM diagnostic_profile WHERE isActive = 1 ORDER BY updatedAt DESC LIMIT 3")
    suspend fun getActiveProfiles(): List<DiagnosticProfileEntity>

    @Query("DELETE FROM diagnostic_answer WHERE profileId = :profileId")
    suspend fun deleteAnswers(profileId: Long)

    @Query("UPDATE diagnostic_profile SET isActive = 0, updatedAt = :updatedAt WHERE id = :profileId")
    suspend fun archiveProfile(profileId: Long, updatedAt: Long)

    @Query("SELECT * FROM diagnostic_profile WHERE id = :profileId LIMIT 1")
    suspend fun getProfile(profileId: Long): DiagnosticProfileEntity?

    @Query("UPDATE diagnostic_profile SET name = :name, updatedAt = :updatedAt WHERE id = :profileId")
    suspend fun renameProfile(profileId: Long, name: String, updatedAt: Long)

    @Query("UPDATE diagnostic_profile SET updatedAt = :updatedAt, lastRunAt = :updatedAt WHERE id = :profileId")
    suspend fun markRun(profileId: Long, updatedAt: Long)

    @Insert
    suspend fun insertRun(run: DiagnosticRunEntity)

    @Query("SELECT * FROM diagnostic_run WHERE profileId = :profileId ORDER BY executedAt DESC")
    suspend fun getRuns(profileId: Long): List<DiagnosticRunEntity>

    @Query("SELECT * FROM diagnostic_draft WHERE id = 1 LIMIT 1")
    suspend fun getDraft(): DiagnosticDraftEntity?

    @Upsert
    suspend fun upsertDraft(draft: DiagnosticDraftEntity)

    @Query("DELETE FROM diagnostic_draft WHERE id = 1")
    suspend fun clearDraft()
}
