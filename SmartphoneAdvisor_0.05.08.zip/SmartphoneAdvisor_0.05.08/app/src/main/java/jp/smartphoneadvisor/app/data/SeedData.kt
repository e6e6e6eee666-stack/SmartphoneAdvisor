package jp.smartphoneadvisor.app.data

import androidx.room.withTransaction

object SeedData {
    private const val seedSourceName = "初期テストデータ"

    /** Model identity is independent of storage/RAM; variants of one model share one model row. */
    private data class ModelKey(
        val manufacturer: String,
        val model: String,
        val platform: String,
        val releaseYear: Int
    )

    data class PhoneSeed(
        val manufacturer: String,
        val model: String,
        val series: String?,
        val platform: String,
        val year: Int,
        val storageGb: Int,
        val ramGb: Int?,
        val gaming: AttributeLevel,
        val camera: AttributeLevel,
        val battery: AttributeLevel,
        val generalLevel: AttributeLevel = AttributeLevel.UNKNOWN,
        val workStudyLevel: AttributeLevel = AttributeLevel.UNKNOWN,
        val videoLevel: AttributeLevel = AttributeLevel.UNKNOWN,
        val aiLevel: AttributeLevel = AttributeLevel.UNKNOWN,
        val osaifuKeitai: SupportStatus = SupportStatus.UNKNOWN,
        val waterproof: SupportStatus = SupportStatus.UNKNOWN,
        val esim: SupportStatus = SupportStatus.UNKNOWN,
        val fingerprint: SupportStatus = SupportStatus.SUPPORTED,
        val wirelessCharging: SupportStatus = SupportStatus.UNKNOWN,
        val microSd: SupportStatus = SupportStatus.UNKNOWN,
        val headphoneJack: SupportStatus = SupportStatus.UNKNOWN,
        val physical: PhysicalSpecsEntity? = null,
        val display: DisplaySpecsEntity? = null,
        val cameraSpecs: CameraSpecsEntity? = null,
        val batterySpecs: BatterySpecsEntity? = null,
        val connectivitySpecs: ConnectivitySpecsEntity? = null,
        val softwareSpecs: SoftwareSpecsEntity? = null,
        val testNormalPriceYen: Int? = 100_000
    )

    // 初期動作確認用。最終カタログではありません。
    val phones = listOf(
        PhoneSeed(
            manufacturer = "Google", model = "Pixel 10", series = "Pixel", platform = "ANDROID", year = 2025,
            storageGb = 128, ramGb = 12, gaming = AttributeLevel.GOOD, camera = AttributeLevel.EXCELLENT,
            battery = AttributeLevel.GOOD, generalLevel = AttributeLevel.EXCELLENT, workStudyLevel = AttributeLevel.GOOD,
            videoLevel = AttributeLevel.EXCELLENT, aiLevel = AttributeLevel.EXCELLENT,
            osaifuKeitai = SupportStatus.SUPPORTED, waterproof = SupportStatus.NOT_SUPPORTED, esim = SupportStatus.NOT_SUPPORTED,
            testNormalPriceYen = 128_900
        ),
        PhoneSeed(
            manufacturer = "Google", model = "Pixel 10 Pro", series = "Pixel", platform = "ANDROID", year = 2025,
            storageGb = 256, ramGb = 16, gaming = AttributeLevel.GOOD, camera = AttributeLevel.EXCELLENT,
            battery = AttributeLevel.GOOD, generalLevel = AttributeLevel.EXCELLENT, workStudyLevel = AttributeLevel.EXCELLENT,
            videoLevel = AttributeLevel.EXCELLENT, aiLevel = AttributeLevel.EXCELLENT,
            osaifuKeitai = SupportStatus.SUPPORTED, waterproof = SupportStatus.NOT_SUPPORTED, esim = SupportStatus.NOT_SUPPORTED,
            testNormalPriceYen = 159_800
        ),
        PhoneSeed(
            manufacturer = "Google", model = "Pixel 10", series = "Pixel", platform = "ANDROID", year = 2025,
            storageGb = 256, ramGb = 12, gaming = AttributeLevel.GOOD, camera = AttributeLevel.EXCELLENT,
            battery = AttributeLevel.GOOD, generalLevel = AttributeLevel.EXCELLENT, workStudyLevel = AttributeLevel.GOOD,
            videoLevel = AttributeLevel.EXCELLENT, aiLevel = AttributeLevel.EXCELLENT,
            osaifuKeitai = SupportStatus.SUPPORTED, waterproof = SupportStatus.NOT_SUPPORTED, esim = SupportStatus.NOT_SUPPORTED,
            testNormalPriceYen = 145_000
        ),
        PhoneSeed(
            manufacturer = "Google", model = "Pixel 10 Pro", series = "Pixel", platform = "ANDROID", year = 2025,
            storageGb = 512, ramGb = 16, gaming = AttributeLevel.GOOD, camera = AttributeLevel.EXCELLENT,
            battery = AttributeLevel.GOOD, generalLevel = AttributeLevel.EXCELLENT, workStudyLevel = AttributeLevel.EXCELLENT,
            videoLevel = AttributeLevel.EXCELLENT, aiLevel = AttributeLevel.EXCELLENT,
            osaifuKeitai = SupportStatus.SUPPORTED, waterproof = SupportStatus.NOT_SUPPORTED, esim = SupportStatus.NOT_SUPPORTED,
            testNormalPriceYen = 194_900
        ),
        PhoneSeed(
            manufacturer = "Apple", model = "iPhone 17", series = "iPhone", platform = "IPHONE", year = 2025,
            storageGb = 256, ramGb = 8, gaming = AttributeLevel.GOOD, camera = AttributeLevel.EXCELLENT,
            battery = AttributeLevel.GOOD, generalLevel = AttributeLevel.EXCELLENT, workStudyLevel = AttributeLevel.EXCELLENT,
            videoLevel = AttributeLevel.EXCELLENT, aiLevel = AttributeLevel.EXCELLENT,
            osaifuKeitai = SupportStatus.SUPPORTED, waterproof = SupportStatus.NOT_SUPPORTED, esim = SupportStatus.NOT_SUPPORTED,
            testNormalPriceYen = 124_800
        ),
        PhoneSeed(
            manufacturer = "Samsung", model = "Galaxy S26", series = "Galaxy S", platform = "ANDROID", year = 2026,
            storageGb = 256, ramGb = 12, gaming = AttributeLevel.EXCELLENT, camera = AttributeLevel.GOOD,
            battery = AttributeLevel.GOOD, generalLevel = AttributeLevel.EXCELLENT, workStudyLevel = AttributeLevel.EXCELLENT,
            videoLevel = AttributeLevel.GOOD, aiLevel = AttributeLevel.EXCELLENT,
            osaifuKeitai = SupportStatus.SUPPORTED, waterproof = SupportStatus.NOT_SUPPORTED, esim = SupportStatus.NOT_SUPPORTED,
            testNormalPriceYen = 136_400
        ),
        PhoneSeed(
            manufacturer = "Sony", model = "Xperia 1 VII", series = "Xperia", platform = "ANDROID", year = 2025,
            storageGb = 256, ramGb = 12, gaming = AttributeLevel.EXCELLENT, camera = AttributeLevel.GOOD,
            battery = AttributeLevel.GOOD, generalLevel = AttributeLevel.GOOD, workStudyLevel = AttributeLevel.GOOD,
            videoLevel = AttributeLevel.GOOD, aiLevel = AttributeLevel.GOOD,
            osaifuKeitai = SupportStatus.SUPPORTED, waterproof = SupportStatus.SUPPORTED, esim = SupportStatus.SUPPORTED,
            testNormalPriceYen = 179_300
        ),
        PhoneSeed(
            manufacturer = "SHARP", model = "AQUOS sense10", series = "AQUOS sense", platform = "ANDROID", year = 2025,
            storageGb = 128, ramGb = 6, gaming = AttributeLevel.STANDARD, camera = AttributeLevel.GOOD,
            battery = AttributeLevel.GOOD, generalLevel = AttributeLevel.GOOD, workStudyLevel = AttributeLevel.GOOD,
            videoLevel = AttributeLevel.STANDARD, aiLevel = AttributeLevel.STANDARD,
            osaifuKeitai = SupportStatus.SUPPORTED, waterproof = SupportStatus.UNKNOWN, esim = SupportStatus.UNKNOWN,
            testNormalPriceYen = 69_800
        ),
        PhoneSeed(
            manufacturer = "Xiaomi", model = "Xiaomi 15T Pro", series = "Xiaomi T", platform = "ANDROID", year = 2025,
            storageGb = 256, ramGb = 12, gaming = AttributeLevel.EXCELLENT, camera = AttributeLevel.EXCELLENT,
            battery = AttributeLevel.GOOD, generalLevel = AttributeLevel.GOOD, workStudyLevel = AttributeLevel.GOOD,
            videoLevel = AttributeLevel.EXCELLENT, aiLevel = AttributeLevel.GOOD,
            osaifuKeitai = SupportStatus.SUPPORTED, waterproof = SupportStatus.NOT_SUPPORTED, esim = SupportStatus.NOT_SUPPORTED,
            testNormalPriceYen = 119_800
        )
,        PhoneSeed(
            manufacturer = "Google", model = "Pixel 11 Pro XL", series = "Pixel", platform = "ANDROID", year = 2026,
            storageGb = 256, ramGb = 12, gaming = AttributeLevel.EXCELLENT, camera = AttributeLevel.EXCELLENT,
            battery = AttributeLevel.EXCELLENT, generalLevel = AttributeLevel.EXCELLENT, workStudyLevel = AttributeLevel.EXCELLENT,
            videoLevel = AttributeLevel.EXCELLENT, aiLevel = AttributeLevel.EXCELLENT,
            waterproof = SupportStatus.SUPPORTED, esim = SupportStatus.SUPPORTED, fingerprint = SupportStatus.SUPPORTED,
            wirelessCharging = SupportStatus.SUPPORTED, microSd = SupportStatus.NOT_SUPPORTED, headphoneJack = SupportStatus.NOT_SUPPORTED,
            testNormalPriceYen = 207_800,
            physical = PhysicalSpecsEntity(0, 0, 162.7, 76.5, 8.5, 226.0, "Google公式"),
            display = DisplaySpecsEntity(0, 0, 70.0, 155.6, 6.8, "1344 x 2992", "LTPO OLED", 120, "対角・20:9から計算"),
            cameraSpecs = CameraSpecsEntity(0, 0, 50.0, 48.0, 48.0, 42.0, "8K 24/30fps、4K 24/30/60fps", "光学式・電子式手ぶれ補正", "Google公式"),
            batterySpecs = BatterySpecsEntity(0, 0, 5115, 45, SupportStatus.SUPPORTED, "30時間以上。45W以上のUSB-C PPS充電器使用時、約30分で最大75%", null, "Google公式"),
            connectivitySpecs = ConnectivitySpecsEntity(0, 0, SupportStatus.SUPPORTED, 2, SupportStatus.SUPPORTED, "Wi-Fi 7", "Bluetooth 6", "Google公式"),
            softwareSpecs = SoftwareSpecsEntity(0, 0, "Android 17", 7, "発売から7年間", "Google公式")
        ),
        PhoneSeed(
            manufacturer = "Sony", model = "Xperia 1 VIII", series = "Xperia", platform = "ANDROID", year = 2026,
            storageGb = 256, ramGb = 12, gaming = AttributeLevel.EXCELLENT, camera = AttributeLevel.EXCELLENT,
            battery = AttributeLevel.EXCELLENT, generalLevel = AttributeLevel.EXCELLENT, workStudyLevel = AttributeLevel.EXCELLENT,
            videoLevel = AttributeLevel.EXCELLENT, aiLevel = AttributeLevel.GOOD,
            waterproof = SupportStatus.SUPPORTED, esim = SupportStatus.SUPPORTED, fingerprint = SupportStatus.SUPPORTED,
            microSd = SupportStatus.SUPPORTED, headphoneJack = SupportStatus.SUPPORTED,
            testNormalPriceYen = null,
            physical = PhysicalSpecsEntity(0, 0, 162.0, 74.0, 8.3, 200.0, "ソニー公式"),
            display = DisplaySpecsEntity(0, 0, null, null, 6.5, "Full HD+", "有機EL", 120, "ソニー公式・画面縦横は未確認"),
            cameraSpecs = CameraSpecsEntity(0, 0, 48.0, 48.0, 48.0, 12.0, "公式ページ記載の動画仕様を確認後に拡充", "光学・動画機能は公式仕様を別途拡充", "ソニー公式"),
            batterySpecs = BatterySpecsEntity(0, 0, 5000, null, SupportStatus.SUPPORTED, null, null, "ソニー公式"),
            connectivitySpecs = ConnectivitySpecsEntity(0, 0, SupportStatus.SUPPORTED, 2, SupportStatus.SUPPORTED, "IEEE 802.11a/b/g/n/ac/ax/be", "Bluetooth 6.0 / LE Audio / Auracast", "ソニー公式"),
            softwareSpecs = SoftwareSpecsEntity(0, 0, null, 4, "6年間のセキュリティアップデート", "ソニー公式")
        )
    )

    suspend fun ensureSeeded(db: AppDatabase) = db.withTransaction {
        if (db.phoneDao().countDevices() == 0) {
            val manufacturerIds = mutableMapOf<String, Long>()
            phones.map { it.manufacturer }.distinct().forEach { name ->
                val id = db.phoneDao().insertManufacturers(listOf(ManufacturerEntity(name = name))).single()
                manufacturerIds[name] = id
            }

        // A model may have multiple storage/RAM variants. Create its model row once,
        // then attach each variant to that shared model ID instead of duplicating the model.
        val modelIds = mutableMapOf<ModelKey, Long>()
        phones.forEach { seed ->
            val modelKey = ModelKey(seed.manufacturer, seed.model, seed.platform, seed.year)
            val modelId = modelIds[modelKey] ?: db.phoneDao().insertModels(
                listOf(
                    SmartphoneModelEntity(
                        manufacturerId = manufacturerIds.getValue(seed.manufacturer),
                        seriesName = seed.series,
                        modelName = seed.model,
                        platform = seed.platform,
                        releaseYear = seed.year,
                        releaseDate = null,
                        isJapanOfficial = true
                    )
                )
            ).single().also { insertedId -> modelIds[modelKey] = insertedId }
            val variantId = db.phoneDao().insertVariants(
                listOf(
                    DeviceVariantEntity(
                        modelId = modelId,
                        storageGb = seed.storageGb,
                        ramGb = seed.ramGb
                    )
                )
            ).single()
            db.phoneDao().insertAttributes(
                listOf(
                    RecommendationAttributesEntity(
                        deviceVariantId = variantId,
                        gamingLevel = seed.gaming,
                        cameraLevel = seed.camera,
                        batterySuitability = seed.battery,
                        osaifuKeitai = seed.osaifuKeitai,
                        waterproof = seed.waterproof,
                        esim = seed.esim,
                        fingerprint = seed.fingerprint,
                        wirelessCharging = seed.wirelessCharging,
                        microSd = seed.microSd,
                        headphoneJack = seed.headphoneJack,
                        generalLevel = seed.generalLevel,
                        workStudyLevel = seed.workStudyLevel,
                        videoLevel = seed.videoLevel,
                        aiLevel = seed.aiLevel
                    )
                )
            )
            db.phoneDao().insertPrices(
                listOf(
                    PriceRecordEntity(
                        deviceVariantId = variantId,
                        priceType = "NORMAL",
                        priceYen = seed.testNormalPriceYen,
                        checkedAt = System.currentTimeMillis(),
                        isCurrent = true
                    )
                )
            )
            // 詳細スペックは、公式確認済みデータがあれば投入し、それ以外は未確認の器だけ作成する。
            db.phoneDao().insertPhysicalSpecs(listOf((seed.physical ?: PhysicalSpecsEntity(deviceVariantId = variantId)).copy(deviceVariantId = variantId, id = 0)))
            db.phoneDao().insertDisplaySpecs(listOf((seed.display ?: DisplaySpecsEntity(deviceVariantId = variantId)).copy(deviceVariantId = variantId, id = 0)))
            db.phoneDao().insertCameraSpecs(listOf((seed.cameraSpecs ?: CameraSpecsEntity(deviceVariantId = variantId)).copy(deviceVariantId = variantId, id = 0)))
            db.phoneDao().insertBatterySpecs(listOf((seed.batterySpecs ?: BatterySpecsEntity(deviceVariantId = variantId)).copy(deviceVariantId = variantId, id = 0)))
            db.phoneDao().insertConnectivitySpecs(listOf((seed.connectivitySpecs ?: ConnectivitySpecsEntity(deviceVariantId = variantId)).copy(deviceVariantId = variantId, id = 0)))
            db.phoneDao().insertSoftwareSpecs(listOf((seed.softwareSpecs ?: SoftwareSpecsEntity(deviceVariantId = variantId)).copy(deviceVariantId = variantId, id = 0)))
        }

        // 0.2.3以前に作られた端末データにも、今回のテスト価格を追加する。
        if (db.phoneDao().countPriceRecords() == 0) {
            val byModel = phones.associateBy { it.model }
            val existing = db.phoneDao().getAllDeviceModels()
            db.phoneDao().insertPrices(
                existing.mapNotNull { row ->
                    byModel[row.modelName]?.let { seed ->
                        PriceRecordEntity(
                            deviceVariantId = row.deviceVariantId,
                            priceType = "NORMAL",
                            priceYen = seed.testNormalPriceYen,
                            checkedAt = System.currentTimeMillis(),
                            isCurrent = true
                        )
                    }
                }
            )
        }
        }

        // 0.2.18: 公式仕様を確認した追加モデル。モデル名だけではなく、メーカー・OS・発売年・容量・RAMで存在確認する。
        // 既存モデルに新しい容量/RAMバリアントだけが不足している場合も追加できるようにする。
        val verifiedAdditions = phones.filter { it.model == "Pixel 11 Pro XL" || it.model == "Xperia 1 VIII" }
        val manufacturerIds = mutableMapOf<String, Long>()
        verifiedAdditions.map { it.manufacturer }.distinct().forEach { name ->
            manufacturerIds[name] = db.phoneDao().getManufacturerId(name)
                ?: db.phoneDao().insertManufacturers(listOf(ManufacturerEntity(name = name))).single().let { insertedId ->
                    if (insertedId >= 0L) insertedId else db.phoneDao().getManufacturerId(name)
                        ?: error("Manufacturer ID could not be resolved: $name")
                }
        }
        verifiedAdditions.forEach { seed ->
            val manufacturerId = manufacturerIds.getValue(seed.manufacturer)
            val modelId = db.phoneDao().getModelIdByIdentity(
                manufacturerId = manufacturerId,
                modelName = seed.model,
                platform = seed.platform,
                releaseYear = seed.year
            ) ?: db.phoneDao().insertModels(listOf(SmartphoneModelEntity(
                manufacturerId = manufacturerId,
                seriesName = seed.series,
                modelName = seed.model,
                platform = seed.platform,
                releaseYear = seed.year,
                releaseDate = null,
                isJapanOfficial = true
            ))).single().let { insertedId ->
                if (insertedId >= 0L) insertedId else db.phoneDao().getModelIdByIdentity(
                    manufacturerId, seed.model, seed.platform, seed.year
                ) ?: error("Model ID could not be resolved: ${seed.model}")
            }
            val existingVariantId = db.phoneDao().getDeviceVariantIdByModelIdStorageAndRam(
                modelId, seed.storageGb, seed.ramGb
            )
            if (existingVariantId != null) return@forEach

            val variantId = db.phoneDao().insertVariants(listOf(DeviceVariantEntity(
                modelId = modelId, storageGb = seed.storageGb, ramGb = seed.ramGb
            ))).single().let { insertedId ->
                if (insertedId >= 0L) insertedId else db.phoneDao().getDeviceVariantIdByModelIdStorageAndRam(
                    modelId, seed.storageGb, seed.ramGb
                ) ?: error("Variant ID could not be resolved: ${seed.model} ${seed.storageGb}GB/${seed.ramGb}GB")
            }
            db.phoneDao().insertAttributes(listOf(RecommendationAttributesEntity(
                deviceVariantId = variantId, gamingLevel = seed.gaming, cameraLevel = seed.camera, batterySuitability = seed.battery,
                osaifuKeitai = seed.osaifuKeitai, waterproof = seed.waterproof, esim = seed.esim, fingerprint = seed.fingerprint,
                wirelessCharging = seed.wirelessCharging, microSd = seed.microSd, headphoneJack = seed.headphoneJack,
                generalLevel = seed.generalLevel, workStudyLevel = seed.workStudyLevel, videoLevel = seed.videoLevel, aiLevel = seed.aiLevel
            )))
            db.phoneDao().insertPrices(listOf(PriceRecordEntity(deviceVariantId = variantId, priceType = "NORMAL", priceYen = seed.testNormalPriceYen, checkedAt = System.currentTimeMillis(), isCurrent = true)))
            db.phoneDao().insertPhysicalSpecs(listOf((seed.physical ?: PhysicalSpecsEntity(deviceVariantId = variantId)).copy(deviceVariantId = variantId, id = 0)))
            db.phoneDao().insertDisplaySpecs(listOf((seed.display ?: DisplaySpecsEntity(deviceVariantId = variantId)).copy(deviceVariantId = variantId, id = 0)))
            db.phoneDao().insertCameraSpecs(listOf((seed.cameraSpecs ?: CameraSpecsEntity(deviceVariantId = variantId)).copy(deviceVariantId = variantId, id = 0)))
            db.phoneDao().insertBatterySpecs(listOf((seed.batterySpecs ?: BatterySpecsEntity(deviceVariantId = variantId)).copy(deviceVariantId = variantId, id = 0)))
            db.phoneDao().insertConnectivitySpecs(listOf((seed.connectivitySpecs ?: ConnectivitySpecsEntity(deviceVariantId = variantId)).copy(deviceVariantId = variantId, id = 0)))
            db.phoneDao().insertSoftwareSpecs(listOf((seed.softwareSpecs ?: SoftwareSpecsEntity(deviceVariantId = variantId)).copy(deviceVariantId = variantId, id = 0)))
        }

        val seedSourceId = db.phoneDao().getDataSourceId(seedSourceName)
        if (seedSourceId != null) {
            db.phoneDao().attributeUnattributedPrices(seedSourceId)
        }

        // 0.2.20: 購入先情報の初期データ。公式購入ページだけを登録し、価格条件は別レコードで管理する。
        seedPurchaseData(db)
        // 0.2.47: 日本公式販売モデルの拡張カタログを追加。既存データは保持する。
        CatalogExpansion.ensureExpanded(db)
        // 0.2.48: 公式販売ページで確認した通常価格・SIMフリー販売情報を追加。
        VerifiedSalesSeed.ensureSeeded(db)
        SimFreeCatalogSeed.ensureSeeded(db)
        // 0.2.49: 主要キャリアの公式販売チャネルを追加。価格は条件分離のため別管理。
        CarrierCatalogSeed.ensureSeeded(db)
        // 0.2.51: UQ mobile / Y!mobile / IIJmio / mineo の公式販売チャネルを追加。
        SubBrandMvnoCatalogSeed.ensureSeeded(db)
    }

    private suspend fun seedPurchaseData(db: AppDatabase) {
        seedOfficialListing(
            db = db,
            modelName = "Pixel 11 Pro XL",
            retailerName = "Google Store Japan",
            retailerType = RetailerType.MANUFACTURER,
            salesChannel = SalesChannel.SIM_FREE,
            url = "https://store.google.com/jp/config/pixel_11_pro",
            priceYen = 207_800,
            note = "256GB / 12GB RAM。Google Storeの通常価格。確認日: 2026-09-25"
        )
        seedOfficialListing(
            db = db,
            modelName = "Xperia 1 VIII",
            retailerName = "ソニーストア",
            retailerType = RetailerType.MANUFACTURER,
            salesChannel = SalesChannel.SIM_FREE,
            url = "https://pur.store.sony.jp/xperia/products/xperia1m8/xperia1m8_purchase/",
            priceYen = 235_400,
            note = "12GB / 256GB。ソニーストア通常価格。確認日: 2026-09-25"
        )
    }

    private suspend fun seedOfficialListing(
        db: AppDatabase,
        modelName: String,
        retailerName: String,
        retailerType: RetailerType,
        salesChannel: SalesChannel,
        url: String,
        priceYen: Int,
        note: String
    ) {
        val variantId = db.phoneDao().getDeviceVariantIdByModel(modelName) ?: return
        val retailerId = db.phoneDao().getRetailerId(retailerName)
            ?: db.phoneDao().insertRetailers(listOf(RetailerEntity(
                name = retailerName, type = retailerType, official = true, websiteUrl = url
            ))).single()
        val salesVariantId = db.phoneDao().getSalesVariantId(variantId, salesChannel)
            ?: db.phoneDao().insertSalesVariants(listOf(SalesVariantEntity(
                deviceVariantId = variantId, salesChannel = salesChannel, simType = "SIMフリー"
            ))).single()
        val listingId = db.phoneDao().getProductListingId(salesVariantId, retailerId)
            ?: db.phoneDao().insertProductListings(listOf(ProductListingEntity(
                salesVariantId = salesVariantId, retailerId = retailerId, productUrl = url,
                productName = modelName, availability = AvailabilityStatus.AVAILABLE, checkedAt = System.currentTimeMillis()
            ))).single()
        if (db.phoneDao().countV2Prices(listingId) == 0) {
            db.phoneDao().insertPriceRecordsV2(listOf(PriceRecordV2Entity(
                productListingId = listingId, priceType = PriceType.NORMAL, priceYen = priceYen,
                conditions = note, checkedAt = System.currentTimeMillis()
            )))
        }
    }
}
