package jp.smartphoneadvisor.app.data

import androidx.room.withTransaction

/**
 * 0.2.89: メーカー公式SIMフリー販売チャネルの逆引き監査で確認した販売登録。
 * 販売価格とは分離し、日本向け公式販売ページが確認できた機種を登録する。
 */
object SimFreeCatalogSeed {
    private const val checkedAt = 1790726400000L // 2026-09-30

    private data class Entry(
        val model: String,
        val storageGb: Int,
        val retailer: String,
        val url: String,
        val availability: AvailabilityStatus = AvailabilityStatus.AVAILABLE,
        val ramGb: Int? = null
    )

    private val entries = listOf(
        // 2026-09-30 official Google Store reverse-audit. Pixel 9a remains listed but is currently out of stock.
        Entry("Pixel 9a", 128, "Google Store Japan", "https://store.google.com/jp/product/pixel_9a", AvailabilityStatus.OUT_OF_STOCK),
        Entry("Pixel 9a", 256, "Google Store Japan", "https://store.google.com/jp/product/pixel_9a", AvailabilityStatus.OUT_OF_STOCK),
        Entry("Pixel 10", 128, "Google Store Japan", "https://store.google.com/jp/product/pixel_10"),
        Entry("Pixel 10", 256, "Google Store Japan", "https://store.google.com/jp/product/pixel_10"),
        Entry("Pixel 10 Pro", 256, "Google Store Japan", "https://store.google.com/jp/product/pixel_10_pro"),
        // 2026-09-30 screenshot check: 512GB is listed but currently out of stock in Google Store Japan.
        Entry("Pixel 10 Pro", 512, "Google Store Japan", "https://store.google.com/jp/product/pixel_10_pro", AvailabilityStatus.OUT_OF_STOCK),
        Entry("ROG Phone 9", 256, "ASUS Store Japan", "https://rog.asus.com/jp/phones/rog-phone-9/"),
        Entry("ROG Phone 9 Pro", 512, "ASUS Store Japan", "https://rog.asus.com/jp/phones/rog-phone-9-pro/"),
        Entry("ROG Phone 9 Pro Edition", 1024, "ASUS Store Japan", "https://rog.asus.com/jp/phones/rog-phone-9-pro/"),
        Entry("Zenfone 12 Ultra", 256, "ASUS Store Japan", "https://www.asus.com/jp/mobile-handhelds/phones/zenfone/zenfone-12-ultra/"),
        Entry("nubia Z80 Ultra", 512, "nubia Store Japan", "https://jp.nubia.com/pages/nubia-z80-ultra"),
        Entry("nubia Z70 Ultra", 256, "nubia Store Japan", "https://jp.nubia.com/pages/nubia-z70-ultra"),
        Entry("nubia Z70 Ultra", 512, "nubia Store Japan", "https://jp.nubia.com/pages/nubia-z70-ultra"),
        Entry("nubia Z70S Ultra", 512, "nubia Store Japan", "https://jp.nubia.com/collections/nubia-z-series", AvailabilityStatus.OUT_OF_STOCK),
        Entry("nubia flip 2", 128, "nubia Store Japan", "https://jp.nubia.com/collections/nubia-z-series"),
        Entry("nubia S 5G", 128, "nubia Store Japan", "https://jp.nubia.com/collections/nubia-z-series"),
        Entry("Phone (4a) Pro", 256, "Nothing Store Japan", "https://jp.nothing.tech/products/phone-4a-pro", AvailabilityStatus.OUT_OF_STOCK),
        Entry("Phone (4a)", 128, "Nothing Store Japan", "https://jp.nothing.tech/products/phone-4a"),
        Entry("Phone (3)", 256, "Nothing Store Japan", "https://jp.nothing.tech/products/phone-3"),
        Entry("Phone (3a) Lite", 128, "Nothing Store Japan", "https://jp.nothing.tech/products/phone-3a-lite"),
        Entry("Phone (2a)", 256, "Nothing Store Japan", "https://jp.nothing.tech/products/phone-2a"),
        Entry("CMF Phone 2 Pro", 256, "Nothing Store Japan", "https://jp.nothing.tech/products/cmf-phone-2-pro"),
        Entry("CMF Phone 1", 256, "Nothing Store Japan", "https://jp.nothing.tech/collections/phones"),
        Entry("REDMAGIC 11 Pro", 256, "REDMAGIC Japan", "https://jp.redmagic.gg/pages/redmagic-11-pro"),
        Entry("REDMAGIC 11 Pro", 512, "REDMAGIC Japan", "https://jp.redmagic.gg/pages/redmagic-11-pro"),
        Entry("REDMAGIC 11 Pro", 1024, "REDMAGIC Japan", "https://jp.redmagic.gg/pages/redmagic-11-pro"),
        Entry("Xiaomi 17 Ultra", 512, "Xiaomi Japan", "https://buy.mi.com/jp/products/all"),
        Entry("Xiaomi 17T", 512, "Xiaomi Japan", "https://buy.mi.com/jp/products/all"),
        Entry("POCO F9 Ultra", 512, "Xiaomi Japan", "https://buy.mi.com/jp/products/all"),
        Entry("POCO F7", 256, "Xiaomi Japan", "https://buy.mi.com/jp/products/all"),
        Entry("POCO F7 Pro", 256, "Xiaomi Japan", "https://buy.mi.com/jp/products/all"),
        Entry("POCO F7 Ultra", 256, "Xiaomi Japan", "https://buy.mi.com/jp/products/all"),
        Entry("POCO F6 Pro", 512, "Xiaomi Japan", "https://buy.mi.com/jp/products/all"),
        Entry("POCO M7 Pro 5G", 256, "Xiaomi Japan", "https://buy.mi.com/jp/products/all")
    )

    suspend fun ensureSeeded(db: AppDatabase) = db.withTransaction {
        entries.forEach { entry ->
            val variantId = db.phoneDao().getDeviceVariantIdByModelAndStorage(entry.model, entry.storageGb, entry.ramGb)
                ?: return@forEach
            val sourceId = db.phoneDao().getDataSourceId(entry.retailer)
                ?: db.phoneDao().insertDataSources(listOf(
                    DataSourceEntity(entry.retailer, SourceType.MANUFACTURER_OFFICIAL, entry.url, true)
                )).single()
            val retailerId = db.phoneDao().getRetailerId(entry.retailer)
                ?: db.phoneDao().insertRetailers(listOf(
                    RetailerEntity(entry.retailer, RetailerType.MANUFACTURER, true, entry.url)
                )).single()
            val salesVariantId = db.phoneDao().getSalesVariantId(variantId, SalesChannel.SIM_FREE)
                ?: db.phoneDao().insertSalesVariants(listOf(
                    SalesVariantEntity(variantId, SalesChannel.SIM_FREE, simType = "SIMフリー")
                )).single()
            db.phoneDao().getProductListingId(salesVariantId, retailerId)
                ?: db.phoneDao().insertProductListings(listOf(
                    ProductListingEntity(
                        salesVariantId = salesVariantId,
                        retailerId = retailerId,
                        productUrl = entry.url,
                        productName = entry.model,
                        availability = entry.availability,
                        checkedAt = checkedAt
                    )
                )).single()
        }
    }
}
