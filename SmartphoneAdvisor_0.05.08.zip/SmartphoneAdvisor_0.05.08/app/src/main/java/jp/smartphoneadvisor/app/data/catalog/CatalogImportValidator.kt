package jp.smartphoneadvisor.app.data.catalog


/** Pure validation rules; no Room/network dependency, so this can run before publishing data. */
object CatalogImportValidator {
    fun validate(batch: CatalogImportBatch): List<String> {
        val errors = mutableListOf<String>()
        if (batch.schemaVersion != 1) errors += "Unsupported catalog schemaVersion: ${batch.schemaVersion}"
        if (batch.catalogVersion.isBlank()) errors += "catalogVersion is required"
        if (batch.records.isEmpty()) errors += "records must not be empty"

        val phoneKeys = mutableSetOf<String>()
        val canonicalIdentities = mutableMapOf<String, String>()
        batch.records.forEachIndexed { index, phone ->
            val prefix = "records[$index]"
            if (phone.manufacturerKey.isBlank()) errors += "$prefix.manufacturerKey is required"
            if (phone.seriesKey.isBlank()) errors += "$prefix.seriesKey is required"
            if (phone.modelKey.isBlank()) errors += "$prefix.modelKey is required"
            if (phone.modelName.isBlank()) errors += "$prefix.modelName is required"
            if (phone.releaseYear !in 2000..2100) errors += "$prefix.releaseYear is invalid"
            if (!phone.isJapanOfficial) errors += "$prefix must be Japan-official for this app's recommendation catalog"
            if (!phoneKeys.add(phone.modelKey)) errors += "$prefix.modelKey is duplicated: ${phone.modelKey}"
            val identity = CatalogModelIdentity.key(phone.manufacturerName, phone.modelName, phone.platform, phone.releaseYear)
            val previousModelKey = canonicalIdentities.putIfAbsent(identity, phone.modelKey)
            if (previousModelKey != null && previousModelKey != phone.modelKey) {
                errors += "$prefix duplicates canonical model identity '$identity' already used by modelKey '$previousModelKey'"
            }
            if (phone.variants.isEmpty()) errors += "$prefix.variants must not be empty"

            val variantKeys = mutableSetOf<String>()
            phone.variants.forEachIndexed { vIndex, variant ->
                val vp = "$prefix.variants[$vIndex]"
                if (variant.variantKey.isBlank()) errors += "$vp.variantKey is required"
                if (variant.storageGb <= 0) errors += "$vp.storageGb must be positive"
                if (variant.ramGb != null && variant.ramGb <= 0) errors += "$vp.ramGb must be positive"
                if (!variantKeys.add(variant.variantKey)) errors += "$vp.variantKey is duplicated: ${variant.variantKey}"
            }
        }
        return errors
    }

}
