package jp.smartphoneadvisor.app.data.catalog

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * JSON化した日本市場販売カタログを読み込むためのモデル。
 * phones.json は app/src/main/assets/ に配置する。
 *
 * この移行層は既存Room seedを直接破壊・置換せず、JSONを安全に読み込めるようにする。
 */
data class JsonPhoneCatalog(
    val schemaVersion: String,
    val generatedFrom: String,
    val phones: List<JsonPhone>,
    val auditFindings: List<JsonAuditFinding>
)

data class JsonPhone(
    val id: String,
    val manufacturer: String,
    val model: String,
    val series: String?,
    val platform: String,
    val releaseYear: Int,
    val isJapanOfficial: Boolean,
    val variants: List<JsonVariant>
)

data class JsonVariant(
    val storageGb: Int,
    val ramGb: Int?,
    val sales: List<JsonSalesListing>
)

data class JsonSalesListing(
    val channel: String,
    val retailer: String,
    val modelNumber: String?,
    val availability: String,
    val url: String?,
    val priceOptions: List<JsonPriceOption> = emptyList()
)

data class JsonPriceOption(
    val color: String?,
    val priceYen: Int,
    val priceType: String,
    val conditions: String?,
    val sourceUrl: String?,
    val checkedAt: String?
)

data class JsonAuditFinding(
    val model: String?,
    val storageGb: Int?,
    val ramGb: Int?,
    val modelNumber: String?,
    val channel: String?,
    val action: String?,
    val evidence: String?
)

object PhoneCatalogJsonParser {
    fun parse(jsonText: String): JsonPhoneCatalog {
        val root = JSONObject(jsonText)
        require(root.optString("schemaVersion").isNotBlank()) { "phones.json: schemaVersion is missing" }

        val phonesArray = root.optJSONArray("phones") ?: JSONArray()
        val phones = buildList(phonesArray.length()) {
            for (i in 0 until phonesArray.length()) {
                add(parsePhone(phonesArray.getJSONObject(i)))
            }
        }

        val auditArray = root.optJSONArray("auditFindings") ?: JSONArray()
        val findings = buildList(auditArray.length()) {
            for (i in 0 until auditArray.length()) {
                val item = auditArray.getJSONObject(i)
                add(
                    JsonAuditFinding(
                        model = item.optNullableString("model"),
                        storageGb = item.optNullableInt("storageGb"),
                        ramGb = item.optNullableInt("ramGb"),
                        modelNumber = item.optNullableString("modelNumber"),
                        channel = item.optNullableString("channel"),
                        action = item.optNullableString("action"),
                        evidence = item.optNullableString("evidence")
                    )
                )
            }
        }

        // If the generator supplies counts, verify them against the parsed content.
        // A stale count block can otherwise make an incomplete or mismatched catalog look valid.
        val counts = root.optJSONObject("counts")
        if (counts != null) {
            val actualCounts = mapOf(
                "phoneModels" to phones.size,
                "variants" to phones.sumOf { it.variants.size },
                "salesListings" to phones.sumOf { phone -> phone.variants.sumOf { it.sales.size } },
                "priceOptions" to phones.sumOf { phone -> phone.variants.sumOf { variant -> variant.sales.sumOf { it.priceOptions.size } } },
                "auditFindings" to findings.size
            )
            actualCounts.forEach { (key, actual) ->
                require(counts.has(key) && !counts.isNull(key)) {
                    "phones.json: counts.$key is missing"
                }
                require(counts.getInt(key) == actual) {
                    "phones.json: counts.$key=${counts.getInt(key)} does not match parsed value $actual"
                }
            }
        }

        return JsonPhoneCatalog(
            schemaVersion = root.getString("schemaVersion"),
            generatedFrom = root.optString("generatedFrom"),
            phones = phones,
            auditFindings = findings
        )
    }

    private fun parsePhone(item: JSONObject): JsonPhone {
        val variantsArray = item.optJSONArray("variants") ?: JSONArray()
        val variants = buildList(variantsArray.length()) {
            for (i in 0 until variantsArray.length()) {
                val variant = variantsArray.getJSONObject(i)
                val salesArray = variant.optJSONArray("sales") ?: JSONArray()
                val sales = buildList(salesArray.length()) {
                    for (j in 0 until salesArray.length()) {
                        val sale = salesArray.getJSONObject(j)
                        add(
                            JsonSalesListing(
                                channel = sale.getString("channel"),
                                retailer = sale.getString("retailer"),
                                modelNumber = sale.optNullableString("modelNumber"),
                                availability = sale.getString("availability"),
                                url = sale.optNullableString("url"),
                                priceOptions = parsePriceOptions(sale.optJSONArray("priceOptions"))
                            )
                        )
                    }
                }
                add(
                    JsonVariant(
                        storageGb = variant.getInt("storageGb"),
                        ramGb = variant.optNullableInt("ramGb"),
                        sales = sales
                    )
                )
            }
        }

        return JsonPhone(
            id = item.getString("id"),
            manufacturer = item.getString("manufacturer"),
            model = item.getString("model"),
            series = item.optNullableString("series"),
            platform = item.getString("platform"),
            releaseYear = item.getInt("releaseYear"),
            isJapanOfficial = item.optBoolean("isJapanOfficial", false),
            variants = variants
        )
    }

    private fun parsePriceOptions(array: JSONArray?): List<JsonPriceOption> {
        if (array == null) return emptyList()
        return buildList(array.length()) {
            for (i in 0 until array.length()) {
                val item = array.getJSONObject(i)
                add(
                    JsonPriceOption(
                        color = item.optNullableString("color"),
                        priceYen = item.getInt("priceYen"),
                        priceType = item.optString("priceType", "NORMAL"),
                        conditions = item.optNullableString("conditions"),
                        sourceUrl = item.optNullableString("sourceUrl"),
                        checkedAt = item.optNullableString("checkedAt")
                    )
                )
            }
        }
    }

    private fun JSONObject.optNullableString(key: String): String? =
        if (!has(key) || isNull(key)) null else optString(key).takeIf { it.isNotBlank() }

    private fun JSONObject.optNullableInt(key: String): Int? =
        if (!has(key) || isNull(key)) null else optInt(key)
}

object PhoneCatalogJsonLoader {
    private const val ASSET_NAME = "phones.json"

    fun load(context: Context): JsonPhoneCatalog {
        val jsonText = context.assets.open(ASSET_NAME).bufferedReader(Charsets.UTF_8).use { it.readText() }
        return PhoneCatalogJsonParser.parse(jsonText)
    }
}
