package jp.smartphoneadvisor.app.ui

import android.content.Context
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import jp.smartphoneadvisor.app.data.AppDatabase
import jp.smartphoneadvisor.app.data.CandidateOs
import jp.smartphoneadvisor.app.data.PhoneListRow
import jp.smartphoneadvisor.app.data.PrimaryUse
import jp.smartphoneadvisor.app.data.catalog.PhoneCatalogJsonLoader
import jp.smartphoneadvisor.app.domain.SinglePhoneDiagnosticEngine
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.Locale

private enum class Step { BUDGET, USE, MUST_HAVE, RESULT }

@Composable
fun SinglePhoneDiagnosticFlow(context: Context, onBack: () -> Unit) {
    var step by remember { mutableStateOf(Step.BUDGET) }
    var targetBudget by remember { mutableStateOf<Int?>(150_000) }
    var absoluteMax by remember { mutableStateOf<Int?>(200_000) }
    var os by remember { mutableStateOf(CandidateOs.EITHER) }
    var use by remember { mutableStateOf(PrimaryUse.GENERAL) }
    var osaifu by remember { mutableStateOf(false) }
    var microSd by remember { mutableStateOf(false) }
    var result by remember { mutableStateOf<SinglePhoneDiagnosticEngine.Result?>(null) }
    var loading by remember { mutableStateOf(false) }
    var noResultMessage by remember { mutableStateOf<String?>(null) }
    var diagnosticError by remember { mutableStateOf(false) }

    LaunchedEffect(loading) {
        if (!loading) return@LaunchedEffect
        val outcome = try {
            withContext(Dispatchers.IO) {
                val catalog = PhoneCatalogJsonLoader.load(context)
                val rows = AppDatabase.getInstance(context).phoneDao().searchJapanOfficialDevices(os.name, "")
                val candidates = SinglePhoneDiagnosticEngine.catalogCandidates(catalog, rows)
                SinglePhoneDiagnosticEngine.recommend(
                    SinglePhoneDiagnosticEngine.Requirement(
                        os = os,
                        targetBudgetYen = targetBudget,
                        absoluteMaxYen = absoluteMax,
                        primaryUse = use,
                        mustHaveOsaifuKeitai = osaifu,
                        mustHaveMicroSd = microSd
                    ), candidates
                )
            }
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (_: Exception) {
            // カタログ読込やDB検索の失敗で画面全体をクラッシュさせず、
            // 条件を満たす端末がない場合とは別のメッセージで案内する。
            result = null
            diagnosticError = true
            noResultMessage = "診断データの読み込み中に問題が発生しました。端末データを確認してから、もう一度お試しください。条件を緩めて未確認の機種を推薦することはありません。"
            loading = false
            step = Step.RESULT
            return@LaunchedEffect
        }
        result = outcome
        diagnosticError = false
        noResultMessage = if (outcome == null) {
            "現在の検証済みデータでは、指定した条件をすべて満たす1台を確認できませんでした。条件を勝手に緩めたり、未確認データを推測して推薦したりしません。"
        } else null
        loading = false
        step = Step.RESULT
    }

    Scaffold { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Text("スマホ診断", style = MaterialTheme.typography.headlineMedium)
                Text("一般的な1台持ちユーザー向けに、条件に合う1台を選びます。")
            }
            when (step) {
                Step.BUDGET -> item {
                    QuestionCard("1. 予算") {
                        Text("希望価格")
                        ChoiceRow(listOf(100_000 to "10万円", 150_000 to "15万円", 200_000 to "20万円", 250_000 to "25万円"), targetBudget) {
                            targetBudget = it
                            if (absoluteMax != null && absoluteMax!! < it) {
                                absoluteMax = listOf(100_000, 150_000, 200_000, 300_000).first { limit -> limit >= it }
                            }
                        }
                        Spacer(Modifier.height(12.dp))
                        Text("絶対上限")
                        ChoiceRow(listOf(100_000 to "10万円", 150_000 to "15万円", 200_000 to "20万円", 300_000 to "30万円"), absoluteMax) {
                            absoluteMax = it
                            if (targetBudget != null && targetBudget!! > it) targetBudget = it
                        }
                        if (targetBudget != null && absoluteMax != null && targetBudget!! > absoluteMax!!) {
                            Text("絶対上限は希望価格以上に設定してください。", color = MaterialTheme.colorScheme.error)
                        }
                        Spacer(Modifier.height(12.dp))
                        Text("OS")
                        ChoiceRow(listOf(CandidateOs.EITHER to "どちらでも", CandidateOs.ANDROID to "Android", CandidateOs.IPHONE to "iPhone"), os) { os = it }
                        Spacer(Modifier.height(12.dp))
                        Button(onClick = { step = Step.USE }, Modifier.fillMaxWidth()) { Text("次へ") }
                    }
                }
                Step.USE -> item {
                    QuestionCard("2. 主な用途") {
                        Text("一番よく使う用途を1つ選んでください。")
                        ChoiceRow(listOf(PrimaryUse.GENERAL to "普段使い", PrimaryUse.GAMING to "ゲーム", PrimaryUse.CAMERA to "写真・動画"), use) { use = it }
                        Spacer(Modifier.height(12.dp))
                        Button(onClick = { step = Step.MUST_HAVE }, Modifier.fillMaxWidth()) { Text("次へ") }
                        OutlinedButton(onClick = { step = Step.BUDGET }, Modifier.fillMaxWidth()) { Text("戻る") }
                    }
                }
                Step.MUST_HAVE -> item {
                    QuestionCard("3. 必須機能") {
                        Text("なくても困らない機能は選ばなくて大丈夫です。")
                        Spacer(Modifier.height(8.dp))
                        FilterChip(selected = osaifu, onClick = { osaifu = !osaifu }, label = { Text("おサイフケータイ") })
                        FilterChip(selected = microSd, onClick = { microSd = !microSd }, label = { Text("SDカード") })
                        Spacer(Modifier.height(16.dp))
                        Button(onClick = { loading = true }, enabled = !loading, Modifier.fillMaxWidth()) { Text(if (loading) "診断中…" else "診断する") }
                        OutlinedButton(onClick = { step = Step.USE }, Modifier.fillMaxWidth()) { Text("戻る") }
                    }
                }
                Step.RESULT -> {
                    item {
                        Text("診断結果", style = MaterialTheme.typography.headlineSmall)
                        Text("今回の条件で最も適合度が高い1台です。")
                    }
                    result?.let { recommendation ->
                        item { ResultCard(recommendation) }
                        item {
                            OutlinedButton(onClick = { step = Step.BUDGET }, Modifier.fillMaxWidth()) { Text("条件を変更して再診断") }
                            OutlinedButton(onClick = onBack, Modifier.fillMaxWidth()) { Text("ホームへ戻る") }
                        }
                    }
                    noResultMessage?.let { message ->
                        item { Card(Modifier.fillMaxWidth()) { Text(message, Modifier.padding(18.dp)) } }
                        item {
                            if (diagnosticError) {
                                Button(onClick = { loading = true }, Modifier.fillMaxWidth(), enabled = !loading) { Text("同じ条件でもう一度診断する") }
                            }
                            OutlinedButton(onClick = { step = Step.BUDGET }, Modifier.fillMaxWidth()) { Text("条件を変更する") }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun QuestionCard(title: String, content: @Composable () -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, style = MaterialTheme.typography.titleLarge)
            content()
        }
    }
}

@Composable
private fun <T> ChoiceRow(options: List<Pair<T, String>>, selected: T, onSelect: (T) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEach { (value, label) ->
            FilterChip(selected = selected == value, onClick = { onSelect(value) }, label = { Text(label) })
        }
    }
}

@Composable
private fun ResultCard(result: SinglePhoneDiagnosticEngine.Result) {
    val c = result.candidate
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(c.modelName, style = MaterialTheme.typography.headlineSmall)
            Text("${c.manufacturerName}・${c.platform}")
            Text("${c.storageGb}GB${c.ramGb?.let { " / RAM ${it}GB" } ?: ""}")
            Text(c.normalPriceYen?.let { "確認済み通常価格：¥${"%,d".format(it)}" } ?: "通常価格：未確認")
            Text("主な仕様", style = MaterialTheme.typography.titleMedium)
            Text("本体サイズ：${formatMillimeters(c.bodyHeightMm)} × ${formatMillimeters(c.bodyWidthMm)} × ${formatMillimeters(c.bodyThicknessMm)}（高さ × 幅 × 厚さ）")
            Text("重量：${c.weightG?.let { "${it.toInt()}g" } ?: "未確認"}")
            Text("画面リフレッシュレート：${c.displayRefreshRateHz?.let { "${it}Hz" } ?: "未確認"}")
            Text("バッテリー容量：${c.batteryCapacityMah?.let { "${it}mAh" } ?: "未確認"}")
            Text("有線充電：${c.chargingPowerW?.let { "最大${it}W（公称値）" } ?: "未確認"}")
            Text("望遠カメラ：${c.rearTelephotoMp?.let { "${it}MP" } ?: "未確認"}")
            Text("おサイフケータイ：${supportLabel(c.osaifuKeitai)}")
            Text("SDカード：${supportLabel(c.microSd)}")
            Text("防水：${supportLabel(c.waterproof)}")
            Text("ソフトウェア更新サポート：${c.updateSupportYears?.let { "約${it}年" } ?: "未確認"}")
            Text("販売状態：${if (c.availabilityStatus == "AVAILABLE") "販売中として登録" else "未確認"}")
            Text("おすすめの理由", style = MaterialTheme.typography.titleMedium)
            result.reasons.forEach { Text("・$it") }
            if (result.cautions.isNotEmpty()) {
                Text("注意点", style = MaterialTheme.typography.titleMedium)
                result.cautions.forEach { Text("・$it") }
            }
        }
    }
}

private fun formatMillimeters(value: Double?): String =
    value?.let { "${"%.1f".format(Locale.US, it)}mm" } ?: "未確認"

private fun supportLabel(value: jp.smartphoneadvisor.app.data.SupportStatus?): String = when (value) {
    jp.smartphoneadvisor.app.data.SupportStatus.SUPPORTED -> "対応"
    jp.smartphoneadvisor.app.data.SupportStatus.NOT_SUPPORTED -> "非対応"
    jp.smartphoneadvisor.app.data.SupportStatus.UNKNOWN, null -> "未確認"
}
