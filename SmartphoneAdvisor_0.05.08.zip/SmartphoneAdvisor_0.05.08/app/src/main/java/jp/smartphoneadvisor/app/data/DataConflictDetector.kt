package jp.smartphoneadvisor.app.data

/**
 * Compares observations from different sources without deciding which source is correct.
 * A higher-priority source may be displayed first by the UI, but conflicts remain visible.
 */
object DataConflictDetector {
    data class Observation(
        val sourceName: String,
        val sourceType: SourceType,
        val value: String
    )

    fun detect(
        deviceVariantId: Long,
        fieldKey: String,
        fieldLabel: String,
        observations: List<Observation>,
        detectedAt: Long
    ): DataConflictEntity? {
        val normalized = observations
            .filter { it.value.isNotBlank() }
            .map { it.value.trim() }
            .distinct()
        if (normalized.size <= 1) return null

        val sources = observations
            .groupBy { it.sourceName }
            .keys
            .sorted()
            .joinToString(" / ")
        val severity = when {
            observations.any { it.sourceType == SourceType.MANUFACTURER_OFFICIAL } -> ConflictSeverity.WARNING
            else -> ConflictSeverity.INFO
        }
        return DataConflictEntity(
            deviceVariantId = deviceVariantId,
            fieldKey = fieldKey,
            fieldLabel = fieldLabel,
            valuesSummary = normalized.joinToString(" / "),
            sourcesSummary = sources,
            severity = severity,
            detectedAt = detectedAt
        )
    }
}
