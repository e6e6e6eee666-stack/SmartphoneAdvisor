package jp.smartphoneadvisor.app.data

import androidx.room.withTransaction

/**
 * 0.2.48: 公式販売ページで確認した価格・販売先の初期データ。
 * 条件付き価格（MNP・下取り等）は通常価格として登録しない。
 */
object VerifiedSalesSeed {
    private const val checkedAt = 1790294400000L // 既存SIMフリー価格の確認日: 2026-09-25。
    private const val softBankCheckedAt = 1791126000000L // SoftBank価格の確認日: 2026-10-05 00:00 JST。

    data class PriceEntry(
        val model: String,
        val storageGb: Int,
        val priceYen: Int,
        val retailer: String,
        val retailerType: RetailerType,
        val url: String,
        val note: String,
        val ramGb: Int? = null,
        val salesChannel: SalesChannel = SalesChannel.SIM_FREE,
        val modelNumber: String? = null
    )

    private val entries = listOf(
        // Apple Japan: 2026-09-25確認の通常価格
        PriceEntry("iPhone 18 Pro", 256, 219_800, "Apple Store Japan", RetailerType.MANUFACTURER, "https://www.apple.com/jp/shop/buy-iphone/iphone-18-pro", "Apple公式通常価格。下取り・通信キャリア割引は含めない。確認: 2026-09-25"),
        PriceEntry("iPhone 18 Pro", 512, 254_800, "Apple Store Japan", RetailerType.MANUFACTURER, "https://www.apple.com/jp/shop/buy-iphone/iphone-18-pro", "Apple公式通常価格。下取り・通信キャリア割引は含めない。確認: 2026-09-25"),
        PriceEntry("iPhone 18 Pro", 1024, 324_800, "Apple Store Japan", RetailerType.MANUFACTURER, "https://www.apple.com/jp/shop/buy-iphone/iphone-18-pro", "Apple公式通常価格。下取り・通信キャリア割引は含めない。確認: 2026-09-25"),
        PriceEntry("iPhone 18 Pro", 2048, 429_800, "Apple Store Japan", RetailerType.MANUFACTURER, "https://www.apple.com/jp/shop/buy-iphone/iphone-18-pro", "Apple公式通常価格。下取り・通信キャリア割引は含めない。確認: 2026-09-25"),
        PriceEntry("iPhone 18 Pro Max", 256, 239_800, "Apple Store Japan", RetailerType.MANUFACTURER, "https://www.apple.com/jp/shop/buy-iphone/iphone-18-pro", "Apple公式通常価格。下取り・通信キャリア割引は含めない。確認: 2026-09-25"),
        PriceEntry("iPhone 18 Pro Max", 512, 274_800, "Apple Store Japan", RetailerType.MANUFACTURER, "https://www.apple.com/jp/shop/buy-iphone/iphone-18-pro", "Apple公式通常価格。下取り・通信キャリア割引は含めない。確認: 2026-09-25"),
        PriceEntry("iPhone 18 Pro Max", 1024, 344_800, "Apple Store Japan", RetailerType.MANUFACTURER, "https://www.apple.com/jp/shop/buy-iphone/iphone-18-pro", "Apple公式通常価格。下取り・通信キャリア割引は含めない。確認: 2026-09-25"),
        PriceEntry("iPhone 18 Pro Max", 2048, 449_800, "Apple Store Japan", RetailerType.MANUFACTURER, "https://www.apple.com/jp/shop/buy-iphone/iphone-18-pro", "Apple公式通常価格。下取り・通信キャリア割引は含めない。確認: 2026-09-25"),

        // Google Store Japan: 2026-09-25確認
        PriceEntry("Pixel 11", 256, 136_800, "Google Store Japan", RetailerType.MANUFACTURER, "https://store.google.com/jp/product/pixel_11", "Google Store SIMフリー通常価格。確認: 2026-09-25"),
        PriceEntry("Pixel 11", 512, 156_800, "Google Store Japan", RetailerType.MANUFACTURER, "https://store.google.com/jp/product/pixel_11", "Google Store SIMフリー通常価格。確認: 2026-09-25"),
        PriceEntry("Pixel 11 Pro", 256, 174_800, "Google Store Japan", RetailerType.MANUFACTURER, "https://store.google.com/jp/config/pixel_11_pro", "Google Store SIMフリー通常価格。確認: 2026-09-25"),
        PriceEntry("Pixel 11 Pro", 512, 194_800, "Google Store Japan", RetailerType.MANUFACTURER, "https://store.google.com/jp/config/pixel_11_pro", "Google Store SIMフリー通常価格。確認: 2026-09-25"),
        PriceEntry("Pixel 11 Pro", 1024, 234_800, "Google Store Japan", RetailerType.MANUFACTURER, "https://store.google.com/jp/config/pixel_11_pro", "Google Store SIMフリー通常価格。確認: 2026-09-25"),
        PriceEntry("Pixel 11 Pro XL", 256, 207_800, "Google Store Japan", RetailerType.MANUFACTURER, "https://store.google.com/jp/config/pixel_11_pro", "Google Store SIMフリー通常価格。確認: 2026-09-25"),
        PriceEntry("Pixel 11 Pro XL", 512, 227_800, "Google Store Japan", RetailerType.MANUFACTURER, "https://store.google.com/jp/config/pixel_11_pro", "Google Store SIMフリー通常価格。確認: 2026-09-25"),
        PriceEntry("Pixel 11 Pro XL", 1024, 267_800, "Google Store Japan", RetailerType.MANUFACTURER, "https://store.google.com/jp/config/pixel_11_pro", "Google Store SIMフリー通常価格。確認: 2026-09-25"),

        // Sony Store Japan: 2026-09-25確認
        PriceEntry("Xperia 1 VIII", 256, 235_400, "ソニーストア", RetailerType.MANUFACTURER, "https://pur.store.sony.jp/xperia/products/xperia1m8/xperia1m8_purchase/", "SIMフリー・12GB/256GBの一括通常価格。返却プログラムは含めない。確認: 2026-09-25", ramGb = 12),
        PriceEntry("Xperia 1 VIII", 512, 251_900, "ソニーストア", RetailerType.MANUFACTURER, "https://pur.store.sony.jp/xperia/products/xperia1m8/xperia1m8_purchase/", "SIMフリー・12GB/512GBの一括通常価格。確認: 2026-09-25", ramGb = 12),
        PriceEntry("Xperia 1 VIII", 512, 268_400, "ソニーストア", RetailerType.MANUFACTURER, "https://pur.store.sony.jp/xperia/products/xperia1m8/xperia1m8_purchase/", "SIMフリー・16GB/512GBの一括通常価格。確認: 2026-09-25", ramGb = 16),
        PriceEntry("Xperia 1 VIII", 1024, 299_200, "ソニーストア", RetailerType.MANUFACTURER, "https://pur.store.sony.jp/xperia/products/xperia1m8/xperia1m8_purchase/", "SIMフリー・16GB/1TBの一括通常価格。確認: 2026-09-25", ramGb = 16),

        // Apple Japan: iPhone Duo pre-order / 2026-10-23 release confirmed 2026-09-30
        PriceEntry("iPhone Duo", 256, 364_800, "Apple Store Japan", RetailerType.MANUFACTURER, "https://www.apple.com/jp/shop/buy-iphone/iphone-duo", "Apple公式。予約注文10月16日、発売10月23日。確認: 2026-09-30"),
        PriceEntry("iPhone Duo", 512, 399_800, "Apple Store Japan", RetailerType.MANUFACTURER, "https://www.apple.com/jp/shop/buy-iphone/iphone-duo", "Apple公式。予約注文10月16日、発売10月23日。確認: 2026-09-30"),
        PriceEntry("iPhone Duo", 1024, 469_800, "Apple Store Japan", RetailerType.MANUFACTURER, "https://www.apple.com/jp/shop/buy-iphone/iphone-duo", "Apple公式。予約注文10月16日、発売10月23日。確認: 2026-09-30"),
        PriceEntry("iPhone Duo", 2048, 574_800, "Apple Store Japan", RetailerType.MANUFACTURER, "https://www.apple.com/jp/shop/buy-iphone/iphone-duo", "Apple公式。予約注文10月16日、発売10月23日。確認: 2026-09-30"),
        PriceEntry("REDMAGIC 11S Pro", 256, 149_800, "REDMAGIC Japan", RetailerType.MANUFACTURER, "https://jp.redmagic.gg/products/redmagic-11s-pro", "日本公式通常価格。12GB/256GB。確認: 2026-09-30"),
        PriceEntry("REDMAGIC 11S Pro", 512, 172_800, "REDMAGIC Japan", RetailerType.MANUFACTURER, "https://jp.redmagic.gg/products/redmagic-11s-pro", "日本公式通常価格。16GB/512GB。確認: 2026-09-30"),
        PriceEntry("REDMAGIC 11 Air", 256, 94_800, "REDMAGIC Japan", RetailerType.MANUFACTURER, "https://jp.redmagic.gg/products/redmagic-11-air", "日本公式通常価格。12GB/256GB。確認: 2026-09-30"),
        PriceEntry("REDMAGIC 11 Air", 512, 114_800, "REDMAGIC Japan", RetailerType.MANUFACTURER, "https://jp.redmagic.gg/products/redmagic-11-air", "日本公式通常価格。16GB/512GB。確認: 2026-09-30"),

        // SHARP COCORO STORE Japan: 2026-09-25確認
        PriceEntry("AQUOS R11", 512, 163_900, "COCORO STORE", RetailerType.MANUFACTURER, "https://cocorostore.jp.sharp/sh-m35-a.html", "SIMフリー・512GB通常価格。確認: 2026-09-25"),
        // 0.01.04.31 official reverse-audit: SoftBank current Pixel 8a/9/9 Pro/9 Pro Fold price cards.
        // Current official price-card values are recorded as NORMAL prices; campaign/return-program amounts are not substituted.
        PriceEntry("Pixel 8a", 128, 77_760, "ソフトバンク", RetailerType.CARRIER, "https://www.softbank.jp/mobile/special/price-card/product-price/google-pixel/", "SoftBank公式プライスカード表示価格。確認: 2026-10-05。RAM 8GB。", ramGb = 8, salesChannel = SalesChannel.SOFTBANK),
        PriceEntry("Pixel 9", 128, 132_048, "ソフトバンク", RetailerType.CARRIER, "https://www.softbank.jp/mobile/special/price-card/product-price/google-pixel-9_google-pixel-8a/", "SoftBank公式プライスカード表示価格。確認: 2026-10-05。RAM 12GB。", ramGb = 12, salesChannel = SalesChannel.SOFTBANK),
        PriceEntry("Pixel 9", 256, 151_200, "ソフトバンク", RetailerType.CARRIER, "https://www.softbank.jp/mobile/special/price-card/product-price/google-pixel-9_google-pixel-8a/", "SoftBank公式プライスカード表示価格。確認: 2026-10-05。RAM 12GB。", ramGb = 12, salesChannel = SalesChannel.SOFTBANK),
        PriceEntry("Pixel 9 Pro", 128, 142_560, "ソフトバンク", RetailerType.CARRIER, "https://www.softbank.jp/mobile/special/price-card/product-price/google-pixel/", "SoftBank公式プライスカード表示価格。確認: 2026-10-05。RAM 16GB。", ramGb = 16, salesChannel = SalesChannel.SOFTBANK),
        PriceEntry("Pixel 9 Pro", 256, 162_000, "ソフトバンク", RetailerType.CARRIER, "https://www.softbank.jp/mobile/special/price-card/product-price/google-pixel/", "SoftBank公式プライスカード表示価格。確認: 2026-10-05。RAM 16GB。", ramGb = 16, salesChannel = SalesChannel.SOFTBANK),
        PriceEntry("Pixel 9 Pro Fold", 256, 306_000, "ソフトバンク", RetailerType.CARRIER, "https://www.softbank.jp/mobile/special/price-card/product-price/google-pixel/", "SoftBank公式プライスカード表示価格。確認: 2026-10-05。RAM 16GB。", ramGb = 16, salesChannel = SalesChannel.SOFTBANK),
        // SoftBank公式製品一覧: 2026-10-05確認。表示価格（税込）。
        // ここではMNP等の条件付き割引価格ではなく、公式製品一覧に表示される機種価格を記録する。
        PriceEntry("AQUOS R10", 256, 129_888, "ソフトバンク", RetailerType.CARRIER, "https://www.softbank.jp/mobile/products/smartphone/aquos-r10/", "SoftBank公式製品一覧表示価格。確認: 2026-10-05", ramGb = 12, salesChannel = SalesChannel.SOFTBANK, modelNumber = "A501SH"),
        PriceEntry("Xperia 1 VII", 256, 247_680, "ソフトバンク", RetailerType.CARRIER, "https://www.softbank.jp/mobile/products/smartphone/xperia1m7/", "SoftBank公式製品一覧表示価格。確認: 2026-10-05", ramGb = 12, salesChannel = SalesChannel.SOFTBANK, modelNumber = "A501SO"),
        PriceEntry("AQUOS R9 pro", 512, 199_440, "ソフトバンク", RetailerType.CARRIER, "https://www.softbank.jp/mobile/products/smartphone/aquos-r9-pro/", "SoftBank公式製品一覧表示価格。確認: 2026-10-05", ramGb = 12, salesChannel = SalesChannel.SOFTBANK, modelNumber = "A504SH"),
        PriceEntry("arrows We2", 64, 21_984, "ソフトバンク", RetailerType.CARRIER, "https://www.softbank.jp/mobile/products/smartphone/arrows-we2/", "SoftBank公式製品一覧表示価格。確認: 2026-10-05", ramGb = 4, salesChannel = SalesChannel.SOFTBANK, modelNumber = "A402FC"),
        PriceEntry("motorola razr 50 ultra", 512, 97_920, "ソフトバンク", RetailerType.CARRIER, "https://www.softbank.jp/mobile/products/smartphone/motorola-razr-50-ultra/", "SoftBank公式製品一覧表示価格。確認: 2026-10-05", ramGb = 12, salesChannel = SalesChannel.SOFTBANK, modelNumber = "XT2451-5"),
        PriceEntry("AQUOS sense9", 128, 69_840, "ソフトバンク", RetailerType.CARRIER, "https://www.softbank.jp/mobile/products/smartphone/aquos-sense9/", "SoftBank公式製品一覧表示価格。確認: 2026-10-05", ramGb = 6, salesChannel = SalesChannel.SOFTBANK, modelNumber = "A405SH"),
        PriceEntry("Xiaomi 14T Pro", 512, 60_480, "ソフトバンク", RetailerType.CARRIER, "https://www.softbank.jp/mobile/products/smartphone/xiaomi-14t-pro/", "SoftBank公式製品一覧表示価格。確認: 2026-10-05", ramGb = 12, salesChannel = SalesChannel.SOFTBANK, modelNumber = "A402XM"),
        PriceEntry("motorola razr 50s", 256, 41_760, "ソフトバンク", RetailerType.CARRIER, "https://www.softbank.jp/mobile/products/smartphone/motorola-razr-50s/", "SoftBank公式製品一覧表示価格。確認: 2026-10-05", ramGb = 8, salesChannel = SalesChannel.SOFTBANK, modelNumber = "XT2453-7"),
        PriceEntry("motorola edge 50s pro", 256, 23_472, "ソフトバンク", RetailerType.CARRIER, "https://www.softbank.jp/mobile/products/smartphone/motorola-edge-50s-pro/", "SoftBank公式製品一覧表示価格。確認: 2026-10-05", ramGb = 8, salesChannel = SalesChannel.SOFTBANK, modelNumber = "XT2403-5"),
        PriceEntry("シンプルスマホ7", 64, 59_760, "ソフトバンク", RetailerType.CARRIER, "https://www.softbank.jp/mobile/products/smartphone/simple-sumaho7/", "SoftBank公式製品一覧表示価格。確認: 2026-10-05", ramGb = 4, salesChannel = SalesChannel.SOFTBANK, modelNumber = "A404SH"),
        PriceEntry("Xperia 1 VI", 256, 168_192, "ソフトバンク", RetailerType.CARRIER, "https://www.softbank.jp/mobile/products/smartphone/xperia1m6/", "SoftBank公式製品一覧表示価格。確認: 2026-10-05", ramGb = 12, salesChannel = SalesChannel.SOFTBANK, modelNumber = "A401SO"),
        PriceEntry("Xperia 10 VI", 128, 31_824, "ソフトバンク", RetailerType.CARRIER, "https://www.softbank.jp/mobile/products/smartphone/xperia10m6/", "SoftBank公式製品一覧表示価格。確認: 2026-10-05", ramGb = 6, salesChannel = SalesChannel.SOFTBANK, modelNumber = "A402SO"),
        PriceEntry("AQUOS R9", 256, 124_560, "ソフトバンク", RetailerType.CARRIER, "https://www.softbank.jp/mobile/products/smartphone/aquos-r9/", "SoftBank公式製品一覧表示価格。確認: 2026-10-05", ramGb = 12, salesChannel = SalesChannel.SOFTBANK, modelNumber = "A401SH"),
        PriceEntry("Redmi 12 5G", 128, 21_984, "ソフトバンク", RetailerType.CARRIER, "https://www.softbank.jp/mobile/products/smartphone/redmi12-5g/", "SoftBank公式製品一覧表示価格。確認: 2026-10-05", ramGb = 4, salesChannel = SalesChannel.SOFTBANK, modelNumber = "A401XM"),
        PriceEntry("LEITZ PHONE 3", 512, 143_280, "ソフトバンク", RetailerType.CARRIER, "https://www.softbank.jp/mobile/products/smartphone/leitz-phone3/", "SoftBank公式製品一覧表示価格。確認: 2026-10-05", ramGb = 12, salesChannel = SalesChannel.SOFTBANK, modelNumber = "LP-03"),
        PriceEntry("DuraForce EX", 64, 59_040, "ソフトバンク", RetailerType.CARRIER, "https://www.softbank.jp/mobile/products/smartphone/duraforce-ex/", "SoftBank公式製品一覧表示価格。確認: 2026-10-05", ramGb = 4, salesChannel = SalesChannel.SOFTBANK, modelNumber = "A301KC"),
        PriceEntry("あんしんファミリースマホ", 128, 21_984, "ソフトバンク", RetailerType.CARRIER, "https://www.softbank.jp/mobile/products/smartphone/anshin-family-smartphone/", "SoftBank公式製品一覧表示価格。確認: 2026-10-05", ramGb = 4, salesChannel = SalesChannel.SOFTBANK, modelNumber = "A303ZT"),
    )

    suspend fun ensureSeeded(db: AppDatabase) = db.withTransaction {
        entries.forEach { entry ->
            val variantId = db.phoneDao().getDeviceVariantIdByModelAndStorage(entry.model, entry.storageGb, entry.ramGb)
                ?: return@forEach
            val sourceName = when (entry.retailerType) {
                RetailerType.MANUFACTURER -> entry.retailer
                else -> entry.retailer
            }
            val sourceId = db.phoneDao().getDataSourceId(sourceName)
                ?: db.phoneDao().insertDataSources(listOf(
                    DataSourceEntity(
                        name = sourceName,
                        sourceType = if (entry.salesChannel == SalesChannel.SOFTBANK) SourceType.CARRIER_OFFICIAL else SourceType.MANUFACTURER_OFFICIAL,
                        url = entry.url,
                        isOfficial = true
                    )
                )).single()
            val retailerId = db.phoneDao().getRetailerId(entry.retailer)
                ?: db.phoneDao().insertRetailers(listOf(
                    RetailerEntity(
                        name = entry.retailer,
                        type = entry.retailerType,
                        official = true,
                        websiteUrl = entry.url
                    )
                )).single()
            val salesVariantId = db.phoneDao().getSalesVariantId(variantId, entry.salesChannel, entry.modelNumber)
                ?: db.phoneDao().insertSalesVariants(listOf(
                    SalesVariantEntity(
                        deviceVariantId = variantId,
                        salesChannel = entry.salesChannel,
                        modelNumber = entry.modelNumber,
                        simType = if (entry.salesChannel == SalesChannel.SIM_FREE) "SIMフリー" else null
                    )
                )).single()
            val listingId = db.phoneDao().getProductListingId(salesVariantId, retailerId)
                ?: db.phoneDao().insertProductListings(listOf(
                    ProductListingEntity(
                        salesVariantId = salesVariantId,
                        retailerId = retailerId,
                        productUrl = entry.url,
                        productName = entry.model,
                        availability = AvailabilityStatus.AVAILABLE,
                        checkedAt = if (entry.salesChannel == SalesChannel.SOFTBANK) softBankCheckedAt else checkedAt
                    )
                )).single()

            if (db.phoneDao().countV2Prices(listingId) == 0) {
                db.phoneDao().insertPriceRecordsV2(listOf(
                    PriceRecordV2Entity(
                        productListingId = listingId,
                        priceType = PriceType.NORMAL,
                        priceYen = entry.priceYen,
                        conditions = entry.note,
                        checkedAt = if (entry.salesChannel == SalesChannel.SOFTBANK) softBankCheckedAt else checkedAt,
                        sourceId = sourceId
                    )
                ))
            }
            db.phoneDao().insertPrices(listOf(
                PriceRecordEntity(
                    deviceVariantId = variantId,
                    priceType = "NORMAL",
                    priceYen = entry.priceYen,
                    checkedAt = if (entry.salesChannel == SalesChannel.SOFTBANK) softBankCheckedAt else checkedAt,
                    isCurrent = true,
                    sourceId = sourceId
                )
            ))
        }
    }
}
