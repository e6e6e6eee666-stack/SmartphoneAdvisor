package jp.smartphoneadvisor.app.domain

import jp.smartphoneadvisor.app.data.AttributeLevel
import jp.smartphoneadvisor.app.data.CandidateOs
import jp.smartphoneadvisor.app.data.PhoneListRow
import jp.smartphoneadvisor.app.data.PrimaryUse
import jp.smartphoneadvisor.app.data.SupportStatus
import jp.smartphoneadvisor.app.data.SourceType

data class BudgetRequirement(val targetPriceYen: Int?, val maxPriceYen: Int?)
enum class BudgetStatus { WITHIN_TARGET, OVER_TARGET_WITHIN_MAX, OVER_MAX, UNKNOWN }
enum class RecommendationConfidence { HIGH, MEDIUM, LOW }

/** A price record interpreted for recommendation purposes. Conditional carrier prices are kept separate. */
data class PriceOfferForRecommendation(
    val priceYen: Int?,
    val priceType: jp.smartphoneadvisor.app.data.PriceType,
    val conditions: String? = null,
    val salesChannel: jp.smartphoneadvisor.app.data.SalesChannel? = null
)

enum class UsablePriceStatus { NORMAL_OR_SALE, CONDITIONAL, UNKNOWN }

data class UsablePrice(
    val priceYen: Int?,
    val status: UsablePriceStatus,
    val explanation: String
)

/**
 * Prevents MNP/new-contract/model-change/contract-required prices from being
 * mistaken for the ordinary purchase price used by the budget filter.
 */
fun selectUsablePrice(
    offers: List<PriceOfferForRecommendation>,
    requestedChannel: String?
): UsablePrice {
    val requested = requestedChannel?.trim()?.takeIf { it.isNotEmpty() && it != "特に決めていない" }
    val wantedChannel = requestedChannelToSalesChannel(requested)
    // An explicitly requested but unsupported channel must not silently become "any channel".
    if (requested != null && wantedChannel == null) {
        return UsablePrice(null, UsablePriceStatus.UNKNOWN, "指定された購入先「$requested」の価格区分を特定できません")
    }
    // When a channel is selected, offers with no channel identity cannot be safely attributed to it.
    val channelOffers = offers.filter { wantedChannel == null || it.salesChannel == wantedChannel }

    val ordinary = channelOffers
        .filter { it.priceType == jp.smartphoneadvisor.app.data.PriceType.NORMAL || it.priceType == jp.smartphoneadvisor.app.data.PriceType.SALE }
        .mapNotNull { it.priceYen?.let { yen -> yen to it } }
        .minByOrNull { it.first }
    if (ordinary != null) {
        val label = if (ordinary.second.priceType == jp.smartphoneadvisor.app.data.PriceType.SALE) "セール価格" else "通常価格"
        return UsablePrice(ordinary.first, UsablePriceStatus.NORMAL_OR_SALE, "予算判定には${label}を使用")
    }

    val campaign = channelOffers.firstOrNull {
        it.priceType == jp.smartphoneadvisor.app.data.PriceType.CAMPAIGN && it.priceYen != null && it.conditions.isNullOrBlank()
    }
    if (campaign != null) {
        return UsablePrice(campaign.priceYen, UsablePriceStatus.NORMAL_OR_SALE, "条件記載のないキャンペーン価格を使用")
    }

    val conditional = channelOffers.firstOrNull {
        it.priceYen != null && it.priceType in setOf(
            jp.smartphoneadvisor.app.data.PriceType.MNP,
            jp.smartphoneadvisor.app.data.PriceType.NEW_CONTRACT,
            jp.smartphoneadvisor.app.data.PriceType.MODEL_CHANGE,
            jp.smartphoneadvisor.app.data.PriceType.CONTRACT_REQUIRED
        )
    }
    if (conditional != null) {
        return UsablePrice(null, UsablePriceStatus.CONDITIONAL, "MNP・新規契約・機種変更などの条件付き価格は一般価格として予算判定しません")
    }
    return UsablePrice(null, UsablePriceStatus.UNKNOWN, "利用可能な一般価格を確認できません")
}

private fun requestedChannelToSalesChannel(value: String?): jp.smartphoneadvisor.app.data.SalesChannel? = when (value) {
    "SIMフリー" -> jp.smartphoneadvisor.app.data.SalesChannel.SIM_FREE
    "docomo" -> jp.smartphoneadvisor.app.data.SalesChannel.DOCOMO
    "au" -> jp.smartphoneadvisor.app.data.SalesChannel.AU
    "SoftBank" -> jp.smartphoneadvisor.app.data.SalesChannel.SOFTBANK
    "楽天モバイル" -> jp.smartphoneadvisor.app.data.SalesChannel.RAKUTEN
    "UQ mobile" -> jp.smartphoneadvisor.app.data.SalesChannel.UQ_MOBILE
    "Y!mobile" -> jp.smartphoneadvisor.app.data.SalesChannel.Y_MOBILE
    "IIJmio" -> jp.smartphoneadvisor.app.data.SalesChannel.IIJ_MIO
    "mineo" -> jp.smartphoneadvisor.app.data.SalesChannel.MINEO
    "MVNO" -> jp.smartphoneadvisor.app.data.SalesChannel.MVNO
    else -> null
}

data class NoCandidateExplanation(
    val reasons: List<String>,
    val checkedCandidateCount: Int
)
fun budgetStatus(budget: BudgetRequirement, priceYen: Int?): BudgetStatus = when {
    priceYen == null -> BudgetStatus.UNKNOWN
    budget.maxPriceYen != null && priceYen > budget.maxPriceYen -> BudgetStatus.OVER_MAX
    budget.targetPriceYen != null && priceYen <= budget.targetPriceYen -> BudgetStatus.WITHIN_TARGET
    budget.maxPriceYen != null -> BudgetStatus.OVER_TARGET_WITHIN_MAX
    else -> BudgetStatus.UNKNOWN
}

enum class MustHaveFeature { OSAIFU_KEITAI, WATERPROOF, ESIM, FINGERPRINT, WIRELESS_CHARGING, MICRO_SD, HEADPHONE_JACK }

data class UserRequirement(
    val os: CandidateOs,
    val budget: BudgetRequirement,
    val primaryUse: PrimaryUse,
    val gameType: String? = null,
    val cameraSubject: String? = null,
    val useDetail: String? = null,
    val batteryImportance: Int = 1,
    val batteryChargePreference: String? = null,
    val sizePreference: String? = null,
    val storageMinimumGb: Int? = null,
    val niceHaveFeatures: Set<String> = emptySet(),
    val purchaseChannel: String? = null,
    val productConditionPreference: String? = null,
    val intendedUseYears: Int? = null,
    val designPreference: String? = null,
    val mustHaveFeatures: Set<MustHaveFeature> = emptySet()
)

data class RecommendationResult(
    val phone: PhoneListRow,
    val fitScore: Int,
    val confidence: RecommendationConfidence,
    val reasons: List<String>,
    val cautions: List<String>
)

enum class DataFreshnessStatus { FRESH, AGING, STALE, UNKNOWN }

private const val PRICE_FRESH_DAYS = 14L
private const val AVAILABILITY_FRESH_DAYS = 7L

fun dataFreshnessStatus(checkedAt: Long?, maxAgeDays: Long, now: Long = System.currentTimeMillis()): DataFreshnessStatus {
    if (checkedAt == null || checkedAt <= 0L) return DataFreshnessStatus.UNKNOWN
    val age = (now - checkedAt).coerceAtLeast(0L)
    val freshMs = maxAgeDays * 24L * 60L * 60L * 1000L
    return when {
        age <= freshMs -> DataFreshnessStatus.FRESH
        age <= freshMs * 2 -> DataFreshnessStatus.AGING
        else -> DataFreshnessStatus.STALE
    }
}

private fun effectiveRecommendationPrice(c: PhoneListRow, now: Long = System.currentTimeMillis()): Int? =
    if (dataFreshnessStatus(c.priceCheckedAt, PRICE_FRESH_DAYS, now) == DataFreshnessStatus.FRESH) c.normalPriceYen else null

private fun availabilityBlocksRecommendation(c: PhoneListRow): Boolean =
    c.availabilityStatus == "DISCONTINUED" || c.availabilityStatus == "OUT_OF_STOCK"

private fun sourceReliability(sourceType: SourceType?): Int = when (sourceType) {
    SourceType.MANUFACTURER_OFFICIAL -> 5
    SourceType.JAPAN_OFFICIAL_SALES -> 4
    SourceType.CARRIER_OFFICIAL -> 3
    SourceType.TRUSTED_THIRD_PARTY -> 2
    SourceType.REVIEW -> 1
    SourceType.OTHER -> 0
    null -> -1
}

object RecommendationEngine {
    fun recommend(requirement: UserRequirement, candidates: List<PhoneListRow>, limit: Int = 3): List<RecommendationResult> {
        val filtered = candidates.filter { candidate ->
            osMatches(requirement.os, candidate.platform) &&
                !availabilityBlocksRecommendation(candidate) &&
                budgetMatches(requirement.budget, effectiveRecommendationPrice(candidate)) &&
                storageMatches(requirement.storageMinimumGb, candidate.storageGb) &&
                purchaseChannelMatches(requirement.purchaseChannel, candidate.purchaseChannels) &&
                productConditionMatches(requirement.productConditionPreference, candidate.productCondition) &&
                mustHaveMatches(requirement.mustHaveFeatures, candidate)
        }
        val scored = filtered.map { candidate ->
            RecommendationResult(candidate, score(requirement, candidate), confidence(candidate), buildReasons(requirement, candidate), buildCautions(requirement, candidate))
        }.sortedWith(compareByDescending<RecommendationResult> { it.fitScore }.thenBy { it.phone.normalPriceYen ?: Int.MAX_VALUE })

        val requestedLimit = limit.coerceIn(2, 5)
        val naturalLimit = chooseNaturalResultCount(scored, requestedLimit)
        return selectDiverseCandidates(scored, naturalLimit)
    }

    /**
     * Chooses a natural result count without padding the result with weak matches.
     * Three is the normal presentation size; four or five are used only when there
     * are enough similarly relevant candidates to make the extra choices useful.
     */
    private fun chooseNaturalResultCount(
        scored: List<RecommendationResult>,
        requestedLimit: Int
    ): Int {
        if (scored.size <= 2) return scored.size
        if (requestedLimit <= 2) return 2
        if (scored.size <= 3) return scored.size

        val topScore = scored.first().fitScore
        val usefulCandidates = scored.count { it.fitScore >= topScore - 12 }

        return when {
            requestedLimit >= 5 && scored.size >= 5 && usefulCandidates >= 5 -> 5
            requestedLimit >= 4 && scored.size >= 4 && usefulCandidates >= 4 -> 4
            else -> 3
        }
    }

    /**
     * Prevents a recommendation list from being filled by near-duplicate entries
     * such as the same model in multiple storage variants. This is a soft diversity
     * rule: relevance remains primary, while the list tries to expose distinct models
     * and avoids letting one manufacturer occupy every slot when alternatives exist.
     */
    private fun selectDiverseCandidates(
        scored: List<RecommendationResult>,
        limit: Int
    ): List<RecommendationResult> {
        if (scored.size <= limit) return scored

        val selected = mutableListOf<RecommendationResult>()
        val selectedModelKeys = mutableSetOf<String>()
        val manufacturerCounts = mutableMapOf<String, Int>()

        fun modelKey(result: RecommendationResult): String =
            "${result.phone.manufacturerName}|${result.phone.modelName}"

        fun canSelect(result: RecommendationResult, enforceManufacturerCap: Boolean): Boolean {
            val key = modelKey(result)
            if (key in selectedModelKeys) return false
            if (enforceManufacturerCap && (manufacturerCounts[result.phone.manufacturerName] ?: 0) >= 2) return false
            return true
        }

        // First pass: distinct models, with a soft two-per-manufacturer cap.
        scored.forEach { result ->
            if (selected.size >= limit) return@forEach
            if (canSelect(result, enforceManufacturerCap = true)) {
                selected += result
                selectedModelKeys += modelKey(result)
                manufacturerCounts[result.phone.manufacturerName] =
                    (manufacturerCounts[result.phone.manufacturerName] ?: 0) + 1
            }
        }

        // If the market data is narrow, never return too few candidates merely for
        // diversity. Fill remaining slots while still preventing duplicate models.
        if (selected.size < limit) {
            scored.forEach { result ->
                if (selected.size >= limit) return@forEach
                if (canSelect(result, enforceManufacturerCap = false)) {
                    selected += result
                    selectedModelKeys += modelKey(result)
                }
            }
        }

        return selected
    }

    fun explainNoCandidates(requirement: UserRequirement, candidates: List<PhoneListRow>): NoCandidateExplanation {
        val reasons = mutableListOf<String>()
        val osCandidates = candidates.filter { osMatches(requirement.os, it.platform) }
        if (osCandidates.isEmpty()) reasons += "選択したOSに一致する日本公式端末データがありません"

        val budgetCandidates = osCandidates.filter { budgetMatches(requirement.budget, it.normalPriceYen) }
        if (osCandidates.isNotEmpty() && budgetCandidates.isEmpty()) {
            if (osCandidates.any { it.normalPriceYen == null }) {
                reasons += "価格データが未確認の端末があるため、上限条件を満たすと確認できません"
            } else {
                reasons += "設定した絶対上限以内の端末がありません"
            }
        }

        val storageCandidates = budgetCandidates.filter { storageMatches(requirement.storageMinimumGb, it.storageGb) }
        if (budgetCandidates.isNotEmpty() && storageCandidates.isEmpty() && requirement.storageMinimumGb != null) {
            reasons += "指定した最低ストレージ容量を満たす端末がありません"
        }
        val purchaseCandidates = storageCandidates.filter { purchaseChannelMatches(requirement.purchaseChannel, it.purchaseChannels) }
        if (storageCandidates.isNotEmpty() && purchaseCandidates.isEmpty() && !requirement.purchaseChannel.isNullOrBlank() && requirement.purchaseChannel != "特に決めていない") {
            reasons += "指定した購入先で販売されていると確認できる端末がありません"
        }
        val conditionCandidates = purchaseCandidates.filter { productConditionMatches(requirement.productConditionPreference, it.productCondition) }
        if (purchaseCandidates.isNotEmpty() && conditionCandidates.isEmpty() && requirement.productConditionPreference == "新品のみ") {
            reasons += "新品として登録されている端末がありません"
        }
        val mustHaveCandidates = conditionCandidates.filter { mustHaveMatches(requirement.mustHaveFeatures, it) }
        if (conditionCandidates.isNotEmpty() && mustHaveCandidates.isEmpty() && requirement.mustHaveFeatures.isNotEmpty()) {
            reasons += "指定した必須条件をすべて満たす端末がありません"
        }
        if (reasons.isEmpty()) reasons += "現在の推薦データでは条件を満たす候補がありません"
        return NoCandidateExplanation(reasons.distinct(), candidates.size)
    }

    fun exclusionReasonSummary(requirement: UserRequirement, candidates: List<PhoneListRow>): List<String> = buildList {
        val osFiltered = candidates.filter { osMatches(requirement.os, it.platform) }
        val budgetFiltered = osFiltered.filter { budgetMatches(requirement.budget, it.normalPriceYen) }
        val storageFiltered = budgetFiltered.filter { storageMatches(requirement.storageMinimumGb, it.storageGb) }
        val purchaseFiltered = storageFiltered.filter { purchaseChannelMatches(requirement.purchaseChannel, it.purchaseChannels) }
        val conditionFiltered = purchaseFiltered.filter { productConditionMatches(requirement.productConditionPreference, it.productCondition) }
        val mustHaveFiltered = conditionFiltered.filter { mustHaveMatches(requirement.mustHaveFeatures, it) }
        if (candidates.isNotEmpty() && osFiltered.size < candidates.size) {
            add("OS条件で ${candidates.size - osFiltered.size}件を除外")
        }
        if (osFiltered.isNotEmpty() && budgetFiltered.size < osFiltered.size) {
            add("予算上限で ${osFiltered.size - budgetFiltered.size}件を除外")
        }
        if (budgetFiltered.isNotEmpty() && storageFiltered.size < budgetFiltered.size) {
            add("ストレージ条件で ${budgetFiltered.size - storageFiltered.size}件を除外")
        }
        if (storageFiltered.isNotEmpty() && purchaseFiltered.size < storageFiltered.size) {
            add("購入先条件で ${storageFiltered.size - purchaseFiltered.size}件を除外")
        }
        if (purchaseFiltered.isNotEmpty() && conditionFiltered.size < purchaseFiltered.size) {
            add("新品・中古条件で ${purchaseFiltered.size - conditionFiltered.size}件を除外")
        }
        if (conditionFiltered.isNotEmpty() && mustHaveFiltered.size < conditionFiltered.size) {
            add("必須条件で ${conditionFiltered.size - mustHaveFiltered.size}件を除外")
        }
    }

    fun prioritySummary(requirement: UserRequirement): List<String> = buildList {
        add("必須条件・絶対上限 → 最優先")
        add("${primaryUseLabel(requirement.primaryUse)} → 最優先の用途条件")
        if (requirement.intendedUseYears != null) add("長期利用（${requirement.intendedUseYears}年以上） → 重視")
        if (requirement.batteryImportance > 0) add("バッテリー → 重視度${requirement.batteryImportance}")
        if (!requirement.sizePreference.isNullOrBlank() && requirement.sizePreference != "特に希望なし") add("サイズ・重量 → 希望条件として反映")
        if (requirement.niceHaveFeatures.isNotEmpty()) add("あると嬉しい機能 → 加点要素として反映")
        if (!requirement.designPreference.isNullOrBlank() && requirement.designPreference != "特に希望なし") add("デザイン・表示 → 希望条件として反映")
    }

    private fun primaryUseLabel(use: PrimaryUse): String = when (use) {
        PrimaryUse.GENERAL -> "普段使い"
        PrimaryUse.GAMING -> "ゲーム"
        PrimaryUse.CAMERA -> "カメラ"
        PrimaryUse.VIDEO -> "動画"
        PrimaryUse.SNS -> "SNS"
        PrimaryUse.CALLS -> "通話・LINE"
        PrimaryUse.MUSIC -> "音楽"
        PrimaryUse.EBOOK -> "電子書籍"
        PrimaryUse.WORK -> "仕事・学習"
        PrimaryUse.AI -> "AI"
        PrimaryUse.VIDEO_EDITING -> "動画編集"
        PrimaryUse.OTHER -> "その他"
    }

    private fun confidence(c: PhoneListRow): RecommendationConfidence {
        val unknowns = listOf(c.normalPriceYen, c.gamingLevel, c.cameraLevel, c.generalLevel, c.workStudyLevel, c.videoLevel, c.aiLevel).count { it == null || it == AttributeLevel.UNKNOWN }
        val priceFreshness = dataFreshnessStatus(c.priceCheckedAt, PRICE_FRESH_DAYS)
        val availabilityFreshness = dataFreshnessStatus(c.availabilityCheckedAt, AVAILABILITY_FRESH_DAYS)
        val freshnessPenalty = (if (priceFreshness != DataFreshnessStatus.FRESH) 1 else 0) + (if (availabilityFreshness != DataFreshnessStatus.FRESH) 1 else 0)
        val sourceReliability = sourceReliability(c.priceSourceType)
        val sourcePenalty = when {
            sourceReliability < 0 -> 2
            sourceReliability <= 1 -> 1
            else -> 0
        }
        return when {
            unknowns == 0 && freshnessPenalty == 0 && sourcePenalty == 0 -> RecommendationConfidence.HIGH
            unknowns <= 2 && freshnessPenalty <= 1 && sourcePenalty <= 1 -> RecommendationConfidence.MEDIUM
            else -> RecommendationConfidence.LOW
        }
    }

    private fun osMatches(required: CandidateOs, actual: String): Boolean =
        required == CandidateOs.EITHER ||
            (required == CandidateOs.ANDROID && actual == CandidateOs.ANDROID) ||
            (required == CandidateOs.IPHONE && actual == CandidateOs.IPHONE)

    private fun budgetMatches(budget: BudgetRequirement, price: Int?): Boolean =
        budget.maxPriceYen == null || (price != null && price <= budget.maxPriceYen)

    private fun storageMatches(minimumGb: Int?, actualGb: Int): Boolean =
        minimumGb == null || actualGb >= minimumGb

    private fun mustHaveMatches(required: Set<MustHaveFeature>, c: PhoneListRow): Boolean = required.all { feature ->
        when (feature) {
            MustHaveFeature.OSAIFU_KEITAI -> c.osaifuKeitai == SupportStatus.SUPPORTED
            MustHaveFeature.WATERPROOF -> c.waterproof == SupportStatus.SUPPORTED
            MustHaveFeature.ESIM -> c.esim == SupportStatus.SUPPORTED
            MustHaveFeature.FINGERPRINT -> c.fingerprint == SupportStatus.SUPPORTED
            MustHaveFeature.WIRELESS_CHARGING -> c.wirelessCharging == SupportStatus.SUPPORTED
            MustHaveFeature.MICRO_SD -> c.microSd == SupportStatus.SUPPORTED
            MustHaveFeature.HEADPHONE_JACK -> c.headphoneJack == SupportStatus.SUPPORTED
        }
    }

    /**
     * The order of importance is explicit here so the recommendation logic remains
     * explainable and can evolve without changing the UI. Hard requirements have
     * already been filtered before this function is called.
     */
    private data class RecommendationWeights(
        val useCase: Int,
        val branchDetail: Int,
        val battery: Int,
        val size: Int,
        val niceHave: Int,
        val longTerm: Int,
        val purchase: Int,
        val design: Int
    )

    private fun weightsFor(use: PrimaryUse): RecommendationWeights = when (use) {
        PrimaryUse.GAMING -> RecommendationWeights(12, 10, 5, 2, 2, 3, 2, 2)
        PrimaryUse.CAMERA -> RecommendationWeights(12, 10, 3, 2, 3, 3, 2, 3)
        PrimaryUse.VIDEO, PrimaryUse.VIDEO_EDITING -> RecommendationWeights(11, 10, 4, 2, 2, 3, 2, 3)
        PrimaryUse.WORK -> RecommendationWeights(11, 8, 4, 3, 2, 5, 3, 3)
        PrimaryUse.AI -> RecommendationWeights(12, 10, 3, 2, 2, 4, 2, 3)
        PrimaryUse.SNS -> RecommendationWeights(9, 7, 5, 3, 3, 3, 2, 3)
        PrimaryUse.GENERAL, PrimaryUse.CALLS, PrimaryUse.MUSIC, PrimaryUse.EBOOK, PrimaryUse.OTHER ->
            RecommendationWeights(8, 4, 5, 4, 3, 4, 3, 3)
    }

    private fun score(r: UserRequirement, c: PhoneListRow): Int {
        val weights = weightsFor(r.primaryUse)
        var score = when (budgetStatus(r.budget, effectiveRecommendationPrice(c))) {
            BudgetStatus.WITHIN_TARGET -> 8
            BudgetStatus.OVER_TARGET_WITHIN_MAX -> 3
            else -> 0
        }
        score += useCaseScore(r.primaryUse, c) * weights.useCase / 12
        score += branchDetailScore(r, c) * weights.branchDetail / 12
        score += batteryScore(r, c) * weights.battery / 5
        score += sizeScore(r, c) * weights.size / 5
        score += niceHaveScore(r, c) * weights.niceHave / 3
        score += longTermScore(r, c) * weights.longTerm / 6
        score += purchaseScore(r, c) * weights.purchase / 4
        score += designScore(r, c) * weights.design / 3
        return score
    }

    private fun useCaseScore(use: PrimaryUse, c: PhoneListRow): Int = when (use) {
        PrimaryUse.GAMING -> levelScore(c.gamingLevel)
        PrimaryUse.CAMERA -> levelScore(c.cameraLevel)
        PrimaryUse.VIDEO -> levelScore(c.videoLevel)
        PrimaryUse.WORK -> levelScore(c.workStudyLevel)
        PrimaryUse.AI -> levelScore(c.aiLevel)
        PrimaryUse.GENERAL, PrimaryUse.SNS, PrimaryUse.CALLS, PrimaryUse.MUSIC, PrimaryUse.EBOOK, PrimaryUse.VIDEO_EDITING, PrimaryUse.OTHER -> levelScore(c.generalLevel)
    }

    private fun branchDetailScore(r: UserRequirement, c: PhoneListRow): Int = when (r.primaryUse) {
        PrimaryUse.GAMING -> when (r.gameType) {
            "軽いゲーム" -> levelScore(c.gamingLevel) / 4
            "普通のゲーム" -> levelScore(c.gamingLevel) / 3
            "重い3Dゲーム" -> levelScore(c.gamingLevel) / 2
            "最高画質" -> levelScore(c.gamingLevel)
            else -> 0
        }
        PrimaryUse.CAMERA -> when (r.cameraSubject) {
            "夜景", "スポーツ・動くもの", "子ども", "ペット" -> levelScore(c.cameraLevel) / 2
            "人物", "旅行", "風景" -> levelScore(c.cameraLevel) / 3
            else -> 0
        }
        PrimaryUse.VIDEO, PrimaryUse.SNS -> when (r.useDetail) {
            "撮影する", "写真・動画を投稿", "撮影と編集の両方", "撮影・編集も重視" -> levelScore(c.videoLevel) / 2
            else -> 0
        }
        PrimaryUse.VIDEO_EDITING -> when (r.useDetail) {
            "本格的な編集" -> levelScore(c.videoLevel)
            "SNS動画編集" -> levelScore(c.videoLevel) / 2
            "軽い編集" -> levelScore(c.videoLevel) / 3
            else -> 0
        }
        PrimaryUse.WORK -> when (r.useDetail) {
            "PDF・Office", "オンライン会議", "長文入力", "AIも使う" -> levelScore(c.workStudyLevel) / 2
            else -> 0
        }
        PrimaryUse.AI -> when (r.useDetail) {
            "画像生成", "端末内AI" -> levelScore(c.aiLevel)
            "文章作成", "音声" -> levelScore(c.aiLevel) / 2
            "チャット" -> levelScore(c.aiLevel) / 3
            else -> 0
        }
        else -> 0
    }

    private fun levelScore(level: AttributeLevel?): Int = when (level) {
        AttributeLevel.EXCELLENT -> 12
        AttributeLevel.GOOD -> 8
        AttributeLevel.STANDARD -> 4
        AttributeLevel.WEAK -> 0
        AttributeLevel.UNKNOWN, null -> 0
    }

    private fun purchaseChannelMatches(required: String?, channels: String?): Boolean {
        if (required.isNullOrBlank() || required == "特に決めていない") return true
        val wanted = when (required) {
            "SIMフリー" -> "SIM_FREE"
            "docomo" -> "DOCOMO"
            "au" -> "AU"
            "SoftBank" -> "SOFTBANK"
            "楽天モバイル" -> "RAKUTEN"
            "UQ mobile" -> "UQ_MOBILE"
            "Y!mobile" -> "Y_MOBILE"
            "IIJmio" -> "IIJ_MIO"
            "mineo" -> "MINEO"
            "MVNO" -> "MVNO"
            else -> return false
        }
        return channels?.split(',')?.any { it.trim() == wanted } == true
    }

    private fun productConditionMatches(required: String?, actual: jp.smartphoneadvisor.app.data.ProductCondition): Boolean =
        required.isNullOrBlank() || required == "中古も候補" || required == "未使用品・整備済みも候補" ||
            required != "新品のみ" || actual == jp.smartphoneadvisor.app.data.ProductCondition.NEW

    private fun batteryScore(r: UserRequirement, c: PhoneListRow): Int {
        var score = when (r.batteryImportance) { 0 -> 0; 2 -> 3; 3 -> 5; else -> 1 }
        if (r.batteryImportance > 0) {
            when {
                c.batteryCapacityMah == null -> Unit
                c.batteryCapacityMah >= 5000 -> score += 3
                c.batteryCapacityMah >= 4500 -> score += 1
            }
            if (r.batteryChargePreference == "外出中はあまり充電できない" && c.batteryCapacityMah != null && c.batteryCapacityMah >= 5000) score += 3
            if (r.batteryChargePreference == "モバイルバッテリーをよく使う" && (c.chargingPowerW ?: 0) >= 45) score += 2
        }
        return score
    }

    private fun sizeScore(r: UserRequirement, c: PhoneListRow): Int = when (r.sizePreference) {
        "小さく軽い方がいい" -> when { c.weightG == null -> 0; c.weightG <= 190 -> 5; c.weightG <= 210 -> 2; else -> 0 }
        "大きくても画面重視" -> when { (c.displayDiagonalInch ?: 0.0) >= 6.7 -> 5; (c.displayDiagonalInch ?: 0.0) >= 6.5 -> 2; else -> 0 }
        else -> 0
    }

    private fun niceHaveScore(r: UserRequirement, c: PhoneListRow): Int = r.niceHaveFeatures.sumOf { key ->
        when (key) {
            "高リフレッシュレート" -> if ((c.displayRefreshRateHz ?: 0) >= 120) 3 else 0
            "ワイヤレス充電" -> if (c.batteryWirelessCharging == SupportStatus.SUPPORTED) 3 else 0
            "指紋認証" -> if (c.fingerprint == SupportStatus.SUPPORTED) 3 else 0
            "microSD" -> if (c.microSd == SupportStatus.SUPPORTED) 3 else 0
            "イヤホンジャック" -> if (c.headphoneJack == SupportStatus.SUPPORTED) 3 else 0
            "軽量" -> if ((c.weightG ?: 999.0) <= 190) 3 else 0
            "大画面" -> if ((c.displayDiagonalInch ?: 0.0) >= 6.7) 3 else 0
            "望遠カメラ" -> if ((c.rearTelephotoMp ?: 0.0) > 0.0) 3 else 0
            else -> 0
        }
    }

    private fun longTermScore(r: UserRequirement, c: PhoneListRow): Int {
        val years = r.intendedUseYears ?: return 0
        val support = c.updateSupportYears ?: return 0
        return when { support >= years -> 6; support + 1 >= years -> 3; else -> 0 }
    }

    private fun purchaseScore(r: UserRequirement, c: PhoneListRow): Int =
        if (purchaseChannelMatches(r.purchaseChannel, c.purchaseChannels) && !r.purchaseChannel.isNullOrBlank() && r.purchaseChannel != "特に決めていない") 4 else 0

    private fun designScore(r: UserRequirement, c: PhoneListRow): Int = when (r.designPreference) {
        "見やすさ・大画面" -> if ((c.displayDiagonalInch ?: 0.0) >= 6.7) 3 else 0
        "高リフレッシュレート" -> if ((c.displayRefreshRateHz ?: 0) >= 120) 3 else 0
        "片手で使いやすい" -> if ((c.weightG ?: 999.0) <= 190 && (c.displayDiagonalInch ?: 99.0) <= 6.4) 3 else 0
        else -> 0
    }

    private fun buildReasons(r: UserRequirement, c: PhoneListRow): List<String> = buildList {
        when (budgetStatus(r.budget, effectiveRecommendationPrice(c))) {
            BudgetStatus.WITHIN_TARGET -> add("あなたが設定した希望予算の範囲内です")
            BudgetStatus.OVER_TARGET_WITHIN_MAX -> add("希望予算は超えますが、あなたが設定した絶対上限以内です")
            else -> Unit
        }
        if (r.storageMinimumGb != null && c.storageGb >= r.storageMinimumGb) {
            add("あなたが指定した${r.storageMinimumGb}GB以上のストレージ条件を満たしています")
        }
        if (r.mustHaveFeatures.isNotEmpty()) {
            add("あなたが必須にした機能をすべて確認できています")
        }
        if (!r.purchaseChannel.isNullOrBlank() && r.purchaseChannel != "特に決めていない") {
            add("あなたが指定した${r.purchaseChannel}での販売データがあります")
        }
        if (r.intendedUseYears != null && c.updateSupportYears != null && c.updateSupportYears >= r.intendedUseYears) {
            add("あなたが予定している${r.intendedUseYears}年の利用に対して、更新サポート期間が確認できています")
        }
        when (r.sizePreference) {
            "小さく軽い方がいい" -> if ((c.weightG ?: 999.0) <= 190) add("あなたが重視した軽さに合っています")
            "大きくても画面重視" -> if ((c.displayDiagonalInch ?: 0.0) >= 6.7) add("あなたが重視した大画面に合っています")
        }
        if (r.batteryImportance >= 2 && (c.batteryCapacityMah ?: 0) >= 5000) {
            add("あなたが重視したバッテリー容量の条件に合っています")
        }
        if (r.batteryChargePreference == "モバイルバッテリーをよく使う" && (c.chargingPowerW ?: 0) >= 45) {
            add("あなたの充電スタイルに対して、比較的速い充電出力が確認できています")
        }
        r.niceHaveFeatures.forEach { key ->
            if (niceHaveSupported(key, c)) add("「$key」を希望しており、この端末は対応しています")
        }
        when (r.designPreference) {
            "見やすさ・大画面" -> if ((c.displayDiagonalInch ?: 0.0) >= 6.7) add("あなたが希望した見やすさ・大画面の方向性に合っています")
            "高リフレッシュレート" -> if ((c.displayRefreshRateHz ?: 0) >= 120) add("あなたが希望した高リフレッシュレートに対応しています")
            "片手で使いやすい" -> if ((c.weightG ?: 999.0) <= 190 && (c.displayDiagonalInch ?: 99.0) <= 6.4) add("あなたが希望した片手での使いやすさに近いサイズ・重量です")
        }
        when (r.primaryUse) {
            PrimaryUse.GAMING -> addUseReason("ゲーム", c.gamingLevel)
            PrimaryUse.CAMERA -> addUseReason("カメラ", c.cameraLevel)
            PrimaryUse.VIDEO -> addUseReason("動画", c.videoLevel)
            PrimaryUse.WORK -> addUseReason("仕事・学習", c.workStudyLevel)
            PrimaryUse.AI -> addUseReason("AI", c.aiLevel)
            PrimaryUse.VIDEO_EDITING -> addUseReason("動画編集", c.videoLevel)
            PrimaryUse.SNS -> addUseReason("SNS", c.generalLevel)
            else -> addUseReason("普段使い", c.generalLevel)
        }
        when (r.primaryUse) {
            PrimaryUse.GAMING -> r.gameType?.takeIf { it != "よく分からない" }?.let { add("ゲームの種類として「$it」を選択した条件を反映しています") }
            PrimaryUse.CAMERA -> r.cameraSubject?.let { add("撮影対象として「$it」を選択した条件を反映しています") }
            PrimaryUse.VIDEO, PrimaryUse.SNS, PrimaryUse.WORK, PrimaryUse.AI, PrimaryUse.VIDEO_EDITING ->
                r.useDetail?.let { add("用途の詳細として「$it」を選択した条件を反映しています") }
            else -> Unit
        }
    }

    private fun niceHaveSupported(key: String, c: PhoneListRow): Boolean = when (key) {
        "高リフレッシュレート" -> (c.displayRefreshRateHz ?: 0) >= 120
        "ワイヤレス充電" -> c.batteryWirelessCharging == SupportStatus.SUPPORTED
        "指紋認証" -> c.fingerprint == SupportStatus.SUPPORTED
        "microSD" -> c.microSd == SupportStatus.SUPPORTED
        "イヤホンジャック" -> c.headphoneJack == SupportStatus.SUPPORTED
        "軽量" -> (c.weightG ?: 999.0) <= 190
        "大画面" -> (c.displayDiagonalInch ?: 0.0) >= 6.7
        "望遠カメラ" -> (c.rearTelephotoMp ?: 0.0) > 0.0
        else -> false
    }

    private fun buildCautions(r: UserRequirement, c: PhoneListRow): List<String> = buildList {
        if (r.budget.targetPriceYen != null && c.normalPriceYen != null && c.normalPriceYen > r.budget.targetPriceYen) {
            add("希望予算を${formatYen(r.budget.targetPriceYen)}上回っています")
        }
        if (c.normalPriceYen == null) add("通常価格が未確認のため、予算との比較には注意が必要です")
        when (r.primaryUse) {
            PrimaryUse.GAMING -> if (r.gameType != null && r.gameType != "よく分からない" && (c.gamingLevel == null || c.gamingLevel == AttributeLevel.UNKNOWN)) add("選択したゲーム用途に関する性能データが未確認です")
            PrimaryUse.CAMERA -> if (r.cameraSubject != null && (c.cameraLevel == null || c.cameraLevel == AttributeLevel.UNKNOWN)) add("選択した撮影用途に関するカメラ評価データが未確認です")
            PrimaryUse.VIDEO, PrimaryUse.SNS, PrimaryUse.VIDEO_EDITING -> if (r.useDetail != null && (c.videoLevel == null || c.videoLevel == AttributeLevel.UNKNOWN)) add("選択した動画用途に関するデータが未確認です")
            PrimaryUse.WORK -> if (r.useDetail != null && (c.workStudyLevel == null || c.workStudyLevel == AttributeLevel.UNKNOWN)) add("選択した仕事・学習用途に関するデータが未確認です")
            PrimaryUse.AI -> if (r.useDetail != null && (c.aiLevel == null || c.aiLevel == AttributeLevel.UNKNOWN)) add("選択したAI用途に関するデータが未確認です")
            else -> Unit
        }
        if (r.intendedUseYears != null && c.updateSupportYears == null) add("長期利用に関係する更新サポート年数が未確認です")
        if (r.sizePreference == "小さく軽い方がいい") {
            when {
                c.weightG == null -> add("本体重量が未確認のため、軽さの判定は限定的です")
                c.weightG > 210 -> add("あなたが希望した軽さに対して、本体重量がやや大きめです")
            }
        }
        if (r.sizePreference == "大きくても画面重視" && c.displayDiagonalInch == null) add("画面サイズが未確認のため、大画面条件の判定は限定的です")
        if (r.batteryImportance > 0 && c.batteryCapacityMah == null) add("バッテリー容量が未確認のため、電池持ちの判定は限定的です")
        if (r.batteryChargePreference == "モバイルバッテリーをよく使う" && c.chargingPowerW == null) add("充電出力が未確認のため、充電速度の判定は限定的です")
        if (r.purchaseChannel != null && r.purchaseChannel != "特に決めていない" && !purchaseChannelMatches(r.purchaseChannel, c.purchaseChannels)) add("指定した購入先での販売条件を確認してください")
        r.niceHaveFeatures.forEach { key ->
            if (!niceHaveSupported(key, c)) {
                when (key) {
                    "ワイヤレス充電" -> if (c.batteryWirelessCharging == SupportStatus.UNKNOWN) add("ワイヤレス充電の対応状況が未確認です")
                    "指紋認証" -> if (c.fingerprint == SupportStatus.UNKNOWN) add("指紋認証の対応状況が未確認です")
                    "microSD" -> if (c.microSd == SupportStatus.UNKNOWN) add("microSDの対応状況が未確認です")
                    "イヤホンジャック" -> if (c.headphoneJack == SupportStatus.UNKNOWN) add("イヤホンジャックの対応状況が未確認です")
                    "望遠カメラ" -> if (c.rearTelephotoMp == null) add("望遠カメラの情報が未確認です")
                }
            }
        }
        when (r.primaryUse) {
            PrimaryUse.GAMING -> addUseCaution("ゲーム", c.gamingLevel)
            PrimaryUse.CAMERA -> addUseCaution("カメラ", c.cameraLevel)
            PrimaryUse.VIDEO -> addUseCaution("動画", c.videoLevel)
            PrimaryUse.WORK -> addUseCaution("仕事・学習", c.workStudyLevel)
            PrimaryUse.AI -> addUseCaution("AI", c.aiLevel)
            PrimaryUse.VIDEO_EDITING -> addUseCaution("動画編集", c.videoLevel)
            else -> Unit
        }
        if (c.priceSourceType == null) {
            add("価格情報の出典が未登録のため、情報源の信頼度を確認できません")
        } else if (sourceReliability(c.priceSourceType) <= 1) {
            add("価格情報の出典の信頼度が低いため、購入前に公式情報も確認してください")
        }
        when (dataFreshnessStatus(c.priceCheckedAt, PRICE_FRESH_DAYS)) {
            DataFreshnessStatus.AGING -> add("価格情報は少し古いため、最新価格を確認してください")
            DataFreshnessStatus.STALE, DataFreshnessStatus.UNKNOWN -> add("価格情報が古いか未確認のため、現在の価格としては注意が必要です")
            DataFreshnessStatus.FRESH -> Unit
        }
        when (dataFreshnessStatus(c.availabilityCheckedAt, AVAILABILITY_FRESH_DAYS)) {
            DataFreshnessStatus.AGING -> add("販売状況の確認日が少し古いため、購入前に在庫を確認してください")
            DataFreshnessStatus.STALE, DataFreshnessStatus.UNKNOWN -> add("販売状況が古いか未確認のため、購入前に在庫・販売継続を確認してください")
            DataFreshnessStatus.FRESH -> Unit
        }
        if (c.availabilityStatus == "OUT_OF_STOCK") add("現在の在庫状況では在庫切れとして登録されています")
        if (c.availabilityStatus == "DISCONTINUED") add("販売終了として登録されています")
        if (c.waterproof == SupportStatus.UNKNOWN) add("防水情報は未確認です")
    }

    private fun MutableList<String>.addUseCaution(label: String, level: AttributeLevel?) {
        when (level) {
            AttributeLevel.UNKNOWN, null -> add("$label用途の適性データが未確認です")
            AttributeLevel.WEAK -> add("$label用途では注意が必要な適性評価です")
            else -> Unit
        }
    }

    private fun formatYen(value: Int): String = "¥%,d".format(value)

}
