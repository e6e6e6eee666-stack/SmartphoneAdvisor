package jp.smartphoneadvisor.app.data

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

enum class CandidateOs { ANDROID, IPHONE, EITHER }
enum class PrimaryUse { GENERAL, GAMING, CAMERA, VIDEO, SNS, CALLS, MUSIC, EBOOK, WORK, AI, VIDEO_EDITING, OTHER }
enum class ProductCondition { NEW, USED, REFURBISHED }
enum class SupportStatus { SUPPORTED, NOT_SUPPORTED, UNKNOWN }
enum class AttributeLevel { EXCELLENT, GOOD, STANDARD, WEAK, UNKNOWN }

enum class SalesChannel {
    SIM_FREE, DOCOMO, AU, SOFTBANK, RAKUTEN,
    UQ_MOBILE, Y_MOBILE, IIJ_MIO, MINEO,
    MVNO, OTHER
}
enum class RetailerType { MANUFACTURER, CARRIER, AMAZON, RAKUTEN, MVNO, OTHER }
enum class PriceType { NORMAL, SALE, CAMPAIGN, MNP, NEW_CONTRACT, MODEL_CHANGE, CONTRACT_REQUIRED, OTHER }
enum class AvailabilityStatus { AVAILABLE, LIMITED, OUT_OF_STOCK, DISCONTINUED, PREORDER, UNKNOWN }
enum class SourceType { MANUFACTURER_OFFICIAL, JAPAN_OFFICIAL_SALES, CARRIER_OFFICIAL, TRUSTED_THIRD_PARTY, REVIEW, OTHER }
enum class ConflictSeverity { INFO, WARNING, CRITICAL }

@Entity(tableName = "data_source")
data class DataSourceEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val sourceType: SourceType,
    val url: String? = null,
    val isOfficial: Boolean = false,
    val isActive: Boolean = true
)

@Entity(
    tableName = "sales_variant",
    indices = [Index(value = ["deviceVariantId", "salesChannel", "modelNumber"], unique = true)]
)
data class SalesVariantEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val deviceVariantId: Long,
    val salesChannel: SalesChannel,
    val modelNumber: String? = null,
    val simType: String? = null,
    val isActive: Boolean = true
)

@Entity(tableName = "retailer")
data class RetailerEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val type: RetailerType,
    val official: Boolean,
    val websiteUrl: String? = null
)

@Entity(tableName = "product_listing", indices = [Index(value = ["salesVariantId", "retailerId"], unique = true)])
data class ProductListingEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val salesVariantId: Long,
    val retailerId: Long,
    val productUrl: String,
    val productName: String? = null,
    val availability: AvailabilityStatus = AvailabilityStatus.UNKNOWN,
    val checkedAt: Long
)

@Entity(tableName = "campaign")
data class CampaignEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val description: String? = null,
    val startsAt: Long? = null,
    val endsAt: Long? = null,
    val conditions: String? = null,
    val sourceId: Long? = null,
    val checkedAt: Long
)

@Entity(tableName = "price_record_v2", indices = [Index(value = ["productListingId", "priceType", "checkedAt"]), Index(value = ["productListingId", "priceType", "color", "checkedAt"])])
data class PriceRecordV2Entity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val productListingId: Long,
    val priceType: PriceType,
    val priceYen: Int?,
    val pointsValueYen: Int? = null,
    val couponValueYen: Int? = null,
    val tradeInValueYen: Int? = null,
    val shippingFeeYen: Int? = null,
    val conditions: String? = null,
    val campaignId: Long? = null,
    val checkedAt: Long,
    val sourceId: Long? = null,
    val color: String? = null,
    val sourceUrl: String? = null
)

@Entity(
    tableName = "favorite_device",
    indices = [Index(value = ["deviceVariantId"], unique = true)]
)
data class FavoriteDeviceEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val deviceVariantId: Long,
    val createdAt: Long
)

@Entity(tableName = "manufacturer")
data class ManufacturerEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val country: String? = null,
    val officialWebsiteUrl: String? = null,
    val isActive: Boolean = true
)

@Entity(tableName = "smartphone_model")
data class SmartphoneModelEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val manufacturerId: Long,
    val seriesName: String?,
    val seriesId: Long? = null,
    val modelName: String,
    val platform: String = "ANDROID",
    val releaseYear: Int,
    val releaseDate: String?,
    val isJapanOfficial: Boolean,
    val isActive: Boolean = true
)

@Entity(
    tableName = "device_variant",
    indices = [Index(value = ["modelId", "storageGb", "ramGb"], unique = true)]
)
data class DeviceVariantEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val modelId: Long,
    val storageGb: Int,
    val ramGb: Int?,
    val condition: ProductCondition = ProductCondition.NEW,
    val isActive: Boolean = true
)

@Entity(
    tableName = "physical_specs",
    indices = [Index(value = ["deviceVariantId"], unique = true)]
)
data class PhysicalSpecsEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val deviceVariantId: Long,
    val heightMm: Double? = null,
    val widthMm: Double? = null,
    val thicknessMm: Double? = null,
    val weightG: Double? = null,
    val measurementSource: String? = null
)

@Entity(
    tableName = "display_specs",
    indices = [Index(value = ["deviceVariantId"], unique = true)]
)
data class DisplaySpecsEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val deviceVariantId: Long,
    val heightMm: Double? = null,
    val widthMm: Double? = null,
    val diagonalInch: Double? = null,
    val resolutionText: String? = null,
    val panelType: String? = null,
    val refreshRateHz: Int? = null,
    val measurementSource: String? = null
)

@Entity(
    tableName = "camera_specs",
    indices = [Index(value = ["deviceVariantId"], unique = true)]
)
data class CameraSpecsEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val deviceVariantId: Long,
    val rearMainMp: Double? = null,
    val rearUltraWideMp: Double? = null,
    val rearTelephotoMp: Double? = null,
    val frontMp: Double? = null,
    val videoMaxText: String? = null,
    val stabilizationText: String? = null,
    val sourceNote: String? = null
)

@Entity(
    tableName = "battery_specs",
    indices = [Index(value = ["deviceVariantId"], unique = true)]
)
data class BatterySpecsEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val deviceVariantId: Long,
    val capacityMah: Int? = null,
    val chargingPowerW: Int? = null,
    val wirelessCharging: SupportStatus = SupportStatus.UNKNOWN,
    val manufacturerClaim: String? = null,
    val realWorldTestHours: Double? = null,
    val sourceNote: String? = null
)

@Entity(
    tableName = "connectivity_specs",
    indices = [Index(value = ["deviceVariantId"], unique = true)]
)
data class ConnectivitySpecsEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val deviceVariantId: Long,
    val fiveG: SupportStatus = SupportStatus.UNKNOWN,
    val simCount: Int? = null,
    val esim: SupportStatus = SupportStatus.UNKNOWN,
    val wifiText: String? = null,
    val bluetoothText: String? = null,
    val sourceNote: String? = null
)

@Entity(
    tableName = "software_specs",
    indices = [Index(value = ["deviceVariantId"], unique = true)]
)
data class SoftwareSpecsEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val deviceVariantId: Long,
    val osVersion: String? = null,
    val updateSupportYears: Int? = null,
    val securitySupportUntil: String? = null,
    val sourceNote: String? = null
)

@Entity(
    tableName = "recommendation_attributes",
    indices = [Index(value = ["deviceVariantId"], unique = true)]
)
data class RecommendationAttributesEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val deviceVariantId: Long,
    val gamingLevel: AttributeLevel = AttributeLevel.UNKNOWN,
    val cameraLevel: AttributeLevel = AttributeLevel.UNKNOWN,
    val videoLevel: AttributeLevel = AttributeLevel.UNKNOWN,
    val workStudyLevel: AttributeLevel = AttributeLevel.UNKNOWN,
    val aiLevel: AttributeLevel = AttributeLevel.UNKNOWN,
    val generalLevel: AttributeLevel = AttributeLevel.UNKNOWN,
    val batterySuitability: AttributeLevel = AttributeLevel.UNKNOWN,
    val portabilityLevel: AttributeLevel = AttributeLevel.UNKNOWN,
    val longTermSupportLevel: AttributeLevel = AttributeLevel.UNKNOWN,
    val osaifuKeitai: SupportStatus = SupportStatus.UNKNOWN,
    val waterproof: SupportStatus = SupportStatus.UNKNOWN,
    val esim: SupportStatus = SupportStatus.UNKNOWN,
    val fingerprint: SupportStatus = SupportStatus.UNKNOWN,
    val wirelessCharging: SupportStatus = SupportStatus.UNKNOWN,
    val microSd: SupportStatus = SupportStatus.UNKNOWN,
    val headphoneJack: SupportStatus = SupportStatus.UNKNOWN
)

@Entity(
    tableName = "price_record",
    indices = [Index(value = ["deviceVariantId", "priceType", "isCurrent"])]
)
data class PriceRecordEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val deviceVariantId: Long,
    val priceType: String,
    val priceYen: Int?,
    val checkedAt: Long,
    val isCurrent: Boolean = true,
    val sourceId: Long? = null
)

@Entity(tableName = "diagnostic_profile")
data class DiagnosticProfileEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val createdAt: Long,
    val updatedAt: Long,
    val lastRunAt: Long? = null,
    val isActive: Boolean = true
)

@Entity(
    tableName = "diagnostic_answer",
    indices = [Index(value = ["profileId", "questionId"], unique = true)]
)
data class DiagnosticAnswerEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val profileId: Long,
    val questionId: String,
    val answerValue: String
)

@Entity(tableName = "diagnostic_draft")
data class DiagnosticDraftEntity(
    @PrimaryKey val id: Int = 1,
    val payload: String,
    val updatedAt: Long
)

@Entity(tableName = "diagnostic_run")
data class DiagnosticRunEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val profileId: Long,
    val executedAt: Long,
    val databaseVersion: String,
    val requirementSnapshot: String,
    val recommendedDeviceIds: String,
    val excludedDeviceIds: String
)
