package jp.smartphoneadvisor.app.data.catalog

import jp.smartphoneadvisor.app.data.DeviceVariantEntity
import jp.smartphoneadvisor.app.data.PriceRecordV2Entity
import jp.smartphoneadvisor.app.data.ProductListingEntity
import jp.smartphoneadvisor.app.data.RetailerEntity
import jp.smartphoneadvisor.app.data.SalesVariantEntity

/** Read-only cross-table integrity checks. It never repairs, deletes, or merges records. */
object ProductListingRelationAudit {
    data class Report(
        val salesVariantRows: Int,
        val productListingRows: Int,
        val priceRecordRows: Int,
        val salesVariantsMissingDeviceVariant: Map<Long, Long>,
        val listingsMissingSalesVariant: Map<Long, Long>,
        val listingsMissingRetailer: Map<Long, Long>,
        val blankProductUrls: Map<Long, Long>,
        val duplicateListingIdentities: Map<String, Int>,
        val priceRecordsMissingListing: Map<Long, Long>,
        val duplicateSalesVariantIdentities: Map<String, Int>
    ) {
        /** Number of distinct issue keys/groups, not the number of affected rows. */
        val issueGroupCount: Int get() = salesVariantsMissingDeviceVariant.size + listingsMissingSalesVariant.size +
            listingsMissingRetailer.size + blankProductUrls.size + duplicateListingIdentities.size +
            priceRecordsMissingListing.size + duplicateSalesVariantIdentities.size

        /** Sum of affected-row incidences. A row can appear in more than one issue category. */
        val issueRowCount: Int get() = salesVariantsMissingDeviceVariant.size + listingsMissingSalesVariant.size +
            listingsMissingRetailer.size + blankProductUrls.size + priceRecordsMissingListing.size +
            duplicateListingIdentities.values.sumOf { it } + duplicateSalesVariantIdentities.values.sumOf { it }
    }

    fun analyze(
        deviceVariants: List<DeviceVariantEntity>,
        salesVariants: List<SalesVariantEntity>,
        retailers: List<RetailerEntity>,
        listings: List<ProductListingEntity>,
        prices: List<PriceRecordV2Entity>
    ): Report {
        val deviceVariantIds = deviceVariants.map { it.id }.toSet()
        val salesVariantIds = salesVariants.map { it.id }.toSet()
        val retailerIds = retailers.map { it.id }.toSet()
        val listingIds = listings.map { it.id }.toSet()
        val duplicateListingIdentities = listings
            .groupingBy { "salesVariantId=${it.salesVariantId},retailerId=${it.retailerId}" }
            .eachCount().filterValues { it > 1 }.toSortedMap()
        // SQLite UNIQUE indexes treat NULL values as distinct. Therefore the declared
        // (deviceVariantId, salesChannel, modelNumber) index cannot alone prevent
        // duplicate identities when modelNumber is NULL.
        val duplicateSalesVariantIdentities = salesVariants
            .groupingBy { "deviceVariantId=${it.deviceVariantId},salesChannel=${it.salesChannel},modelNumber=${it.modelNumber ?: "<NULL>"}" }
            .eachCount().filterValues { it > 1 }.toSortedMap()
        return Report(
            salesVariantRows = salesVariants.size,
            productListingRows = listings.size,
            priceRecordRows = prices.size,
            salesVariantsMissingDeviceVariant = salesVariants.filter { it.deviceVariantId !in deviceVariantIds }
                .associate { it.id to it.deviceVariantId }.toSortedMap(),
            listingsMissingSalesVariant = listings.filter { it.salesVariantId !in salesVariantIds }
                .associate { it.id to it.salesVariantId }.toSortedMap(),
            listingsMissingRetailer = listings.filter { it.retailerId !in retailerIds }
                .associate { it.id to it.retailerId }.toSortedMap(),
            blankProductUrls = listings.filter { it.productUrl.isBlank() }
                .associate { it.id to it.retailerId }.toSortedMap(),
            duplicateListingIdentities = duplicateListingIdentities,
            priceRecordsMissingListing = prices.filter { it.productListingId !in listingIds }
                .associate { it.id to it.productListingId }.toSortedMap(),
            duplicateSalesVariantIdentities = duplicateSalesVariantIdentities
        )
    }
}
