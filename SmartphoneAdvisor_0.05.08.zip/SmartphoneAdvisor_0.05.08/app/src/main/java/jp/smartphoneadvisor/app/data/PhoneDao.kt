package jp.smartphoneadvisor.app.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import kotlinx.coroutines.flow.Flow

@Dao
interface PhoneDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertManufacturers(items: List<ManufacturerEntity>): List<Long>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertSeries(items: List<PhoneSeriesEntity>): List<Long>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertChangeLogs(items: List<DataChangeLogEntity>)

    @Query("SELECT * FROM phone_series WHERE manufacturerId = :manufacturerId AND isActive = 1 ORDER BY name")
    suspend fun getSeriesForManufacturer(manufacturerId: Long): List<PhoneSeriesEntity>

    @Query("SELECT * FROM data_change_log WHERE deviceVariantId = :deviceVariantId ORDER BY changedAt DESC")
    suspend fun getChangeLogs(deviceVariantId: Long): List<DataChangeLogEntity>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertModels(items: List<SmartphoneModelEntity>): List<Long>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertVariants(items: List<DeviceVariantEntity>): List<Long>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertAttributes(items: List<RecommendationAttributesEntity>)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertPrices(items: List<PriceRecordEntity>)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertDataSources(items: List<DataSourceEntity>)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertDataConflicts(items: List<DataConflictEntity>)

    @Query("SELECT * FROM data_conflict WHERE deviceVariantId = :deviceVariantId AND isResolved = 0 ORDER BY severity DESC, detectedAt DESC")
    suspend fun getOpenDataConflicts(deviceVariantId: Long): List<DataConflictEntity>

    @Query("SELECT id FROM data_source WHERE name = :name LIMIT 1")
    suspend fun getDataSourceId(name: String): Long?

    @Query("UPDATE price_record SET sourceId = :sourceId WHERE sourceId IS NULL")
    suspend fun attributeUnattributedPrices(sourceId: Long)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertPhysicalSpecs(items: List<PhysicalSpecsEntity>)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertDisplaySpecs(items: List<DisplaySpecsEntity>)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertCameraSpecs(items: List<CameraSpecsEntity>)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertBatterySpecs(items: List<BatterySpecsEntity>)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertConnectivitySpecs(items: List<ConnectivitySpecsEntity>)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertSoftwareSpecs(items: List<SoftwareSpecsEntity>)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertSalesVariants(items: List<SalesVariantEntity>)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertRetailers(items: List<RetailerEntity>)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertProductListings(items: List<ProductListingEntity>)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertCampaigns(items: List<CampaignEntity>)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertPriceRecordsV2(items: List<PriceRecordV2Entity>)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertFavorite(item: FavoriteDeviceEntity)

    @Query("DELETE FROM favorite_device WHERE deviceVariantId = :deviceVariantId")
    suspend fun deleteFavorite(deviceVariantId: Long)

    @Query("SELECT EXISTS(SELECT 1 FROM favorite_device WHERE deviceVariantId = :deviceVariantId)")
    suspend fun isFavorite(deviceVariantId: Long): Boolean

    @Query("SELECT deviceVariantId FROM favorite_device ORDER BY createdAt DESC")
    fun observeFavoriteDeviceIds(): Flow<List<Long>>

    @Query("SELECT COUNT(*) FROM price_record")
    suspend fun countPriceRecords(): Int

    @Query("SELECT d.id AS deviceVariantId, m.modelName AS modelName FROM device_variant d INNER JOIN smartphone_model m ON m.id = d.modelId")
    suspend fun getAllDeviceModels(): List<DeviceModelRow>
    @Query("""
        SELECT d.id AS deviceVariantId,
               m.modelName AS modelName,
               mf.name AS manufacturerName,
               d.storageGb AS storageGb,
               d.ramGb AS ramGb,
               p.priceYen AS normalPriceYen,
               p.checkedAt AS priceCheckedAt,
               ps.heightMm AS bodyHeightMm,
               ps.widthMm AS bodyWidthMm,
               ps.thicknessMm AS bodyThicknessMm,
               ps.weightG AS weightG,
               ds.diagonalInch AS displayDiagonalInch,
               ds.resolutionText AS displayResolutionText,
               ds.panelType AS displayPanelType,
               ds.refreshRateHz AS displayRefreshRateHz,
               cs.rearMainMp AS rearMainMp,
               cs.rearUltraWideMp AS rearUltraWideMp,
               cs.rearTelephotoMp AS rearTelephotoMp,
               bs.capacityMah AS batteryCapacityMah,
               bs.chargingPowerW AS chargingPowerW,
               bs.wirelessCharging AS batteryWirelessCharging,
               sw.updateSupportYears AS updateSupportYears,
               a.osaifuKeitai AS osaifuKeitai,
               a.waterproof AS waterproof,
               a.esim AS esim,
               a.microSd AS microSd,
               a.headphoneJack AS headphoneJack
        FROM device_variant d
        INNER JOIN smartphone_model m ON m.id = d.modelId
        INNER JOIN manufacturer mf ON mf.id = m.manufacturerId
        LEFT JOIN price_record p ON p.deviceVariantId = d.id AND p.priceType = 'NORMAL' AND p.isCurrent = 1
        LEFT JOIN physical_specs ps ON ps.deviceVariantId = d.id
        LEFT JOIN display_specs ds ON ds.deviceVariantId = d.id
        LEFT JOIN camera_specs cs ON cs.deviceVariantId = d.id
        LEFT JOIN battery_specs bs ON bs.deviceVariantId = d.id
        LEFT JOIN software_specs sw ON sw.deviceVariantId = d.id
        LEFT JOIN recommendation_attributes a ON a.deviceVariantId = d.id
        WHERE d.id IN (:deviceIds) AND d.isActive = 1 AND m.isActive = 1
        ORDER BY m.releaseYear DESC, m.modelName ASC, d.storageGb ASC
    """)
    suspend fun getComparisonItems(deviceIds: List<Long>): List<ComparisonRow>

    /** 最新の販売先別・色別価格。旧 price_record テーブルの価格と混ぜずに表示する。 */
    @Query("""
        SELECT sv.deviceVariantId AS deviceVariantId,
               r.name AS retailerName,
               r.official AS official,
               pr.color AS color,
               pr.priceType AS priceType,
               pr.priceYen AS priceYen,
               pr.checkedAt AS checkedAt,
               pr.conditions AS conditions,
               pr.sourceUrl AS sourceUrl,
               pl.productUrl AS productUrl
        FROM sales_variant sv
        INNER JOIN product_listing pl ON pl.salesVariantId = sv.id
        INNER JOIN retailer r ON r.id = pl.retailerId
        INNER JOIN price_record_v2 pr ON pr.productListingId = pl.id
        WHERE sv.deviceVariantId IN (:deviceIds)
          AND sv.isActive = 1
          AND pl.availability IN ('AVAILABLE','LIMITED')
          AND pl.productUrl IS NOT NULL
          AND TRIM(pl.productUrl) <> ''
          AND pr.priceYen IS NOT NULL
          AND pr.id = (
              SELECT pr2.id FROM price_record_v2 pr2
              WHERE pr2.productListingId = pr.productListingId
                AND pr2.priceType = pr.priceType
                AND ((pr2.color = pr.color) OR (pr2.color IS NULL AND pr.color IS NULL))
              ORDER BY pr2.checkedAt DESC, pr2.id DESC
              LIMIT 1
          )
        ORDER BY sv.deviceVariantId, r.official DESC, pr.priceType, pr.color, pr.priceYen
    """)
    suspend fun getComparisonPrices(deviceIds: List<Long>): List<ComparisonPriceRow>


    @Query("SELECT COUNT(*) FROM device_variant")
    suspend fun countDevices(): Int

    @Query("SELECT * FROM manufacturer WHERE name = :name ORDER BY id")
    suspend fun getManufacturersByName(name: String): List<ManufacturerEntity>

    @Query("SELECT id FROM manufacturer WHERE name = :name LIMIT 1")
    suspend fun getManufacturerId(name: String): Long?

    @Query("SELECT * FROM smartphone_model WHERE manufacturerId = :manufacturerId AND modelName = :modelName AND platform = :platform ORDER BY id")
    suspend fun getModelsByNameAndPlatform(manufacturerId: Long, modelName: String, platform: String): List<SmartphoneModelEntity>

    @Query("SELECT * FROM device_variant WHERE modelId = :modelId AND storageGb = :storageGb AND ((ramGb = :ramGb) OR (ramGb IS NULL AND :ramGb IS NULL)) ORDER BY id")
    suspend fun getVariantsByModelStorageAndRam(modelId: Long, storageGb: Int, ramGb: Int?): List<DeviceVariantEntity>

    @Query("SELECT EXISTS(SELECT 1 FROM recommendation_attributes WHERE deviceVariantId = :deviceVariantId)")
    suspend fun hasRecommendationAttributes(deviceVariantId: Long): Boolean

    @Query("SELECT id FROM phone_series WHERE manufacturerId = :manufacturerId AND name = :name LIMIT 1")
    suspend fun getSeriesId(manufacturerId: Long, name: String): Long?

    @Query("SELECT * FROM manufacturer WHERE isActive = 1 ORDER BY name")
    suspend fun getActiveManufacturers(): List<ManufacturerEntity>

    @Query("SELECT * FROM smartphone_model WHERE isActive = 1 AND manufacturerId = :manufacturerId ORDER BY releaseYear DESC, modelName ASC")
    suspend fun getModelsForManufacturer(manufacturerId: Long): List<SmartphoneModelEntity>

    @Query("""
        SELECT CASE
            WHEN COUNT(d.id) = 1 THEN MIN(d.id)
            ELSE NULL
        END
        FROM device_variant d
        INNER JOIN smartphone_model m ON m.id = d.modelId
        WHERE m.modelName = :modelName
    """)
    suspend fun getDeviceVariantIdByModel(modelName: String): Long?

    @Query("""
        SELECT CASE WHEN COUNT(m.id) = 1 THEN MIN(m.id) ELSE NULL END
        FROM smartphone_model m
        WHERE m.modelName = :modelName AND m.isActive = 1
    """)
    suspend fun getModelIdByName(modelName: String): Long?

    @Query("""
        SELECT CASE WHEN COUNT(m.id) = 1 THEN MIN(m.id) ELSE NULL END
        FROM smartphone_model m
        WHERE m.manufacturerId = :manufacturerId
          AND m.modelName = :modelName
          AND m.platform = :platform
          AND m.releaseYear = :releaseYear
          AND m.isActive = 1
    """)
    suspend fun getModelIdByIdentity(
        manufacturerId: Long,
        modelName: String,
        platform: String,
        releaseYear: Int
    ): Long?

    @Query("SELECT d.id FROM device_variant d WHERE d.modelId = :modelId AND d.storageGb = :storageGb AND ((d.ramGb = :ramGb) OR (d.ramGb IS NULL AND :ramGb IS NULL)) LIMIT 1")
    suspend fun getDeviceVariantIdByModelIdStorageAndRam(modelId: Long, storageGb: Int, ramGb: Int?): Long?

    /** Exact catalog identity lookup for seeds that carry manufacturer, platform and release year. */
    @Query("""
        SELECT CASE
            WHEN (SELECT COUNT(*)
                  FROM smartphone_model identityModel
                  INNER JOIN manufacturer identityManufacturer ON identityManufacturer.id = identityModel.manufacturerId
                  WHERE identityModel.modelName = :modelName
                    AND identityManufacturer.name = :manufacturerName
                    AND identityModel.platform = :platform
                    AND identityModel.releaseYear = :releaseYear
                    AND identityModel.isActive = 1) = 1
                 AND :ramGb IS NULL AND COUNT(d.id) = 1 THEN MIN(d.id)
            WHEN (SELECT COUNT(*)
                  FROM smartphone_model identityModel
                  INNER JOIN manufacturer identityManufacturer ON identityManufacturer.id = identityModel.manufacturerId
                  WHERE identityModel.modelName = :modelName
                    AND identityManufacturer.name = :manufacturerName
                    AND identityModel.platform = :platform
                    AND identityModel.releaseYear = :releaseYear
                    AND identityModel.isActive = 1) = 1
                 AND :ramGb IS NOT NULL
                 AND SUM(CASE WHEN d.ramGb = :ramGb THEN 1 ELSE 0 END) = 1
                THEN MIN(CASE WHEN d.ramGb = :ramGb THEN d.id END)
            ELSE NULL
        END
        FROM device_variant d
        INNER JOIN smartphone_model m ON m.id = d.modelId
        INNER JOIN manufacturer mf ON mf.id = m.manufacturerId
        WHERE m.modelName = :modelName
          AND mf.name = :manufacturerName
          AND m.platform = :platform
          AND m.releaseYear = :releaseYear
          AND d.storageGb = :storageGb
          AND d.condition = :condition
          AND d.isActive = 1
          AND m.isActive = 1
    """)
    suspend fun getDeviceVariantIdByFullIdentity(
        modelName: String,
        manufacturerName: String,
        platform: String,
        releaseYear: Int,
        storageGb: Int,
        ramGb: Int? = null,
        condition: ProductCondition = ProductCondition.NEW
    ): Long?

    @Query("""
        SELECT CASE
            WHEN (SELECT COUNT(*) FROM smartphone_model identityModel
                  WHERE identityModel.modelName = :modelName AND identityModel.isActive = 1) = 1
                 AND :ramGb IS NULL AND COUNT(d.id) = 1 THEN MIN(d.id)
            WHEN (SELECT COUNT(*) FROM smartphone_model identityModel
                  WHERE identityModel.modelName = :modelName AND identityModel.isActive = 1) = 1
                 AND :ramGb IS NOT NULL
                 AND SUM(CASE WHEN d.ramGb = :ramGb THEN 1 ELSE 0 END) = 1
                THEN MIN(CASE WHEN d.ramGb = :ramGb THEN d.id END)
            ELSE NULL
        END
        FROM device_variant d
        INNER JOIN smartphone_model m ON m.id = d.modelId
        WHERE m.modelName = :modelName
          AND d.storageGb = :storageGb
          AND d.condition = :condition
          AND d.isActive = 1
          AND m.isActive = 1
    """)
    suspend fun getDeviceVariantIdByModelAndStorage(
        modelName: String,
        storageGb: Int,
        ramGb: Int? = null,
        condition: ProductCondition = ProductCondition.NEW
    ): Long?

    @Query("SELECT * FROM retailer WHERE name = :name ORDER BY id")
    suspend fun getRetailersByName(name: String): List<RetailerEntity>

    @Query("SELECT * FROM retailer ORDER BY name, id")
    suspend fun getAllRetailersForAudit(): List<RetailerEntity>

    @Query("SELECT * FROM sales_variant ORDER BY id")
    suspend fun getAllSalesVariantsForAudit(): List<SalesVariantEntity>

    @Query("SELECT * FROM device_variant ORDER BY id")
    suspend fun getAllDeviceVariantsForAudit(): List<DeviceVariantEntity>

    @Query("SELECT * FROM product_listing ORDER BY id")
    suspend fun getAllProductListingsForAudit(): List<ProductListingEntity>

    @Query("SELECT * FROM price_record_v2 ORDER BY id")
    suspend fun getAllPriceRecordsV2ForAudit(): List<PriceRecordV2Entity>

    @Query("SELECT * FROM sales_variant WHERE deviceVariantId = :deviceVariantId AND salesChannel = :salesChannel AND ((modelNumber = :modelNumber) OR (modelNumber IS NULL AND :modelNumber IS NULL)) ORDER BY id")
    suspend fun getSalesVariantsByIdentity(deviceVariantId: Long, salesChannel: SalesChannel, modelNumber: String?): List<SalesVariantEntity>

    @Query("SELECT * FROM product_listing WHERE salesVariantId = :salesVariantId AND retailerId = :retailerId ORDER BY id")
    suspend fun getProductListingsByIdentity(salesVariantId: Long, retailerId: Long): List<ProductListingEntity>

    @Query("SELECT id FROM retailer WHERE name = :name LIMIT 1")
    suspend fun getRetailerId(name: String): Long?

    @Query("""
        SELECT id FROM sales_variant
        WHERE deviceVariantId = :deviceVariantId
          AND salesChannel = :salesChannel
          AND ((modelNumber = :modelNumber) OR (modelNumber IS NULL AND :modelNumber IS NULL))
        LIMIT 1
    """)
    suspend fun getSalesVariantId(
        deviceVariantId: Long,
        salesChannel: SalesChannel,
        modelNumber: String? = null
    ): Long?

    @Query("SELECT id FROM product_listing WHERE salesVariantId = :salesVariantId AND retailerId = :retailerId LIMIT 1")
    suspend fun getProductListingId(salesVariantId: Long, retailerId: Long): Long?

    @Query("SELECT COUNT(*) FROM price_record_v2 WHERE productListingId = :productListingId")
    suspend fun countV2Prices(productListingId: Long): Int

    @Query("SELECT EXISTS(SELECT 1 FROM price_record_v2 WHERE productListingId = :productListingId AND priceType = :priceType AND ((color = :color) OR (color IS NULL AND :color IS NULL)) AND checkedAt = :checkedAt AND priceYen = :priceYen)")
    suspend fun hasPriceOption(productListingId: Long, priceType: PriceType, color: String?, checkedAt: Long, priceYen: Int): Boolean

    @Query("""
        SELECT d.id AS deviceVariantId,
               m.modelName AS modelName,
               mf.name AS manufacturerName,
               m.seriesName AS seriesName,
               m.platform AS platform,
               m.releaseYear AS releaseYear,
               m.releaseDate AS releaseDate,
               d.storageGb AS storageGb,
               d.ramGb AS ramGb,
               p.priceYen AS normalPriceYen,
               p.checkedAt AS priceCheckedAt,
               a.gamingLevel AS gamingLevel,
               a.cameraLevel AS cameraLevel,
               a.generalLevel AS generalLevel,
               a.workStudyLevel AS workStudyLevel,
               a.videoLevel AS videoLevel,
               a.aiLevel AS aiLevel,
               a.batterySuitability AS batterySuitability,
               a.portabilityLevel AS portabilityLevel,
               a.longTermSupportLevel AS longTermSupportLevel,
               a.osaifuKeitai AS osaifuKeitai,
               a.waterproof AS waterproof,
               a.esim AS esim,
               a.fingerprint AS fingerprint,
               a.wirelessCharging AS wirelessCharging,
               a.microSd AS microSd,
               a.headphoneJack AS headphoneJack,
               ps.heightMm AS bodyHeightMm,
               ps.widthMm AS bodyWidthMm,
               ps.thicknessMm AS bodyThicknessMm,
               ps.weightG AS weightG,
               ds.heightMm AS displayHeightMm,
               ds.widthMm AS displayWidthMm,
               ds.diagonalInch AS displayDiagonalInch,
               ds.resolutionText AS displayResolutionText,
               ds.panelType AS displayPanelType,
               ds.refreshRateHz AS displayRefreshRateHz,
               cs.rearMainMp AS rearMainMp,
               cs.rearUltraWideMp AS rearUltraWideMp,
               cs.rearTelephotoMp AS rearTelephotoMp,
               cs.frontMp AS frontMp,
               cs.videoMaxText AS videoMaxText,
               cs.stabilizationText AS stabilizationText,
               bs.capacityMah AS batteryCapacityMah,
               bs.chargingPowerW AS chargingPowerW,
               bs.wirelessCharging AS batteryWirelessCharging,
               bs.manufacturerClaim AS batteryManufacturerClaim,
               bs.realWorldTestHours AS batteryRealWorldTestHours,
               co.fiveG AS fiveG,
               co.simCount AS simCount,
               co.esim AS connectivityEsim,
               co.wifiText AS wifiText,
               co.bluetoothText AS bluetoothText,
               sw.osVersion AS osVersion,
               sw.updateSupportYears AS updateSupportYears,
               sw.securitySupportUntil AS securitySupportUntil
        FROM device_variant d
        INNER JOIN smartphone_model m ON m.id = d.modelId
        INNER JOIN manufacturer mf ON mf.id = m.manufacturerId
        LEFT JOIN price_record p
          ON p.deviceVariantId = d.id AND p.priceType = 'NORMAL' AND p.isCurrent = 1
        LEFT JOIN data_source src ON src.id = p.sourceId
        LEFT JOIN recommendation_attributes a
          ON a.deviceVariantId = d.id
        LEFT JOIN physical_specs ps ON ps.deviceVariantId = d.id
        LEFT JOIN display_specs ds ON ds.deviceVariantId = d.id
        LEFT JOIN camera_specs cs ON cs.deviceVariantId = d.id
        LEFT JOIN battery_specs bs ON bs.deviceVariantId = d.id
        LEFT JOIN connectivity_specs co ON co.deviceVariantId = d.id
        LEFT JOIN software_specs sw ON sw.deviceVariantId = d.id
        WHERE d.id = :deviceVariantId
          AND d.isActive = 1 AND m.isActive = 1
        LIMIT 1
    """)
    suspend fun getDeviceDetail(deviceVariantId: Long): PhoneDetailRow?

    @Query("""
        SELECT sv.id AS salesVariantId,
               r.name AS retailerName,
               r.type AS retailerType,
               r.official AS official,
               pl.productUrl AS productUrl,
               pl.availability AS availability,
               pr.priceType AS priceType,
               pr.priceYen AS priceYen,
               pr.pointsValueYen AS pointsValueYen,
               pr.couponValueYen AS couponValueYen,
               pr.tradeInValueYen AS tradeInValueYen,
               pr.shippingFeeYen AS shippingFeeYen,
               pr.conditions AS priceConditions,
               pr.checkedAt AS checkedAt,
               pr.color AS priceColor,
               pr.sourceUrl AS priceSourceUrl
        FROM sales_variant sv
        INNER JOIN product_listing pl ON pl.salesVariantId = sv.id
        INNER JOIN retailer r ON r.id = pl.retailerId
        LEFT JOIN price_record_v2 pr
          ON pr.productListingId = pl.id
         AND pl.availability IN ('AVAILABLE','LIMITED')
         AND pl.productUrl IS NOT NULL
         AND TRIM(pl.productUrl) <> ''
         AND pr.id = (
             SELECT pr2.id FROM price_record_v2 pr2
             WHERE pr2.productListingId = pl.id
               AND pr2.priceType = pr.priceType
               AND ((pr2.color = pr.color) OR (pr2.color IS NULL AND pr.color IS NULL))
             ORDER BY pr2.checkedAt DESC, pr2.id DESC
             LIMIT 1
         )
        WHERE sv.deviceVariantId = :deviceVariantId
          AND sv.isActive = 1
          AND pl.availability <> 'DISCONTINUED'
        ORDER BY r.official DESC, pr.priceYen ASC
    """)
    suspend fun getPurchaseOptions(deviceVariantId: Long): List<PurchaseOptionRow>

    @Query("""
        SELECT d.id AS deviceVariantId,
               m.modelName AS modelName,
               mf.name AS manufacturerName,
               m.seriesName AS seriesName,
               m.releaseYear AS releaseYear,
               m.platform AS platform,
               d.storageGb AS storageGb,
               d.ramGb AS ramGb,
               COALESCE(
                   (SELECT pr.priceYen
                    FROM price_record_v2 pr
                    INNER JOIN product_listing plv ON plv.id = pr.productListingId
                    INNER JOIN sales_variant svv ON svv.id = plv.salesVariantId
                    WHERE svv.deviceVariantId = d.id
                      AND svv.isActive = 1
                      AND (:purchaseChannel = '' OR svv.salesChannel = :purchaseChannel)
                      AND plv.availability IN ('AVAILABLE','LIMITED')
                      AND pr.priceType IN ('NORMAL','SALE')
                      AND pr.priceYen IS NOT NULL
                      AND pr.id = (
                             SELECT pr2.id FROM price_record_v2 pr2
                             WHERE pr2.productListingId = pr.productListingId
                               AND pr2.priceType = pr.priceType
                               AND ((pr2.color = pr.color) OR (pr2.color IS NULL AND pr.color IS NULL))
                             ORDER BY pr2.checkedAt DESC, pr2.id DESC
                             LIMIT 1
                         )
                    ORDER BY pr.checkedAt DESC, pr.priceYen ASC, pr.id DESC
                    LIMIT 1),
                   CASE WHEN :purchaseChannel = '' THEN p.priceYen ELSE NULL END
               ) AS normalPriceYen,
               COALESCE(
                   (SELECT pr.checkedAt
                    FROM price_record_v2 pr
                    INNER JOIN product_listing plv ON plv.id = pr.productListingId
                    INNER JOIN sales_variant svv ON svv.id = plv.salesVariantId
                    WHERE svv.deviceVariantId = d.id
                      AND svv.isActive = 1
                      AND (:purchaseChannel = '' OR svv.salesChannel = :purchaseChannel)
                      AND plv.availability IN ('AVAILABLE','LIMITED')
                      AND pr.priceType IN ('NORMAL','SALE')
                      AND pr.priceYen IS NOT NULL
                      AND pr.id = (
                             SELECT pr2.id FROM price_record_v2 pr2
                             WHERE pr2.productListingId = pr.productListingId
                               AND pr2.priceType = pr.priceType
                               AND ((pr2.color = pr.color) OR (pr2.color IS NULL AND pr.color IS NULL))
                             ORDER BY pr2.checkedAt DESC, pr2.id DESC
                             LIMIT 1
                         )
                    ORDER BY pr.checkedAt DESC, pr.priceYen ASC, pr.id DESC
                    LIMIT 1),
                   CASE WHEN :purchaseChannel = '' THEN p.checkedAt ELSE NULL END
               ) AS priceCheckedAt,
               CASE WHEN EXISTS (
                   SELECT 1 FROM price_record_v2 pr
                   INNER JOIN product_listing plv ON plv.id = pr.productListingId
                   INNER JOIN sales_variant svv ON svv.id = plv.salesVariantId
                   WHERE svv.deviceVariantId = d.id AND svv.isActive = 1
                      AND (:purchaseChannel = '' OR svv.salesChannel = :purchaseChannel)
                     AND plv.availability IN ('AVAILABLE','LIMITED')
                     AND pr.priceType IN ('NORMAL','SALE') AND pr.priceYen IS NOT NULL
               ) THEN (
                   SELECT src2.sourceType FROM data_source src2
                   WHERE src2.id = (
                       SELECT pr.sourceId FROM price_record_v2 pr
                       INNER JOIN product_listing plv ON plv.id = pr.productListingId
                       INNER JOIN sales_variant svv ON svv.id = plv.salesVariantId
                       WHERE svv.deviceVariantId = d.id AND svv.isActive = 1
                      AND (:purchaseChannel = '' OR svv.salesChannel = :purchaseChannel)
                         AND plv.availability IN ('AVAILABLE','LIMITED')
                         AND pr.priceType IN ('NORMAL','SALE') AND pr.priceYen IS NOT NULL
                         AND pr.id = (
                             SELECT pr2.id FROM price_record_v2 pr2
                             WHERE pr2.productListingId = pr.productListingId
                               AND pr2.priceType = pr.priceType
                               AND ((pr2.color = pr.color) OR (pr2.color IS NULL AND pr.color IS NULL))
                             ORDER BY pr2.checkedAt DESC, pr2.id DESC
                             LIMIT 1
                         )
                       ORDER BY pr.checkedAt DESC, pr.priceYen ASC, pr.id DESC LIMIT 1
                   )
               ) ELSE CASE WHEN :purchaseChannel = '' THEN src.sourceType ELSE NULL END END AS priceSourceType,
               CASE WHEN EXISTS (
                   SELECT 1 FROM price_record_v2 pr
                   INNER JOIN product_listing plv ON plv.id = pr.productListingId
                   INNER JOIN sales_variant svv ON svv.id = plv.salesVariantId
                   WHERE svv.deviceVariantId = d.id AND svv.isActive = 1
                      AND (:purchaseChannel = '' OR svv.salesChannel = :purchaseChannel)
                     AND plv.availability IN ('AVAILABLE','LIMITED')
                     AND pr.priceType IN ('NORMAL','SALE') AND pr.priceYen IS NOT NULL
               ) THEN (
                   SELECT src2.name FROM data_source src2
                   WHERE src2.id = (
                       SELECT pr.sourceId FROM price_record_v2 pr
                       INNER JOIN product_listing plv ON plv.id = pr.productListingId
                       INNER JOIN sales_variant svv ON svv.id = plv.salesVariantId
                       WHERE svv.deviceVariantId = d.id AND svv.isActive = 1
                      AND (:purchaseChannel = '' OR svv.salesChannel = :purchaseChannel)
                         AND plv.availability IN ('AVAILABLE','LIMITED')
                         AND pr.priceType IN ('NORMAL','SALE') AND pr.priceYen IS NOT NULL
                         AND pr.id = (
                             SELECT pr2.id FROM price_record_v2 pr2
                             WHERE pr2.productListingId = pr.productListingId
                               AND pr2.priceType = pr.priceType
                               AND ((pr2.color = pr.color) OR (pr2.color IS NULL AND pr.color IS NULL))
                             ORDER BY pr2.checkedAt DESC, pr2.id DESC
                             LIMIT 1
                         )
                       ORDER BY pr.checkedAt DESC, pr.priceYen ASC, pr.id DESC LIMIT 1
                   )
               ) ELSE CASE WHEN :purchaseChannel = '' THEN src.name ELSE NULL END END AS priceSourceName,
               a.osaifuKeitai AS osaifuKeitai,
               a.waterproof AS waterproof,
               a.esim AS esim,
               a.fingerprint AS fingerprint,
               a.wirelessCharging AS wirelessCharging,
               a.microSd AS microSd,
               a.headphoneJack AS headphoneJack,
               a.gamingLevel AS gamingLevel,
               a.cameraLevel AS cameraLevel,
               a.generalLevel AS generalLevel,
               a.workStudyLevel AS workStudyLevel,
               a.videoLevel AS videoLevel,
               a.aiLevel AS aiLevel,
               a.batterySuitability AS batterySuitability,
               a.portabilityLevel AS portabilityLevel,
               a.longTermSupportLevel AS longTermSupportLevel,
               ps.heightMm AS bodyHeightMm,
               ps.widthMm AS bodyWidthMm,
               ps.thicknessMm AS bodyThicknessMm,
               ps.weightG AS weightG,
               ds.diagonalInch AS displayDiagonalInch,
               ds.refreshRateHz AS displayRefreshRateHz,
               cs.rearTelephotoMp AS rearTelephotoMp,
               bs.capacityMah AS batteryCapacityMah,
               bs.chargingPowerW AS chargingPowerW,
               bs.wirelessCharging AS batteryWirelessCharging,
               sw.updateSupportYears AS updateSupportYears,
               d.condition AS productCondition,
               (SELECT GROUP_CONCAT(DISTINCT sv2.salesChannel) FROM sales_variant sv2 WHERE sv2.deviceVariantId = d.id AND sv2.isActive = 1) AS purchaseChannels,
               (SELECT CASE
                   WHEN EXISTS (SELECT 1 FROM product_listing pl1 INNER JOIN sales_variant sv1 ON sv1.id = pl1.salesVariantId WHERE sv1.deviceVariantId = d.id AND sv1.isActive = 1 AND pl1.availability IN ('AVAILABLE','LIMITED')) THEN 'AVAILABLE'
                   WHEN EXISTS (SELECT 1 FROM product_listing pl2 INNER JOIN sales_variant sv2 ON sv2.id = pl2.salesVariantId WHERE sv2.deviceVariantId = d.id AND sv2.isActive = 1 AND pl2.availability = 'PREORDER') THEN 'PREORDER'
                   WHEN EXISTS (SELECT 1 FROM product_listing pl3 INNER JOIN sales_variant sv3 ON sv3.id = pl3.salesVariantId WHERE sv3.deviceVariantId = d.id AND sv3.isActive = 1 AND pl3.availability = 'OUT_OF_STOCK') THEN 'OUT_OF_STOCK'
                   WHEN EXISTS (SELECT 1 FROM product_listing pl4 INNER JOIN sales_variant sv4 ON sv4.id = pl4.salesVariantId WHERE sv4.deviceVariantId = d.id AND sv4.isActive = 1 AND pl4.availability = 'DISCONTINUED') THEN 'DISCONTINUED'
                   ELSE 'UNKNOWN' END) AS availabilityStatus,
               (SELECT MAX(pl5.checkedAt) FROM product_listing pl5 INNER JOIN sales_variant sv5 ON sv5.id = pl5.salesVariantId WHERE sv5.deviceVariantId = d.id AND sv5.isActive = 1) AS availabilityCheckedAt
        FROM device_variant d
        INNER JOIN smartphone_model m ON m.id = d.modelId
        INNER JOIN manufacturer mf ON mf.id = m.manufacturerId
        LEFT JOIN price_record p
          ON p.id = (
              SELECT p2.id FROM price_record p2
              WHERE p2.deviceVariantId = d.id
                AND p2.priceType = 'NORMAL' AND p2.isCurrent = 1
              ORDER BY p2.checkedAt DESC, p2.id DESC
              LIMIT 1
          )
        LEFT JOIN data_source src
          ON src.id = p.sourceId
        LEFT JOIN recommendation_attributes a
          ON a.deviceVariantId = d.id
        LEFT JOIN physical_specs ps ON ps.deviceVariantId = d.id
        LEFT JOIN display_specs ds ON ds.deviceVariantId = d.id
        LEFT JOIN camera_specs cs ON cs.deviceVariantId = d.id
        LEFT JOIN battery_specs bs ON bs.deviceVariantId = d.id
        LEFT JOIN software_specs sw ON sw.deviceVariantId = d.id
        WHERE d.isActive = 1 AND m.isActive = 1 AND m.isJapanOfficial = 1
          AND (:platform = 'EITHER' OR m.platform = :platform)
          AND (:query = '' OR m.modelName LIKE '%' || :query || '%' OR mf.name LIKE '%' || :query || '%')
        ORDER BY m.releaseYear DESC, m.modelName ASC, d.storageGb ASC
    """)
    suspend fun searchJapanOfficialDevices(platform: String, query: String, purchaseChannel: String = ""): List<PhoneListRow>
}

data class PurchaseOptionRow(
    val salesVariantId: Long,
    val retailerName: String,
    val retailerType: String,
    val official: Boolean,
    val productUrl: String?,
    val availability: String,
    val priceType: String?,
    val priceYen: Int?,
    val pointsValueYen: Int?,
    val couponValueYen: Int?,
    val tradeInValueYen: Int?,
    val shippingFeeYen: Int?,
    val priceConditions: String?,
    val checkedAt: Long?,
    val priceColor: String?,
    val priceSourceUrl: String?
)

data class PhoneListRow(
    val deviceVariantId: Long,
    val modelName: String,
    val manufacturerName: String,
    val seriesName: String?,
    val releaseYear: Int,
    val platform: String,
    val storageGb: Int,
    val ramGb: Int?,
    val normalPriceYen: Int?,
    val osaifuKeitai: SupportStatus?,
    val waterproof: SupportStatus?,
    val esim: SupportStatus?,
    val fingerprint: SupportStatus?,
    val wirelessCharging: SupportStatus?,
    val microSd: SupportStatus?,
    val headphoneJack: SupportStatus?,
    val gamingLevel: AttributeLevel?,
    val cameraLevel: AttributeLevel?,
    val generalLevel: AttributeLevel?,
    val workStudyLevel: AttributeLevel?,
    val videoLevel: AttributeLevel?,
    val aiLevel: AttributeLevel?,
    val batterySuitability: AttributeLevel?,
    val portabilityLevel: AttributeLevel?,
    val longTermSupportLevel: AttributeLevel?,
    val bodyHeightMm: Double?,
    val bodyWidthMm: Double?,
    val bodyThicknessMm: Double?,
    val weightG: Double?,
    val displayDiagonalInch: Double?,
    val displayRefreshRateHz: Int?,
    val rearTelephotoMp: Double?,
    val batteryCapacityMah: Int?,
    val chargingPowerW: Int?,
    val batteryWirelessCharging: SupportStatus?,
    val updateSupportYears: Int?,
    val productCondition: ProductCondition,
    val purchaseChannels: String?,
    val priceCheckedAt: Long? = null,
    val availabilityStatus: String = "UNKNOWN",
    val availabilityCheckedAt: Long? = null,
    val priceSourceType: SourceType? = null,
    val priceSourceName: String? = null
)

data class PhoneDetailRow(
    val deviceVariantId: Long,
    val modelName: String,
    val manufacturerName: String,
    val seriesName: String?,
    val platform: String,
    val releaseYear: Int,
    val releaseDate: String?,
    val storageGb: Int,
    val ramGb: Int?,
    val normalPriceYen: Int?,
    val gamingLevel: AttributeLevel?,
    val cameraLevel: AttributeLevel?,
    val generalLevel: AttributeLevel?,
    val workStudyLevel: AttributeLevel?,
    val videoLevel: AttributeLevel?,
    val aiLevel: AttributeLevel?,
    val batterySuitability: AttributeLevel?,
    val portabilityLevel: AttributeLevel?,
    val longTermSupportLevel: AttributeLevel?,
    val osaifuKeitai: SupportStatus?,
    val waterproof: SupportStatus?,
    val esim: SupportStatus?,
    val fingerprint: SupportStatus?,
    val wirelessCharging: SupportStatus?,
    val microSd: SupportStatus?,
    val headphoneJack: SupportStatus?,
    val bodyHeightMm: Double?,
    val bodyWidthMm: Double?,
    val bodyThicknessMm: Double?,
    val weightG: Double?,
    val displayHeightMm: Double?,
    val displayWidthMm: Double?,
    val displayDiagonalInch: Double?,
    val displayResolutionText: String?,
    val displayPanelType: String?,
    val displayRefreshRateHz: Int?,
    val rearMainMp: Double?,
    val rearUltraWideMp: Double?,
    val rearTelephotoMp: Double?,
    val frontMp: Double?,
    val videoMaxText: String?,
    val stabilizationText: String?,
    val batteryCapacityMah: Int?,
    val chargingPowerW: Int?,
    val batteryWirelessCharging: SupportStatus?,
    val batteryManufacturerClaim: String?,
    val batteryRealWorldTestHours: Double?,
    val fiveG: SupportStatus?,
    val simCount: Int?,
    val connectivityEsim: SupportStatus?,
    val wifiText: String?,
    val bluetoothText: String?,
    val osVersion: String?,
    val updateSupportYears: Int?,
    val securitySupportUntil: String?
)

data class ComparisonPriceRow(
    val deviceVariantId: Long,
    val retailerName: String,
    val official: Boolean,
    val color: String?,
    val priceType: String,
    val priceYen: Int,
    val checkedAt: Long,
    val conditions: String?,
    val sourceUrl: String?,
    val productUrl: String
)

data class ComparisonRow(
    val deviceVariantId: Long,
    val modelName: String,
    val manufacturerName: String,
    val storageGb: Int,
    val ramGb: Int?,
    val normalPriceYen: Int?,
    val bodyHeightMm: Double?,
    val bodyWidthMm: Double?,
    val bodyThicknessMm: Double?,
    val weightG: Double?,
    val displayDiagonalInch: Double?,
    val displayResolutionText: String?,
    val displayPanelType: String?,
    val displayRefreshRateHz: Int?,
    val rearMainMp: Double?,
    val rearUltraWideMp: Double?,
    val rearTelephotoMp: Double?,
    val batteryCapacityMah: Int?,
    val chargingPowerW: Int?,
    val batteryWirelessCharging: SupportStatus?,
    val updateSupportYears: Int?,
    val osaifuKeitai: SupportStatus?,
    val waterproof: SupportStatus?,
    val esim: SupportStatus?,
    val microSd: SupportStatus?,
    val headphoneJack: SupportStatus?
)

data class DeviceModelRow(
    val deviceVariantId: Long,
    val modelName: String
)
