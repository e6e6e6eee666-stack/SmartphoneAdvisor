package jp.smartphoneadvisor.app.domain

import jp.smartphoneadvisor.app.data.CandidateOs
import jp.smartphoneadvisor.app.data.PhoneListRow
import jp.smartphoneadvisor.app.data.PrimaryUse
import jp.smartphoneadvisor.app.data.ProductCondition
import jp.smartphoneadvisor.app.data.SupportStatus
import jp.smartphoneadvisor.app.data.catalog.JsonPhoneCatalog
import java.text.NumberFormat
import java.util.Locale

/**
 * 一般的な1台持ちユーザー向けの診断ロジック。
 *
 * phones.json は販売チャネル・容量・RAMの母集団を決める一次カタログとして使用し、
 * 価格・機能・用途適性など、phones.json にまだ存在しない詳細属性は既存Roomの
 * PhoneListRowから取得する。これにより価格や必須機能を推測して推薦しない。
 */
object SinglePhoneDiagnosticEngine {
    data class Requirement(
        val os: CandidateOs = CandidateOs.EITHER,
        val targetBudgetYen: Int?,
        val absoluteMaxYen: Int?,
        val primaryUse: PrimaryUse,
        val mustHaveOsaifuKeitai: Boolean,
        val mustHaveMicroSd: Boolean,
        // この診断画面には中古・整備済みの選択肢がないため、新品を既定条件にする。
        val productCondition: ProductCondition = ProductCondition.NEW
    )

    data class Result(
        val candidate: PhoneListRow,
        val score: Int,
        val reasons: List<String>,
        val cautions: List<String>
    )

    fun catalogCandidates(catalog: JsonPhoneCatalog, roomRows: List<PhoneListRow>): List<PhoneListRow> {
        val allowed = buildSet {
            catalog.phones.filter { it.isJapanOfficial }.forEach { phone ->
                phone.variants.forEach { variant ->
                    // 診断は「販売確認できる1台」を選ぶ。販売情報がないVariantや、
                    // 販売終了・在庫切れしかないVariantは候補に入れない。
                    if (variant.sales.any { sale ->
                            sale.availability == "AVAILABLE" || sale.availability == "LIMITED"
                        }) {
                        add(Key(phone.manufacturer, phone.model, phone.platform, variant.storageGb, variant.ramGb))
                    }
                }
            }
        }
        return roomRows.filter { row ->
            allowed.any { key ->
                key.manufacturer == row.manufacturerName &&
                    key.model == row.modelName &&
                    key.platform == row.platform &&
                    key.storageGb == row.storageGb &&
                    key.ramGb == row.ramGb
            }
        }
    }

    fun recommend(requirement: Requirement, candidates: List<PhoneListRow>): Result? {
        // 予算判定に使う価格は、通常/セール価格の確認日から14日以内に限定する。
        // 古い価格は null に落としてから判定・表示し、最新価格と誤認させない。
        val freshnessCheckedCandidates = candidates.map { candidate ->
            val priceFreshness = dataFreshnessStatus(candidate.priceCheckedAt, 14L)
            if (priceFreshness == DataFreshnessStatus.FRESH) candidate
            else candidate.copy(normalPriceYen = null)
        }
        val filtered = freshnessCheckedCandidates.filter { candidate ->
            osMatches(requirement.os, candidate.platform) &&
                available(candidate) &&
                candidate.productCondition == requirement.productCondition &&
                budgetMatches(requirement.absoluteMaxYen, candidate.normalPriceYen) &&
                mustHaveMatches(requirement, candidate)
        }

        return filtered
            .map { candidate -> score(requirement, candidate) }
            .sortedWith(compareByDescending<Result> { it.score }.thenBy { it.candidate.normalPriceYen ?: Int.MAX_VALUE })
            .firstOrNull()
    }

    private fun score(r: Requirement, c: PhoneListRow): Result {
        var score = 0
        val reasons = mutableListOf<String>()
        val cautions = mutableListOf<String>()

        val priceText = c.normalPriceYen?.let(::formatYen) ?: "価格未確認"
        val targetText = r.targetBudgetYen?.let(::formatYen) ?: "未設定"
        val maxText = r.absoluteMaxYen?.let(::formatYen) ?: "未設定"
        when (budgetStatus(r.targetBudgetYen, r.absoluteMaxYen, c.normalPriceYen)) {
            DiagnosticBudgetStatus.WITHIN_TARGET -> {
                score += 30
                reasons += "価格${priceText}は希望予算${targetText}以内です"
            }
            DiagnosticBudgetStatus.OVER_TARGET_WITHIN_MAX -> {
                score += 15
                reasons += "価格${priceText}は希望予算${targetText}を超えますが、絶対上限${maxText}以内です"
            }
            DiagnosticBudgetStatus.WITHIN_MAX_NO_TARGET -> {
                score += 15
                reasons += "価格${priceText}は希望価格未設定ですが、絶対上限${maxText}以内です"
            }
            DiagnosticBudgetStatus.UNKNOWN -> {
                val budgetContext = buildList {
                    r.targetBudgetYen?.let { add("希望予算${formatYen(it)}") }
                    r.absoluteMaxYen?.let { add("絶対上限${formatYen(it)}") }
                }.joinToString("・")
                cautions += if (budgetContext.isEmpty()) {
                    "一般価格を確認できないため、予算適合度は未確認です"
                } else {
                    "価格が未確認のため、${budgetContext}への適合を確認できません"
                }
            }
            DiagnosticBudgetStatus.OVER_MAX -> Unit
        }

        when (r.primaryUse) {
            PrimaryUse.GAMING -> { score += useScore(c.gamingLevel); if (c.gamingLevel == jp.smartphoneadvisor.app.data.AttributeLevel.EXCELLENT || c.gamingLevel == jp.smartphoneadvisor.app.data.AttributeLevel.GOOD) reasons += "ゲーム用途への適性が良好です" }
            PrimaryUse.CAMERA -> {
                // 画面上の選択肢は「写真・動画」のため、カメラだけでなく動画適性も採点する。
                // 未確認値は0点として平均に含め、片方の良さだけで高評価にしない。
                score += (useScore(c.cameraLevel) + useScore(c.videoLevel)) / 2
                val cameraKnownGood = c.cameraLevel == jp.smartphoneadvisor.app.data.AttributeLevel.EXCELLENT || c.cameraLevel == jp.smartphoneadvisor.app.data.AttributeLevel.GOOD
                val videoKnownGood = c.videoLevel == jp.smartphoneadvisor.app.data.AttributeLevel.EXCELLENT || c.videoLevel == jp.smartphoneadvisor.app.data.AttributeLevel.GOOD
                if (cameraKnownGood && videoKnownGood) reasons += "写真・動画用途への適性が良好です"
                if (c.cameraLevel == null || c.cameraLevel == jp.smartphoneadvisor.app.data.AttributeLevel.UNKNOWN) cautions += "カメラ性能の評価が未確認です"
                if (c.videoLevel == null || c.videoLevel == jp.smartphoneadvisor.app.data.AttributeLevel.UNKNOWN) cautions += "動画性能の評価が未確認です"
            }
            PrimaryUse.VIDEO -> { score += useScore(c.videoLevel); if (c.videoLevel == jp.smartphoneadvisor.app.data.AttributeLevel.EXCELLENT || c.videoLevel == jp.smartphoneadvisor.app.data.AttributeLevel.GOOD) reasons += "動画用途への適性が良好です" }
            else -> { score += useScore(c.generalLevel); if (c.generalLevel == jp.smartphoneadvisor.app.data.AttributeLevel.EXCELLENT || c.generalLevel == jp.smartphoneadvisor.app.data.AttributeLevel.GOOD) reasons += "普段使いへの適性が良好です" }
        }

        if (r.mustHaveOsaifuKeitai) reasons += "おサイフケータイ対応を必須条件にしました"
        if (r.mustHaveMicroSd) reasons += "SDカード対応を必須条件にしました"

        if (c.normalPriceYen == null) cautions += "価格が未確認です"
        if (c.osaifuKeitai == null || c.microSd == null) cautions += "一部機能の確認状態が未確認です"
        if (c.availabilityStatus != "AVAILABLE") cautions += "販売状態が販売中として確認できていません"
        if (c.ramGb == null && c.platform == "ANDROID") cautions += "RAM容量が未確認です"

        val storage = "${c.storageGb}GB"
        val ram = c.ramGb?.let { "・RAM ${it}GB" } ?: ""
        reasons += "${storage}${ram}のバリアントを対象にしました"

        return Result(c, score, reasons.distinct(), cautions.distinct())
    }

    private fun formatYen(amount: Int): String =
        NumberFormat.getNumberInstance(Locale.JAPAN).format(amount) + "円"

    private fun useScore(level: jp.smartphoneadvisor.app.data.AttributeLevel?): Int = when (level) {
        jp.smartphoneadvisor.app.data.AttributeLevel.EXCELLENT -> 30
        jp.smartphoneadvisor.app.data.AttributeLevel.GOOD -> 20
        jp.smartphoneadvisor.app.data.AttributeLevel.STANDARD -> 10
        jp.smartphoneadvisor.app.data.AttributeLevel.WEAK,
        jp.smartphoneadvisor.app.data.AttributeLevel.UNKNOWN,
        null -> 0
    }

    private fun mustHaveMatches(r: Requirement, c: PhoneListRow): Boolean =
        (!r.mustHaveOsaifuKeitai || c.osaifuKeitai == SupportStatus.SUPPORTED) &&
            (!r.mustHaveMicroSd || c.microSd == SupportStatus.SUPPORTED)

    // UNKNOWN / PREORDER は「現在購入できる」と確認できた状態ではないため、
    // 1台診断では販売中として扱わない。PhoneDaoは AVAILABLE/LIMITED を AVAILABLE に集約する。
    private fun available(c: PhoneListRow): Boolean = c.availabilityStatus == "AVAILABLE"

    private fun budgetMatches(max: Int?, price: Int?): Boolean =
        max == null || (price != null && price <= max)

    private fun budgetStatus(target: Int?, max: Int?, price: Int?): DiagnosticBudgetStatus = when {
        price == null -> DiagnosticBudgetStatus.UNKNOWN
        max != null && price > max -> DiagnosticBudgetStatus.OVER_MAX
        target != null && price <= target -> DiagnosticBudgetStatus.WITHIN_TARGET
        target != null && max != null -> DiagnosticBudgetStatus.OVER_TARGET_WITHIN_MAX
        target == null && max != null -> DiagnosticBudgetStatus.WITHIN_MAX_NO_TARGET
        else -> DiagnosticBudgetStatus.UNKNOWN
    }

    private fun osMatches(required: CandidateOs, actual: String): Boolean =
        required == CandidateOs.EITHER ||
            required == CandidateOs.ANDROID && actual == "ANDROID" ||
            required == CandidateOs.IPHONE && actual == "IPHONE"

    private enum class DiagnosticBudgetStatus {
        WITHIN_TARGET,
        OVER_TARGET_WITHIN_MAX,
        WITHIN_MAX_NO_TARGET,
        OVER_MAX,
        UNKNOWN
    }

    private data class Key(
        val manufacturer: String,
        val model: String,
        val platform: String,
        val storageGb: Int,
        val ramGb: Int?
    )
}
