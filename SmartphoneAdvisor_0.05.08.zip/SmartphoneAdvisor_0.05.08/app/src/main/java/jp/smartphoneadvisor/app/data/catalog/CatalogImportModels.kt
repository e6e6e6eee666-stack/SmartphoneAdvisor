package jp.smartphoneadvisor.app.data.catalog

/** Versioned, data-only format for adding Japanese-market smartphone catalog records.
 *  The format is intentionally independent from Room IDs so future imports can upsert by stable keys.
 */
data class CatalogPhoneRecord(
    val manufacturerKey: String,
    val manufacturerName: String,
    val seriesKey: String,
    val seriesName: String,
    val modelKey: String,
    val modelName: String,
    val platform: String,
    val releaseDate: String?,
    val releaseYear: Int,
    val isJapanOfficial: Boolean,
    val variants: List<CatalogVariantRecord>
)

data class CatalogVariantRecord(
    val variantKey: String,
    val storageGb: Int,
    val ramGb: Int?,
    val condition: String = "NEW",
    val salesChannels: List<String> = emptyList()
)

data class CatalogImportBatch(
    val schemaVersion: Int = 1,
    val catalogVersion: String,
    val generatedAt: String,
    val records: List<CatalogPhoneRecord>
)
