package jp.smartphoneadvisor.app.data.catalog

import androidx.room.withTransaction
import jp.smartphoneadvisor.app.data.AppDatabase
import jp.smartphoneadvisor.app.data.AvailabilityStatus
import jp.smartphoneadvisor.app.data.ProductListingEntity
import jp.smartphoneadvisor.app.data.PriceRecordV2Entity
import jp.smartphoneadvisor.app.data.PriceType
import jp.smartphoneadvisor.app.data.RetailerEntity
import jp.smartphoneadvisor.app.data.RetailerType
import jp.smartphoneadvisor.app.data.SalesChannel
import jp.smartphoneadvisor.app.data.SalesVariantEntity
import jp.smartphoneadvisor.app.data.DeviceVariantEntity
import jp.smartphoneadvisor.app.data.ManufacturerEntity
import jp.smartphoneadvisor.app.data.PhoneSeriesEntity
import jp.smartphoneadvisor.app.data.RecommendationAttributesEntity
import jp.smartphoneadvisor.app.data.SmartphoneModelEntity
import java.net.URI
import java.time.LocalDate
import java.time.ZoneOffset

/**
 * Non-destructive import of the authoritative phone/variant catalog into Room.
 * Sales identities are imported conservatively. Existing listings are never overwritten;
 * URL-less source entries create a sales-channel identity but not a fabricated product URL.
 * Color-specific price options are persisted as separate price records. Existing records are preserved and exact duplicate options are skipped.
 */
object PhoneCatalogRoomImporter {
    data class Result(
        val modelsInserted: Int,
        val modelsReused: Int,
        val variantsInserted: Int,
        val variantsReused: Int,
        val conflicts: List<String>,
        val skippedNonOfficial: Int,
        val salesVariantsInserted: Int,
        val salesVariantsReused: Int,
        val retailersInserted: Int,
        val retailersReused: Int,
        val listingsInserted: Int,
        val listingsReused: Int,
        val listingsSkippedNoUrl: Int
    )

    fun validate(catalog: JsonPhoneCatalog): List<String> {
        val errors = mutableListOf<String>()
        if (catalog.phones.isEmpty()) errors += "phones.json contains no phones"
        val ids = mutableSetOf<String>()
        val identities = mutableSetOf<String>()
        catalog.phones.forEachIndexed { index, phone ->
            val prefix = "phones[$index] (${phone.model})"
            if (phone.id.isBlank()) errors += "$prefix: blank id"
            if (!ids.add(phone.id)) errors += "$prefix: duplicate id ${phone.id}"
            if (phone.manufacturer.isBlank() || phone.model.isBlank()) errors += "$prefix: manufacturer/model required"
            if (phone.platform !in setOf("ANDROID", "IPHONE")) errors += "$prefix: unsupported platform ${phone.platform}"
            if (phone.releaseYear !in 2000..2100) errors += "$prefix: invalid releaseYear ${phone.releaseYear}"
            val identity = CatalogModelIdentity.key(phone.manufacturer, phone.model, phone.platform, phone.releaseYear)
            if (!identities.add(identity)) errors += "$prefix: duplicate canonical model identity $identity"
            if (phone.variants.isEmpty()) errors += "$prefix: no variants"
            val variantKeys = mutableSetOf<String>()
            phone.variants.forEach variantLoop@ { variant ->
                val key = "${variant.storageGb}|${variant.ramGb ?: "NULL"}"
                if (variant.storageGb <= 0) errors += "$prefix: invalid storage ${variant.storageGb}"
                if (variant.ramGb != null && variant.ramGb <= 0) errors += "$prefix: invalid RAM ${variant.ramGb}"
                if (!variantKeys.add(key)) errors += "$prefix: duplicate variant $key"
                val salesKeys = mutableSetOf<String>()
                variant.sales.forEach { sale ->
                    if (sale.channel !in setOf("SIM_FREE", "DOCOMO", "AU", "SOFTBANK", "RAKUTEN", "UQ_MOBILE", "Y_MOBILE", "IIJ_MIO", "MINEO", "MVNO", "OTHER")) {
                        errors += "$prefix: unsupported sales channel ${sale.channel}"
                    }
                    if (sale.retailer.isBlank()) errors += "$prefix: blank sales retailer"
                    else if (sale.retailer != sale.retailer.trim()) errors += "$prefix: sales retailer has leading/trailing whitespace"
                    if (sale.modelNumber != null && sale.modelNumber.isBlank()) errors += "$prefix: blank modelNumber must be null, not an empty string"
                    if (sale.availability !in setOf("AVAILABLE", "LIMITED", "OUT_OF_STOCK", "DISCONTINUED", "PREORDER", "UNKNOWN")) {
                        errors += "$prefix: unsupported availability ${sale.availability}"
                    }
                    sale.priceOptions.forEachIndexed { priceIndex, price ->
                        if (price.priceYen <= 0) errors += "$prefix: non-positive priceYen for ${sale.retailer} price option $priceIndex"
                        if (price.priceType !in setOf("NORMAL", "SALE", "CAMPAIGN", "MNP", "NEW_CONTRACT", "MODEL_CHANGE", "CONTRACT_REQUIRED", "OTHER")) {
                            errors += "$prefix: unsupported priceType ${price.priceType} for ${sale.retailer} price option $priceIndex"
                        }
                        if (price.color != null && price.color.isBlank()) errors += "$prefix: blank color must be null for ${sale.retailer} price option $priceIndex"
                        val checkedAt = price.checkedAt
                        if (checkedAt.isNullOrBlank()) {
                            errors += "$prefix: checkedAt is required for ${sale.retailer} price option $priceIndex"
                        } else {
                            val parsedDate = runCatching { LocalDate.parse(checkedAt) }.getOrNull()
                            if (parsedDate == null || parsedDate.toString() != checkedAt) {
                                errors += "$prefix: checkedAt must be a real calendar date in YYYY-MM-DD for ${sale.retailer} price option $priceIndex"
                            }
                        }
                        val source = price.sourceUrl?.trim()
                        val parsedSource = source?.let { runCatching { URI(it) }.getOrNull() }
                        if (source == null || source.isBlank() || source != price.sourceUrl || parsedSource == null ||
                            !parsedSource.scheme.equals("https", true) || parsedSource.host.isNullOrBlank()) {
                            errors += "$prefix: price sourceUrl must be a valid HTTPS URL for ${sale.retailer} price option $priceIndex"
                        }
                    }
                    val salesKey = "${sale.channel}|${sale.retailer}|${sale.modelNumber ?: "NULL"}"
                    if (!salesKeys.add(salesKey)) errors += "$prefix: duplicate sales identity $salesKey"
                    val rawUrl = sale.url
                    val url = rawUrl?.trim()
                    if (rawUrl != null && rawUrl.isNotEmpty()) {
                        if (url != rawUrl) errors += "$prefix: sales URL has leading/trailing whitespace for ${sale.retailer}"
                        val parsed = runCatching { URI(url) }.getOrNull()
                        if (parsed == null || !parsed.scheme.equals("https", ignoreCase = true) && !parsed.scheme.equals("http", ignoreCase = true)) {
                            errors += "$prefix: invalid sales URL scheme or syntax for ${sale.retailer}"
                        } else if (parsed.host.isNullOrBlank()) {
                            errors += "$prefix: sales URL has no valid host for ${sale.retailer}"
                        }
                    }
                }
            }
        }
        return errors
    }

    suspend fun importCatalog(db: AppDatabase, catalog: JsonPhoneCatalog): Result {
        val validationErrors = validate(catalog)
        require(validationErrors.isEmpty()) {
            "Catalog import rejected before database changes: ${validationErrors.take(10).joinToString("; ")}"
        }

        var modelsInserted = 0
        var modelsReused = 0
        var variantsInserted = 0
        var variantsReused = 0
        var skippedNonOfficial = 0
        var salesVariantsInserted = 0
        var salesVariantsReused = 0
        var retailersInserted = 0
        var retailersReused = 0
        var listingsInserted = 0
        var listingsReused = 0
        var listingsSkippedNoUrl = 0
        val conflicts = mutableListOf<String>()
        val dao = db.phoneDao()

        db.withTransaction {
            catalog.phones.forEach { phone ->
                if (!phone.isJapanOfficial) {
                    skippedNonOfficial++
                    return@forEach
                }

                val manufacturers = dao.getManufacturersByName(phone.manufacturer)
                val manufacturerId = when {
                    manufacturers.size > 1 -> {
                        conflicts += "${phone.model}: duplicate manufacturer master '${phone.manufacturer}'"
                        return@forEach
                    }
                    manufacturers.size == 1 && !manufacturers.single().isActive -> {
                        conflicts += "${phone.model}: manufacturer '${phone.manufacturer}' is inactive"
                        return@forEach
                    }
                    manufacturers.size == 1 -> manufacturers.single().id
                    else -> {
                        val inserted = dao.insertManufacturers(listOf(ManufacturerEntity(name = phone.manufacturer))).single()
                        val resolved = dao.getManufacturersByName(phone.manufacturer)
                        if (inserted < 0L || resolved.size != 1 || !resolved.single().isActive) {
                            conflicts += "${phone.model}: manufacturer '${phone.manufacturer}' could not be resolved uniquely"
                            return@forEach
                        }
                        resolved.single().id
                    }
                }

                val sameNameModels = dao.getModelsByNameAndPlatform(manufacturerId, phone.model, phone.platform)
                val modelId: Long = when {
                    sameNameModels.size > 1 -> {
                        conflicts += "${phone.model}: multiple Room model masters share manufacturer/name/platform"
                        return@forEach
                    }
                    sameNameModels.size == 1 && !sameNameModels.single().isActive -> {
                        conflicts += "${phone.model}: matching Room model is inactive"
                        return@forEach
                    }
                    sameNameModels.size == 1 && sameNameModels.single().releaseYear != phone.releaseYear -> {
                        conflicts += "${phone.model}: releaseYear mismatch (Room=${sameNameModels.single().releaseYear}, JSON=${phone.releaseYear}); no overwrite"
                        return@forEach
                    }
                    sameNameModels.size == 1 -> {
                        modelsReused++
                        sameNameModels.single().id
                    }
                    else -> {
                        val seriesId = phone.series?.takeIf { it.isNotBlank() }?.let { seriesName ->
                            dao.getSeriesId(manufacturerId, seriesName) ?: run {
                                dao.insertSeries(listOf(PhoneSeriesEntity(manufacturerId = manufacturerId, name = seriesName)))
                                dao.getSeriesId(manufacturerId, seriesName)
                            }
                        }
                        val inserted = dao.insertModels(listOf(SmartphoneModelEntity(
                            manufacturerId = manufacturerId,
                            seriesName = phone.series,
                            seriesId = seriesId,
                            modelName = phone.model,
                            platform = phone.platform,
                            releaseYear = phone.releaseYear,
                            releaseDate = null,
                            isJapanOfficial = phone.isJapanOfficial
                        ))).single()
                        val resolved = dao.getModelsByNameAndPlatform(manufacturerId, phone.model, phone.platform)
                        if (inserted < 0L || resolved.size != 1 || resolved.single().releaseYear != phone.releaseYear) {
                            conflicts += "${phone.model}: newly inserted model could not be resolved uniquely"
                            return@forEach
                        }
                        modelsInserted++
                        resolved.single().id
                    }
                }

                phone.variants.forEach variantLoop@ { variant ->
                    val matches = dao.getVariantsByModelStorageAndRam(modelId, variant.storageGb, variant.ramGb)
                    val variantId: Long = when {
                        matches.size > 1 -> {
                            conflicts += "${phone.model} ${variant.storageGb}GB RAM${variant.ramGb ?: "unknown"}: duplicate Room variant rows"
                            return@variantLoop
                        }
                        matches.size == 1 && !matches.single().isActive -> {
                            conflicts += "${phone.model} ${variant.storageGb}GB RAM${variant.ramGb ?: "unknown"}: matching variant is inactive"
                            return@variantLoop
                        }
                        matches.size == 1 -> {
                            variantsReused++
                            matches.single().id
                        }
                        else -> {
                            val inserted = dao.insertVariants(listOf(DeviceVariantEntity(
                                modelId = modelId,
                                storageGb = variant.storageGb,
                                ramGb = variant.ramGb
                            ))).single()
                            val resolved = dao.getVariantsByModelStorageAndRam(modelId, variant.storageGb, variant.ramGb)
                            if (resolved.size != 1 || !resolved.single().isActive) {
                                conflicts += "${phone.model} ${variant.storageGb}GB RAM${variant.ramGb ?: "unknown"}: variant could not be resolved uniquely"
                                return@variantLoop
                            }
                            if (inserted >= 0L) variantsInserted++ else variantsReused++
                            resolved.single().id
                        }
                    }
                    if (!dao.hasRecommendationAttributes(variantId)) {
                        // Unknown is intentional: catalog identity does not prove feature support or performance.
                        dao.insertAttributes(listOf(RecommendationAttributesEntity(deviceVariantId = variantId)))
                    }

                    variant.sales.forEach saleLoop@ { sale ->
                        val channel = runCatching { SalesChannel.valueOf(sale.channel) }.getOrNull()
                        val availability = runCatching { AvailabilityStatus.valueOf(sale.availability) }.getOrNull()
                        if (channel == null || availability == null) {
                            conflicts += "${phone.model} ${variant.storageGb}GB: unsupported sales enum (${sale.channel}/${sale.availability})"
                            return@saleLoop
                        }

                        val existingSales = dao.getSalesVariantsByIdentity(variantId, channel, sale.modelNumber)
                        val salesVariantId = when {
                            existingSales.size > 1 -> {
                                conflicts += "${phone.model} ${variant.storageGb}GB ${sale.channel}: duplicate Room sales-variant identity"
                                return@saleLoop
                            }
                            existingSales.size == 1 && !existingSales.single().isActive -> {
                                conflicts += "${phone.model} ${variant.storageGb}GB ${sale.channel}: matching sales variant is inactive"
                                return@saleLoop
                            }
                            existingSales.size == 1 -> {
                                salesVariantsReused++
                                existingSales.single().id
                            }
                            else -> {
                                val inserted = dao.insertSalesVariants(listOf(SalesVariantEntity(
                                    deviceVariantId = variantId,
                                    salesChannel = channel,
                                    modelNumber = sale.modelNumber,
                                    simType = if (channel == SalesChannel.SIM_FREE) "SIMフリー" else null
                                ))).single()
                                val resolved = dao.getSalesVariantsByIdentity(variantId, channel, sale.modelNumber)
                                if (resolved.size != 1 || !resolved.single().isActive) {
                                    conflicts += "${phone.model} ${variant.storageGb}GB ${sale.channel}: sales variant could not be resolved uniquely"
                                    return@saleLoop
                                }
                                if (inserted >= 0L) salesVariantsInserted++ else salesVariantsReused++
                                resolved.single().id
                            }
                        }

                        val expectedRetailerType = when (channel) {
                            SalesChannel.SIM_FREE -> RetailerType.MANUFACTURER
                            SalesChannel.DOCOMO, SalesChannel.AU, SalesChannel.SOFTBANK, SalesChannel.RAKUTEN,
                            SalesChannel.UQ_MOBILE, SalesChannel.Y_MOBILE -> RetailerType.CARRIER
                            SalesChannel.IIJ_MIO, SalesChannel.MINEO, SalesChannel.MVNO -> RetailerType.MVNO
                            SalesChannel.OTHER -> RetailerType.OTHER
                        }
                        val retailers = dao.getRetailersByName(sale.retailer)
                        val retailerId = when {
                            retailers.size > 1 -> {
                                conflicts += "${phone.model} ${sale.channel}: duplicate Room retailer '${sale.retailer}'"
                                return@saleLoop
                            }
                            retailers.size == 1 && retailers.single().type != expectedRetailerType -> {
                                conflicts += "${phone.model} ${sale.channel}: retailer '${sale.retailer}' type mismatch (Room=${retailers.single().type}, source-derived=${expectedRetailerType}); preserved without reuse"
                                return@saleLoop
                            }
                            retailers.size == 1 -> {
                                retailersReused++
                                retailers.single().id
                            }
                            else -> {
                                // This is a conservative channel-derived classification, not proof of official status.
                                // URL presence does not prove that the retailer is official.
                                val inserted = dao.insertRetailers(listOf(RetailerEntity(
                                    name = sale.retailer,
                                    type = expectedRetailerType,
                                    official = false,
                                    websiteUrl = null
                                ))).single()
                                val resolved = dao.getRetailersByName(sale.retailer)
                                if (resolved.size != 1) {
                                    conflicts += "${phone.model} ${sale.channel}: retailer '${sale.retailer}' could not be resolved uniquely"
                                    return@saleLoop
                                }
                                if (inserted >= 0L) retailersInserted++ else retailersReused++
                                resolved.single().id
                            }
                        }

                        val url = sale.url?.trim()?.takeIf { it.isNotEmpty() }
                        if (url == null) {
                            listingsSkippedNoUrl++
                            return@saleLoop
                        }
                        val existingListings = dao.getProductListingsByIdentity(salesVariantId, retailerId)
                        var listingIdentitySafeForPrices = true
                        when {
                            existingListings.size > 1 -> {
                                conflicts += "${phone.model} ${sale.channel}: duplicate Room product-listing identity for '${sale.retailer}'"
                                return@saleLoop
                            }
                            existingListings.size == 1 -> {
                                val old = existingListings.single()
                                if (old.productUrl != url || old.availability != availability) {
                                    conflicts += "${phone.model} ${sale.channel}: existing listing differs for '${sale.retailer}'; preserved without overwrite; source price options skipped"
                                    listingIdentitySafeForPrices = false
                                }
                                listingsReused++
                            }
                            else -> {
                                val inserted = dao.insertProductListings(listOf(ProductListingEntity(
                                    salesVariantId = salesVariantId,
                                    retailerId = retailerId,
                                    productUrl = url,
                                    productName = "${phone.model} ${variant.storageGb}GB",
                                    availability = availability,
                                    checkedAt = System.currentTimeMillis()
                                ))).single()
                                val resolved = dao.getProductListingsByIdentity(salesVariantId, retailerId)
                                if (resolved.size != 1) {
                                    conflicts += "${phone.model} ${sale.channel}: new listing could not be resolved uniquely for '${sale.retailer}'"
                                    return@saleLoop
                                } else if (inserted >= 0L) {
                                    listingsInserted++
                                } else {
                                    listingsReused++
                                }
                            }
                        }

                        // Import every verified price option without collapsing color variants.
                        val listingId = if (listingIdentitySafeForPrices) dao.getProductListingId(salesVariantId, retailerId) else null
                        if (listingId == null) {
                            if (sale.priceOptions.isNotEmpty()) conflicts += "${phone.model} ${sale.channel}: price options skipped because listing identity is unresolved"
                        } else {
                            sale.priceOptions.forEach priceLoop@ { price ->
                                val type = runCatching { PriceType.valueOf(price.priceType) }.getOrNull()
                                if (type == null) {
                                    conflicts += "${phone.model} ${sale.channel}: unsupported price type ${price.priceType}; skipped"
                                    return@priceLoop
                                }
                                val checkedAt = runCatching {
                                    price.checkedAt?.let { LocalDate.parse(it).atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli() }
                                }.getOrNull()
                                if (checkedAt == null) {
                                    conflicts += "${phone.model} ${sale.channel}: price option for '${sale.retailer}' has no valid checkedAt date; price skipped"
                                    return@priceLoop
                                }
                                if (dao.hasPriceOption(listingId, type, price.color, checkedAt, price.priceYen)) return@priceLoop
                                dao.insertPriceRecordsV2(listOf(PriceRecordV2Entity(
                                    productListingId = listingId,
                                    priceType = type,
                                    priceYen = price.priceYen,
                                    conditions = price.conditions,
                                    checkedAt = checkedAt,
                                    color = price.color,
                                    sourceUrl = price.sourceUrl
                                )))
                            }
                        }
                    }
                }
            }
        }

        return Result(
            modelsInserted, modelsReused, variantsInserted, variantsReused, conflicts, skippedNonOfficial,
            salesVariantsInserted, salesVariantsReused, retailersInserted, retailersReused,
            listingsInserted, listingsReused, listingsSkippedNoUrl
        )
    }
}
