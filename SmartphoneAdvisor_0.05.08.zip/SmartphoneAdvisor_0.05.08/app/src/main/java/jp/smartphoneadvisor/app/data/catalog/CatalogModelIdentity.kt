package jp.smartphoneadvisor.app.data.catalog

import java.text.Normalizer
import java.util.Locale

/** Shared canonical identity for catalog preflight and JSON-to-Room import validation. */
object CatalogModelIdentity {
    /**
     * Normalize common manufacturer-prefix aliases ("Nothing Phone (4a)" vs "Phone (4a)").
     * Punctuation remains significant so models such as Galaxy S26 and S26+ stay distinct.
     * This creates a comparison key only; it never renames or merges records.
     */
    fun key(manufacturer: String, model: String, platform: String, releaseYear: Int): String {
        fun normalize(value: String): String = Normalizer.normalize(value, Normalizer.Form.NFKC)
            .lowercase(Locale.ROOT)
            .trim()
            .replace(Regex("\\s+"), " ")

        val normalizedManufacturer = normalize(manufacturer)
        var normalizedModel = normalize(model)
        if (normalizedManufacturer.isNotBlank() && normalizedModel.startsWith("$normalizedManufacturer ")) {
            normalizedModel = normalizedModel.removePrefix("$normalizedManufacturer ").trim()
        }
        return listOf(normalizedManufacturer, normalizedModel, normalize(platform), releaseYear.toString())
            .joinToString("|")
    }
}
