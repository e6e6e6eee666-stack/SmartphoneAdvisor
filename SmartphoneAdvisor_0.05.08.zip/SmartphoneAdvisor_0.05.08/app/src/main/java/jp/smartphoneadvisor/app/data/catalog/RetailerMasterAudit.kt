package jp.smartphoneadvisor.app.data.catalog

import jp.smartphoneadvisor.app.data.RetailerEntity

/** Read-only diagnostics for the existing retailer master; never changes or merges rows. */
object RetailerMasterAudit {
    data class Report(
        val totalRows: Int,
        val blankNames: Int,
        val duplicateNames: Map<String, Int>,
        val mixedTypes: Map<String, Set<String>>,
        val mixedOfficialFlags: Map<String, Set<Boolean>>,
        /** Distinct original spellings that collapse to the same trimmed, case-insensitive key. */
        val normalizedNameVariants: Map<String, Set<String>>,
        /** Multiple nonblank website URLs attached to rows sharing a normalized name. */
        val mixedWebsiteUrls: Map<String, Set<String>>,
        /** Nonblank website URLs that are not valid absolute HTTP(S) URLs with a host. */
        val invalidWebsiteUrls: Map<Long, String>,
        /** Nonblank URLs with leading or trailing whitespace, preserved for manual review. */
        val whitespaceWebsiteUrls: Map<Long, String>
    ) {
        val issueCount: Int
            get() = blankNames + duplicateNames.size + mixedTypes.size + mixedOfficialFlags.size +
                normalizedNameVariants.size + mixedWebsiteUrls.size + invalidWebsiteUrls.size + whitespaceWebsiteUrls.size
    }

    fun analyze(retailers: List<RetailerEntity>): Report {
        val duplicateNames = retailers.asSequence()
            .filter { it.name.isNotBlank() }
            .groupingBy { it.name }
            .eachCount()
            .filterValues { it > 1 }
            .toSortedMap()
        val mixedTypes = retailers.asSequence()
            .filter { it.name.isNotBlank() }
            .groupBy { it.name }
            .mapValues { (_, rows) -> rows.map { it.type.name }.toSet() }
            .filterValues { it.size > 1 }
            .toSortedMap()
        val mixedOfficialFlags = retailers.asSequence()
            .filter { it.name.isNotBlank() }
            .groupBy { it.name }
            .mapValues { (_, rows) -> rows.map { it.official }.toSet() }
            .filterValues { it.size > 1 }
            .toSortedMap()
        val normalizedNameVariants = retailers.asSequence()
            .filter { it.name.isNotBlank() }
            .groupBy { it.name.trim().lowercase(java.util.Locale.ROOT) }
            .mapValues { (_, rows) -> rows.map { it.name }.toSet() }
            .filterValues { it.size > 1 }
            .toSortedMap()
        val mixedWebsiteUrls = retailers.asSequence()
            .filter { it.name.isNotBlank() }
            .groupBy { it.name.trim().lowercase(java.util.Locale.ROOT) }
            .mapValues { (_, rows) -> rows.mapNotNull { it.websiteUrl?.trim()?.takeIf { it.isNotEmpty() } }.toSet() }
            .filterValues { it.size > 1 }
            .toSortedMap()
        val invalidWebsiteUrls = retailers.mapNotNull { retailer ->
            val raw = retailer.websiteUrl ?: return@mapNotNull null
            val trimmed = raw.trim()
            if (trimmed.isEmpty()) return@mapNotNull null
            val uri = runCatching { java.net.URI(trimmed) }.getOrNull()
            val valid = uri != null &&
                (uri.scheme.equals("https", ignoreCase = true) || uri.scheme.equals("http", ignoreCase = true)) &&
                !uri.host.isNullOrBlank()
            if (valid) null else retailer.id to raw
        }.toMap().toSortedMap()
        val whitespaceWebsiteUrls = retailers.mapNotNull { retailer ->
            val raw = retailer.websiteUrl ?: return@mapNotNull null
            if (raw.isNotEmpty() && raw != raw.trim()) retailer.id to raw else null
        }.toMap().toSortedMap()
        return Report(
            totalRows = retailers.size,
            blankNames = retailers.count { it.name.isBlank() },
            duplicateNames = duplicateNames,
            mixedTypes = mixedTypes,
            mixedOfficialFlags = mixedOfficialFlags,
            normalizedNameVariants = normalizedNameVariants,
            mixedWebsiteUrls = mixedWebsiteUrls,
            invalidWebsiteUrls = invalidWebsiteUrls,
            whitespaceWebsiteUrls = whitespaceWebsiteUrls
        )
    }
}
