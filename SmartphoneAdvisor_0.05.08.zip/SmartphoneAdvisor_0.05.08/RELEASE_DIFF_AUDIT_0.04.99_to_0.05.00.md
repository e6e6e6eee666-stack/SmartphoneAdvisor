# Release diff audit: 0.04.99 → 0.05.00

## Version
- `versionName=0.05.00`, `versionCode=148`.
- ZIP作成は区切り時まで保留（ユーザー指示）。

## Catalog changes
- Galaxy S26+: Samsung Japan official SIM-free sales registration for 256GB (¥192,130) and 512GB (¥219,100).
- Galaxy S26 Ultra: Samsung Japan official SIM-free sales registration for 256GB (¥239,800), 512GB (¥268,600), and 1TB (¥334,200).
- Existing Galaxy S26 256GB/512GB registrations and existing carrier sales registrations preserved.
- All listed prices are current official store normal prices incl. tax as checked 2026-10-21; trade-in, campaign discounts, and points excluded.

## Counts
| Metric | 0.04.99 | 0.05.00 |
|---|---:|---:|
| Models | 195 | 195 |
| Variants | 315 | 315 |
| Sales listings | 506 | 511 |
| Price options | 89 | 94 |
| Audit findings | 45 | 45 |

## Regression hygiene
- Updated live catalog count assertions to 511 sales / 94 prices.
- Fixed stale current-price expectation for Docomo iPhone 18 Pro 2TB and IIJmio Redmi Note 17 Pro Max 512GB SALE price; corrected a stale IIJmio source URL assertion to match catalog source evidence.
- Historical preservation tests remain independent and were rerun.

## Verification
- Python regression scripts: 68/68 passed across four batches; all failures from the initial pass were investigated, corrected where assertions were stale, and rerun.
- Python compileall and all three catalog audit generators passed.
- Catalog counts reconcile; all 94 price options have a source URL and checked date.
- Android build, Kotlin/JUnit execution, Room runtime import, emulator, and physical-device execution remain unverified.
