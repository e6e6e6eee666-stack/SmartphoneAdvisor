# SmartphoneAdvisor 0.04.75 作業記録

## 目的・完了条件
0.04.74以前の保存済み販売URLインベントリを比較し、過去に修正したデータが後続版で再び失われたり誤った販売先に戻ったりした履歴を特定し、将来の回帰テストに固定する。

## 実施内容
- `SALES_URL_INVENTORY_0.04.52.csv`〜`.74.csv` のうち保存されている14スナップショットを比較。
- iPhone 18 Pro 2TBのキャリア販売登録4件が0.04.57/0.04.59で消失し、0.04.60で復元された履歴を特定。
- Xiaomi REDMI Note 17 Pro Max 5G 256GB/512GBが0.04.61で公式SIMフリー登録に修正された後、0.04.62で根拠のないY!mobile・URLなし登録へ戻り、0.04.69で再修正された履歴を特定。
- Nothing Phone (4a)の二重機種識別が0.04.70〜0.04.72に並存し、0.04.73で統合された履歴を再確認。0.04.72のURL台帳が実JSONの2つ目のmodel_idを出力していなかった不整合も確認。
- `tools/test_historical_sales_regressions_0_04_75.py` を追加し、過去の回帰履歴と現行JSONの重要販売登録・価格保持を検査。
- `HISTORICAL_CATALOG_REGRESSION_AUDIT_0.04.75.md` と実ZIPから抽出した `tools/historical_catalog_facts_0_04_75.json` を追加。価格カバレッジ・販売根拠・URL台帳の生成器を現行版出力へ分離し、版数ガードを整合。

## 検証結果
- 過去版販売URL台帳の比較：完了（保存済みスナップショット14件）。
- 履歴回帰テスト：PASS。Python回帰テスト39/39を最終状態で確認。詳細は `test_results_0.04.75.txt` と `VALIDATION_0.04.75.txt`。
- Android Gradle/KSPビルド、Room実ランタイム取込、Android JUnit、エミュレーター・実機テストは未実施。

## 問題・未確認事項
- `.54`〜`.56`など一部版の個別URL台帳は保存されていない。
- 旧版の全 `phones.json` スナップショットがないため、全価格・全仕様・全販売登録の過去からの完全な消失監査はできない。
- 現行版の価格未登録販売登録448件は継続課題。未登録は0円や販売終了を意味しない。

## 進捗位置
大項目14「品質・監査」／中項目「過去版との回帰照合」／小項目「履歴回帰の特定・テスト固定」

## 証跡
- `HISTORICAL_CATALOG_REGRESSION_AUDIT_0.04.75.md`
- `tools/test_historical_sales_regressions_0_04_75.py`
- `SALES_URL_INVENTORY_0.04.52.csv` ほか保存済みインベントリ
