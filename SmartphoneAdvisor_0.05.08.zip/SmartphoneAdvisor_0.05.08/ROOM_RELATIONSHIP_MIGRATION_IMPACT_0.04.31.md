# Room参照関係・移行影響調査（0.04.31）

## 結論

**この版では外部キーを追加するデータベース移行を実装しない。** 現在のDBはversion 13で、端末内の既存データに参照切れがあるかは未測定である。既存データを検査せずに外部キーを追加すると、移行時に失敗したり、行の削除・再作成時に参照データを失うおそれがあるため、まず読み取り専用監査と移行設計を進める。

## 実ファイルから確認した現状

- `AppDatabase.kt`: Room schema versionは13。`MIGRATION_1_2`から`MIGRATION_12_13`までが登録済み。`MIGRATION_13_14`は未実装。
- `SalesVariantEntity.deviceVariantId` は `DeviceVariantEntity.id` を参照する想定だが、Roomの外部キー宣言はない。
- `ProductListingEntity.salesVariantId` と `retailerId` はそれぞれ販売バリアント・販売先を参照する想定だが、外部キー宣言はない。
- `PriceRecordV2Entity.productListingId` は商品掲載情報を参照する想定だが、外部キー宣言はない。
- `product_listing(salesVariantId, retailerId)` の一意インデックスはEntityとmigration 6→7の両方に存在する。
- `sales_variant(deviceVariantId, salesChannel, modelNumber)` の一意インデックスもEntityとmigration 6→7の両方に存在する。ただしSQLiteではUNIQUEインデックス内のNULLは互いに同値扱いされないため、`modelNumber IS NULL` の重複をこのインデックスだけでは防げない。
- `PhoneCatalogRoomImporter.kt` は空URLの掲載情報を登録せず、既存掲載情報が異なる場合も自動上書きせず、同一ID候補が複数なら競合として扱う。
- JSONカタログの静的集計は196機種、314バリアント、販売登録477件、URL空欄2件。これはソースJSONの件数であり、Room内の実件数・参照切れ件数ではない。

## 対象関係と移行前に必要な確認

| 子テーブル | 参照列 | 親テーブル | 移行前の確認 |
|---|---|---|---|
| `sales_variant` | `deviceVariantId` | `device_variant.id` | 存在しない親IDの件数とID一覧 |
| `product_listing` | `salesVariantId` | `sales_variant.id` | 存在しない親IDの件数とID一覧 |
| `product_listing` | `retailerId` | `retailer.id` | 存在しない親IDの件数とID一覧 |
| `price_record_v2` | `productListingId` | `product_listing.id` | 存在しない親IDの件数とID一覧 |

## 安全な次の手順

1. 0.04.30以降の読み取り専用監査を使い、実端末DBの参照切れ・重複を記録する。現段階で実端末DBの結果はない。
2. 問題行を親子のIDと件数で出力し、データ元・登録経路を特定する。自動削除、統合、ID付け替えはしない。
3. 参照切れが0件であることを確認できたテストDBに対して、外部キー付きテーブルの再作成案を試す。`product_listing`には2本、`price_record_v2`には1本の外部キーが必要で、既存インデックスと全列を維持する。
4. `sales_variant`のNULL `modelNumber`重複対策は、単純な一意インデックス追加だけでは不十分。アプリ側の同一性判定・移行前監査を維持し、データ形式を変える場合は別途移行設計する。
5. schema exportが無効（`exportSchema = false`）のため、テスト可能なmigration fixture / schema検証方法も整える。
6. migration 13→14を実装するのは、上記の事前監査とデータ保持テストが通った後に限定する。

## 検証範囲と限界

`tools/audit_migration_impact_0_04_31.py` はソースコード・JSONの静的整合性を確認する。実端末内DBのデータを読み取るものではない。Android Gradle/KSPビルド、Room migration実行、端末テストは別途必要。
