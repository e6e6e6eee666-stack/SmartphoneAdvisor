# Work log 0.05.03 — IIJmio / au existing sales price options

## Purpose
Add five source-qualified normal price options to existing sales entries without creating duplicate sales registrations.

## Changes
- `Samsung:Galaxy S26:2026`, 256GB, `IIJ_MIO`: ¥136,400; IIJmio official announcement.
- `Samsung:Galaxy S26+:2026`, 256GB, `IIJ_MIO`: ¥169,920; IIJmio official announcement.
- `Samsung:Galaxy S26 Ultra:2026`, 256GB, `IIJ_MIO`: ¥218,900; IIJmio official product page.
- `Sony:Xperia 1 VIII:2026`, 256GB, `AU`: ¥269,800; user-provided au Online Shop screenshot. Independent re-retrieval remains incomplete and is explicitly recorded in `conditions`.
- `Sony:Xperia 10 VIII:2026`, 128GB, `AU`: ¥98,800; user-provided au Online Shop screenshot. Independent re-retrieval remains incomplete and is explicitly recorded in `conditions`.
- Reused all five existing sales entries; no sales registrations were added.
- Updated catalog counts from 95 to 100 price options. Models 195, variants 315, sales listings 511, audit findings 45 remain unchanged.
- Updated Gradle versionName to 0.05.03 and versionCode to 151 because runtime catalog data changed.
- Regenerated the price-gap audit. Unpriced sales rows decreased from 434 to 429; available but unpriced decreased from 389 to 385.

## Verification
- JSON parse: PASS.
- Catalog declared counts vs actual contents: PASS (195 / 315 / 511 / 100 / 45).
- Targeted five-row provenance regression: added for this version; PASS (dedicated five-row test).
- Price-gap audit generator: PASS.
- Initial regression run found three stale expectations for the price-gap count (434 rather than the current 429). The current JSON and regenerated audit reports were independently reconciled: 511 sales registrations, 82 registrations with at least one price option, 429 registrations without price options, and 100 nested price options.
- Updated only stale regression expectations: `test_price_gap_followup_0_04_89.py` now checks current follow-up counts (429 gaps, 354 missing model numbers, 315 available rows missing model numbers, 7 generic URLs); `test_sales_fact_completeness_0_04_55.py` expects the generated report to state 429 unpriced registrations. `test_sales_fact_completeness_0_04_54.py` is a wrapper and needed no change.
- Regenerated price-gap audit, follow-up audit, and sales-fact completeness report from the current JSON. All report counts reconcile with the JSON and its SHA-256.
- Re-ran all 63 Python regression tests in 13 batches of five (last batch three): **63 PASS / 0 FAIL / 0 timeouts**. Merged evidence is `test_results_0.05.03.txt`; individual batch reports are `test_results_0.05.03_batch_1.txt` through `test_results_0.05.03_batch_13.txt`.
- `python3 -m compileall -q tools`: PASS. Android Gradle build, Kotlin/JUnit runtime, Room runtime import, emulator and physical-device testing: NOT RUN.
- Android Gradle build, Kotlin/JUnit, Room runtime import, emulator and physical-device testing: NOT RUN.
