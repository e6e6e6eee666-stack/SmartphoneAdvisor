# SmartphoneAdvisor マスタープラン更新 0.04.86

## 今回の進捗
品質・監査工程の次の停止要因は、ソースの静的検査から先へ進むためのAndroid実ビルド環境がないこと。0.04.86では、Android Studioの英語UIを前提に、プロジェクトを開く位置、SDK要件、Gradle同期、ビルド、Room smoke test、主要画面の実操作と証跡の残し方を日本語で明文化した。

## 守るべき検証区分
- Pythonソース契約テスト合格 ≠ Kotlinコンパイル成功。
- ZIP整合性合格 ≠ Androidアプリがビルド可能。
- APK生成 ≠ Room登録や画面操作が正常。
- `AppDatabaseSmokeTest.kt` の存在 ≠ Android上でテスト実行済み。
- 価格や販売情報は公式根拠を確認し、未確認を推測で埋めない。

## 次工程の順序
1. Gradle WrapperをAGP/Kotlin/KSPに適合する公式Gradle版で再現可能に追加。
2. Android Gradle/KSPビルドとKotlin/JUnitを実行。
3. `AppDatabaseSmokeTest` およびJSON→Room取込、重複、価格根拠、migrationを実DBで検証。
4. 1台診断、検索、詳細、比較、お気に入り、保存診断を実機/エミュレーターで検証。
5. その後、価格未登録の販売登録を公式根拠付きで補完。

## 現在の制約
現環境ではGradle Wrapper、Gradle本体、Android SDKが利用できず、Androidビルド・ランタイム試験は未実施。詳細手順は `ANDROID_STUDIO_BUILD_GUIDE_0.04.86.md`。


## 0.04.86 追加項目：Wrapper生成手段の整備
- 公式Gradle 9.6.0配布物をSHA-256検証してからWrapperを生成するWindowsスクリプトを追加。
- Android Studioでの実ビルドは未実施。Wrapper生成、Gradle同期、Kotlin/Roomテスト、実機操作を次の検証ゲートとする。
