# SmartphoneAdvisor 0.05.07 — Kotlin compile-error follow-up

## Changes
- Carried forward the fixes already present in 0.05.06 for the compiler errors reported from 0.05.05:
  - safely handle nullable `purchaseChannel` with `orEmpty()` before `toSalesChannelDbValue()`;
  - use `takeIf { it.isNotBlank() }` for nullable optional `UserRequirement` strings;
  - import `kotlinx.coroutines.launch` for coroutine calls.
- Updated Android app metadata to versionName `0.05.07` and versionCode `155`.
- Updated version-specific Python regression guards for this release.

## Validation
- ZIP integrity: checked after packaging.
- Python regression suite: 71/71 tests passed, run in six batches.
- Gradle/Kotlin Android build: NOT verified in this environment. The latest inspected GitHub Actions run (2026-10-28, run 40661405210) still extracted `SmartphoneAdvisor_0.05.05_Gradle9.8.1-compatibility.zip`; it therefore did not compile this 0.05.07 source.
