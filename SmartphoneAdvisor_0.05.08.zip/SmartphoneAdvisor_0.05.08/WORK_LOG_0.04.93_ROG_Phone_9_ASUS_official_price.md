# Work log — 0.04.93 ASUS ROG Phone 9 official price

- Date: 2026-10-21
- Change: added the ASUS Japan official listed price of ¥159,800 (tax included) for ROG Phone 9 12GB/256GB. Official page lists both ROG9-BK12R256 (Phantom Black) and ROG9-WH12R256 (Storm White) at the same price.
- Evidence: https://rog.asus.com/jp/phones/rog-phone-9/ (ASUS Japan official product page).
- Conditions: standard total price; no campaign, points, or carrier trade-in terms included.
- Catalog totals: 195 models, 314 variants, 501 sales listings, 80 price options, 45 audit findings.
- Version: versionName 0.04.93, versionCode 141.
- Automated verification: current regression suite run is recorded in test_results_0.04.93.txt.
- Not verified: Android Gradle build, Kotlin/JUnit, Room runtime, emulator, and physical-device operation.
