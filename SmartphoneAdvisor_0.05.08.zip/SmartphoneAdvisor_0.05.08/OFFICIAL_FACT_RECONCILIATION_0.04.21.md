# Official fact reconciliation — 0.04.21

## Confirmed changes

1. iPhone 17e seed model-year corrected from 2025 to 2026 (8 carrier records). Apple Japan announced the model on 2026-03-02 and lists 256GB/512GB: https://www.apple.com/jp/newsroom/2026/03/apple-introduces-iphone-17e/
2. motorola razr 60 ultra catalog releaseYear corrected from 2026 to 2025. Motorola Japan announced sale on 2025-12-12: https://store.motorola.co.jp/topics_detail.html?info_id=1115
3. AQUOS R9 pro seed model-year normalized to 2024. NTT Docomo lists 2024-12-05 release and Sharp lists RAM 12GB/ROM 512GB: https://www.docomo.ne.jp/support/product/sh54e/spec.html ; https://www.sharp.co.jp/k-tai/products/aquos-r9-pro/specs/
4. Xperia 10 VI catalog RAM corrected from 8GB to 6GB. Sony Japan official specification lists RAM/ROM 6GB/128GB: https://exclusive-origin.sony.jp/xperia/xperia/xperia10m6/spec.html
5. iPhone 17 Pro Max 2TB variant added after Apple Japan's official buy page showed 2TB: https://www.apple.com/jp/shop/buy-iphone/iphone-17-pro/6.9%E3%82%A4%E3%83%B3%E3%83%81%E3%83%87%E3%82%A3%E3%82%B9%E3%83%97%E3%83%AC%E3%82%A4-2tb-%E3%82%B7%E3%83%AB%E3%83%90%E3%83%BC-%E3%83%89%E3%82%B3%E3%83%A2 . Because carrier-specific 2TB stock/offer was not independently proven for every channel, all five channel listings remain `UNKNOWN`, not `AVAILABLE`.

## Limitations

Official pages were checked for model-level year/storage/RAM facts. This does not verify live inventory, exact carrier-specific SKU availability, prices, Gradle build, Room integration, or device runtime.
