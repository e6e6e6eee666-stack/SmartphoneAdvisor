# Release diff audit: 0.04.94 → 0.04.95

Date: 2026-10-21

## Version
- Previous: versionName 0.04.94 / versionCode 142
- Current: versionName 0.04.95 / versionCode 143

## Product/catalog changes
- Added Zenfone 12 Ultra 16GB RAM / 512GB storage as a distinct variant.
- Added ASUS Store Japan sales registration for the 512GB variant.
- Recorded the source-backed normal price JPY 169,800 (tax included), checked 2026-10-21.
- The source also displays a time-limited special price JPY 152,820; it is explicitly described in conditions but is not stored as the NORMAL price.
- Existing 12GB/256GB variant and JPY 149,800 normal price remain unchanged.

## Counts
| Metric | 0.04.94 | 0.04.95 |
|---|---:|---:|
| Models | 195 | 195 |
| Variants | 314 | 315 |
| Sales registrations | 501 | 502 |
| Price options | 81 | 82 |
| Unpriced sales registrations | 438 | 438 |
| AVAILABLE without price | 393 | 393 |
| Audit findings | 45 | 45 |

The price-gap totals remain unchanged because the newly added sales registration has a price option.

## Tests and audit artifacts
- Added `tools/test_zenfone12ultra_512gb_official_price_0_04_95.py` and registered it in `tools/current_regression_manifest.json`.
- Updated current-catalog assertions that pinned 314 variants, 501 sales registrations, or 81 price options.
- Regenerated `CATALOG_PRICE_GAP_AUDIT_2026-10-20.csv/.md` and `CATALOG_PRICE_GAP_FOLLOWUP_2026-10-20.csv/.md` from the current JSON.
- Current regression suite: 58/58 PASS, 0 failures, across five batches.
- Python `compileall`: PASS.
- Catalog count reconciliation: PASS.

## Source
- ASUS Store Rakuten official shop listing: https://www.rakuten.ne.jp/gold/asus-store/sale/2510CP2/
- ASUS Japan Zenfone 12 Ultra product page: https://www.asus.com/jp/mobile-handhelds/phones/zenfone/zenfone-12-ultra/

## Not verified
Android Gradle build, Kotlin/JUnit execution, Room runtime import, emulator launch, and physical-device interaction remain unverified in this environment. Python source-contract tests do not substitute for those checks.
