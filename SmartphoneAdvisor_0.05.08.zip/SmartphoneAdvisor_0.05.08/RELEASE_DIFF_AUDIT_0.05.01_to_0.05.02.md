# リリース差分監査 0.05.01 → 0.05.02

## 版
- 比較基準ZIP：`SmartphoneAdvisor_0.05.01_現時点ソース一式.zip`（SHA-256 `e056b138c70b0b513d11f61705aa0a64199b2dcc29d2e8756aa1cb80e58b7c6c`）
- 前版：`versionName=0.05.01` / `versionCode=149`
- 今版：`versionName=0.05.02` / `versionCode=150`
- 版更新理由：前回の比較画面整理ZIPに `MainActivity.kt` のアプリコード変更が含まれていたにもかかわらず、アプリ版が据え置かれていたため。今回、採番ルールを適用して是正。

## 変更内容
- `MainActivity.kt`：比較画面の表示値生成ロジックを共通化し、通常表示・条件優先表示・差分フィルターで同じ関数を利用。
- `phones.json`：`auditFindings` 内の旧 `price_yen` フィールド27件を除去。監査指摘45件、機種195、バリアント315、販売登録511、価格選択肢95の宣言件数は維持。レコード自体は削除していない。
- `tools/convert_carrier_seed_to_phones_json.py`：変換時に旧 `price_yen` フィールドを再生成しないよう修正。
- `tools/test_comparison_row_value_single_source.py`：表示値生成の単一実装を維持する回帰テストを追加。
- `AUDIT_FINDINGS_SCHEMA_NOTES_2026-10-21.md`、`tools/test_audit_findings_action_distribution.py`、`WORK_LOG_2026-10-21_auditFindings-status-audit.md`：監査指摘の混在形式を文書化し、action内訳を固定検査。
- `tools/test_audit_findings_legacy_price_yen.py` と既存変換/JSONの価格監査整理：旧 `price_yen` の扱いを回帰検査。
- `PROJECT_MASTER_PLAN_CURRENT.md`、`README.md`、作業ログ、VER-01監査書を更新。
- モデル・バリアント・販売登録・価格選択肢は追加/削除していない。監査指摘内の旧フィールドのみ除去し、表示ロジックを修正。

## 検証
- ZIP内ファイルの比較で、前回 `0.05.01_comparison-row-formatting.zip` から `MainActivity.kt` の変更を確認。
- 現行登録Python回帰スイート：62/62 PASS、6バッチ。結果は `test_results_0.05.02.txt` に記録。
- 追加個別回帰テスト（比較画面、auditFindings、旧 `price_yen`、JSON件数、MIVE価格）：すべてPASS。
- `python -m compileall -q tools`：PASS。
- ZIP CRC、内部アプリ版 `0.05.02/150`、JSON宣言件数：PASS。
- Android Gradleビルド、Kotlin/JUnit、Room実取込、CI、エミュレータ、実機は未検証。
