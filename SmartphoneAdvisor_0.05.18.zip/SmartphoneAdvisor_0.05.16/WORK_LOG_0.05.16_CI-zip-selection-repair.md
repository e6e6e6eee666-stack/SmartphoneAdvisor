# WORK_LOG_0.05.16 — CI ZIP選択と版整合性修正

## 目的
CIが重複識別子付きZIPを見落とす問題を修正し、ZIP名と内部アプリ版の不一致を早期に検出する。

## 修正内容
- `.github/workflows/android-validation.yml` の候補選択正規表現を拡張し、`SmartphoneAdvisor_X.Y.Z.zip` に加え `SmartphoneAdvisor_X.Y.Z(1).zip`、suffix付きZIP名を許容。
- ZIPファイル名からアプリ版を抽出し、展開した `app/build.gradle.kts` の `versionName` と一致しない場合はCIを停止する検査を追加。
- `tools/test_android_validation_workflow.py` に構造チェックと許可/拒否ZIP名のケースを追加。
- `PROJECT_MASTER_PLAN_CURRENT.md` のG1状態をGitHub Run #66の実証に合わせて更新し、G2の現状と今回の検証限界を記録。

## 検証
- workflow構造/suffix検査: PASS
- Python compileall: PASS
- G2関連検査8件: PASS（SQLite/静的検査。Android Room実機実行ではない）
- 回帰batch 1/12 (6 tests): PASS 6/6
- 71件一括再実行: 外側実行時間上限により31件出力時点で中断。今回の再実行全体をPASSとは扱わない。
- Gradle build/JVM/Android instrumented test: 今回未実施。Run #66の過去成功記録は別証跡として参照。

## アプリ版
アプリ本体、実行時データ、アプリビルド設定は変更していないため `0.05.16 / 164` を維持。配布ZIPの重複識別子 `(2)` はアプリ版とは別のファイル識別子。

## 次工程
Android実Roomでの取込・再取込・移行・異常系の実証に進み、G2完了条件を満たす証跡を追加する。
