# Work log — ZIP 0.05.18 CI package-numbering repair

## Purpose / completion criteria
- Separate ZIP package numbering from the Android app's `versionName` / `versionCode`.
- Make the ZIP-internal workflow reject ambiguous duplicate ZIP package numbers, matching the repository-root workflow's selection guard.
- Add regression coverage and rerun the maintained Python suite.

## Baseline
- Input artifact: `SmartphoneAdvisor_0.05.17.zip` (its contents were byte-identical to the preceding 0.05.16(2) archive).
- App version remains `0.05.16`, versionCode `164`.
- Catalog baseline remains 195 models / 315 variants / 511 sales / 100 priceOptions / 45 audit findings.

## Changes
- `.github/workflows/android-validation.yml`: renamed the extracted filename version to `ZIP_PACKAGE_VERSION`; added a guard requiring exactly one ZIP for the highest package number; removed the invalid equality check between ZIP filename number and app `versionName`; logs now distinguish package number and app version.
- `tools/test_android_validation_workflow.py`: verifies suffix handling, independent package/app numbering, and duplicate package guard.
- App source, catalog data, Gradle configuration, `versionName`, and `versionCode` were not changed.

## Verification
- `tools/test_android_validation_workflow.py`: PASS.
- `python3 -m compileall -q tools`: PASS.
- Maintained Python regression suite: 71/71 PASS, 0 FAIL, run in 12 batches (batch sizes 6 except final batch 5). Merged report: `test_results_0.05.16.txt`.
- ZIP CRC and SHA-256 are checked after packaging (see artifact record in final response).

## Limitations / unresolved
- GitHub root workflow was fetched and reviewed. It currently uses manual SDK installation (`platforms;android-37.0`) and a richer diagnostics/upload flow, while the ZIP workflow uses `android-actions/setup-android@v3` and `platforms;android-37`. These are not yet unified.
- Attempt to update `.github/workflows/android-validation.yml` on GitHub was rejected with HTTP 403 `Resource not accessible by integration`. No GitHub commit was made. The local ZIP contains the corrected workflow only.
- No GitHub Actions run, Gradle build, JVM/JUnit run, emulator test, Android Room runtime test, or real-device test was performed in this checkpoint.

## Current status
- ZIP workflow's package/app version-numbering defect is fixed and locally regression-tested.
- G1 remains not passed: repository-root and ZIP workflows still need a permission-enabled reconciliation and a fresh CI run.
