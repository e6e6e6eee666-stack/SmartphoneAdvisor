# SmartphoneAdvisor 0.05.09

## 修正内容
- アプリのバージョンを `0.05.09`、versionCode を `157` に更新。
- `test_budget_reason_amounts_0_05_04.py` が過去バージョン `0.05.07 / 155` を固定チェックしていたため、予算理由の検証と無関係なバージョン条件を削除。予算理由に金額が含まれること、未確認価格の注意文、JUnit側の回帰ケースは引き続き検証する。
- `test_mainactivity_compile_regressions_0_05_07.py` からも旧バージョン固定条件を削除。MainActivity.kt のコンパイル修正に関する文字列チェックは維持。

## 検証範囲
- Python静的回帰テストを実行して確認する。
- Android Gradleビルド、Kotlin/JUnit実行、実機動作はこの作業では実施していない。
