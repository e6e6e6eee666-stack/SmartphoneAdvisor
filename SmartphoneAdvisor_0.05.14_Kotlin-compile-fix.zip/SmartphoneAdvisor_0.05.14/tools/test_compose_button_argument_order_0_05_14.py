#!/usr/bin/env python3
"""Guard against positional arguments following named arguments in Compose buttons."""
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]
SOURCE_ROOT = ROOT / "app/src/main/java"
BUTTON_CALL = re.compile(r"\b(?:Button|OutlinedButton)\s*\(")


def split_top_level_arguments(source: str) -> list[str]:
    args = []
    start = 0
    stack = []
    quote = None
    escaped = False
    line_comment = False
    block_comment = 0
    i = 0
    while i < len(source):
        char = source[i]
        nxt = source[i + 1] if i + 1 < len(source) else ""
        if line_comment:
            if char == "\n":
                line_comment = False
        elif block_comment:
            if char == "/" and nxt == "*":
                block_comment += 1
                i += 1
            elif char == "*" and nxt == "/":
                block_comment -= 1
                i += 1
        elif quote:
            if escaped:
                escaped = False
            elif char == "\\":
                escaped = True
            elif char == quote:
                quote = None
        elif char == "/" and nxt == "/":
            line_comment = True
            i += 1
        elif char == "/" and nxt == "*":
            block_comment = 1
            i += 1
        elif char in ('"', "'"):
            quote = char
        elif char in "([{":
            stack.append(char)
        elif char in ")]}":
            if stack:
                stack.pop()
        elif char == "," and not stack:
            args.append(source[start:i].strip())
            start = i + 1
        i += 1
    if source[start:].strip():
        args.append(source[start:].strip())
    return args


def extract_call_arguments(text: str, open_paren: int):
    depth = 1
    quote = None
    escaped = False
    line_comment = False
    block_comment = 0
    i = open_paren + 1
    while i < len(text) and depth:
        char = text[i]
        nxt = text[i + 1] if i + 1 < len(text) else ""
        if line_comment:
            if char == "\n":
                line_comment = False
        elif block_comment:
            if char == "/" and nxt == "*":
                block_comment += 1
                i += 1
            elif char == "*" and nxt == "/":
                block_comment -= 1
                i += 1
        elif quote:
            if escaped:
                escaped = False
            elif char == "\\":
                escaped = True
            elif char == quote:
                quote = None
        elif char == "/" and nxt == "/":
            line_comment = True
            i += 1
        elif char == "/" and nxt == "*":
            block_comment = 1
            i += 1
        elif char in ('"', "'"):
            quote = char
        elif char == "(":
            depth += 1
        elif char == ")":
            depth -= 1
        i += 1
    if depth:
        return None
    return text[open_paren + 1:i - 1]


errors = []
for path in SOURCE_ROOT.rglob("*.kt"):
    text = path.read_text(encoding="utf-8")
    for match in BUTTON_CALL.finditer(text):
        args_source = extract_call_arguments(text, match.end() - 1)
        if args_source is None:
            errors.append(f"{path}: unclosed Button call")
            continue
        args = split_top_level_arguments(args_source)
        named_seen = False
        for arg in args:
            is_named = bool(re.match(r"[A-Za-z_][A-Za-z0-9_]*\s*=", arg))
            if named_seen and not is_named:
                line = text.count("\n", 0, match.start()) + 1
                errors.append(
                    f"{path}:{line}: positional argument after named argument: {arg[:100]}"
                )
            if is_named:
                named_seen = True

if errors:
    print("FAIL: invalid Button/OutlinedButton argument ordering detected")
    print("\n".join(errors))
    raise SystemExit(1)

print("PASS: all Button/OutlinedButton calls use consistent named/positional argument ordering")
