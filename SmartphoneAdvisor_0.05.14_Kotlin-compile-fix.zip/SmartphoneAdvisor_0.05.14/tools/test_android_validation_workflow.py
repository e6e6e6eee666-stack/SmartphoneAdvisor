"""Structural guard for the repository-root ZIP-driven Android CI workflow; not proof CI ran."""
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
workflow = (ROOT / ".github/workflows/android-validation.yml").read_text(encoding="utf-8")
root_build = (ROOT / "build.gradle.kts").read_text(encoding="utf-8")
app_build = (ROOT / "app/build.gradle.kts").read_text(encoding="utf-8")
required = [
    "actions/checkout@v4",
    "actions/setup-java@v4",
    "java-version: '17'",
    "gradle/actions/setup-gradle@v4",
    "gradle-version: '9.8.1'",
    "android-actions/setup-android@v3",
    '"platforms;android-37"',
    '"platforms;android-36"',
    '"platforms;android-35"',
    '"build-tools;36.0.0"',
    'sort -V | tail -n 1',
    'SmartphoneAdvisor_[0-9]+\\.[0-9]+\\.[0-9]+\\.zip',
    'APP_VERSION=$APP_VERSION',
    "Extract source ZIP",
    "ANDROID_PROJECT_DIR=$PROJECT_ROOT",
    "tools/run_current_regression_suite.py",
    "assembleDebug testDebugUnitTest",
    "reactivecircus/android-emulator-runner@v2",
    "api-level: 35",
    "connectedDebugAndroidTest",
    "actions/upload-artifact@v4",
    "SmartphoneAdvisor-debug-apk",
    "test_results_${{ env.APP_VERSION }}.txt",
]
missing = [item for item in required if item not in workflow]
assert not missing, f"Missing Android CI workflow requirements: {missing}"
assert "if: success()" in workflow and "if: always()" in workflow
assert "build-tools;37.0.0" not in workflow, "Avoid requesting unverified build-tools 37.0.0"

agp = re.search(r'id\("com\.android\.application"\) version "([0-9.]+)"', root_build)
compile_sdk = re.search(r"compileSdk\s*=\s*(\d+)", app_build)
min_sdk = re.search(r"minSdk\s*=\s*(\d+)", app_build)
target_sdk = re.search(r"targetSdk\s*=\s*(\d+)", app_build)
gradle = re.search(r"gradle-version:\s*'([0-9.]+)'", workflow)
java = re.search(r"java-version:\s*'([0-9]+)'", workflow)
assert all((agp, compile_sdk, min_sdk, target_sdk, gradle, java)), "Could not parse build/CI compatibility values"
assert agp.group(1) == "9.4.0", f"Review Gradle compatibility table for AGP {agp.group(1)}"
assert tuple(map(int, gradle.group(1).split("."))) >= (9, 6, 0), f"AGP 9.4.0 requires Gradle 9.6.0 or newer; found {gradle.group(1)}"
assert int(java.group(1)) == 17, f"AGP 9.4.0 requires JDK 17; found {java.group(1)}"
assert f'"platforms;android-{compile_sdk.group(1)}"' in workflow, "CI must install the app compileSdk platform"
assert int(re.search(r"api-level:\s*(\d+)", workflow).group(1)) >= int(min_sdk.group(1)), "Emulator API must be >= minSdk"
assert int(target_sdk.group(1)) <= int(compile_sdk.group(1)), "targetSdk cannot exceed compileSdk"
print(f"PASS: ZIP-driven CI workflow structure (latest versioned source ZIP; AGP {agp.group(1)}, Gradle {gradle.group(1)}, JDK {java.group(1)}, compileSdk {compile_sdk.group(1)}, minSdk {min_sdk.group(1)}, targetSdk {target_sdk.group(1)}). Workflow execution remains unverified.")
