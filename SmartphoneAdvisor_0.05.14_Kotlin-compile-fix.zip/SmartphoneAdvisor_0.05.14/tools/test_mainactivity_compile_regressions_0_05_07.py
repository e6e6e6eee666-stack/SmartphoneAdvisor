#!/usr/bin/env python3
"""Regression guards for MainActivity.kt compile fixes carried into 0.05.08."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE = (ROOT / "app/src/main/java/jp/smartphoneadvisor/app/MainActivity.kt").read_text(encoding="utf-8")
errors = []

required = [
    "import kotlinx.coroutines.launch",
    'purchaseChannel.orEmpty().toSalesChannelDbValue()',
    'gameType = gameType?.takeIf { primaryUse == PrimaryUse.GAMING && it.isNotBlank() },',
    'cameraSubject = cameraSubject?.takeIf { primaryUse == PrimaryUse.CAMERA && it.isNotBlank() },',
    'useDetail = useDetail?.takeIf { (primaryUse == PrimaryUse.VIDEO || primaryUse == PrimaryUse.SNS || primaryUse == PrimaryUse.WORK || primaryUse == PrimaryUse.AI || primaryUse == PrimaryUse.VIDEO_EDITING) && it.isNotBlank() },',
    'selected = mustHave.toSet(),',
    'OutlinedCard(onClick = onResumeDraft, modifier = Modifier.fillMaxWidth()) {',
    'OutlinedCard(onClick = onBrowse, modifier = Modifier.fillMaxWidth()) {',
]
for item in required:
    if item not in SOURCE:
        errors.append(f"MainActivity.kt missing expected compile fix: {item}")
if ".ifBlank { null }" in SOURCE:
    errors.append("String.ifBlank { null } remains; ifBlank requires a non-null CharSequence result")

if errors:
    print("\n".join("FAIL: " + error for error in errors))
    raise SystemExit(1)
print("PASS: MainActivity.kt compile-regression guards")
