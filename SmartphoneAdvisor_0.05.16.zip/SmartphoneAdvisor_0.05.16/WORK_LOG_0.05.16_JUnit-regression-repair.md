# WORK_LOG_0.05.15 — JVM単体テスト失敗修正

## 目的・完了条件
GitHub Actions #56 で失敗したJUnit 7件の原因を修正し、既存の予算ハード制約とカタログ仕様を維持する。

## 実施内容
1. `app/build.gradle.kts` の `testImplementation` に `org.json:json:20260814` を追加。Android標準 `org.json` のJVMテスト用スタブを避けるためのテスト専用依存関係であり、アプリ実行時依存には追加していない。
2. `SinglePhoneDiagnosticEngineTest.kt` の価格未確認テストを、絶対上限なし・希望予算のみの条件へ修正。期待警告は希望予算のみとした。
3. 価格未確認または価格鮮度切れの機種が絶対上限を通過できない既存テストは維持。
4. `test_budget_reason_amounts_0_05_04.py` の静的検査期待値を更新し、絶対上限のハードフィルターを確認するテスト名と `assertNull` の存在も検査対象に追加。

## 検証結果
- Python回帰スイート：71/71 PASS（6バッチで全件を今回実行）
- 予算関連の個別静的検査：PASS
- ZIP CRC：作成時に検証予定
- Kotlin/JUnit、Gradle assemble、Android instrumented test：未実施。作業環境にGradle/Android SDKがなく、基準ZIPにもGradle Wrapperが含まれていないため。

## アプリ版・採番
- `versionName=0.05.15`、`versionCode=163` を維持。今回の変更はテスト専用コードとテスト専用依存関係に限定され、アプリ本体・実行時データ・アプリビルド設定の変更ではないため。
- ZIP名はアプリ版と一致させる。工程番号・テスト修正番号をアプリ版に流用しない。

## 変更ファイル
- `app/build.gradle.kts`
- `app/src/test/java/jp/smartphoneadvisor/app/domain/SinglePhoneDiagnosticEngineTest.kt`
- `tools/test_budget_reason_amounts_0_05_04.py`
- `test_results_0.05.15.txt` および6バッチ分の結果
- 本作業ログ
